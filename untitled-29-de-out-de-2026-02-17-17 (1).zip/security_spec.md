# Security Specification for KORDEL

## 1. Data Invariants

- **User Identity & Balances**: A user can never modify their own `role`, `kards`, `xp`, `level`, `progressionCycle`, `hasExperiencedReaderBadge`, `isVerifiedWriter`, or `isBanned`. Balances and status flags are strictly managed by server logic or Developer administration.
- **Bootstrapped Administrator**: Developer access is permitted for `timaosemlimite001@gmail.com` (when authenticated and verified) or documents in `/admins/{userId}`.
- **Authorship of Books & Chapters**: A book or chapter can only be created or modified if `authorId == request.auth.uid` or by admin.
- **Kard Transactions**: Transactions in `/transactions` cannot be modified or deleted. Only system/admin or authorized purchase settlement can create completed transactions.
- **Community Scoping**: A post in `/communities/{communityId}/posts/{postId}` must have its `communityId` match the parent collection path and `authorId == request.auth.uid`.
- **Beta Applications**: A beta application can only be created by the candidate reader (`readerId == request.auth.uid`), and status updates (approved/rejected) are only permitted by the author of the book or the developer.
- **Reports**: Any authenticated user can submit a report. Only admins can resolve or dismiss reports.

## 2. The Dirty Dozen Payloads (Security Tests)

1. **Self-Promotion to Developer**: Attacker attempts to write `{ role: "desenvolvedor" }` to their `/users/{uid}` profile. (Must be rejected).
2. **Kard Balance Forgery**: Attacker attempts to update `{ kards: 99999 }` directly via Firestore client. (Must be rejected).
3. **Ghost Book Authoring**: Attacker writes a book setting `authorId: "victim_uid"`. (Must be rejected).
4. **Unauthenticated Chapter Injection**: Unauthenticated user attempts to write a chapter in a published book. (Must be rejected).
5. **Cross-Community Post Injection**: Attacker tries to create a post in community A with `communityId: "community_B"`. (Must be rejected).
6. **Self-Granting Verified Writer Badge**: Attacker updates `{ isVerifiedWriter: true }`. (Must be rejected).
7. **Self-Granting Experienced Reader Badge**: Attacker updates `{ hasExperiencedReaderBadge: true }`. (Must be rejected).
8. **Bypassing Ban**: Banned user (`isBanned: true`) attempting to publish books or posts. (Must be rejected).
9. **Falsifying Completed Transaction**: Client directly creates a transaction document with `{ status: "completed", amount: 5000 }` without backend verification. (Must be rejected).
10. **Unsanctioned Beta Approval**: Non-author user attempts to approve their own or another's beta application. (Must be rejected).
11. **Altering Audit Logs**: Any user trying to delete or update an audit log entry in `/auditLogs/{logId}`. (Must be rejected).
12. **Tampering with Another User's Reading Progress**: Attacker writes to `/libraries/{victimId}/items/{bookId}`. (Must be rejected).
