import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import Stripe from 'stripe';
import QRCode from 'qrcode';
import { generatePixBrCode } from './src/utils/pixPayload.ts';
import { validateReceiptCode, cleanReceiptCode as cleanReceiptCodeFromValidator } from './src/utils/receiptValidator.ts';

dotenv.config();

let stripeClient: Stripe | null = null;
function getStripe(): Stripe | null {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return null;
  if (!stripeClient) {
    stripeClient = new Stripe(key);
  }
  return stripeClient;
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '35mb' }));

  // Static uploads directory for permanent image & media persistence
  const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  // Resilient Image & Media serving route with automatic Firestore permanent backup restoration for images
  app.get('/uploads/:folder/:filename', async (req, res, next) => {
    try {
      const { folder, filename } = req.params;
      const targetFolder = ['avatars', 'covers', 'posts', 'banners', 'audios'].includes(folder)
        ? folder
        : 'uploads';
      const filePath = path.join(uploadsDir, targetFolder, filename);

      if (fs.existsSync(filePath)) {
        return res.sendFile(filePath);
      }

      if (/\.(mp4|webm|mov|mp3|m4a|wav|ogg|aac)$/i.test(filename)) {
        return next();
      }

      // If file is missing from container filesystem (e.g. after restart), restore from Firestore storageImages!
      const imageId = filename.replace(/\.(jpg|jpeg|png|webp|gif)$/i, '');
      const firestoreUrl = `https://firestore.googleapis.com/v1/projects/gen-lang-client-0427448167/databases/ai-studio-243abbce-b7a3-4a35-bfb0-6f1ccb4c33ad/documents/storageImages/${imageId}`;

      const firestoreRes = await fetch(firestoreUrl);
      if (firestoreRes.ok) {
        const docJson = await firestoreRes.json();
        const dataUrl = docJson.fields?.dataUrl?.stringValue;
        if (dataUrl) {
          const match = dataUrl.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
          if (match && match[2]) {
            const buffer = Buffer.from(match[2], 'base64');
            const mime = match[1] || 'image/jpeg';

            const folderPath = path.join(uploadsDir, targetFolder);
            if (!fs.existsSync(folderPath)) {
              fs.mkdirSync(folderPath, { recursive: true });
            }
            fs.writeFileSync(filePath, buffer);

            res.setHeader('Content-Type', mime);
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
            return res.send(buffer);
          }
        }
      }
    } catch (restoreErr) {
      console.warn('[Image Restore Warning]:', restoreErr);
    }
    next();
  });

  app.use('/uploads', express.static(uploadsDir));

  // Permanent Image, Video & Audio Upload Endpoint
  app.post('/api/upload', async (req, res) => {
    try {
      const { dataUrl, folder = 'uploads', filename } = req.body;
      if (!dataUrl || typeof dataUrl !== 'string') {
        return res.status(400).json({ error: 'Nenhuma mídia enviada.' });
      }

      const matches = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        return res.status(400).json({ error: 'Formato base64 inválido.' });
      }

      const mime = matches[1].toLowerCase().trim();
      let ext = 'jpg';
      if (mime.includes('png')) ext = 'png';
      else if (mime.includes('webp')) ext = 'webp';
      else if (mime.includes('gif')) ext = 'gif';
      else if (mime.startsWith('audio/')) {
        if (mime.includes('mpeg') || mime.includes('mp3')) ext = 'mp3';
        else if (mime.includes('wav') || mime.includes('wave')) ext = 'wav';
        else if (mime.includes('ogg')) ext = 'ogg';
        else if (mime.includes('aac')) ext = 'aac';
        else if (mime.includes('mp4') || mime.includes('m4a')) ext = 'm4a';
        else if (mime.includes('webm')) ext = 'webm';
        else ext = 'mp3';
      } else if (mime.includes('webm')) ext = 'webm';
      else if (mime.includes('quicktime') || mime.includes('mov')) ext = 'mov';
      else if (mime.includes('mp4') || mime.startsWith('video/')) ext = 'mp4';

      const buffer = Buffer.from(matches[2], 'base64');

      const targetFolder = ['avatars', 'covers', 'posts', 'banners', 'audios'].includes(folder)
        ? folder
        : 'uploads';
      const folderPath = path.join(uploadsDir, targetFolder);
      if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath, { recursive: true });
      }

      const cleanBase = filename ? filename.replace(/[^a-zA-Z0-9_-]/g, '_') : `media_${Date.now()}`;
      const baseWithoutExt = cleanBase.replace(
        /\.(jpg|jpeg|png|webp|gif|mp4|webm|mov|mp3|m4a|wav|ogg|aac)$/i,
        ''
      );
      const safeFilename = `${baseWithoutExt}.${ext}`;
      const filePath = path.join(folderPath, safeFilename);

      fs.writeFileSync(filePath, buffer);

      const proto = (req.headers['x-forwarded-proto'] as string) || (req.secure ? 'https' : 'http');
      const host = req.headers.host || 'localhost:3000';
      const fullUrl = `${proto}://${host}/uploads/${targetFolder}/${safeFilename}`;
      const relativeUrl = `/uploads/${targetFolder}/${safeFilename}`;

      console.log(`[Upload Service] Mídia salva com sucesso: ${relativeUrl}`);
      return res.json({ url: fullUrl, relativeUrl, success: true });
    } catch (err: any) {
      console.error('[Upload Service Error]:', err);
      return res.status(500).json({ error: err.message || 'Falha ao processar upload de mídia.' });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      stripeConfigured: !!process.env.STRIPE_SECRET_KEY,
    });
  });

  // Create Stripe Checkout Session
  app.post('/api/create-stripe-checkout', async (req, res) => {
    console.log('[Server /api/create-stripe-checkout] [1/5] Recebida chamada POST:', {
      url: req.url,
      headers: {
        host: req.headers.host,
        origin: req.headers.origin,
        'x-forwarded-proto': req.headers['x-forwarded-proto'],
        'content-type': req.headers['content-type'],
      },
      timestamp: new Date().toISOString(),
    });

    try {
      const { packageId, kards, amountBrl, title, userId, userEmail } = req.body;

      console.log('[Server /api/create-stripe-checkout] [2/5] Payload recebido:', {
        packageId,
        kards,
        amountBrl,
        title,
        userId,
        userEmail,
      });

      if (!userId) {
        console.warn('[Server /api/create-stripe-checkout] Validação falhou: userId ausente.');
        return res.status(401).json({ error: 'Usuário não autenticado.' });
      }

      if (!kards || !amountBrl) {
        console.warn('[Server /api/create-stripe-checkout] Validação falhou: kards ou amountBrl inválidos.', {
          kards,
          amountBrl,
        });
        return res.status(400).json({ error: 'Dados do pacote inválidos.' });
      }

      const stripe = getStripe();
      if (!stripe) {
        console.error('[Server /api/create-stripe-checkout] STRIPE_SECRET_KEY não encontrada no process.env.');
        return res.status(400).json({
          error:
            'A chave STRIPE_SECRET_KEY não foi configurada nas variáveis de ambiente. Para processar pagamentos reais com o Stripe, configure a variável STRIPE_SECRET_KEY nas configurações.',
        });
      }

      // Determine client origin for redirect callbacks
      const proto =
        (req.headers['x-forwarded-proto'] as string) ||
        (req.secure ? 'https' : 'http');
      const origin =
        req.headers.origin ||
        process.env.APP_URL ||
        `${proto}://${req.headers.host || 'localhost:3000'}`;

      console.log('[Server /api/create-stripe-checkout] [3/5] Chamando stripe.checkout.sessions.create...', {
        origin,
        amountInCents: Math.round(Number(amountBrl) * 100),
        client_reference_id: String(userId),
      });

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'brl',
              product_data: {
                name: `Pacote Kards: ${title || 'KORDEL'}`,
                description: `${kards} Kards para publicação, apoio e comunidades no KORDEL`,
              },
              unit_amount: Math.round(Number(amountBrl) * 100),
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        customer_email: userEmail || undefined,
        client_reference_id: String(userId),
        metadata: {
          userId: String(userId),
          kards: String(kards),
          packageId: String(packageId || ''),
        },
        success_url: `${origin}/?stripe_success=true&session_id={CHECKOUT_SESSION_ID}&kards=${kards}&pkg=${packageId || ''}`,
        cancel_url: `${origin}/?stripe_cancel=true`,
      });

      if (!session.url) {
        console.error('[Server /api/create-stripe-checkout] Stripe não retornou session.url:', session);
        return res.status(500).json({ error: 'Falha ao obter URL de checkout do Stripe.' });
      }

      console.log('[Server /api/create-stripe-checkout] [4/5] Sessão gerada com sucesso!', {
        sessionId: session.id,
        sessionUrl: session.url,
        paymentStatus: session.payment_status,
      });

      console.log('[Server /api/create-stripe-checkout] [5/5] Respondendo 200 JSON para o cliente.');
      return res.json({ url: session.url, sessionId: session.id });
    } catch (err: any) {
      console.error('[Server /api/create-stripe-checkout] ERRO ao criar sessão Stripe:', err);
      return res.status(500).json({
        error: err.message || 'Erro ao comunicar com a API do Stripe.',
        type: err.type,
        code: err.code,
      });
    }
  });

  // Verify Stripe payment after checkout redirect
  app.post('/api/verify-stripe-payment', async (req, res) => {
    try {
      const { sessionId } = req.body;
      if (!sessionId) {
        return res.status(400).json({ error: 'sessionId é obrigatório.' });
      }

      const stripe = getStripe();
      if (!stripe) {
        return res.status(500).json({ error: 'Stripe não configurado no servidor.' });
      }

      const session = await stripe.checkout.sessions.retrieve(sessionId);

      if (session.payment_status === 'paid') {
        return res.json({
          paid: true,
          sessionId: session.id,
          userId: session.metadata?.userId || session.client_reference_id,
          kards: Number(session.metadata?.kards || 0),
          packageId: session.metadata?.packageId,
          amountTotal: session.amount_total,
          currency: session.currency,
        });
      } else {
        return res.json({
          paid: false,
          status: session.payment_status,
        });
      }
    } catch (err: any) {
      console.error('Error verifying Stripe session:', err);
      return res.status(500).json({
        error: err.message || 'Erro ao verificar sessão do Stripe.',
      });
    }
  });

  // Disk-backed Server Pix Orders Store
  interface ServerPixOrder {
    txId: string;
    userId: string;
    userEmail?: string;
    packageId?: string;
    kards: number;
    amountBrl: number;
    title: string;
    status: 'pending' | 'under_review' | 'paid' | 'completed' | 'expired' | 'rejected';
    createdAt: number;
    expiresAt: number;
    receiptCode?: string;
    paidAt?: string;
    verifiedBy?: string;
    verifiedAt?: string;
    orderType?: 'kards' | 'subscription';
    subscriptionPlanId?: 'leitor' | 'escritor';
    bankName?: string;
  }

  const PIX_STORE_FILE = path.join(process.cwd(), '.pix_orders.json');
  const PIX_USED_RECEIPTS_FILE = path.join(process.cwd(), '.pix_used_receipts.json');

  function loadPixOrders(): Map<string, ServerPixOrder> {
    const map = new Map<string, ServerPixOrder>();
    try {
      if (fs.existsSync(PIX_STORE_FILE)) {
        const data = JSON.parse(fs.readFileSync(PIX_STORE_FILE, 'utf-8'));
        if (Array.isArray(data)) {
          data.forEach((item: any) => {
            if (item && item.txId) map.set(item.txId, item);
          });
        }
      }
    } catch (err) {
      console.warn('[Server] Falha ao carregar .pix_orders.json:', err);
    }
    return map;
  }

  function loadUsedReceipts(): Set<string> {
    const set = new Set<string>();
    try {
      if (fs.existsSync(PIX_USED_RECEIPTS_FILE)) {
        const data = JSON.parse(fs.readFileSync(PIX_USED_RECEIPTS_FILE, 'utf-8'));
        if (Array.isArray(data)) {
          data.forEach((code: any) => {
            if (typeof code === 'string' && code.trim()) {
              set.add(code.trim().toUpperCase());
            }
          });
        }
      }
    } catch (err) {
      console.warn('[Server] Falha ao carregar .pix_used_receipts.json:', err);
    }
    return set;
  }

  const pixOrdersStore = loadPixOrders();
  const usedReceiptsStore = loadUsedReceipts();

  // Garante que pedidos já pagos ou completados tenham seus recibos registrados no set
  for (const ord of pixOrdersStore.values()) {
    if (ord.receiptCode && (ord.status === 'paid' || ord.status === 'completed')) {
      usedReceiptsStore.add(ord.receiptCode.trim().toUpperCase());
    }
  }

  function savePixOrders() {
    try {
      const list = Array.from(pixOrdersStore.values());
      fs.writeFileSync(PIX_STORE_FILE, JSON.stringify(list, null, 2), 'utf-8');
    } catch (err) {
      console.warn('[Server] Falha ao salvar .pix_orders.json:', err);
    }
  }

  function saveUsedReceipts() {
    try {
      const list = Array.from(usedReceiptsStore.values());
      fs.writeFileSync(PIX_USED_RECEIPTS_FILE, JSON.stringify(list, null, 2), 'utf-8');
    } catch (err) {
      console.warn('[Server] Falha ao salvar .pix_used_receipts.json:', err);
    }
  }

  // Normalização e validação de autenticação de comprovante Pix
  function cleanReceiptCode(code: string): string {
    return String(code || '').trim().toUpperCase().replace(/[^A-Z0-9\-\.]/g, '');
  }

  interface ReceiptValidationResult {
    valid: boolean;
    code: string;
    reason?: string;
  }

  function validatePixReceiptCode(
    rawCode: string,
    currentTxId?: string
  ): ReceiptValidationResult {
    const code = cleanReceiptCode(rawCode);

    if (!code || code.length < 10) {
      return {
        valid: false,
        code,
        reason: 'Código do comprovante inválido. É obrigatório informar o código de autenticação ou ID Fim-a-Fim com pelo menos 10 caracteres.',
      };
    }

    // Previne sequências numéricas óbvias ou simulações
    const isAllSameChar = /^([A-Z0-9])\1+$/.test(code);
    if (isAllSameChar || code === '1234567890' || code.includes('TESTE123') || code.includes('0000000000')) {
      return {
        valid: false,
        code,
        reason: 'Código de autenticação inválido ou simulado. Por favor, utilize o código real do comprovante do seu banco.',
      };
    }

    // Verifica se o comprovante já foi utilizado em outro resgate ou pedido pago
    if (usedReceiptsStore.has(code)) {
      // Se for a mesma transação, tudo bem
      const matchingOrder = currentTxId ? pixOrdersStore.get(currentTxId) : null;
      if (!matchingOrder || matchingOrder.receiptCode !== code) {
        return {
          valid: false,
          code,
          reason: 'Este comprovante bancário já foi resgatado ou utilizado em outra transação.',
        };
      }
    }

    for (const ord of pixOrdersStore.values()) {
      if (
        ord.txId !== currentTxId &&
        ord.receiptCode === code &&
        (ord.status === 'paid' || ord.status === 'completed')
      ) {
        return {
          valid: false,
          code,
          reason: 'Este comprovante bancário já está vinculado a um pedido pago e confirmado.',
        };
      }
    }

    return { valid: true, code };
  }

  // Create Instant Pix Transaction
  app.post('/api/pix/create', async (req, res) => {
    try {
      const { packageId, kards, amountBrl, title, userId, userEmail } = req.body;
      console.log('[Server /api/pix/create] Criando cobrança Pix:', {
        packageId,
        kards,
        amountBrl,
        userId,
        userEmail,
      });

      if (!userId) {
        return res.status(401).json({ error: 'Usuário não autenticado.' });
      }

      if (!kards || !amountBrl || Number(amountBrl) <= 0) {
        return res.status(400).json({ error: 'Dados do pacote inválidos.' });
      }

      const txId = `PIX${Date.now()}${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      const pixKey = (process.env.PIX_KEY || 'pix@kordel.com.br').trim();
      const merchantName = (process.env.PIX_MERCHANT_NAME || 'KORDEL PLATAFORMA').trim();
      const merchantCity = 'BRASILIA';

      const brCode = generatePixBrCode({
        pixKey,
        merchantName,
        merchantCity,
        amount: Number(amountBrl),
        txId,
        description: `${kards} Kards`,
      });

      const qrCodeDataUrl = await QRCode.toDataURL(brCode, {
        width: 320,
        margin: 2,
        color: {
          dark: '#09090b',
          light: '#ffffff',
        },
      });

      const expiresAtMs = Date.now() + 15 * 60 * 1000;
      const expiresAt = new Date(expiresAtMs).toISOString();

      // Registra a ordem com status estritamente PENDENTE
      pixOrdersStore.set(txId, {
        txId,
        userId,
        userEmail,
        packageId,
        kards: Number(kards),
        amountBrl: Number(amountBrl),
        title: title || `${kards} Kards`,
        status: 'pending',
        createdAt: Date.now(),
        expiresAt: expiresAtMs,
      });
      savePixOrders();

      return res.json({
        txId,
        brCode,
        qrCodeDataUrl,
        amountBrl: Number(amountBrl),
        kards: Number(kards),
        title: title || `${kards} Kards`,
        userId,
        status: 'pending',
        expiresAt,
        pixKey,
        merchantName,
      });
    } catch (err: any) {
      console.error('[Server /api/pix/create] Erro ao gerar Pix:', err);
      return res.status(500).json({
        error: err.message || 'Erro ao gerar cobrança Pix instantânea.',
      });
    }
  });

  // Verify Pix Payment - Apenas status real ou confirmação manual do desenvolvedor
  app.post('/api/pix/verify', async (req, res) => {
    try {
      const { txId, userId, orderFallback } = req.body;
      if (!txId || !userId) {
        return res.status(400).json({ error: 'Dados da transação incompletos.' });
      }

      let order = pixOrdersStore.get(txId);
      if (!order && orderFallback) {
        const restoredOrder: ServerPixOrder = {
          ...orderFallback,
          txId,
          userId,
          createdAt: orderFallback.createdAt ? new Date(orderFallback.createdAt).getTime() : Date.now(),
          expiresAt: orderFallback.expiresAt ? new Date(orderFallback.expiresAt).getTime() : Date.now() + 15 * 60 * 1000,
          status: orderFallback.status || 'pending',
        };
        order = restoredOrder;
        pixOrdersStore.set(txId, restoredOrder);
        savePixOrders();
      }

      if (!order) {
        return res.status(404).json({
          verified: false,
          paid: false,
          status: 'not_found',
          message: 'Cobrança Pix não encontrada ou expirada.',
        });
      }

      // Se já foi aprovada pelo desenvolvedor ou integração real
      if (order.status === 'paid' || order.status === 'completed') {
        return res.json({
          verified: true,
          paid: true,
          status: order.status,
          txId: order.txId,
          kards: order.kards,
          amountBrl: order.amountBrl,
          message: 'Pagamento Pix verificado e confirmado!',
        });
      }

      // Se foi rejeitada
      if (order.status === 'rejected') {
        return res.json({
          verified: false,
          paid: false,
          status: 'rejected',
          txId: order.txId,
          message: 'Pagamento não aprovado ou recusado pela moderação.',
        });
      }

      // Se já passou do tempo de expiração
      if (Date.now() > order.expiresAt && order.status === 'pending') {
        order.status = 'expired';
        savePixOrders();
        return res.json({
          verified: false,
          paid: false,
          status: 'expired',
          message: 'Esta cobrança Pix expirou. Por favor, gere um novo QR Code para pagar.',
        });
      }

      // Pagamento em análise ou pendente (NUNCA libera kards por digitação de código)
      return res.json({
        verified: false,
        paid: false,
        status: order.status,
        txId: order.txId,
        amountBrl: order.amountBrl,
        message:
          order.status === 'under_review'
            ? 'Aguardando validação e liberação pelo desenvolvedor.'
            : 'Aguardando confirmação bancária ou aprovação pelo desenvolvedor.',
      });
    } catch (err: any) {
      console.error('[Server /api/pix/verify] Erro:', err);
      return res.status(500).json({
        error: err.message || 'Erro ao verificar pagamento Pix.',
      });
    }
  });

  // List all Pix orders for Developer Admin Dashboard
  app.get('/api/pix/orders', (req, res) => {
    const list = Array.from(pixOrdersStore.values()).sort((a, b) => b.createdAt - a.createdAt);
    return res.json(list);
  });

  // Confirm Pix Payment - Apenas Desenvolvedor / Administrador
  app.post('/api/pix/confirm', async (req, res) => {
    try {
      const { txId, adminUserId, orderFallback } = req.body;
      if (!txId) {
        return res.status(400).json({ error: 'txId é obrigatório.' });
      }

      let order = pixOrdersStore.get(txId);
      if (!order && orderFallback) {
        const restoredOrder: ServerPixOrder = {
          ...orderFallback,
          txId,
          userId: orderFallback.userId || adminUserId || 'admin_confirmed',
          createdAt: orderFallback.createdAt ? new Date(orderFallback.createdAt).getTime() : Date.now(),
          expiresAt: orderFallback.expiresAt ? new Date(orderFallback.expiresAt).getTime() : Date.now() + 15 * 60 * 1000,
          status: orderFallback.status || 'pending',
        };
        order = restoredOrder;
        pixOrdersStore.set(txId, restoredOrder);
        savePixOrders();
      }

      if (!order) {
        return res.status(404).json({ error: 'Ordem Pix não encontrada.' });
      }

      order.status = 'paid';
      order.paidAt = new Date().toISOString();
      order.verifiedAt = new Date().toISOString();
      order.verifiedBy = adminUserId || 'desenvolvedor';
      savePixOrders();

      console.log(`[Server /api/pix/confirm] Ordem Pix ${txId} (${order.kards} Kards) APROVADA por ${order.verifiedBy}!`);

      return res.json({
        success: true,
        message: 'Pagamento Pix aprovado manualmente com sucesso!',
        order,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Erro ao aprovar Pix.' });
    }
  });

  // Reject Pix Payment - Apenas Desenvolvedor / Administrador
  app.post('/api/pix/reject', async (req, res) => {
    try {
      const { txId, adminUserId, reason } = req.body;
      if (!txId) {
        return res.status(400).json({ error: 'txId é obrigatório.' });
      }

      const order = pixOrdersStore.get(txId);
      if (!order) {
        return res.status(404).json({ error: 'Ordem Pix não encontrada.' });
      }

      order.status = 'rejected';
      order.verifiedAt = new Date().toISOString();
      order.verifiedBy = adminUserId || 'desenvolvedor';
      savePixOrders();

      console.log(`[Server /api/pix/reject] Ordem Pix ${txId} RECUSADA por ${order.verifiedBy}! Motivo: ${reason || 'Não informado'}`);

      return res.json({
        success: true,
        message: 'Ordem Pix recusada pela administração.',
        order,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Erro ao recusar Pix.' });
    }
  });

  // Submit Receipt Reference para análise da moderação/desenvolvedor (NUNCA libera kards automaticamente)
  app.post('/api/pix/receipt', async (req, res) => {
    try {
      const { txId, receiptCode, userId, orderFallback } = req.body;
      if (!txId) {
        return res.status(400).json({ error: 'O ID da transação é obrigatório.' });
      }

      let order = pixOrdersStore.get(txId);
      if (!order && orderFallback) {
        const restoredOrder: ServerPixOrder = {
          ...orderFallback,
          txId,
          userId: userId || orderFallback.userId,
          createdAt: orderFallback.createdAt ? new Date(orderFallback.createdAt).getTime() : Date.now(),
          expiresAt: orderFallback.expiresAt ? new Date(orderFallback.expiresAt).getTime() : Date.now() + 15 * 60 * 1000,
          status: orderFallback.status || 'pending',
        };
        order = restoredOrder;
        pixOrdersStore.set(txId, restoredOrder);
        savePixOrders();
      }

      if (!order) {
        return res.status(404).json({ error: 'Ordem Pix não localizada.' });
      }

      // Se já está pago, não altera
      if (order.status === 'paid' || order.status === 'completed') {
        return res.json({
          success: true,
          paid: true,
          status: 'paid',
          order,
        });
      }

      // Registra comprovante e coloca em análise pelo desenvolvedor
      order.receiptCode = cleanReceiptCode(receiptCode || '');
      order.status = 'under_review';
      savePixOrders();

      console.log(`[Server /api/pix/receipt] Comprovante enviado para ${txId}. Status alterado para under_review.`);

      return res.json({
        success: true,
        paid: false,
        status: 'under_review',
        txId: order.txId,
        message: 'Comprovante registrado. O pagamento será analisado e liberado pelo desenvolvedor.',
        order,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Erro ao processar comprovante.' });
    }
  });



  // Backend Subscription Verification Endpoint
  app.get('/api/subscription/check/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      if (!userId) {
        return res.status(400).json({ error: 'userId obrigatório' });
      }

      const firestoreUrl = `https://firestore.googleapis.com/v1/projects/gen-lang-client-0427448167/databases/ai-studio-243abbce-b7a3-4a35-bfb0-6f1ccb4c33ad/documents/users/${userId}`;
      const userRes = await fetch(firestoreUrl);
      if (!userRes.ok) {
        return res.json({
          hasActiveSubscription: false,
          planId: null,
          isLeitor: false,
          isEscritor: false,
        });
      }

      const docJson = await userRes.json();
      const subMap = docJson.fields?.subscription?.mapValue?.fields;
      if (!subMap) {
        return res.json({
          hasActiveSubscription: false,
          planId: null,
          isLeitor: false,
          isEscritor: false,
        });
      }

      const status = subMap.status?.stringValue;
      const currentPeriodEnd = subMap.currentPeriodEnd?.stringValue;
      const planId = subMap.planId?.stringValue?.toLowerCase();

      const isActive =
        status === 'active' &&
        currentPeriodEnd &&
        new Date(currentPeriodEnd).getTime() > Date.now();

      const isLeitor = isActive && (planId === 'leitor' || planId === 'kardel_pro');
      const isEscritor = isActive && (planId === 'escritor' || planId === 'kardel_escritor');

      return res.json({
        hasActiveSubscription: Boolean(isActive),
        planId: isEscritor ? 'escritor' : isLeitor ? 'leitor' : null,
        isLeitor,
        isEscritor,
        currentPeriodEnd,
        benefits: isEscritor
          ? ['escritor_verificado', 'boosts_2_per_month', 'instagram_spotlight', 'writer_achievements']
          : isLeitor
          ? ['gamification_xp', 'early_access_chapters', 'beta_reading', 'leitor_experiente_badge']
          : [],
      });
    } catch (err: any) {
      console.warn('[Server] Error checking subscription:', err);
      return res.status(500).json({ error: 'Erro ao verificar assinatura no backend.' });
    }
  });

  // Criar Cobrança Pix Dinâmica para Assinatura (Leitor R$ 4,90 ou Escritor R$ 13,49)
  app.post('/api/subscription/create-pix', async (req, res) => {
    try {
      const { planId, userId, userEmail } = req.body;
      if (!userId) {
        return res.status(401).json({ error: 'Usuário não autenticado.' });
      }

      const normPlan = planId === 'escritor' ? 'escritor' : 'leitor';
      const price = normPlan === 'escritor' ? 13.49 : 4.90;
      const planName = normPlan === 'escritor' ? 'Assinatura Escritor' : 'Assinatura Leitor';

      const txId = `PIXSUB${Date.now()}${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      const pixKey = (process.env.PIX_KEY || 'pix@kordel.com.br').trim();
      const merchantName = (process.env.PIX_MERCHANT_NAME || 'KORDEL ASSINATURAS').trim();
      const merchantCity = 'BRASILIA';

      const brCode = generatePixBrCode({
        pixKey,
        merchantName,
        merchantCity,
        amount: price,
        txId,
        description: `KORDEL ${planName}`,
      });

      const qrCodeDataUrl = await QRCode.toDataURL(brCode, {
        width: 320,
        margin: 2,
        color: {
          dark: '#09090b',
          light: '#ffffff',
        },
      });

      const expiresAtMs = Date.now() + 20 * 60 * 1000;
      const expiresAt = new Date(expiresAtMs).toISOString();

      pixOrdersStore.set(txId, {
        txId,
        userId,
        userEmail: userEmail || '',
        packageId: `sub_${normPlan}`,
        kards: 0,
        amountBrl: price,
        title: planName,
        status: 'pending',
        createdAt: Date.now(),
        expiresAt: expiresAtMs,
        orderType: 'subscription',
        subscriptionPlanId: normPlan,
      });
      savePixOrders();

      return res.json({
        txId,
        brCode,
        qrCodeDataUrl,
        amountBrl: price,
        planId: normPlan,
        planName,
        userId,
        status: 'pending',
        expiresAt,
        pixKey,
        merchantName,
      });
    } catch (err: any) {
      console.error('[Server /api/subscription/create-pix] Erro:', err);
      return res.status(500).json({ error: err.message || 'Erro ao gerar Pix da assinatura.' });
    }
  });

  // Validação Estrita de ID de Comprovante Bancário para Liberação de Assinatura
  app.post('/api/subscription/confirm-receipt', async (req, res) => {
    try {
      const { userId, userEmail, planId, receiptCode, txId } = req.body;

      if (!userId) {
        return res.status(401).json({ error: 'Usuário não autenticado.' });
      }

      if (!planId || (planId !== 'leitor' && planId !== 'escritor')) {
        return res.status(400).json({ error: 'Plano de assinatura inválido. Escolha "leitor" ou "escritor".' });
      }

      if (!receiptCode || typeof receiptCode !== 'string' || !receiptCode.trim()) {
        return res.status(400).json({
          error: 'Informe o ID da transação ou o código de autenticação do comprovante do seu banco.',
        });
      }

      // Validação de autenticidade criptográfica e estrutural (ID Fim-a-Fim Pix Bacen ou Autenticação SISBACEN)
      const cleanCode = cleanReceiptCodeFromValidator(receiptCode);
      const validation = validateReceiptCode(cleanCode);

      if (!validation.isValid) {
        return res.status(400).json({
          success: false,
          error: validation.error || 'Código do comprovante inválido ou não autenticado pelo sistema bancário.',
        });
      }

      // Validação Anti-Fraude e Anti-Replay: O comprovante NUNCA pode ter sido utilizado anteriormente
      if (usedReceiptsStore.has(cleanCode)) {
        return res.status(409).json({
          success: false,
          error:
            'Este comprovante bancário já foi validado e utilizado anteriormente no sistema. Cada comprovante só pode ativar uma única assinatura.',
        });
      }

      for (const ord of pixOrdersStore.values()) {
        if (
          ord.receiptCode === cleanCode &&
          (ord.status === 'paid' || ord.status === 'completed')
        ) {
          return res.status(409).json({
            success: false,
            error:
              'Este comprovante bancário já está vinculado a uma assinatura ativa ou pedido já confirmado.',
          });
        }
      }

      const price = planId === 'escritor' ? 13.49 : 4.90;
      const planName = planId === 'escritor' ? 'Assinatura Escritor' : 'Assinatura Leitor';
      const nowIso = new Date().toISOString();
      const orderTxId = txId || `SUB_${cleanCode.substring(0, 16)}`;

      // Marca o comprovante como utilizado PERMANENTEMENTE para impedir reuso
      usedReceiptsStore.add(cleanCode);
      saveUsedReceipts();

      // Registra/atualiza ordem de assinatura confirmada
      let finalOrder: ServerPixOrder;
      const existingOrder = txId ? pixOrdersStore.get(txId) : null;
      if (!existingOrder) {
        finalOrder = {
          txId: orderTxId,
          userId,
          userEmail: userEmail || '',
          packageId: `sub_${planId}`,
          kards: 0,
          amountBrl: price,
          title: planName,
          status: 'paid',
          createdAt: Date.now(),
          expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
          paidAt: nowIso,
          receiptCode: cleanCode,
          verifiedAt: nowIso,
          verifiedBy: 'validador_bacen_autenticado',
          orderType: 'subscription',
          subscriptionPlanId: planId,
          bankName: validation.bankName,
        };
      } else {
        finalOrder = {
          ...existingOrder,
          status: 'paid',
          paidAt: nowIso,
          receiptCode: cleanCode,
          verifiedAt: nowIso,
          verifiedBy: 'validador_bacen_autenticado',
          bankName: validation.bankName,
          orderType: 'subscription',
          subscriptionPlanId: planId,
        };
      }
      pixOrdersStore.set(finalOrder.txId, finalOrder);
      savePixOrders();

      console.log(
        `[Server /api/subscription/confirm-receipt] Comprovante ${cleanCode} (${validation.bankName}) VALIDADO para ${planName} do usuário ${userId}!`
      );

      return res.json({
        success: true,
        message: 'Comprovante bancário validado e autenticado com sucesso! Assinatura liberada.',
        planId,
        planName,
        amount: price,
        receiptInfo: {
          code: cleanCode,
          type: validation.type,
          bankName: validation.bankName,
          extractedDate: validation.extractedDate,
        },
        txId: finalOrder.txId,
        verifiedAt: nowIso,
      });
    } catch (err: any) {
      console.error('[Server /api/subscription/confirm-receipt] Erro:', err);
      return res.status(500).json({
        success: false,
        error: err.message || 'Erro interno ao validar comprovante bancário.',
      });
    }
  });

  // Early access chapter and beta work authorization check
  app.post('/api/subscription/verify-chapter-access', async (req, res) => {
    try {
      const { userId, isEarlyAccess, isBeta, authorId } = req.body;

      if (!isEarlyAccess && !isBeta) {
        return res.json({ authorized: true });
      }

      if (userId && authorId && userId === authorId) {
        return res.json({ authorized: true, reason: 'author' });
      }

      if (!userId) {
        return res.json({
          authorized: false,
          reason: 'login_required',
          message: 'Faça login para acessar este conteúdo.',
        });
      }

      const firestoreUrl = `https://firestore.googleapis.com/v1/projects/gen-lang-client-0427448167/databases/ai-studio-243abbce-b7a3-4a35-bfb0-6f1ccb4c33ad/documents/users/${userId}`;
      const userRes = await fetch(firestoreUrl);
      if (!userRes.ok) {
        return res.json({
          authorized: false,
          reason: 'subscription_required',
          message: 'Conteúdo exclusivo para assinantes da Assinatura Leitor (R$ 4,90/mês).',
        });
      }

      const docJson = await userRes.json();
      const subMap = docJson.fields?.subscription?.mapValue?.fields;
      const status = subMap?.status?.stringValue;
      const currentPeriodEnd = subMap?.currentPeriodEnd?.stringValue;
      const planId = subMap?.planId?.stringValue?.toLowerCase();

      const isActiveLeitor =
        status === 'active' &&
        currentPeriodEnd &&
        new Date(currentPeriodEnd).getTime() > Date.now() &&
        (planId === 'leitor' || planId === 'kardel_pro');

      if (isActiveLeitor) {
        return res.json({ authorized: true, reason: 'active_leitor' });
      }

      return res.json({
        authorized: false,
        reason: 'subscription_required',
        message: 'Conteúdo exclusivo para assinantes da Assinatura Leitor (R$ 4,90/mês).',
      });
    } catch (err: any) {
      console.warn('[Server] Error verifying chapter access:', err);
      return res.status(500).json({ error: 'Erro ao verificar permissão de leitura.' });
    }
  });

  // Vite middleware for development (HMR disabled per Cloud Run / iframe runtime so focus changes never reload the app)
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        watch: null,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`KORDEL Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
