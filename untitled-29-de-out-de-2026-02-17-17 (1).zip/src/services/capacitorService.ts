import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';
import { App as CapApp } from '@capacitor/app';

export const isNative = Capacitor.isNativePlatform();

export async function initializeCapacitorApp(): Promise<void> {
  if (!isNative) return;

  try {
    // Configure Status Bar for dark aesthetic
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color: '#18181b' });
  } catch (err) {
    console.warn('Capacitor StatusBar init error:', err);
  }

  try {
    // Hide splash screen smoothly once web app mounted
    await SplashScreen.hide();
  } catch (err) {
    console.warn('Capacitor SplashScreen hide error:', err);
  }

  try {
    // Android back button hardware integration
    CapApp.addListener('backButton', ({ canGoBack }) => {
      if (window.location.pathname !== '/' && window.location.pathname !== '') {
        window.history.back();
      } else if (canGoBack) {
        window.history.back();
      } else {
        CapApp.exitApp();
      }
    });
  } catch (err) {
    console.warn('Capacitor backButton handler error:', err);
  }
}
