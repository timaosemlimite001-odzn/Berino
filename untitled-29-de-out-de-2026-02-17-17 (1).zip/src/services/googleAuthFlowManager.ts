import { useSyncExternalStore } from 'react';

export type GoogleAuthFlowStatus = 'idle' | 'authenticating' | 'syncing_profile' | 'error';
export type GoogleAuthFlowMode = 'login' | 'switch' | 'developer';

export interface GoogleAuthFlowError {
  code: string;
  message: string;
}

export interface GoogleAuthFlowState {
  status: GoogleAuthFlowStatus;
  isPending: boolean;
  attemptId: number;
  mode: GoogleAuthFlowMode | null;
  loginHint: string | null;
  startedAt: number | null;
  error: GoogleAuthFlowError | null;
}

type Listener = () => void;

interface PendingSyncWaiter {
  uid: string;
  resolve: () => void;
  timer: ReturnType<typeof setTimeout>;
}

const INITIAL_STATE: GoogleAuthFlowState = {
  status: 'idle',
  isPending: false,
  attemptId: 0,
  mode: null,
  loginHint: null,
  startedAt: null,
  error: null,
};

function isAllowedShieldTarget(target: EventTarget | null): boolean {
  if (!(target instanceof Element)) return false;
  return Boolean(target.closest('[data-google-auth-shield="allow"]'));
}

export function normalizeGoogleAuthError(error: unknown): GoogleAuthFlowError {
  const raw = error as { code?: string; message?: string } | null;
  const code = typeof raw?.code === 'string' ? raw.code : 'auth/unknown';

  if (code === 'auth/popup-blocked') {
    return {
      code,
      message:
        'O navegador bloqueou a janela de seleção do Google. Permita pop-ups para este site e tente novamente.',
    };
  }

  if (
    code === 'auth/cancelled-popup-request' ||
    code === 'auth/popup-closed-by-user' ||
    code === 'auth/cancelled-by-ui-manager'
  ) {
    return {
      code,
      message: 'A seleção de conta do Google foi encerrada antes da confirmação.',
    };
  }

  if (code === 'auth/unauthorized-domain') {
    return {
      code,
      message: 'Domínio de acesso não autorizado no Firebase Authentication.',
    };
  }

  if (code === 'auth/web-storage-unsupported') {
    return {
      code,
      message:
        'O armazenamento seguro de autenticação foi restrito pelo navegador. Verifique se cookies/pop-ups estão permitidos e tente novamente.',
    };
  }

  if (code === 'auth/network-request-failed') {
    return {
      code,
      message: 'Falha de conexão durante a autenticação com o Google. Verifique sua rede e tente novamente.',
    };
  }

  return {
    code,
    message:
      typeof raw?.message === 'string' && raw.message.trim()
        ? raw.message
        : 'Não foi possível concluir a autenticação com o Google.',
  };
}

class GoogleAuthFlowManager {
  private state: GoogleAuthFlowState = INITIAL_STATE;
  private listeners = new Set<Listener>();
  private guardsAttached = false;
  private lastReadyUid: string | null = null;
  private baselineUidAtFlowStart: string | null = null;
  private syncWaiters = new Set<PendingSyncWaiter>();
  private activeCancelReject: ((err: Error & { code?: string }) => void) | null = null;
  private activeResolve: (() => void) | null = null;

  private handleKeyDownCapture = (event: KeyboardEvent) => {
    if (!this.state.isPending) return;

    const key = event.key.toLowerCase();
    const isReloadShortcut =
      event.key === 'F5' || ((event.ctrlKey || event.metaKey) && key === 'r');

    if (isReloadShortcut) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    if ((event.key === 'Enter' || event.key === ' ') && !isAllowedShieldTarget(event.target)) {
      event.preventDefault();
      event.stopPropagation();
    }
  };

  private handleSubmitCapture = (event: Event) => {
    if (!this.state.isPending) return;
    event.preventDefault();
    event.stopPropagation();
  };

  private handleClickCapture = (event: MouseEvent) => {
    if (!this.state.isPending) return;
    if (isAllowedShieldTarget(event.target)) return;
    event.preventDefault();
    event.stopPropagation();
  };

  private attachBrowserGuards() {
    if (this.guardsAttached || typeof window === 'undefined') return;
    this.guardsAttached = true;
    window.addEventListener('keydown', this.handleKeyDownCapture, true);
    document.addEventListener('submit', this.handleSubmitCapture, true);
    document.addEventListener('click', this.handleClickCapture, true);
  }

  private detachBrowserGuards() {
    if (!this.guardsAttached || typeof window === 'undefined') return;
    this.guardsAttached = false;
    window.removeEventListener('keydown', this.handleKeyDownCapture, true);
    document.removeEventListener('submit', this.handleSubmitCapture, true);
    document.removeEventListener('click', this.handleClickCapture, true);
  }

  private emit(deferToMicrotask = false) {
    if (deferToMicrotask) {
      queueMicrotask(() => {
        this.listeners.forEach((listener) => listener());
      });
      return;
    }
    this.listeners.forEach((listener) => listener());
  }

  private updateState(patch: Partial<GoogleAuthFlowState>, deferNotify = false) {
    const nextStatus = patch.status ?? this.state.status;
    const nextIsPending =
      nextStatus === 'authenticating' || nextStatus === 'syncing_profile';

    this.state = {
      ...this.state,
      ...patch,
      status: nextStatus,
      isPending: nextIsPending,
    };

    if (nextIsPending) {
      this.attachBrowserGuards();
    } else {
      this.detachBrowserGuards();
    }

    this.emit(deferNotify);
  }

  public getState = (): GoogleAuthFlowState => {
    return this.state;
  };

  public subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };

  public notifyAuthUserReady(uid: string | null) {
    this.lastReadyUid = uid;
    if (!uid) return;

    for (const waiter of Array.from(this.syncWaiters)) {
      if (waiter.uid === uid) {
        clearTimeout(waiter.timer);
        this.syncWaiters.delete(waiter);
        waiter.resolve();
      }
    }

    // If an active login flow just authenticated a new user via onAuthStateChanged,
    // settle the pending UI lock immediately even if COOP delays popup close resolution.
    if (
      this.state.isPending &&
      this.state.status === 'authenticating' &&
      uid !== this.baselineUidAtFlowStart
    ) {
      const earlyResolve = this.activeResolve;
      this.activeResolve = null;
      this.activeCancelReject = null;
      this.updateState({
        status: 'idle',
        mode: null,
        loginHint: null,
        startedAt: null,
        error: null,
      });
      if (earlyResolve) {
        earlyResolve();
      }
    }
  }

  private waitForUserSync(uid: string, timeoutMs = 1200): Promise<void> {
    if (this.lastReadyUid === uid) {
      return Promise.resolve();
    }

    return new Promise<void>((resolve) => {
      const waiter: PendingSyncWaiter = {
        uid,
        resolve,
        timer: setTimeout(() => {
          this.syncWaiters.delete(waiter);
          resolve();
        }, timeoutMs),
      };
      this.syncWaiters.add(waiter);
    });
  }

  public clearError() {
    if (this.state.status === 'error' || this.state.error) {
      this.updateState({
        status: 'idle',
        error: null,
        mode: null,
        loginHint: null,
        startedAt: null,
      });
    }
  }

  public cancelActiveFlow = () => {
    const cancelReject = this.activeCancelReject;
    this.activeCancelReject = null;
    this.activeResolve = null;

    for (const waiter of Array.from(this.syncWaiters)) {
      clearTimeout(waiter.timer);
      waiter.resolve();
    }
    this.syncWaiters.clear();

    this.updateState({
      attemptId: this.state.attemptId + 1,
      status: 'idle',
      mode: null,
      loginHint: null,
      startedAt: null,
      error: null,
    });

    if (cancelReject) {
      const err: Error & { code?: string } = new Error(
        'A seleção de conta do Google foi encerrada antes da confirmação.'
      );
      err.code = 'auth/cancelled-by-ui-manager';
      cancelReject(err);
    }
  };

  /**
   * Tracks an already-initiated Google `signInWithPopup` promise.
   * Call `signInWithPopup` synchronously FIRST on the user gesture, then pass
   * the resulting promise here so browser popup user-activation is preserved
   * while UI interactions and accidental page reloads are immediately locked.
   */
  public trackAuthPromise<T extends { user?: { uid?: string } }>(
    popupPromise: Promise<T>,
    options: { mode: GoogleAuthFlowMode; loginHint?: string }
  ): Promise<void> {
    const attemptId = this.state.attemptId + 1;
    this.baselineUidAtFlowStart = this.lastReadyUid;

    // Defer React subscriber notification to microtask so the click event finishes cleanly,
    // while locking `this.state.isPending` and browser reload/navigation guards synchronously.
    this.updateState(
      {
        attemptId,
        status: 'authenticating',
        mode: options.mode,
        loginHint: options.loginHint?.trim() || null,
        startedAt: Date.now(),
        error: null,
      },
      true
    );

    const manualOutcomePromise = new Promise<void>((resolve, reject) => {
      this.activeResolve = resolve;
      this.activeCancelReject = reject;
    });

    const lifecyclePromise = popupPromise
      .then(async (credential) => {
        if (this.state.attemptId !== attemptId) return;

        const uid = credential?.user?.uid;
        if (uid) {
          this.updateState({ status: 'syncing_profile' });
          await this.waitForUserSync(uid, 1200);
        }

        if (this.state.attemptId !== attemptId) return;
        this.activeCancelReject = null;
        this.activeResolve = null;
        this.updateState({
          status: 'idle',
          mode: null,
          loginHint: null,
          startedAt: null,
          error: null,
        });
      })
      .catch((rawError: unknown) => {
        const normalized = normalizeGoogleAuthError(rawError);
        const err: Error & { code?: string } = new Error(normalized.message);
        err.code = normalized.code;

        if (this.state.attemptId === attemptId) {
          this.activeCancelReject = null;
          this.activeResolve = null;
          const isBenignClose =
            normalized.code === 'auth/popup-closed-by-user' ||
            normalized.code === 'auth/cancelled-popup-request' ||
            normalized.code === 'auth/cancelled-by-ui-manager';

          this.updateState({
            status: isBenignClose ? 'idle' : 'error',
            mode: null,
            loginHint: null,
            startedAt: null,
            error: isBenignClose ? null : normalized,
          });
        }

        throw err;
      });

    return Promise.race([lifecyclePromise, manualOutcomePromise]);
  }
}

export const googleAuthFlowManager = new GoogleAuthFlowManager();

export function useGoogleAuthFlow(): GoogleAuthFlowState {
  return useSyncExternalStore(
    googleAuthFlowManager.subscribe,
    googleAuthFlowManager.getState,
    googleAuthFlowManager.getState
  );
}
