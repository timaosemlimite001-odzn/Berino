import { Achievement, Mission } from '../types';

export const MAX_LEVEL = 33;

// XP formula: progressive curve up to level 33
// Level 1: 0 - 99
// Level 2: 100
// Level 33 threshold ~ 25,000 XP
export function getXpRequiredForLevel(level: number): number {
  if (level <= 1) return 0;
  if (level > MAX_LEVEL) return getXpRequiredForLevel(MAX_LEVEL);
  // Quadratic curve
  return Math.floor(60 * Math.pow(level - 1, 1.7) + (level - 1) * 40);
}

export function calculateLevelFromXp(xp: number): {
  level: number;
  currentLevelXp: number;
  nextLevelXp: number;
  progressPercent: number;
  didCompleteCycle: boolean;
  excessXp: number;
} {
  const maxCap = getXpRequiredForLevel(MAX_LEVEL + 1);

  if (xp >= maxCap) {
    return {
      level: MAX_LEVEL,
      currentLevelXp: xp,
      nextLevelXp: maxCap,
      progressPercent: 100,
      didCompleteCycle: true,
      excessXp: xp - maxCap,
    };
  }

  let currentLevel = 1;
  for (let lvl = 1; lvl <= MAX_LEVEL; lvl++) {
    if (xp >= getXpRequiredForLevel(lvl)) {
      currentLevel = lvl;
    } else {
      break;
    }
  }

  const currentThreshold = getXpRequiredForLevel(currentLevel);
  const nextThreshold = getXpRequiredForLevel(Math.min(currentLevel + 1, MAX_LEVEL + 1));
  const diff = nextThreshold - currentThreshold;
  const progressInLevel = xp - currentThreshold;
  const progressPercent = diff > 0 ? Math.min(100, Math.round((progressInLevel / diff) * 100)) : 100;

  return {
    level: currentLevel,
    currentLevelXp: xp,
    nextLevelXp: nextThreshold,
    progressPercent,
    didCompleteCycle: false,
    excessXp: 0,
  };
}

export const ALL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_read',
    title: 'Primeiro Cordel',
    description: 'Conclua a leitura do seu primeiro capítulo.',
    category: 'reading',
    icon: 'BookOpen',
    xpReward: 30,
    titleReward: 'Leitor Curioso',
  },
  {
    id: 'chapter_marathon_10',
    title: 'Devorador de Histórias',
    description: 'Leia 10 capítulos de diferentes obras no KORDEL.',
    category: 'reading',
    icon: 'BookmarkCheck',
    xpReward: 100,
    titleReward: 'Devorador de Páginas',
  },
  {
    id: 'books_completed_3',
    title: 'Erudito do Sertão',
    description: 'Termine a leitura completa de 3 livros.',
    category: 'reading',
    icon: 'GraduationCap',
    xpReward: 250,
    titleReward: 'Erudito do Sertão',
  },
  {
    id: 'first_review',
    title: 'Voz Crítica',
    description: 'Escreva uma avaliação honesta com nota para uma obra.',
    category: 'reading',
    icon: 'Star',
    xpReward: 50,
    titleReward: 'Voz Crítica',
  },
  {
    id: 'first_post',
    title: 'Bate-Papo no Terreiro',
    description: 'Faça uma publicação em qualquer comunidade literária.',
    category: 'community',
    icon: 'MessageSquare',
    xpReward: 50,
    titleReward: 'Contador de Causos',
  },
  {
    id: 'first_published_book',
    title: 'Tinta & Xilogravura',
    description: 'Publique seu primeiro livro independente no Estúdio do Autor.',
    category: 'writing',
    icon: 'Feather',
    xpReward: 300,
    titleReward: 'Autor Cordelista',
    isWriterExclusive: true,
  },
  {
    id: 'author_five_chapters',
    title: 'Bardo das Letras',
    description: 'Publique pelo menos 5 capítulos em suas obras autorais.',
    category: 'writing',
    icon: 'Scroll',
    xpReward: 200,
    titleReward: 'Bardo das Letras',
    isWriterExclusive: true,
  },
  {
    id: 'writer_three_books',
    title: 'Acervo Autoral',
    description: 'Publique 3 ou mais obras no catálogo do KORDEL.',
    category: 'writing',
    icon: 'BookOpen',
    xpReward: 400,
    titleReward: 'Escritor Prolífico',
    isWriterExclusive: true,
  },
  {
    id: 'first_completed_work',
    title: 'Mestre do Desfecho',
    description: 'Conclua sua primeira obra autoral com status "Concluída" no acervo.',
    category: 'writing',
    icon: 'BookCheck',
    xpReward: 350,
    titleReward: 'Mestre da Narrativa',
    isWriterExclusive: true,
  },
  {
    id: 'writer_100_views',
    title: 'Palavras ao Vento',
    description: 'Alcance 100 visualizações somadas no conjunto de suas obras.',
    category: 'writing',
    icon: 'Glasses',
    xpReward: 200,
    titleReward: 'Voz Emergente',
    isWriterExclusive: true,
  },
  {
    id: 'writer_500_views',
    title: 'Voz do Sertão',
    description: 'Alcance 500 visualizações somadas no conjunto de suas obras.',
    category: 'writing',
    icon: 'Star',
    xpReward: 350,
    titleReward: 'Voz do Sertão',
    isWriterExclusive: true,
  },
  {
    id: 'writer_1000_views',
    title: 'Fenômeno Literário',
    description: 'Alcance 1.000 visualizações somadas em suas obras no KORDEL.',
    category: 'writing',
    icon: 'Sparkles',
    xpReward: 500,
    titleReward: 'Fenômeno Literário',
    isWriterExclusive: true,
  },
  {
    id: 'writer_high_rating',
    title: 'Obra Aclamada',
    description: 'Conquiste pelo menos 5 avaliações com nota média superior a 4.5 estrelas.',
    category: 'writing',
    icon: 'Award',
    xpReward: 350,
    titleReward: 'Crítica Consagrada',
    isWriterExclusive: true,
  },
  {
    id: 'writer_first_boost',
    title: 'Impulso aos Ventos',
    description: 'Ative um impulsionamento oficial de 7 dias para destacar sua obra.',
    category: 'writing',
    icon: 'Zap',
    xpReward: 250,
    titleReward: 'Autor em Destaque',
    isWriterExclusive: true,
  },
  {
    id: 'featured_week_book',
    title: 'Vitrine de Ouro',
    description: 'Tenha uma obra selecionada nos Destaques da Semana na vitrine da Home.',
    category: 'writing',
    icon: 'Crown',
    xpReward: 500,
    titleReward: 'Autor de Vitrine',
    isWriterExclusive: true,
  },
  {
    id: 'instagram_spotlight_author',
    title: 'Homenagem no Instagram',
    description: 'Participação oficial em quadros, carrosséis ou homenagens do Instagram @kardel.oficial.',
    category: 'writing',
    icon: 'Star',
    xpReward: 500,
    titleReward: 'Voz Consagrada',
    isWriterExclusive: true,
  },
  {
    id: 'community_leader_author',
    title: 'Patrono Literário',
    description: 'Funde e administre uma comunidade literária oficial na plataforma.',
    category: 'community',
    icon: 'MessageSquare',
    xpReward: 250,
    titleReward: 'Patrono Literário',
    isWriterExclusive: true,
  },
  {
    id: 'community_ten_members',
    title: 'Terreiro Movimentado',
    description: 'Sua comunidade literária alcançou 10 ou mais membros engajados.',
    category: 'community',
    icon: 'MessageSquare',
    xpReward: 300,
    titleReward: 'Líder de Comunidade',
    isWriterExclusive: true,
  },
  {
    id: 'community_twenty_five_members',
    title: 'Ágora Sertaneja',
    description: 'Sua comunidade literária alcançou 25 ou mais membros ativos.',
    category: 'community',
    icon: 'Users',
    xpReward: 400,
    titleReward: 'Guardião Comunitário',
    isWriterExclusive: true,
  },
  {
    id: 'community_twenty_posts',
    title: 'Voz Coletiva',
    description: 'Sua comunidade literária registrou 20 ou mais publicações ativas.',
    category: 'community',
    icon: 'MessageSquare',
    xpReward: 350,
    titleReward: 'Farol da Cultura',
    isWriterExclusive: true,
  },
  {
    id: 'writer_three_completed',
    title: 'Saga Concluída',
    description: 'Conclua 3 ou mais obras autorais com status "Concluída" no acervo.',
    category: 'writing',
    icon: 'BookCheck',
    xpReward: 500,
    titleReward: 'Mestre das Sagas',
    isWriterExclusive: true,
  },
  {
    id: 'writer_50_readers',
    title: 'Círculo de Leitores',
    description: 'Alcance 50 leitores assíduos somados no conjunto de suas obras.',
    category: 'writing',
    icon: 'Glasses',
    xpReward: 300,
    titleReward: 'Voz Cativante',
    isWriterExclusive: true,
  },
  {
    id: 'writer_200_readers',
    title: 'Multidão Literária',
    description: 'Alcance 200 ou mais leitores somados em suas produções autorais.',
    category: 'writing',
    icon: 'Sparkles',
    xpReward: 500,
    titleReward: 'Autor Multidões',
    isWriterExclusive: true,
  },
  {
    id: 'writer_50_likes',
    title: 'Corações Conquistados',
    description: 'Receba 50 ou mais curtidas somadas no conjunto de suas obras.',
    category: 'writing',
    icon: 'Heart',
    xpReward: 250,
    titleReward: 'Encantador de Almas',
    isWriterExclusive: true,
  },
  {
    id: 'writer_200_likes',
    title: 'Amor do Povo',
    description: 'Receba 200 ou mais curtidas somadas em seu acervo autoral.',
    category: 'writing',
    icon: 'Star',
    xpReward: 450,
    titleReward: 'Preferido do Povo',
    isWriterExclusive: true,
  },
  {
    id: 'writer_ten_followers',
    title: 'Primeira Comitiva',
    description: 'Conquiste 10 ou mais seguidores no seu perfil autoral.',
    category: 'writing',
    icon: 'Users',
    xpReward: 250,
    titleReward: 'Líder da Tropa',
    isWriterExclusive: true,
  },
  {
    id: 'writer_fifty_followers',
    title: 'Comitiva Consagrada',
    description: 'Conquiste 50 ou mais seguidores fiéis no KORDEL.',
    category: 'writing',
    icon: 'Crown',
    xpReward: 450,
    titleReward: 'Patrono Popular',
    isWriterExclusive: true,
  },
  {
    id: 'beta_feedback',
    title: 'Olhar Clínico',
    description: 'Participe como Leitor Beta e envie feedback sobre uma obra.',
    category: 'reading',
    icon: 'Glasses',
    xpReward: 150,
    titleReward: 'Leitor Visionário',
  },
  {
    id: 'kards_first_purchase',
    title: 'Mecenas Literário',
    description: 'Adquira seu primeiro pacote de Kards na Loja oficial.',
    category: 'progression',
    icon: 'Coins',
    xpReward: 100,
    titleReward: 'Apoiador Literário',
  },
  {
    id: 'legend_cycle',
    title: 'Lenda Renascida',
    description: 'Complete o nível 33 e inicie um novo ciclo literário.',
    category: 'progression',
    icon: 'Crown',
    xpReward: 1000,
    titleReward: 'Imortal do KORDEL',
  },
];

export const ALL_MISSIONS: Mission[] = [
  {
    id: 'daily_read_2',
    title: 'Leitura do Dia',
    description: 'Leia 2 capítulos de qualquer obra hoje.',
    targetType: 'read_chapters',
    targetCount: 2,
    xpReward: 40,
    kardReward: 5,
    period: 'daily',
  },
  {
    id: 'daily_comment_1',
    title: 'Voz Literária',
    description: 'Deixe um comentário em um capítulo ou comunidade hoje.',
    targetType: 'comment',
    targetCount: 1,
    xpReward: 30,
    kardReward: 3,
    period: 'daily',
  },
  {
    id: 'weekly_read_10',
    title: 'Jornada Semanal',
    description: 'Leia 10 capítulos ao longo desta semana.',
    targetType: 'read_chapters',
    targetCount: 10,
    xpReward: 150,
    kardReward: 15,
    period: 'weekly',
  },
  {
    id: 'weekly_community_2',
    title: 'Engajamento Literário',
    description: 'Participe com 2 publicações em comunidades nesta semana.',
    targetType: 'community_post',
    targetCount: 2,
    xpReward: 100,
    kardReward: 0,
    period: 'weekly',
  },
];
