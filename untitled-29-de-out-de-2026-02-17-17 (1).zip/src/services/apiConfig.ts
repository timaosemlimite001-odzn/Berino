import { Capacitor } from '@capacitor/core';

/**
 * Returns the correct base URL for API requests.
 * In a web environment, relative paths ('/api/...') are used.
 * In Capacitor Android native environment, falls back to the hosted Cloud Run server.
 */
export function getApiBaseUrl(): string {
  const envUrl = import.meta.env.VITE_API_BASE_URL;
  if (envUrl && typeof envUrl === 'string') {
    return envUrl.replace(/\/$/, '');
  }

  if (Capacitor.isNativePlatform()) {
    // Production Cloud Run deployment URL for mobile backend calls
    return 'https://ais-pre-sytsemy3ywaxnw3pdid56c-701241103851.us-west2.run.app';
  }

  return '';
}
