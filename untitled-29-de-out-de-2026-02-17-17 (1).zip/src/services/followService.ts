import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  increment,
  onSnapshot,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db, sanitizeFirestoreData } from './firebase';
import { awardXp, sendNotification } from './progressionService';

export interface FollowRecord {
  id: string; // `${followerId}_${followedId}`
  followerId: string;
  followedId: string;
  followerName: string;
  followerPhoto?: string;
  createdAt: string;
}

/**
 * Checks if followerId currently follows targetUserId
 */
export async function isFollowingUser(followerId: string, targetUserId: string): Promise<boolean> {
  if (!followerId || !targetUserId || followerId === targetUserId) return false;
  try {
    const followDoc = await getDoc(doc(db, 'follows', `${followerId}_${targetUserId}`));
    return followDoc.exists();
  } catch (err) {
    console.error('Error checking follow status:', err);
    return false;
  }
}

/**
 * Subscribes to real-time follow status between two users
 */
export function subscribeFollowStatus(
  followerId: string,
  targetUserId: string,
  callback: (isFollowing: boolean) => void
): () => void {
  if (!followerId || !targetUserId || followerId === targetUserId) {
    callback(false);
    return () => {};
  }

  const followRef = doc(db, 'follows', `${followerId}_${targetUserId}`);
  return onSnapshot(
    followRef,
    (snap) => {
      callback(snap.exists());
    },
    (err) => {
      console.error('Error subscribing to follow status:', err);
      callback(false);
    }
  );
}

/**
 * Follow a user: updates Firestore doc, increments counts, sends notification & awards XP
 */
export async function followUser(
  currentUser: { id: string; displayName?: string; photoURL?: string },
  targetUser: { id: string; displayName?: string }
): Promise<void> {
  if (!currentUser.id || !targetUser.id || currentUser.id === targetUser.id) {
    throw new Error('Não é possível seguir seu próprio perfil.');
  }

  const followId = `${currentUser.id}_${targetUser.id}`;
  const followRef = doc(db, 'follows', followId);

  const followData: FollowRecord = {
    id: followId,
    followerId: currentUser.id,
    followedId: targetUser.id,
    followerName: currentUser.displayName || 'Leitor do KORDEL',
    followerPhoto: currentUser.photoURL || '',
    createdAt: new Date().toISOString(),
  };

  // 1. Create follow record
  await setDoc(followRef, sanitizeFirestoreData(followData));

  // 2. Increment followersCount on target user
  try {
    const targetRef = doc(db, 'users', targetUser.id);
    await updateDoc(targetRef, {
      followersCount: increment(1),
    });
  } catch (err) {
    console.warn('Could not increment target followersCount directly:', err);
  }

  // 3. Increment followingCount on current user
  try {
    const currentRef = doc(db, 'users', currentUser.id);
    await updateDoc(currentRef, {
      followingCount: increment(1),
    });
  } catch (err) {
    console.warn('Could not increment current followingCount:', err);
  }

  // 4. Send notification to target user
  try {
    await sendNotification(
      targetUser.id,
      'follower',
      'Novo Seguidor!',
      `${currentUser.displayName || 'Um usuário'} começou a seguir você no KORDEL.`,
      `/usuario/${currentUser.id}`
    );
  } catch (err) {
    console.warn('Could not send follow notification:', err);
  }

  // 5. Award +10 XP to follower for community engagement
  try {
    await awardXp(
      currentUser.id,
      10,
      `follow_${targetUser.id}`,
      `Seguiu o autor/leitor: ${targetUser.displayName || 'Membro'}`
    );
  } catch (err) {
    console.warn('Could not award follow XP:', err);
  }
}

/**
 * Unfollow a user: removes follow doc and decrements counts
 */
export async function unfollowUser(currentUserId: string, targetUserId: string): Promise<void> {
  if (!currentUserId || !targetUserId) return;

  const followId = `${currentUserId}_${targetUserId}`;
  const followRef = doc(db, 'follows', followId);

  await deleteDoc(followRef);

  // Decrement target followersCount
  try {
    const targetRef = doc(db, 'users', targetUserId);
    await updateDoc(targetRef, {
      followersCount: increment(-1),
    });
  } catch (err) {
    console.warn('Could not decrement target followersCount:', err);
  }

  // Decrement current followingCount
  try {
    const currentRef = doc(db, 'users', currentUserId);
    await updateDoc(currentRef, {
      followingCount: increment(-1),
    });
  } catch (err) {
    console.warn('Could not decrement current followingCount:', err);
  }
}

/**
 * Fetches accurate follower and following counts for a user
 */
export async function getFollowCounts(
  userId: string
): Promise<{ followersCount: number; followingCount: number }> {
  try {
    // Check user doc first
    const userSnap = await getDoc(doc(db, 'users', userId));
    const userData = userSnap.data();

    let followers = typeof userData?.followersCount === 'number' ? Math.max(0, userData.followersCount) : 0;
    let following = typeof userData?.followingCount === 'number' ? Math.max(0, userData.followingCount) : 0;

    // If undefined on doc, count directly from query
    if (userData?.followersCount === undefined) {
      const followersSnap = await getDocs(
        query(collection(db, 'follows'), where('followedId', '==', userId))
      );
      followers = followersSnap.size;
    }

    if (userData?.followingCount === undefined) {
      const followingSnap = await getDocs(
        query(collection(db, 'follows'), where('followerId', '==', userId))
      );
      following = followingSnap.size;
    }

    return { followersCount: followers, followingCount: following };
  } catch (err) {
    console.error('Error getting follow counts:', err);
    return { followersCount: 0, followingCount: 0 };
  }
}
