import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  runTransaction,
  where
} from 'firebase/firestore';
import { KardPackage, KardTransaction, TransactionType } from '../types';
import { db, handleFirestoreError, OperationType } from './firebase';
import { sendNotification } from './progressionService';

export const DEFAULT_KARD_PACKAGES: KardPackage[] = [
  {
    id: 'kards_100',
    kards: 100,
    priceBrl: 4.9,
    title: 'Cordel Iniciante',
  },
  {
    id: 'kards_300',
    kards: 300,
    bonus: 30,
    priceBrl: 12.9,
    title: 'Xilogravura Popular',
    popular: true,
  },
  {
    id: 'kards_750',
    kards: 750,
    bonus: 100,
    priceBrl: 29.9,
    title: 'Bardo Lendário',
  },
  {
    id: 'kards_1500',
    kards: 1500,
    bonus: 300,
    priceBrl: 49.9,
    title: 'Erudito Imperial',
  },
];

// App-wide costs in Kards (can be retrieved/overridden from settings)
export const KARD_COSTS = {
  PUBLISH_BOOK: 300, // Custo para publicar uma nova obra: 300 Kards
  CREATE_COMMUNITY: 190, // Custo para criar comunidade: 190 Kards
  POST_IN_COMMUNITY: 15, // Custo para membro publicar em comunidade: 15 Kards (criador posta grátis)
};

// Atomically spend Kards with balance verification, negative balance prevention, and audit logging
export async function spendKards(
  userId: string,
  amount: number,
  type: TransactionType,
  description: string,
  referenceId?: string
): Promise<void> {
  if (amount <= 0) return;

  const userRef = doc(db, 'users', userId);
  const txId = `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const txRef = doc(db, 'transactions', txId);

  try {
    await runTransaction(db, async (transaction) => {
      const userDoc = await transaction.get(userRef);
      if (!userDoc.exists()) {
        throw new Error('Usuário não encontrado.');
      }

      const userData = userDoc.data();
      if (userData.isBanned) {
        throw new Error('Conta suspensa. Não é possível realizar transações.');
      }

      const currentBalance = userData.kards || 0;
      if (currentBalance < amount) {
        throw new Error(`Saldo insuficiente. Você possui ${currentBalance} Kards, mas a ação requer ${amount} Kards.`);
      }

      // Deduct balance
      const newBalance = currentBalance - amount;
      transaction.update(userRef, {
        kards: newBalance,
        updatedAt: new Date().toISOString(),
      });

      // Write immutable transaction record
      transaction.set(txRef, {
        id: txId,
        userId,
        amount: -amount,
        type,
        description,
        referenceId: referenceId || '',
        status: 'completed',
        createdAt: new Date().toISOString(),
      });
    });

    // Notify user of deduction
    await sendNotification(
      userId,
      'kards_spent',
      `${amount} Kards Utilizados`,
      `Você utilizou ${amount} Kards para: ${description}. Saldo atualizado com sucesso.`
    );
  } catch (error) {
    if (error instanceof Error && error.message.includes('Saldo insuficiente')) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, `users/${userId}`);
  }
}

// Atomically credit Kards to a user (from Stripe purchase or admin grant)
export async function creditKards(
  userId: string,
  amount: number,
  type: TransactionType,
  description: string,
  referenceId?: string
): Promise<void> {
  if (amount <= 0) return;

  const userRef = doc(db, 'users', userId);
  const txId = `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const txRef = doc(db, 'transactions', txId);

  try {
    await runTransaction(db, async (transaction) => {
      // 1. ALL READS FIRST: Execute all transaction reads before any writes
      let existingTxRef = null;
      if (referenceId) {
        existingTxRef = doc(db, 'transactions', `ref_${referenceId}`);
        const existingTxDoc = await transaction.get(existingTxRef);
        if (existingTxDoc.exists()) {
          throw new Error('Esta transação já foi processada anteriormente.');
        }
      }

      const userDoc = await transaction.get(userRef);
      if (!userDoc.exists()) {
        throw new Error('Usuário não encontrado.');
      }

      const currentBalance = userDoc.data().kards || 0;
      const newBalance = currentBalance + amount;

      // 2. ALL WRITES AFTER ALL READS: Execute all updates and sets
      if (existingTxRef) {
        transaction.set(existingTxRef, {
          processedAt: new Date().toISOString(),
          userId,
        });
      }

      transaction.update(userRef, {
        kards: newBalance,
        updatedAt: new Date().toISOString(),
      });

      transaction.set(txRef, {
        id: txId,
        userId,
        amount,
        type,
        description,
        referenceId: referenceId || '',
        status: 'completed',
        createdAt: new Date().toISOString(),
      });
    });

    await sendNotification(
      userId,
      'kards_received',
      `+${amount} Kards Creditados!`,
      `Você recebeu ${amount} Kards em sua carteira do KORDEL. ${description}`
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${userId}`);
  }
}

// Get user transaction history
export async function getUserTransactions(userId: string): Promise<KardTransaction[]> {
  try {
    const q = query(
      collection(db, 'transactions'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as KardTransaction);
  } catch (error) {
    console.error('Error fetching transactions:', error);
    return [];
  }
}
