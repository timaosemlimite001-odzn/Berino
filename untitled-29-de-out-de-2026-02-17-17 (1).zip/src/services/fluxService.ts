import {
  QueryDocumentSnapshot,
  DocumentData,
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  startAfter,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Book,
  Community,
  CommunityMember,
  CommunityPoll,
  CommunityPost,
  FavoritePostRecord,
  FluxAudioTrack,
  FluxFeedItem,
  FluxStoryCanvas,
  LibraryItem,
  PollOption,
  PostImageFormat,
  SavedPostResolvedItem,
  UserProfile,
} from '../types';
import {
  OperationType,
  db,
  handleFirestoreError,
  sanitizeFirestoreData,
} from './firebase';
import { awardXp, sendNotification } from './progressionService';
import { uploadAudioToStorage, uploadMediaToStorage } from './storageService';

export function getFluxItemKey(
  item: Pick<FluxFeedItem, 'postSource' | 'communityId' | 'id'>
): string {
  return `${item.postSource}:${item.communityId || 'flux'}:${item.id}`;
}

export function getFavoriteDocId(
  item: Pick<FluxFeedItem, 'postSource' | 'communityId' | 'id'>
): string {
  const raw = `${item.postSource}_${item.communityId || 'flux'}_${item.id}`;
  return raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
}

/**
 * Extracts normalized media items (images and videos) from a Flux or Community post,
 * preserving full backward compatibility with legacy single-image `mediaUrl` / `imageUrl` posts.
 */
export function extractPostMediaItems(
  post: CommunityPost
): { url: string; type: 'image' | 'video' }[] {
  if (Array.isArray(post.mediaUrls) && post.mediaUrls.length > 0) {
    return post.mediaUrls
      .filter((u) => typeof u === 'string' && u.trim().length > 0)
      .map((url, idx) => {
        const explicitType = post.mediaTypes?.[idx];
        const inferredVideo =
          explicitType === 'video' || /\.(mp4|webm|mov)(\?|$)/i.test(url);
        return {
          url,
          type: inferredVideo ? 'video' : 'image',
        };
      });
  }

  const singleUrl = post.mediaUrl || post.imageUrl;
  if (singleUrl && typeof singleUrl === 'string' && singleUrl.trim().length > 0) {
    const isVid =
      post.type === 'video' || /\.(mp4|webm|mov)(\?|$)/i.test(singleUrl);
    return [{ url: singleUrl, type: isVid ? 'video' : 'image' }];
  }

  return [];
}

export const THREE_DAYS_FLUX_MS = 3 * 24 * 60 * 60 * 1000;

export type FluxEngagementSignalType =
  | 'like'
  | 'unlike'
  | 'save'
  | 'unsave'
  | 'comment'
  | 'share'
  | 'poll_vote'
  | 'community_join'
  | 'open_caption'
  | 'open_author'
  | 'open_community'
  | 'dwell'
  | 'quick_skip'
  | 'dismiss';

interface PersistedTelemetryWeights {
  authorWeights: Record<string, number>;
  communityWeights: Record<string, number>;
  categoryWeights: Record<string, number>;
  formatWeights: Record<string, number>;
  topicWeights: Record<string, number>;
  postDirectWeights: Record<string, number>;
}

interface PersistedFluxSessionState {
  openGeneration: number;
  lastLeadKey: string | null;
  shownLeadKeys: string[];
  seenPostKeys: string[];
  lastSequenceSignature: string;
}

interface UserPlatformInterestGraph {
  loadedForUid: string;
  followedAuthorIds: Set<string>;
  libraryAuthorIds: Set<string>;
  libraryAuthorNames: Set<string>;
  savedAuthorIds: Set<string>;
  savedCommunityIds: Set<string>;
  preferredGenresAndCategories: Map<string, number>;
  preferredKeywords: Map<string, number>;
}

const PT_STOPWORDS = new Set([
  'para', 'como', 'mais', 'isso', 'esse', 'essa', 'este', 'esta', 'pelo', 'pela',
  'com', 'sem', 'uma', 'uns', 'umas', 'dos', 'das', 'nos', 'nas', 'por', 'que',
  'quem', 'qual', 'quando', 'onde', 'muito', 'muita', 'todos', 'todas', 'tudo',
  'nada', 'sobre', 'entre', 'depois', 'antes', 'agora', 'hoje', 'aqui', 'voce',
  'voces', 'eles', 'elas', 'dele', 'dela', 'meus', 'minha', 'seus', 'suas',
  'livro', 'livros', 'post', 'flux', 'kordel', 'comunidade', 'capitulo',
]);

function normalizeToken(raw: string): string {
  return raw
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

function extractMeaningfulTokens(text?: string, maxTokens = 14): string[] {
  if (!text || typeof text !== 'string') return [];
  const parts = text.split(/\s+/);
  const tokens: string[] = [];
  const seen = new Set<string>();
  for (const p of parts) {
    const clean = normalizeToken(p);
    if (clean.length < 4 || PT_STOPWORDS.has(clean) || seen.has(clean)) continue;
    seen.add(clean);
    tokens.push(clean);
    if (tokens.length >= maxTokens) break;
  }
  return tokens;
}

function detectPostFormatBucket(post: CommunityPost): string {
  const media = extractPostMediaItems(post);
  if (media.some((m) => m.type === 'video')) return 'video';
  if (post.poll && post.poll.options?.length) return 'poll';
  const hasStoryLayers = Boolean(
    post.storyCanvas?.texts?.some((t) => typeof t.text === 'string' && t.text.trim().length > 0)
  );
  if (post.audioTrack?.url) return 'audio';
  if (media.length > 0 && hasStoryLayers) return 'story';
  if (media.length > 0) return 'image';
  return 'text';
}

export function isPostPublishedUnderThreeDays(
  post: Pick<CommunityPost, 'createdAt'>,
  nowMs = Date.now()
): boolean {
  if (!post.createdAt) return false;
  const createdMs = new Date(post.createdAt).getTime();
  if (Number.isNaN(createdMs) || createdMs <= 0) return false;
  const ageMs = nowMs - createdMs;
  return ageMs >= -60_000 && ageMs < THREE_DAYS_FLUX_MS;
}

/**
 * Real engagement & reach metric computed from database fields (likes, comments, poll votes).
 */
export function computeRealEngagementScore(post: CommunityPost): number {
  const likes = typeof post.likesCount === 'number' ? Math.max(0, post.likesCount) : 0;
  const comments =
    typeof post.commentsCount === 'number' ? Math.max(0, post.commentsCount) : 0;
  const pollVotes =
    typeof post.poll?.totalVotes === 'number' ? Math.max(0, post.poll.totalVotes) : 0;
  return likes + comments * 1.6 + pollVotes * 0.8;
}

export function formatRelativeTimePt(isoString?: string): string {
  if (!isoString) return 'Agora';
  const time = new Date(isoString).getTime();
  if (Number.isNaN(time)) return 'Recente';

  const diffSec = Math.max(0, Math.floor((Date.now() - time) / 1000));
  if (diffSec < 60) return 'Agora';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `Há ${diffMin} min`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) {
    return diffHours === 1 ? 'Há 1 hora' : `Há ${diffHours} horas`;
  }
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 30) {
    return diffDays === 1 ? 'Há 1 dia' : `Há ${diffDays} dias`;
  }
  const diffMonths = Math.floor(diffDays / 30);
  if (diffMonths < 12) {
    return diffMonths === 1 ? 'Há 1 mês' : `Há ${diffMonths} meses`;
  }
  const diffYears = Math.floor(diffMonths / 12);
  return diffYears === 1 ? 'Há 1 ano' : `Há ${diffYears} anos`;
}

/**
 * Stateful incremental loader, personalized engagement recommendation engine & sequence builder for Flux.
 * - Uses collected user platform consumption (books in library + genres, followed authors, saved posts,
 *   joined communities, liked/disliked posts, and real-time Flux dwell/skip/interaction telemetry).
 * - Enforces 1 post published in < 3 days for every 5 older posts recommended by reach & engagement.
 * - Persists lead history & sequence signatures across Flux close/reopen so the first post never repeats
 *   what appeared before closing (unless cycling after exhausting all posts, still avoiding immediate repeat)
 *   and every close/reopen or pull-past-top reorganizes a fresh sequence combination.
 */
export class FluxEngine {
  private pool = new Map<string, FluxFeedItem>();
  private communitiesMap = new Map<string, Community>();
  private bannedAuthorCache = new Map<string, boolean>();

  // Cursors for standalone /fluxPosts
  private fluxRecentCursor: QueryDocumentSnapshot<DocumentData> | null = null;
  private fluxRecentExhausted = false;
  private fluxEngageCursor: QueryDocumentSnapshot<DocumentData> | null = null;
  private fluxEngageExhausted = false;

  // Cursors for /communities and per-community /posts
  private commCursor: QueryDocumentSnapshot<DocumentData> | null = null;
  private commExhausted = false;
  private orderedCommIds: string[] = [];
  private commScanIndex = 0;
  private commRecentCursors = new Map<string, QueryDocumentSnapshot<DocumentData> | null>();
  private commRecentExhausted = new Set<string>();
  private commEngageCursors = new Map<string, QueryDocumentSnapshot<DocumentData> | null>();
  private commEngageExhausted = new Set<string>();

  // Session deduplication, temporary X dismissal, persistent cross-open state & cadence tracking
  private sessionSeenKeys = new Set<string>();
  private dismissedAtMap = new Map<string, number>();
  private dismissedStorageLoadedFor: string | null = null;

  private persistedSessionLoadedFor: string | null = null;
  private persistedSession: PersistedFluxSessionState = {
    openGeneration: 0,
    lastLeadKey: null,
    shownLeadKeys: [],
    seenPostKeys: [],
    lastSequenceSignature: '',
  };

  private telemetryLoadedFor: string | null = null;
  private telemetry: PersistedTelemetryWeights = {
    authorWeights: {},
    communityWeights: {},
    categoryWeights: {},
    formatWeights: {},
    topicWeights: {},
    postDirectWeights: {},
  };

  private interestGraph: UserPlatformInterestGraph | null = null;
  private interestGraphPromise: Promise<void> | null = null;

  private refreshGeneration = 0;
  private cycleGeneration = 0;
  private sequenceOlderStreak = 0;

  private static readonly TEMP_DISMISS_COOLDOWN_MS = 3 * 60 * 1000; // 3 minutes temporary cooldown

  private getScope(currentUserId?: string): string {
    return currentUserId || 'guest';
  }

  private ensureSessionStateLoaded(currentUserId?: string) {
    const scope = this.getScope(currentUserId);
    if (this.persistedSessionLoadedFor === scope) return;
    this.persistedSessionLoadedFor = scope;
    this.persistedSession = {
      openGeneration: 0,
      lastLeadKey: null,
      shownLeadKeys: [],
      seenPostKeys: [],
      lastSequenceSignature: '',
    };
    try {
      const raw = localStorage.getItem(`kordel_flux_session_state_${scope}`);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<PersistedFluxSessionState>;
        this.persistedSession = {
          openGeneration:
            typeof parsed.openGeneration === 'number' ? parsed.openGeneration : 0,
          lastLeadKey:
            typeof parsed.lastLeadKey === 'string' ? parsed.lastLeadKey : null,
          shownLeadKeys: Array.isArray(parsed.shownLeadKeys)
            ? parsed.shownLeadKeys.filter((x): x is string => typeof x === 'string').slice(-180)
            : [],
          seenPostKeys: Array.isArray(parsed.seenPostKeys)
            ? parsed.seenPostKeys.filter((x): x is string => typeof x === 'string').slice(-260)
            : [],
          lastSequenceSignature:
            typeof parsed.lastSequenceSignature === 'string'
              ? parsed.lastSequenceSignature
              : '',
        };
        this.persistedSession.seenPostKeys.forEach((k) => this.sessionSeenKeys.add(k));
      }
    } catch {
      // ignore storage errors
    }
  }

  private persistSessionState(currentUserId?: string) {
    const scope = this.getScope(currentUserId);
    try {
      const trimmed: PersistedFluxSessionState = {
        openGeneration: this.persistedSession.openGeneration,
        lastLeadKey: this.persistedSession.lastLeadKey,
        shownLeadKeys: this.persistedSession.shownLeadKeys.slice(-180),
        seenPostKeys: Array.from(this.sessionSeenKeys).slice(-260),
        lastSequenceSignature: this.persistedSession.lastSequenceSignature,
      };
      this.persistedSession = trimmed;
      localStorage.setItem(
        `kordel_flux_session_state_${scope}`,
        JSON.stringify(trimmed)
      );
    } catch {
      // ignore storage errors
    }
  }

  private ensureTelemetryLoaded(currentUserId?: string) {
    const scope = this.getScope(currentUserId);
    if (this.telemetryLoadedFor === scope) return;
    this.telemetryLoadedFor = scope;
    this.telemetry = {
      authorWeights: {},
      communityWeights: {},
      categoryWeights: {},
      formatWeights: {},
      topicWeights: {},
      postDirectWeights: {},
    };
    try {
      const raw = localStorage.getItem(`kordel_flux_engagement_profile_${scope}`);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<PersistedTelemetryWeights>;
        this.telemetry = {
          authorWeights: parsed.authorWeights || {},
          communityWeights: parsed.communityWeights || {},
          categoryWeights: parsed.categoryWeights || {},
          formatWeights: parsed.formatWeights || {},
          topicWeights: parsed.topicWeights || {},
          postDirectWeights: parsed.postDirectWeights || {},
        };
      }
    } catch {
      // ignore storage errors
    }
  }

  private pruneWeightMap(map: Record<string, number>, maxEntries: number): Record<string, number> {
    const entries = Object.entries(map).filter(
      ([, v]) => typeof v === 'number' && !Number.isNaN(v) && Math.abs(v) >= 0.25
    );
    if (entries.length <= maxEntries) {
      return Object.fromEntries(entries);
    }
    entries.sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]));
    return Object.fromEntries(entries.slice(0, maxEntries));
  }

  private persistTelemetry(currentUserId?: string) {
    const scope = this.getScope(currentUserId);
    try {
      this.telemetry = {
        authorWeights: this.pruneWeightMap(this.telemetry.authorWeights, 80),
        communityWeights: this.pruneWeightMap(this.telemetry.communityWeights, 60),
        categoryWeights: this.pruneWeightMap(this.telemetry.categoryWeights, 40),
        formatWeights: this.pruneWeightMap(this.telemetry.formatWeights, 12),
        topicWeights: this.pruneWeightMap(this.telemetry.topicWeights, 120),
        postDirectWeights: this.pruneWeightMap(this.telemetry.postDirectWeights, 150),
      };
      localStorage.setItem(
        `kordel_flux_engagement_profile_${scope}`,
        JSON.stringify(this.telemetry)
      );
    } catch {
      // ignore storage errors
    }
  }

  private adjustWeight(
    bucket: Record<string, number>,
    key: string | undefined,
    delta: number,
    min = -35,
    max = 60
  ) {
    if (!key) return;
    const prev = bucket[key] || 0;
    bucket[key] = Math.max(min, Math.min(max, Number((prev + delta).toFixed(2))));
  }

  /**
   * Records real user interactions inside Flux so the recommendation algorithm adapts immediately.
   */
  public recordEngagementSignal(
    item: FluxFeedItem,
    signal: FluxEngagementSignalType,
    currentUserId?: string,
    durationMs?: number
  ) {
    if (!item?.id) return;
    this.ensureTelemetryLoaded(currentUserId);

    const itemKey = getFluxItemKey(item);
    const comm = item.communityId ? this.communitiesMap.get(item.communityId) : undefined;
    const categoryKey = comm?.category ? normalizeToken(comm.category) : '';
    const formatKey = detectPostFormatBucket(item);
    const storyText =
      item.storyCanvas?.texts?.map((t) => t.text).join(' ') || '';
    const tokens = extractMeaningfulTokens(
      `${item.content || ''} ${storyText} ${item.communityName || ''}`,
      8
    );

    let authorDelta = 0;
    let commDelta = 0;
    let catDelta = 0;
    let formatDelta = 0;
    let topicDelta = 0;
    let postDelta = 0;

    switch (signal) {
      case 'like':
        authorDelta = 7;
        commDelta = 5.5;
        catDelta = 4.5;
        formatDelta = 2.5;
        topicDelta = 3;
        postDelta = 8;
        break;
      case 'unlike':
        authorDelta = -3.5;
        commDelta = -2.5;
        catDelta = -2;
        topicDelta = -1.5;
        postDelta = -4;
        break;
      case 'save':
        authorDelta = 10;
        commDelta = 8;
        catDelta = 6;
        formatDelta = 3.5;
        topicDelta = 4.5;
        postDelta = 12;
        break;
      case 'unsave':
        authorDelta = -4;
        commDelta = -3;
        topicDelta = -2;
        postDelta = -5;
        break;
      case 'comment':
        authorDelta = 9;
        commDelta = 7.5;
        catDelta = 5;
        formatDelta = 3;
        topicDelta = 4;
        postDelta = 10;
        break;
      case 'share':
        authorDelta = 8;
        commDelta = 6;
        catDelta = 4;
        topicDelta = 3.5;
        postDelta = 9;
        break;
      case 'poll_vote':
        authorDelta = 5;
        commDelta = 5;
        catDelta = 3.5;
        formatDelta = 4;
        topicDelta = 2.5;
        postDelta = 6;
        break;
      case 'community_join':
        authorDelta = 6;
        commDelta = 14;
        catDelta = 8;
        topicDelta = 4;
        postDelta = 8;
        break;
      case 'open_caption':
      case 'open_author':
      case 'open_community':
        authorDelta = 3.5;
        commDelta = 3;
        catDelta = 2;
        topicDelta = 1.8;
        postDelta = 3;
        break;
      case 'dwell': {
        const secs = Math.min(30, Math.max(0, (durationMs || 0) / 1000));
        if (secs < 3.5) return;
        const factor = Math.min(2.6, secs / 8);
        authorDelta = 2.2 * factor;
        commDelta = 1.8 * factor;
        catDelta = 1.5 * factor;
        formatDelta = 1.2 * factor;
        topicDelta = 1.2 * factor;
        postDelta = 2 * factor;
        break;
      }
      case 'quick_skip':
        authorDelta = -1.2;
        commDelta = -0.8;
        formatDelta = -0.6;
        topicDelta = -0.7;
        postDelta = -4.5;
        break;
      case 'dismiss':
        authorDelta = -6;
        commDelta = -4.5;
        catDelta = -2.5;
        topicDelta = -2.5;
        postDelta = -18;
        break;
    }

    this.adjustWeight(this.telemetry.authorWeights, item.authorId, authorDelta);
    if (item.communityId) {
      this.adjustWeight(this.telemetry.communityWeights, item.communityId, commDelta);
    }
    if (categoryKey) {
      this.adjustWeight(this.telemetry.categoryWeights, categoryKey, catDelta);
    }
    this.adjustWeight(this.telemetry.formatWeights, formatKey, formatDelta, -15, 25);
    tokens.forEach((tok) => {
      this.adjustWeight(this.telemetry.topicWeights, tok, topicDelta, -20, 35);
    });
    this.adjustWeight(this.telemetry.postDirectWeights, itemKey, postDelta, -30, 30);

    this.persistTelemetry(currentUserId);
  }

  /**
   * Collects what the authenticated user consumes and does across KORDEL:
   * - Books read, completed, saved, or favorited (`libraries/{uid}/items` + `books/{bookId}` genres/authors)
   * - Followed writers/readers (`follows` where `followerId == uid`)
   * - Saved/favorited posts (`users/{uid}/favoritePosts`)
   * - User profile titles/bio & joined communities
   */
  private async ensureUserPlatformInterestsLoaded(currentUserId?: string): Promise<void> {
    if (!currentUserId) {
      this.interestGraph = null;
      return;
    }
    if (this.interestGraph?.loadedForUid === currentUserId) return;
    if (this.interestGraphPromise) {
      await this.interestGraphPromise;
      if (this.interestGraph?.loadedForUid === currentUserId) return;
    }

    const loadTask = async () => {
      const graph: UserPlatformInterestGraph = {
        loadedForUid: currentUserId,
        followedAuthorIds: new Set<string>(),
        libraryAuthorIds: new Set<string>(),
        libraryAuthorNames: new Set<string>(),
        savedAuthorIds: new Set<string>(),
        savedCommunityIds: new Set<string>(),
        preferredGenresAndCategories: new Map<string, number>(),
        preferredKeywords: new Map<string, number>(),
      };

      const bumpCategory = (raw?: string, weight = 4) => {
        if (!raw) return;
        const norm = normalizeToken(raw);
        if (!norm) return;
        graph.preferredGenresAndCategories.set(
          norm,
          (graph.preferredGenresAndCategories.get(norm) || 0) + weight
        );
      };

      const bumpKeywords = (text?: string, weight = 2) => {
        extractMeaningfulTokens(text, 10).forEach((tok) => {
          graph.preferredKeywords.set(
            tok,
            (graph.preferredKeywords.get(tok) || 0) + weight
          );
        });
      };

      await Promise.all([
        // 1. User's Library items + Book genres/authors
        (async () => {
          try {
            const libSnap = await getDocs(
              query(collection(db, 'libraries', currentUserId, 'items'), limit(25))
            );
            const bookIdsToInspect: { id: string; weight: number }[] = [];
            libSnap.forEach((d) => {
              const li = d.data() as Partial<LibraryItem>;
              const statusBoost =
                li.status === 'favorite'
                  ? 8
                  : li.status === 'completed'
                  ? 7
                  : li.status === 'reading'
                  ? 5 + Math.min(3, (li.progressPercent || 0) / 35)
                  : 4;
              if (li.authorName) {
                graph.libraryAuthorNames.add(normalizeToken(li.authorName));
              }
              bumpKeywords(li.bookTitle, statusBoost * 0.55);
              const bid = li.bookId || d.id;
              if (bid && bookIdsToInspect.length < 10) {
                bookIdsToInspect.push({ id: bid, weight: statusBoost });
              }
            });

            await Promise.all(
              bookIdsToInspect.map(async ({ id, weight }) => {
                try {
                  const bSnap = await getDoc(doc(db, 'books', id));
                  if (bSnap.exists()) {
                    const bData = bSnap.data() as Partial<Book>;
                    if (bData.authorId) {
                      graph.libraryAuthorIds.add(bData.authorId);
                    }
                    if (Array.isArray(bData.genres)) {
                      bData.genres.forEach((g) => bumpCategory(g, weight));
                    }
                    bumpKeywords(bData.synopsis, weight * 0.25);
                  }
                } catch {
                  // ignore individual book error
                }
              })
            );
          } catch {
            // ignore library error
          }
        })(),

        // 2. Followed authors/users
        (async () => {
          try {
            const folSnap = await getDocs(
              query(
                collection(db, 'follows'),
                where('followerId', '==', currentUserId),
                limit(40)
              )
            );
            folSnap.forEach((d) => {
              const fData = d.data() as { followingId?: string };
              if (fData.followingId) {
                graph.followedAuthorIds.add(fData.followingId);
              }
            });
          } catch {
            // ignore follows error
          }
        })(),

        // 3. Saved / Favorite posts
        (async () => {
          try {
            const favSnap = await getDocs(
              query(
                collection(db, 'users', currentUserId, 'favoritePosts'),
                limit(35)
              )
            );
            favSnap.forEach((d) => {
              const fav = d.data() as Partial<FavoritePostRecord>;
              if (fav.authorId) graph.savedAuthorIds.add(fav.authorId);
              if (fav.communityId) graph.savedCommunityIds.add(fav.communityId);
              bumpKeywords(fav.communityName, 3.5);
              bumpKeywords(fav.contentPreview, 2.5);
            });
          } catch {
            // ignore favoritePosts error
          }
        })(),

        // 4. Own user profile bio/titles
        (async () => {
          try {
            const uSnap = await getDoc(doc(db, 'users', currentUserId));
            if (uSnap.exists()) {
              const uData = uSnap.data() as Partial<UserProfile>;
              bumpKeywords(uData.bio, 2);
              if (Array.isArray(uData.titles)) {
                uData.titles.forEach((t) => bumpKeywords(t, 1.5));
              }
            }
          } catch {
            // ignore user profile error
          }
        })(),
      ]);

      this.interestGraph = graph;
    };

    this.interestGraphPromise = loadTask();
    try {
      await this.interestGraphPromise;
    } finally {
      this.interestGraphPromise = null;
    }
  }

  private ensureDismissedLoaded(currentUserId?: string) {
    const scope = this.getScope(currentUserId);
    if (this.dismissedStorageLoadedFor === scope) return;
    this.dismissedStorageLoadedFor = scope;
    this.dismissedAtMap.clear();
    try {
      const raw = localStorage.getItem(`kordel_flux_temp_dismissed_${scope}`);
      if (raw) {
        const parsed = JSON.parse(raw) as Record<string, number>;
        const now = Date.now();
        Object.entries(parsed).forEach(([k, ts]) => {
          if (typeof ts === 'number' && now - ts < FluxEngine.TEMP_DISMISS_COOLDOWN_MS) {
            this.dismissedAtMap.set(k, ts);
          }
        });
      }
    } catch {
      // ignore storage errors
    }
  }

  private persistDismissed(currentUserId?: string) {
    const scope = this.getScope(currentUserId);
    try {
      const now = Date.now();
      const serializable: Record<string, number> = {};
      this.dismissedAtMap.forEach((ts, k) => {
        if (now - ts < FluxEngine.TEMP_DISMISS_COOLDOWN_MS) {
          serializable[k] = ts;
        } else {
          this.dismissedAtMap.delete(k);
        }
      });
      localStorage.setItem(
        `kordel_flux_temp_dismissed_${scope}`,
        JSON.stringify(serializable)
      );
    } catch {
      // ignore storage errors
    }
  }

  public markSeen(item: FluxFeedItem, currentUserId?: string) {
    this.ensureSessionStateLoaded(currentUserId);
    const key = getFluxItemKey(item);
    if (!this.sessionSeenKeys.has(key)) {
      this.sessionSeenKeys.add(key);
      this.persistSessionState(currentUserId);
    }
  }

  public markTemporarilyDismissed(item: FluxFeedItem, currentUserId?: string) {
    this.ensureDismissedLoaded(currentUserId);
    const key = getFluxItemKey(item);
    this.dismissedAtMap.set(key, Date.now());
    this.persistDismissed(currentUserId);
    this.recordEngagementSignal(item, 'dismiss', currentUserId);
  }

  public updateItemInPool(key: string, updater: (prev: FluxFeedItem) => FluxFeedItem) {
    const existing = this.pool.get(key);
    if (existing) {
      this.pool.set(key, updater(existing));
    }
  }

  public removeItemFromPool(key: string) {
    this.pool.delete(key);
    this.dismissedAtMap.delete(key);
  }

  public insertNewlyPublishedItem(item: FluxFeedItem) {
    const key = getFluxItemKey(item);
    this.pool.set(key, item);
    this.dismissedAtMap.delete(key);
  }

  private isDeveloper = false;
  private userActiveCommunityIds = new Set<string>();
  private checkedMembershipCommIds = new Map<string, Set<string>>();

  public setDeveloperFlag(isDev: boolean) {
    this.isDeveloper = isDev;
  }

  public registerActiveMembership(communityId: string, currentUserId?: string) {
    if (!communityId) return;
    this.userActiveCommunityIds.add(communityId);
    if (currentUserId) {
      const checked = this.checkedMembershipCommIds.get(currentUserId) || new Set<string>();
      checked.add(communityId);
      this.checkedMembershipCommIds.set(currentUserId, checked);
    }
  }

  private async verifyMembershipsForCommunities(
    commIds: string[],
    currentUserId?: string
  ): Promise<void> {
    if (!currentUserId || commIds.length === 0) return;

    let checkedSet = this.checkedMembershipCommIds.get(currentUserId);
    if (!checkedSet) {
      checkedSet = new Set<string>();
      this.checkedMembershipCommIds.set(currentUserId, checkedSet);
      this.userActiveCommunityIds.clear();
    }

    const unchecked = Array.from(new Set(commIds)).filter(
      (cid) => cid && !checkedSet!.has(cid)
    );
    if (unchecked.length === 0) return;

    await Promise.all(
      unchecked.map(async (cid) => {
        checkedSet!.add(cid);
        const comm = this.communitiesMap.get(cid);
        if (comm?.creatorId === currentUserId) {
          this.userActiveCommunityIds.add(cid);
          return;
        }
        try {
          const snap = await getDoc(
            doc(db, 'communities', cid, 'members', currentUserId)
          );
          if (snap.exists()) {
            const mData = snap.data() as Partial<CommunityMember>;
            if (mData.status !== 'pending' && mData.status !== 'banned') {
              this.userActiveCommunityIds.add(cid);
            }
          }
        } catch {
          // ignore
        }
      })
    );
  }

  public getCommunitiesSnapshot(currentUserId?: string): Community[] {
    return Array.from(this.communitiesMap.values()).filter((c) => {
      if (!c.isHiddenFromNonMembers) return true;
      if (this.isDeveloper) return true;
      if (currentUserId && (c.creatorId === currentUserId || this.userActiveCommunityIds.has(c.id))) {
        return true;
      }
      return false;
    });
  }

  public hasMoreRemoteData(): boolean {
    if (!this.fluxRecentExhausted || !this.fluxEngageExhausted || !this.commExhausted) {
      return true;
    }
    for (const cid of this.orderedCommIds) {
      if (!this.commRecentExhausted.has(cid) || !this.commEngageExhausted.has(cid)) {
        return true;
      }
    }
    return false;
  }

  private isUserMemberOrOwnerOfCommunity(commId: string, creatorId?: string, currentUserId?: string): boolean {
    if (this.isDeveloper) return true;
    if (!currentUserId || !commId) return false;
    if (creatorId && creatorId === currentUserId) return true;
    const comm = this.communitiesMap.get(commId);
    if (comm?.creatorId === currentUserId) return true;
    return this.userActiveCommunityIds.has(commId);
  }

  private isValidAndAccessible(item: FluxFeedItem, currentUserId?: string): boolean {
    if (!item || !item.id || !item.authorId) return false;

    const hasText = typeof item.content === 'string' && item.content.trim().length > 0;
    const hasMedia = extractPostMediaItems(item).length > 0;
    const hasPoll = Boolean(item.poll && item.poll.options?.length);
    const hasStoryTexts = Boolean(
      item.storyCanvas?.texts?.some(
        (t) => typeof t.text === 'string' && t.text.trim().length > 0
      )
    );
    if (!hasText && !hasMedia && !hasPoll && !hasStoryTexts) return false;

    if (currentUserId) {
      if (item.communityBannedUserIds?.includes(currentUserId)) return false;
    }

    if (this.bannedAuthorCache.get(item.authorId) === true) {
      return false;
    }

    const isAuthor = Boolean(currentUserId && item.authorId === currentUserId);
    const canBypass = this.isDeveloper || isAuthor;

    if (item.communityId) {
      const isMember = this.isUserMemberOrOwnerOfCommunity(
        item.communityId,
        item.communityCreatorId,
        currentUserId
      );
      const comm = this.communitiesMap.get(item.communityId);
      const commPrivate = Boolean(item.communityIsPrivate ?? comm?.isPrivate);
      const commHidden = Boolean(item.communityIsHidden ?? comm?.isHiddenFromNonMembers);
      const commHidePosts = Boolean(item.communityHidePosts ?? comm?.hidePostsFromNonMembers);

      if ((commPrivate || commHidden || commHidePosts) && !isMember && !canBypass) {
        return false;
      }
      if ((item.isPrivate || item.isHiddenFromNonMembers) && !isMember && !canBypass) {
        return false;
      }
    } else {
      if ((item.isPrivate || item.isHiddenFromNonMembers) && !canBypass) {
        return false;
      }
    }

    return true;
  }

  /**
   * Returns active (non-cooled-down) posts and cooled-down posts (ordered oldest-dismissed first).
   * Guarantees Flux NEVER becomes empty: if all posts were dismissed with "X", cooled-down posts
   * automatically return starting with the oldest dismissed!
   */
  private getCandidatePools(currentUserId?: string): {
    active: FluxFeedItem[];
    cooledDown: FluxFeedItem[];
    effective: FluxFeedItem[];
  } {
    this.ensureDismissedLoaded(currentUserId);
    const now = Date.now();
    const allValid = Array.from(this.pool.values()).filter((item) =>
      this.isValidAndAccessible(item, currentUserId)
    );

    const active: FluxFeedItem[] = [];
    const cooledWithTs: { item: FluxFeedItem; ts: number }[] = [];
    let expiredAny = false;

    for (const item of allValid) {
      const k = getFluxItemKey(item);
      const dismissedTs = this.dismissedAtMap.get(k);
      if (typeof dismissedTs === 'number') {
        if (now - dismissedTs < FluxEngine.TEMP_DISMISS_COOLDOWN_MS) {
          cooledWithTs.push({ item, ts: dismissedTs });
          continue;
        } else {
          this.dismissedAtMap.delete(k);
          expiredAny = true;
        }
      }
      active.push(item);
    }

    if (expiredAny) {
      this.persistDismissed(currentUserId);
    }

    cooledWithTs.sort((a, b) => a.ts - b.ts);
    const cooledDown = cooledWithTs.map((entry) => entry.item);

    if (active.length === 0 && cooledDown.length > 0) {
      cooledDown.forEach((it) => this.dismissedAtMap.delete(getFluxItemKey(it)));
      this.persistDismissed(currentUserId);
      return { active: cooledDown, cooledDown: [], effective: cooledDown };
    }

    return { active, cooledDown, effective: active };
  }

  private async verifyAuthorsNotBanned(authorIds: string[]): Promise<void> {
    const unchecked = Array.from(new Set(authorIds)).filter(
      (uid) => uid && !this.bannedAuthorCache.has(uid)
    );
    if (unchecked.length === 0) return;

    await Promise.all(
      unchecked.slice(0, 15).map(async (uid) => {
        try {
          const snap = await getDoc(doc(db, 'users', uid));
          if (snap.exists()) {
            const data = snap.data() as Partial<UserProfile>;
            this.bannedAuthorCache.set(uid, Boolean(data.isBanned));
          } else {
            this.bannedAuthorCache.set(uid, false);
          }
        } catch {
          this.bannedAuthorCache.set(uid, false);
        }
      })
    );
  }

  private async loadMoreCommunitiesBatch(currentUserId?: string): Promise<void> {
    if (this.commExhausted) return;

    try {
      const constraints: any[] = [orderBy('membersCount', 'desc'), limit(8)];
      if (this.commCursor) {
        constraints.splice(1, 0, startAfter(this.commCursor));
      }
      const q = query(collection(db, 'communities'), ...constraints);
      const snap = await getDocs(q);

      if (snap.empty) {
        this.commExhausted = true;
        return;
      }

      if (snap.docs.length < 8) {
        this.commExhausted = true;
      }
      this.commCursor = snap.docs[snap.docs.length - 1];

      for (const d of snap.docs) {
        const comm = d.data() as Community;
        if (!comm?.id) continue;
        if (currentUserId && comm.bannedUserIds?.includes(currentUserId)) {
          continue;
        }
        this.communitiesMap.set(comm.id, comm);
        if (!this.orderedCommIds.includes(comm.id)) {
          this.orderedCommIds.push(comm.id);
        }
      }
    } catch (err) {
      console.warn('[FluxEngine] Notice loading communities page:', err);
      this.commExhausted = true;
    }
  }

  /**
   * Fetches the next incremental batch of recent & high-engagement posts from
   * both `/fluxPosts` and accessible `/communities/{id}/posts`.
   */
  public async fetchNextPoolBatch(currentUserId?: string): Promise<void> {
    this.ensureSessionStateLoaded(currentUserId);
    this.ensureTelemetryLoaded(currentUserId);
    await this.ensureUserPlatformInterestsLoaded(currentUserId);

    const discoveredAuthors: string[] = [];

    // 1. Standalone /fluxPosts - Recent batch
    if (!this.fluxRecentExhausted) {
      try {
        const constraints: any[] = [orderBy('createdAt', 'desc'), limit(14)];
        if (this.fluxRecentCursor) {
          constraints.splice(1, 0, startAfter(this.fluxRecentCursor));
        }
        const snap = await getDocs(query(collection(db, 'fluxPosts'), ...constraints));
        if (snap.docs.length < 14) {
          this.fluxRecentExhausted = true;
        }
        if (!snap.empty) {
          this.fluxRecentCursor = snap.docs[snap.docs.length - 1];
          snap.docs.forEach((d) => {
            const raw = d.data() as CommunityPost;
            const item: FluxFeedItem = {
              ...raw,
              id: raw.id || d.id,
              communityId: raw.communityId || '',
              postSource: 'flux',
            };
            discoveredAuthors.push(item.authorId);
            this.pool.set(getFluxItemKey(item), item);
          });
        }
      } catch (err) {
        console.warn('[FluxEngine] Notice loading recent fluxPosts:', err);
        this.fluxRecentExhausted = true;
      }
    }

    // 2. Standalone /fluxPosts - Engagement batch (fetches older high-reach/engagement posts)
    if (!this.fluxEngageExhausted) {
      try {
        const constraints: any[] = [orderBy('likesCount', 'desc'), limit(16)];
        if (this.fluxEngageCursor) {
          constraints.splice(1, 0, startAfter(this.fluxEngageCursor));
        }
        const snap = await getDocs(query(collection(db, 'fluxPosts'), ...constraints));
        if (snap.docs.length < 16) {
          this.fluxEngageExhausted = true;
        }
        if (!snap.empty) {
          this.fluxEngageCursor = snap.docs[snap.docs.length - 1];
          snap.docs.forEach((d) => {
            const raw = d.data() as CommunityPost;
            const item: FluxFeedItem = {
              ...raw,
              id: raw.id || d.id,
              communityId: raw.communityId || '',
              postSource: 'flux',
            };
            discoveredAuthors.push(item.authorId);
            this.pool.set(getFluxItemKey(item), item);
          });
        }
      } catch (err) {
        console.warn('[FluxEngine] Notice loading engaged fluxPosts:', err);
        this.fluxEngageExhausted = true;
      }
    }

    // 3. Ensure we have accessible communities loaded
    if (
      this.orderedCommIds.length === 0 ||
      (this.commScanIndex >= this.orderedCommIds.length && !this.commExhausted)
    ) {
      await this.loadMoreCommunitiesBatch(currentUserId);
    }

    // 4. Incrementally sample up to 6 communities per batch (both recent + engagement cursors)
    if (this.orderedCommIds.length > 0) {
      const batchCommIds: string[] = [];
      const countToScan = Math.min(6, this.orderedCommIds.length);
      for (let i = 0; i < countToScan; i++) {
        const cid =
          this.orderedCommIds[(this.commScanIndex + i) % this.orderedCommIds.length];
        if (
          !this.commRecentExhausted.has(cid) ||
          !this.commEngageExhausted.has(cid)
        ) {
          batchCommIds.push(cid);
        }
      }
      this.commScanIndex =
        (this.commScanIndex + countToScan) % Math.max(1, this.orderedCommIds.length);

      if (batchCommIds.length === 0 && !this.commExhausted) {
        await this.loadMoreCommunitiesBatch(currentUserId);
      }

      await this.verifyMembershipsForCommunities(batchCommIds, currentUserId);

      await Promise.all(
        batchCommIds.map(async (cid) => {
          const comm = this.communitiesMap.get(cid);
          if (!comm) return;

          const isMember = this.isUserMemberOrOwnerOfCommunity(
            cid,
            comm.creatorId,
            currentUserId
          );
          if (
            (comm.isPrivate || comm.isHiddenFromNonMembers || comm.hidePostsFromNonMembers) &&
            !isMember
          ) {
            this.commRecentExhausted.add(cid);
            this.commEngageExhausted.add(cid);
            return;
          }

          const commCover = comm.iconUrl || comm.avatarUrl || comm.coverUrl || comm.bannerUrl || '';

          // Recent posts from community
          if (!this.commRecentExhausted.has(cid)) {
            try {
              const cursor = this.commRecentCursors.get(cid) || null;
              const constraints: any[] = [orderBy('createdAt', 'desc'), limit(6)];
              if (cursor) constraints.splice(1, 0, startAfter(cursor));

              const snap = await getDocs(
                query(collection(db, 'communities', cid, 'posts'), ...constraints)
              );
              if (snap.docs.length < 6) {
                this.commRecentExhausted.add(cid);
              }
              if (!snap.empty) {
                this.commRecentCursors.set(cid, snap.docs[snap.docs.length - 1]);
                snap.docs.forEach((d) => {
                  const raw = d.data() as CommunityPost;
                  const item: FluxFeedItem = {
                    ...raw,
                    id: raw.id || d.id,
                    communityId: cid,
                    postSource: 'community',
                    communityName: comm.name,
                    communityCoverUrl: commCover,
                    communityCreatorId: comm.creatorId,
                    communityBannedUserIds: comm.bannedUserIds,
                    communityIsPrivate: Boolean(comm.isPrivate),
                    communityIsHidden: Boolean(comm.isHiddenFromNonMembers),
                    communityHidePosts: Boolean(comm.hidePostsFromNonMembers),
                  };
                  discoveredAuthors.push(item.authorId);
                  this.pool.set(getFluxItemKey(item), item);
                });
              }
            } catch {
              this.commRecentExhausted.add(cid);
            }
          }

          // Engaged posts from community
          if (!this.commEngageExhausted.has(cid)) {
            try {
              const cursor = this.commEngageCursors.get(cid) || null;
              const constraints: any[] = [orderBy('likesCount', 'desc'), limit(8)];
              if (cursor) constraints.splice(1, 0, startAfter(cursor));

              const snap = await getDocs(
                query(collection(db, 'communities', cid, 'posts'), ...constraints)
              );
              if (snap.docs.length < 8) {
                this.commEngageExhausted.add(cid);
              }
              if (!snap.empty) {
                this.commEngageCursors.set(cid, snap.docs[snap.docs.length - 1]);
                snap.docs.forEach((d) => {
                  const raw = d.data() as CommunityPost;
                  const item: FluxFeedItem = {
                    ...raw,
                    id: raw.id || d.id,
                    communityId: cid,
                    postSource: 'community',
                    communityName: comm.name,
                    communityCoverUrl: commCover,
                    communityCreatorId: comm.creatorId,
                    communityBannedUserIds: comm.bannedUserIds,
                    communityIsPrivate: Boolean(comm.isPrivate),
                    communityIsHidden: Boolean(comm.isHiddenFromNonMembers),
                    communityHidePosts: Boolean(comm.hidePostsFromNonMembers),
                  };
                  discoveredAuthors.push(item.authorId);
                  this.pool.set(getFluxItemKey(item), item);
                });
              }
            } catch {
              this.commEngageExhausted.add(cid);
            }
          }
        })
      );
    }

    await this.verifyAuthorsNotBanned(discoveredAuthors);
  }

  private tieHash(key: string, gen: number): number {
    let h = (gen + 1) * 2654435761;
    for (let i = 0; i < key.length; i++) {
      h = Math.imul(h ^ key.charCodeAt(i), 1597334677);
    }
    h ^= h >>> 16;
    return h >>> 0;
  }

  private unitJitter(key: string, seed: number): number {
    return (this.tieHash(key, seed) % 10000) / 10000;
  }

  private permuteItems(items: FluxFeedItem[], seed: number): FluxFeedItem[] {
    const arr = [...items];
    let state = (seed * 1664525 + 1013904223) >>> 0;
    for (let i = arr.length - 1; i > 0; i--) {
      state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
      const j = state % (i + 1);
      const tmp = arr[i];
      arr[i] = arr[j];
      arr[j] = tmp;
    }
    return arr;
  }

  /**
   * Computes personalized recommendation score combining:
   * 1. Reach & Real Engagement (likes, comments, poll participation, community reach)
   * 2. User Platform Consumption Affinity (followed writers, library book authors & genres,
   *    saved posts, joined communities & categories, previously liked/disliked posts)
   * 3. Behavioral Flux Telemetry (dwell watch/read time, likes, saves, comments, skips, dismissals)
   * 4. Controlled exploration shuffle seeded by session openGeneration so every close/reopen or
   *    pull-up reorganization creates a fresh sequence combination!
   */
  private computeRecommendationScore(
    item: FluxFeedItem,
    currentUserId: string | undefined,
    generationSeed: number,
    mode: 'older_reach_engagement' | 'recent_under_3d'
  ): number {
    const key = getFluxItemKey(item);
    const comm = item.communityId ? this.communitiesMap.get(item.communityId) : undefined;

    // 1. Reach & Engagement base
    const likes = Math.max(0, item.likesCount || 0);
    const comments = Math.max(0, item.commentsCount || 0);
    const pollVotes = Math.max(0, item.poll?.totalVotes || 0);
    const dislikes = Math.max(0, item.dislikesCount || 0);
    const commMembers = Math.max(1, comm?.membersCount || 1);

    const rawEngagement = likes * 3.4 + comments * 5.2 + pollVotes * 2.4 - dislikes * 1.8;
    const reachBoost =
      Math.log1p(Math.max(0, rawEngagement)) * 6.5 +
      (item.communityId ? Math.log1p(commMembers) * 2.6 : 2.2);

    // 2. User Platform Consumption Affinity
    let affinity = 0;
    const graph = this.interestGraph;

    if (currentUserId && graph && graph.loadedForUid === currentUserId) {
      if (graph.followedAuthorIds.has(item.authorId)) {
        affinity += 28;
      }
      if (
        graph.libraryAuthorIds.has(item.authorId) ||
        (item.authorName && graph.libraryAuthorNames.has(normalizeToken(item.authorName)))
      ) {
        affinity += 24;
      }
      if (graph.savedAuthorIds.has(item.authorId)) {
        affinity += 15;
      }
      if (item.communityId) {
        if (this.userActiveCommunityIds.has(item.communityId)) {
          affinity += 18;
        }
        if (graph.savedCommunityIds.has(item.communityId)) {
          affinity += 14;
        }
      }

      // Genre / Category overlap with user's read books & active communities
      const commCatNorm = comm?.category ? normalizeToken(comm.category) : '';
      if (commCatNorm) {
        const catWeight = graph.preferredGenresAndCategories.get(commCatNorm) || 0;
        affinity += Math.min(22, catWeight * 2.2);

        // Also boost if user is a member of other communities in the same category
        for (const joinedCid of this.userActiveCommunityIds) {
          const joinedComm = this.communitiesMap.get(joinedCid);
          if (joinedComm && normalizeToken(joinedComm.category || '') === commCatNorm) {
            affinity += 6;
            break;
          }
        }
      }

      // Keyword / Topic overlap with user's library books, synopses, saved posts, and bio
      const storyText =
        item.storyCanvas?.texts?.map((t) => t.text).join(' ') || '';
      const postTokens = extractMeaningfulTokens(
        `${item.content || ''} ${storyText} ${item.communityName || ''} ${comm?.category || ''}`,
        14
      );
      let keywordMatchBoost = 0;
      for (const tok of postTokens) {
        const gCat = graph.preferredGenresAndCategories.get(tok) || 0;
        const gKw = graph.preferredKeywords.get(tok) || 0;
        if (gCat > 0) keywordMatchBoost += Math.min(8, gCat * 1.4);
        if (gKw > 0) keywordMatchBoost += Math.min(5, gKw * 1.1);
      }
      affinity += Math.min(28, keywordMatchBoost);
    }

    // Direct historical post likes / dislikes by this user
    if (currentUserId) {
      if (item.dislikedUserIds?.includes(currentUserId)) {
        affinity -= 22;
      } else if (item.likedUserIds?.includes(currentUserId)) {
        // Slight familiarity bonus on author/topic while letting unliked fresh recommendations shine too
        affinity += 4;
      }
    }

    // 3. Real-time Flux Behavioral Telemetry
    const authorTel = this.telemetry.authorWeights[item.authorId] || 0;
    const commTel = item.communityId
      ? this.telemetry.communityWeights[item.communityId] || 0
      : 0;
    const catTel = comm?.category
      ? this.telemetry.categoryWeights[normalizeToken(comm.category)] || 0
      : 0;
    const formatTel =
      this.telemetry.formatWeights[detectPostFormatBucket(item)] || 0;
    const directTel = this.telemetry.postDirectWeights[key] || 0;

    let topicTel = 0;
    const storyTextForTel =
      item.storyCanvas?.texts?.map((t) => t.text).join(' ') || '';
    const telTokens = extractMeaningfulTokens(
      `${item.content || ''} ${storyTextForTel}`,
      8
    );
    for (const tok of telTokens) {
      topicTel += (this.telemetry.topicWeights[tok] || 0) * 0.45;
    }

    const behavioralScore =
      authorTel * 0.9 +
      commTel * 0.85 +
      catTel * 0.75 +
      formatTel * 0.7 +
      Math.max(-15, Math.min(22, topicTel)) +
      directTel;

    // 4. Recency bonus for < 3d mode + exploration shuffle jitter
    let recencyBoost = 0;
    if (mode === 'recent_under_3d') {
      const createdMs = new Date(item.createdAt || 0).getTime() || 0;
      const ageHours = Math.max(0, (Date.now() - createdMs) / (1000 * 60 * 60));
      recencyBoost = Math.max(0, 72 - ageHours) * 0.42;
    }

    // Exploration band jitter (16-24 pts) guarantees fresh shuffled combinations among top relevant posts
    const explorationJitter = this.unitJitter(key, generationSeed) * 22;

    const unseenBonus = this.sessionSeenKeys.has(key) ? 0 : 14;

    if (mode === 'recent_under_3d') {
      return (
        affinity * 1.15 +
        behavioralScore +
        recencyBoost +
        reachBoost * 0.75 +
        unseenBonus +
        explorationJitter
      );
    }

    return (
      reachBoost * 1.45 +
      rawEngagement * 0.55 +
      affinity * 1.2 +
      behavioralScore +
      unseenBonus +
      explorationJitter
    );
  }

  /**
   * Refreshes top recent posts from Firestore so manual/pull-up refreshes pick up newly published posts.
   */
  public async refreshLatestHead(currentUserId?: string): Promise<void> {
    const discoveredAuthors: string[] = [];
    try {
      const snap = await getDocs(
        query(collection(db, 'fluxPosts'), orderBy('createdAt', 'desc'), limit(10))
      );
      snap.docs.forEach((d) => {
        const raw = d.data() as CommunityPost;
        const item: FluxFeedItem = {
          ...raw,
          id: raw.id || d.id,
          communityId: raw.communityId || '',
          postSource: 'flux',
        };
        discoveredAuthors.push(item.authorId);
        this.pool.set(getFluxItemKey(item), item);
      });
    } catch {
      // ignore
    }

    const sampleComms = this.orderedCommIds.slice(0, 4);
    await this.verifyMembershipsForCommunities(sampleComms, currentUserId);
    await Promise.all(
      sampleComms.map(async (cid) => {
        const comm = this.communitiesMap.get(cid);
        if (!comm) return;
        const isMember = this.isUserMemberOrOwnerOfCommunity(
          cid,
          comm.creatorId,
          currentUserId
        );
        if (
          (comm.isPrivate || comm.isHiddenFromNonMembers || comm.hidePostsFromNonMembers) &&
          !isMember
        ) {
          return;
        }
        const commCover =
          comm.iconUrl || comm.avatarUrl || comm.coverUrl || comm.bannerUrl || '';
        try {
          const snap = await getDocs(
            query(
              collection(db, 'communities', cid, 'posts'),
              orderBy('createdAt', 'desc'),
              limit(4)
            )
          );
          snap.docs.forEach((d) => {
            const raw = d.data() as CommunityPost;
            const item: FluxFeedItem = {
              ...raw,
              id: raw.id || d.id,
              communityId: cid,
              postSource: 'community',
              communityName: comm.name,
              communityCoverUrl: commCover,
              communityCreatorId: comm.creatorId,
              communityBannedUserIds: comm.bannedUserIds,
              communityIsPrivate: Boolean(comm.isPrivate),
              communityIsHidden: Boolean(comm.isHiddenFromNonMembers),
              communityHidePosts: Boolean(comm.hidePostsFromNonMembers),
            };
            discoveredAuthors.push(item.authorId);
            this.pool.set(getFluxItemKey(item), item);
          });
        } catch {
          // ignore
        }
      })
    );

    await this.verifyAuthorsNotBanned(discoveredAuthors);
  }

  /**
   * Builds an alternated cycle of existing posts obeying the 5 older recommended + 1 (< 3 days) cadence
   * so infinite downward scroll never ends and each cycle presents posts in a genuinely new combination.
   */
  public buildAlternatedCycle(
    candidates: FluxFeedItem[],
    avoidFirstKey: string | null,
    seed: number,
    currentUserId?: string
  ): FluxFeedItem[] {
    if (candidates.length === 0) return [];
    if (candidates.length === 1) return [candidates[0]];

    const nowMs = Date.now();
    const olderRaw = candidates.filter((it) => !isPostPublishedUnderThreeDays(it, nowMs));
    const recentRaw = candidates.filter((it) => isPostPublishedUnderThreeDays(it, nowMs));

    const olderShuffled = this.permuteItems(olderRaw, seed * 31 + 7);
    const recentShuffled = this.permuteItems(recentRaw, seed * 53 + 19);

    if (olderShuffled.length === 0 || recentShuffled.length === 0) {
      const flat = this.permuteItems(candidates, seed);
      if (avoidFirstKey && getFluxItemKey(flat[0]) === avoidFirstKey) {
        const swapIdx = flat.findIndex((it) => getFluxItemKey(it) !== avoidFirstKey);
        if (swapIdx > 0) {
          const tmp = flat[0];
          flat[0] = flat[swapIdx];
          flat[swapIdx] = tmp;
        }
      }
      return flat;
    }

    // Interleave 5 older + 1 (< 3 days) across the cycle
    const cycled: FluxFeedItem[] = [];
    let oIdx = 0;
    let rIdx = 0;
    let streak = 0;

    while (oIdx < olderShuffled.length || rIdx < recentShuffled.length) {
      if (streak >= 5 && rIdx < recentShuffled.length) {
        cycled.push(recentShuffled[rIdx++]);
        streak = 0;
      } else if (oIdx < olderShuffled.length) {
        cycled.push(olderShuffled[oIdx++]);
        streak += 1;
      } else if (rIdx < recentShuffled.length) {
        cycled.push(recentShuffled[rIdx++]);
        streak = 0;
      }
    }

    if (avoidFirstKey && cycled.length > 1 && getFluxItemKey(cycled[0]) === avoidFirstKey) {
      const swapIdx = cycled.findIndex((it) => getFluxItemKey(it) !== avoidFirstKey);
      if (swapIdx > 0) {
        const tmp = cycled[0];
        cycled[0] = cycled[swapIdx];
        cycled[swapIdx] = tmp;
      }
    }

    void currentUserId;
    return cycled;
  }

  /**
   * Selects a lead post (first post shown at index 0) that NEVER repeats any post that already
   * appeared as first post before closing Flux (`shownLeadKeys`), unless all accessible posts have
   * already served as lead — and even then, never repeats `forbiddenImmediateKey` back-to-back!
   */
  private pickFreshLeadPost(
    rankedOlder: FluxFeedItem[],
    rankedRecentUnder3d: FluxFeedItem[],
    totalCandidatesCount: number,
    forbiddenImmediateKey: string | null,
    generationSeed: number
  ): FluxFeedItem | null {
    // Combine top personalized older & recent candidates with older prioritized first so cadence starts cleanly
    const combinedRanked = [...rankedOlder, ...rankedRecentUnder3d];
    if (combinedRanked.length === 0) return null;
    if (combinedRanked.length === 1) return combinedRanked[0];

    const shownLeadsSet = new Set(this.persistedSession.shownLeadKeys);

    const notImmediate = combinedRanked.filter(
      (it) => !forbiddenImmediateKey || getFluxItemKey(it) !== forbiddenImmediateKey
    );
    const poolBase = notImmediate.length > 0 ? notImmediate : combinedRanked;

    // Tier 1: Never shown as first post before AND never seen at all
    const unseenFreshLeads = poolBase.filter((it) => {
      const k = getFluxItemKey(it);
      return !shownLeadsSet.has(k) && !this.sessionSeenKeys.has(k);
    });

    if (unseenFreshLeads.length > 0) {
      const topWindow = unseenFreshLeads.slice(0, Math.min(5, unseenFreshLeads.length));
      const shuffledTop = this.permuteItems(topWindow, generationSeed * 79 + 11);
      return shuffledTop[0];
    }

    // Tier 2: Never shown as first post before closing Flux
    const neverLeadBefore = poolBase.filter(
      (it) => !shownLeadsSet.has(getFluxItemKey(it))
    );

    if (neverLeadBefore.length > 0) {
      const topWindow = neverLeadBefore.slice(0, Math.min(6, neverLeadBefore.length));
      const shuffledTop = this.permuteItems(topWindow, generationSeed * 83 + 23);
      return shuffledTop[0];
    }

    // Tier 3: All accessible posts have already appeared as first post -> reset lead cycle while
    // strictly excluding `forbiddenImmediateKey` so the previous lead NEVER repeats back-to-back!
    this.persistedSession.shownLeadKeys =
      forbiddenImmediateKey && totalCandidatesCount > 1 ? [forbiddenImmediateKey] : [];

    const rotatedPool = this.permuteItems(poolBase, generationSeed * 97 + 41);
    return rotatedPool[0];
  }

  /**
   * Assembles a recommended sequence chunk obeying:
   * - Personalized engagement & platform consumption ranking + exploration shuffle
   * - Strict cadence: 1 post published in < 3 days for every 5 older (>= 3 days) recommended posts
   */
  private assembleRecommendedCadenceChunk(
    allEffectiveItems: FluxFeedItem[],
    existingSequenceKeys: Set<string>,
    desiredCount: number,
    currentUserId: string | undefined,
    generationSeed: number,
    options: {
      isFreshLead: boolean;
      forbiddenLeadKey: string | null;
      avoidBoundaryKey: string | null;
      initialOlderStreak: number;
    }
  ): { items: FluxFeedItem[]; nextOlderStreak: number } {
    const unused = allEffectiveItems.filter(
      (it) => !existingSequenceKeys.has(getFluxItemKey(it))
    );
    if (unused.length === 0) {
      return { items: [], nextOlderStreak: options.initialOlderStreak };
    }

    const nowMs = Date.now();
    const olderUnused = unused.filter((it) => !isPostPublishedUnderThreeDays(it, nowMs));
    const recentUnder3dUnused = unused.filter((it) =>
      isPostPublishedUnderThreeDays(it, nowMs)
    );
    const allRecentUnder3d = allEffectiveItems.filter((it) =>
      isPostPublishedUnderThreeDays(it, nowMs)
    );

    const scoreMap = new Map<string, number>();
    olderUnused.forEach((it) => {
      scoreMap.set(
        getFluxItemKey(it),
        this.computeRecommendationScore(
          it,
          currentUserId,
          generationSeed,
          'older_reach_engagement'
        )
      );
    });
    recentUnder3dUnused.forEach((it) => {
      scoreMap.set(
        getFluxItemKey(it),
        this.computeRecommendationScore(
          it,
          currentUserId,
          generationSeed,
          'recent_under_3d'
        )
      );
    });

    const rankedOlder = [...olderUnused].sort(
      (a, b) => (scoreMap.get(getFluxItemKey(b)) || 0) - (scoreMap.get(getFluxItemKey(a)) || 0)
    );
    const rankedRecentUnder3d = [...recentUnder3dUnused].sort(
      (a, b) => (scoreMap.get(getFluxItemKey(b)) || 0) - (scoreMap.get(getFluxItemKey(a)) || 0)
    );

    const usedKeys = new Set<string>(existingSequenceKeys);
    const result: FluxFeedItem[] = [];
    let olderStreak = options.initialOlderStreak;

    // 1. If building the head of a fresh sequence, pick Slot 0 with strict lead rotation
    if (options.isFreshLead) {
      const lead = this.pickFreshLeadPost(
        rankedOlder,
        rankedRecentUnder3d,
        allEffectiveItems.length,
        options.forbiddenLeadKey,
        generationSeed
      );
      if (lead) {
        const lk = getFluxItemKey(lead);
        usedKeys.add(lk);
        result.push(lead);
        olderStreak = isPostPublishedUnderThreeDays(lead, nowMs) ? 0 : 1;
      }
    }

    const pickUnusedFrom = (
      pool: FluxFeedItem[],
      avoidAdjacentKey: string | null
    ): FluxFeedItem | null => {
      // First pass: unseen in session
      for (const candidate of pool) {
        const k = getFluxItemKey(candidate);
        if (usedKeys.has(k)) continue;
        if (avoidAdjacentKey && k === avoidAdjacentKey && pool.length > 1) continue;
        if (!this.sessionSeenKeys.has(k)) return candidate;
      }
      // Second pass: any unused in current sequence
      for (const candidate of pool) {
        const k = getFluxItemKey(candidate);
        if (usedKeys.has(k)) continue;
        if (avoidAdjacentKey && k === avoidAdjacentKey && pool.length > 1) continue;
        return candidate;
      }
      return null;
    };

    while (result.length < desiredCount) {
      const prevKey =
        result.length > 0
          ? getFluxItemKey(result[result.length - 1])
          : options.avoidBoundaryKey;

      if (olderStreak >= 5) {
        // Must insert 1 post published in < 3 days after 5 older recommended posts!
        let chosenRecent = pickUnusedFrom(rankedRecentUnder3d, prevKey);

        // If all < 3d posts were already used earlier in a long sequence, rotate one from `allRecentUnder3d`
        // (avoiding the last 4 shown slots) so the 5:1 cadence remains honored whenever < 3d posts exist!
        if (!chosenRecent && allRecentUnder3d.length > 0) {
          const recentTailKeys = new Set(
            result.slice(Math.max(0, result.length - 4)).map(getFluxItemKey)
          );
          if (prevKey) recentTailKeys.add(prevKey);
          const rotatedRecent = this.permuteItems(
            allRecentUnder3d,
            generationSeed * 113 + result.length * 17
          ).find((it) => !recentTailKeys.has(getFluxItemKey(it)));

          if (rotatedRecent) {
            chosenRecent = rotatedRecent;
          }
        }

        if (chosenRecent) {
          usedKeys.add(getFluxItemKey(chosenRecent));
          result.push(chosenRecent);
          olderStreak = 0;
          continue;
        }

        // Fallback only if zero < 3d posts exist in the database
        const fallbackOlder = pickUnusedFrom(rankedOlder, prevKey);
        if (!fallbackOlder) break;
        usedKeys.add(getFluxItemKey(fallbackOlder));
        result.push(fallbackOlder);
        olderStreak = 0;
      } else {
        // Need an older (>= 3 days) post recommended by reach, engagement & user profile
        const chosenOlder = pickUnusedFrom(rankedOlder, prevKey);
        if (chosenOlder) {
          usedKeys.add(getFluxItemKey(chosenOlder));
          result.push(chosenOlder);
          olderStreak += 1;
          continue;
        }

        // Fallback if database has fewer than 5 older posts: fill with < 3d recommended posts
        const fallbackRecent = pickUnusedFrom(rankedRecentUnder3d, prevKey);
        if (!fallbackRecent) break;
        usedKeys.add(getFluxItemKey(fallbackRecent));
        result.push(fallbackRecent);
        olderStreak = 0;
      }
    }

    return { items: result, nextOlderStreak: olderStreak };
  }

  /**
   * Generates a complete new Flux sequence (on every Flux open/reopen, pull-past-first-post, or manual Refresh).
   * - Increments persistent `openGeneration` so closing and reopening Flux ALWAYS updates the sequence.
   * - Ensures the first post never repeats what appeared before closing (unless cycling after exhausting all posts,
   *   and never repeats back-to-back).
   * - Enforces 1 post published in < 3 days for every 5 older high-reach/engagement recommended posts.
   */
  public async generateFreshSequence(
    currentUserId?: string,
    batchSize = 18,
    currentActiveKey?: string | null
  ): Promise<FluxFeedItem[]> {
    this.ensureSessionStateLoaded(currentUserId);
    this.ensureTelemetryLoaded(currentUserId);
    await this.ensureUserPlatformInterestsLoaded(currentUserId);

    this.refreshGeneration += 1;
    this.persistedSession.openGeneration += 1;
    const generationSeed =
      this.persistedSession.openGeneration * 137 +
      this.refreshGeneration * 59 +
      (Date.now() % 997);

    if (this.refreshGeneration > 1) {
      await this.refreshLatestHead(currentUserId);
    }

    if (this.hasMoreRemoteData()) {
      const { effective: preEffective } = this.getCandidatePools(currentUserId);
      const nowMs = Date.now();
      const olderCount = preEffective.filter(
        (it) => !isPostPublishedUnderThreeDays(it, nowMs)
      ).length;
      const recentCount = preEffective.length - olderCount;
      if (preEffective.length < batchSize || olderCount < 10 || recentCount < 2) {
        await this.fetchNextPoolBatch(currentUserId);
      }
    }

    const { effective } = this.getCandidatePools(currentUserId);
    if (effective.length === 0) return [];

    const forbiddenLeadKey =
      currentActiveKey || this.persistedSession.lastLeadKey || null;

    const assembled = this.assembleRecommendedCadenceChunk(
      effective,
      new Set(),
      batchSize,
      currentUserId,
      generationSeed,
      {
        isFreshLead: true,
        forbiddenLeadKey,
        avoidBoundaryKey: null,
        initialOlderStreak: 0,
      }
    );

    let uniqueSeq = assembled.items;
    this.sequenceOlderStreak = assembled.nextOlderStreak;

    // Guarantee a genuinely different combination from the previous sequence when >= 3 posts exist
    const prevSig = this.persistedSession.lastSequenceSignature;
    if (uniqueSeq.length >= 3 && uniqueSeq.map(getFluxItemKey).join('|') === prevSig) {
      const lead = uniqueSeq[0];
      const tail = this.permuteItems(uniqueSeq.slice(1), generationSeed + 313);
      if (
        tail.length >= 2 &&
        [lead, ...tail].map(getFluxItemKey).join('|') === prevSig
      ) {
        uniqueSeq = [lead, ...tail.slice(1), tail[0]];
      } else {
        uniqueSeq = [lead, ...tail];
      }
    }

    if (uniqueSeq.length > 0) {
      const newLeadKey = getFluxItemKey(uniqueSeq[0]);
      this.persistedSession.lastLeadKey = newLeadKey;
      if (!this.persistedSession.shownLeadKeys.includes(newLeadKey)) {
        this.persistedSession.shownLeadKeys.push(newLeadKey);
      }
      this.persistedSession.lastSequenceSignature = uniqueSeq
        .map(getFluxItemKey)
        .join('|');
      this.sessionSeenKeys.add(newLeadKey);
      this.persistSessionState(currentUserId);
    }

    let finalSeq = [...uniqueSeq];
    if (finalSeq.length > 0 && finalSeq.length < 6) {
      this.cycleGeneration += 1;
      const tailKey = getFluxItemKey(finalSeq[finalSeq.length - 1]);
      const extraCycle = this.buildAlternatedCycle(
        effective,
        tailKey,
        this.cycleGeneration * 151 + generationSeed,
        currentUserId
      );
      finalSeq = [...finalSeq, ...extraCycle];
    }

    return finalSeq;
  }

  /**
   * Appends the next chunk for infinite downward scrolling while preserving the 5 older + 1 (< 3 days) cadence.
   */
  public async appendInfiniteCycleChunk(
    recentWindowKeys: Set<string>,
    lastTailKey: string | null,
    currentUserId?: string,
    chunkSize = 12
  ): Promise<FluxFeedItem[]> {
    this.ensureSessionStateLoaded(currentUserId);
    this.ensureTelemetryLoaded(currentUserId);

    const { effective: preEffective } = this.getCandidatePools(currentUserId);
    const availableUnused = preEffective.filter(
      (it) => !recentWindowKeys.has(getFluxItemKey(it))
    );

    if (availableUnused.length < chunkSize && this.hasMoreRemoteData()) {
      await this.fetchNextPoolBatch(currentUserId);
    }

    const { effective } = this.getCandidatePools(currentUserId);
    if (effective.length === 0) return [];

    const generationSeed =
      this.persistedSession.openGeneration * 137 +
      this.cycleGeneration * 89 +
      recentWindowKeys.size;

    const assembled = this.assembleRecommendedCadenceChunk(
      effective,
      recentWindowKeys,
      chunkSize,
      currentUserId,
      generationSeed,
      {
        isFreshLead: false,
        forbiddenLeadKey: null,
        avoidBoundaryKey: lastTailKey,
        initialOlderStreak: this.sequenceOlderStreak,
      }
    );

    this.sequenceOlderStreak = assembled.nextOlderStreak;
    const unusedChunk = assembled.items;

    if (unusedChunk.length >= Math.min(4, chunkSize)) {
      return unusedChunk;
    }

    this.cycleGeneration += 1;
    const seamKey =
      unusedChunk.length > 0
        ? getFluxItemKey(unusedChunk[unusedChunk.length - 1])
        : lastTailKey;

    const cycled = this.buildAlternatedCycle(
      effective,
      seamKey,
      this.cycleGeneration * 193 + generationSeed,
      currentUserId
    );

    const combined = [...unusedChunk, ...cycled];
    if (combined.length === 1) {
      return [combined[0], combined[0]];
    }
    return combined.slice(0, Math.max(chunkSize, combined.length));
  }

  /**
   * Returns immediate replacement items when the user clicks "X" on a post and no further items
   * remain queued in the local sequence, ensuring Flux is never empty.
   */
  public getImmediateReplacementAfterDismiss(
    lastShownKey: string | null,
    currentUserId?: string
  ): FluxFeedItem[] {
    const { effective } = this.getCandidatePools(currentUserId);
    if (effective.length === 0) return [];
    this.cycleGeneration += 1;
    const cycle = this.buildAlternatedCycle(
      effective,
      lastShownKey,
      this.cycleGeneration * 211 + (Date.now() % 509),
      currentUserId
    );
    return cycle.length === 1 ? [cycle[0], cycle[0]] : cycle;
  }
}

export interface FluxAudioComposerInput {
  file?: File;
  existingUrl?: string;
  title: string;
  sourceType?: 'upload' | 'recording' | 'library';
  durationSec?: number;
  startSec?: number;
  endSec?: number;
  volume?: number;
}

/**
 * Publishes a new post from the Flux composer (text, Story canvas, images/videos, and/or audio).
 * Supports standalone Flux posts (`/fluxPosts`) or publishing into an authorized community.
 */
export async function publishFluxPost(params: {
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  authorTitle?: string;
  content: string;
  files: File[];
  imageFormat?: PostImageFormat;
  storyCanvas?: FluxStoryCanvas;
  audioInput?: FluxAudioComposerInput | null;
  isPrivate?: boolean;
  isHiddenFromNonMembers?: boolean;
  community?: Community | null;
}): Promise<FluxFeedItem> {
  const {
    authorId,
    authorName,
    authorPhoto,
    authorTitle,
    content,
    files,
    imageFormat,
    storyCanvas,
    audioInput,
    isPrivate,
    isHiddenFromNonMembers,
    community,
  } = params;

  const trimmedContent = content.trim();
  const hasStoryTexts = Boolean(
    storyCanvas?.texts?.some((t) => typeof t.text === 'string' && t.text.trim().length > 0)
  );
  const hasAudioInput = Boolean(audioInput && (audioInput.file || audioInput.existingUrl));
  if (!trimmedContent && files.length === 0 && !hasStoryTexts && !hasAudioInput) {
    throw new Error(
      'Escreva um texto no quadro, escolha uma mídia ou adicione um áudio para publicar.'
    );
  }

  const postId = `flux_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

  const mediaUrls: string[] = [];
  const mediaTypes: ('image' | 'video')[] = [];

  for (const file of files.slice(0, 8)) {
    const uploaded = await uploadMediaToStorage(file, 'posts', postId);
    mediaUrls.push(uploaded.url);
    mediaTypes.push(uploaded.type);
  }

  let resolvedAudioTrack: FluxAudioTrack | undefined;
  if (audioInput && (audioInput.file || audioInput.existingUrl)) {
    const uploadedAudioUrl = audioInput.file
      ? await uploadAudioToStorage(audioInput.file, postId)
      : audioInput.existingUrl || '';

    if (uploadedAudioUrl) {
      const safeStart =
        typeof audioInput.startSec === 'number' && !Number.isNaN(audioInput.startSec)
          ? Math.max(0, Math.round(audioInput.startSec * 10) / 10)
          : 0;
      const safeDuration =
        typeof audioInput.durationSec === 'number' && audioInput.durationSec > 0
          ? Math.round(audioInput.durationSec * 10) / 10
          : undefined;
      const safeEnd =
        typeof audioInput.endSec === 'number' && audioInput.endSec > safeStart
          ? Math.round(audioInput.endSec * 10) / 10
          : safeDuration;
      const safeVol =
        typeof audioInput.volume === 'number' && !Number.isNaN(audioInput.volume)
          ? Math.max(0.05, Math.min(1, Math.round(audioInput.volume * 100) / 100))
          : 0.85;

      resolvedAudioTrack = {
        url: uploadedAudioUrl,
        title: (audioInput.title || 'Áudio original').trim().slice(0, 90) || 'Áudio original',
        sourceType: audioInput.sourceType || 'upload',
        ...(safeDuration ? { durationSec: safeDuration } : {}),
        startSec: safeStart,
        ...(safeEnd ? { endSec: safeEnd } : {}),
        volume: safeVol,
      };
    }
  }

  const hasAnyImage = mediaTypes.includes('image');
  const resolvedImageFormat: PostImageFormat | undefined = hasAnyImage
    ? imageFormat || 'story'
    : undefined;

  const primaryType: CommunityPost['type'] =
    mediaUrls.length === 0
      ? 'text'
      : mediaUrls.length > 1
      ? 'media'
      : mediaTypes[0] === 'video'
      ? 'video'
      : 'image';

  const nowIso = new Date().toISOString();

  if (community && community.id) {
    const postDoc: CommunityPost = {
      id: postId,
      communityId: community.id,
      authorId,
      authorName,
      authorPhoto: authorPhoto || '',
      authorTitle: authorTitle || '',
      content: trimmedContent,
      type: primaryType,
      ...(resolvedImageFormat ? { imageFormat: resolvedImageFormat } : {}),
      ...(storyCanvas ? { storyCanvas } : {}),
      ...(resolvedAudioTrack ? { audioTrack: resolvedAudioTrack } : {}),
      ...(isPrivate ? { isPrivate: true } : {}),
      ...(isHiddenFromNonMembers ? { isHiddenFromNonMembers: true } : {}),
      mediaUrl: mediaUrls[0] || '',
      mediaUrls,
      mediaTypes,
      likesCount: 0,
      likedUserIds: [],
      dislikesCount: 0,
      dislikedUserIds: [],
      blockedUserIds: [],
      commentsCount: 0,
      createdAt: nowIso,
    };

    const postPath = `communities/${community.id}/posts/${postId}`;
    try {
      await setDoc(
        doc(db, 'communities', community.id, 'posts', postId),
        sanitizeFirestoreData(postDoc)
      );
      await updateDoc(doc(db, 'communities', community.id), {
        postsCount: (community.postsCount || 0) + 1,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, postPath);
    }

    await awardXp(authorId, 20, `flux_post_${postId}`, 'Publicação no Flux');

    return {
      ...postDoc,
      postSource: 'community',
      communityName: community.name,
      communityCoverUrl:
        community.iconUrl ||
        community.avatarUrl ||
        community.coverUrl ||
        community.bannerUrl ||
        '',
      communityCreatorId: community.creatorId,
      communityBannedUserIds: community.bannedUserIds,
      communityIsPrivate: Boolean(community.isPrivate),
      communityIsHidden: Boolean(community.isHiddenFromNonMembers),
      communityHidePosts: Boolean(community.hidePostsFromNonMembers),
    };
  }

  const standaloneDoc: CommunityPost = {
    id: postId,
    communityId: '',
    authorId,
    authorName,
    authorPhoto: authorPhoto || '',
    authorTitle: authorTitle || '',
    content: trimmedContent,
    type: primaryType,
    ...(resolvedImageFormat ? { imageFormat: resolvedImageFormat } : {}),
    ...(storyCanvas ? { storyCanvas } : {}),
    ...(resolvedAudioTrack ? { audioTrack: resolvedAudioTrack } : {}),
    mediaUrl: mediaUrls[0] || '',
    mediaUrls,
    mediaTypes,
    likesCount: 0,
    likedUserIds: [],
    dislikesCount: 0,
    dislikedUserIds: [],
    blockedUserIds: [],
    commentsCount: 0,
    createdAt: nowIso,
  };

  const fluxPath = `fluxPosts/${postId}`;
  try {
    await setDoc(doc(db, 'fluxPosts', postId), sanitizeFirestoreData(standaloneDoc));
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, fluxPath);
  }

  await awardXp(authorId, 20, `flux_post_${postId}`, 'Publicação no Flux');

  return {
    ...standaloneDoc,
    postSource: 'flux',
  };
}

export async function toggleFluxPostLike(
  item: FluxFeedItem,
  currentUserId: string
): Promise<{ liked: boolean; likesCount: number; likedUserIds: string[] }> {
  const hasLiked = Boolean(item.likedUserIds?.includes(currentUserId));
  const hasDisliked = Boolean(item.dislikedUserIds?.includes(currentUserId));

  const postRef =
    item.postSource === 'community' && item.communityId
      ? doc(db, 'communities', item.communityId, 'posts', item.id)
      : doc(db, 'fluxPosts', item.id);

  const path =
    item.postSource === 'community' && item.communityId
      ? `communities/${item.communityId}/posts/${item.id}`
      : `fluxPosts/${item.id}`;

  const currentIds = item.likedUserIds || [];

  try {
    if (hasLiked) {
      const nextCount = Math.max(0, (item.likesCount || 1) - 1);
      await updateDoc(postRef, {
        likedUserIds: arrayRemove(currentUserId),
        likesCount: nextCount,
      });
      return {
        liked: false,
        likesCount: nextCount,
        likedUserIds: currentIds.filter((id) => id !== currentUserId),
      };
    } else {
      const nextCount = (item.likesCount || 0) + 1;
      const updates: Record<string, any> = {
        likedUserIds: arrayUnion(currentUserId),
        likesCount: nextCount,
      };
      if (hasDisliked) {
        updates.dislikedUserIds = arrayRemove(currentUserId);
        updates.dislikesCount = Math.max(0, (item.dislikesCount || 1) - 1);
      }
      await updateDoc(postRef, updates);
      return {
        liked: true,
        likesCount: nextCount,
        likedUserIds: currentIds.includes(currentUserId)
          ? currentIds
          : [...currentIds, currentUserId],
      };
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export function subscribeUserFavoritePostIds(
  userId: string,
  onChange: (favIds: Set<string>) => void
): () => void {
  const favCol = collection(db, 'users', userId, 'favoritePosts');
  return onSnapshot(
    favCol,
    (snap) => {
      const ids = new Set<string>();
      snap.forEach((d) => ids.add(d.id));
      onChange(ids);
    },
    (err) => {
      console.warn('[Flux Favorites] Subscription notice:', err);
    }
  );
}

export async function toggleFluxPostFavorite(
  item: FluxFeedItem,
  currentUserId: string,
  isCurrentlySaved: boolean
): Promise<boolean> {
  const favId = getFavoriteDocId(item);
  const favRef = doc(db, 'users', currentUserId, 'favoritePosts', favId);
  const path = `users/${currentUserId}/favoritePosts/${favId}`;

  try {
    if (isCurrentlySaved) {
      await deleteDoc(favRef);
      return false;
    } else {
      const firstMedia = extractPostMediaItems(item)[0]?.url || item.mediaUrl || item.imageUrl || '';
      const record: FavoritePostRecord = {
        id: favId,
        userId: currentUserId,
        postId: item.id,
        communityId: item.communityId || '',
        postSource: item.postSource,
        savedAt: new Date().toISOString(),
        authorId: item.authorId || '',
        authorName: item.authorName || 'Leitor',
        authorPhoto: item.authorPhoto || '',
        communityName: item.communityName || '',
        contentPreview: (item.content || '').slice(0, 900),
        mediaUrl: firstMedia,
        createdAt: item.createdAt || new Date().toISOString(),
      };
      await setDoc(favRef, sanitizeFirestoreData(record));
      return true;
    }
  } catch (err) {
    handleFirestoreError(
      err,
      isCurrentlySaved ? OperationType.DELETE : OperationType.CREATE,
      path
    );
  }
}

export async function removeUserSavedPostByFavId(
  userId: string,
  favId: string
): Promise<void> {
  const favRef = doc(db, 'users', userId, 'favoritePosts', favId);
  const path = `users/${userId}/favoritePosts/${favId}`;
  try {
    await deleteDoc(favRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function fetchUserSavedPosts(
  userId: string
): Promise<SavedPostResolvedItem[]> {
  const favCol = collection(db, 'users', userId, 'favoritePosts');
  let records: FavoritePostRecord[] = [];

  try {
    const q = query(favCol, orderBy('savedAt', 'desc'));
    const snap = await getDocs(q);
    snap.forEach((d) => {
      records.push({ ...(d.data() as FavoritePostRecord), id: d.id });
    });
  } catch {
    try {
      const fallbackSnap = await getDocs(favCol);
      fallbackSnap.forEach((d) => {
        records.push({ ...(d.data() as FavoritePostRecord), id: d.id });
      });
      records.sort(
        (a, b) =>
          new Date(b.savedAt || 0).getTime() - new Date(a.savedAt || 0).getTime()
      );
    } catch (err) {
      console.warn('[SavedPosts] Could not load favoritePosts:', err);
      return [];
    }
  }

  if (records.length === 0) return [];

  const communityCache = new Map<string, Community | null>();
  const uniqueCommIds = Array.from(
    new Set(
      records
        .filter((r) => r.postSource === 'community' && r.communityId)
        .map((r) => r.communityId)
    )
  );

  await Promise.all(
    uniqueCommIds.map(async (cid) => {
      try {
        const cSnap = await getDoc(doc(db, 'communities', cid));
        communityCache.set(cid, cSnap.exists() ? (cSnap.data() as Community) : null);
      } catch {
        communityCache.set(cid, null);
      }
    })
  );

  const resolved = await Promise.all(
    records.map(async (rec): Promise<SavedPostResolvedItem | null> => {
      try {
        if (rec.postSource === 'community' && rec.communityId) {
          const comm = communityCache.get(rec.communityId);
          if (comm?.bannedUserIds?.includes(userId)) return null;

          const postSnap = await getDoc(
            doc(db, 'communities', rec.communityId, 'posts', rec.postId)
          );
          if (!postSnap.exists()) return null;

          const postData = postSnap.data() as CommunityPost;

          const item: FluxFeedItem = {
            ...postData,
            id: postData.id || postSnap.id,
            communityId: rec.communityId,
            postSource: 'community',
            communityName: comm?.name || rec.communityName || 'Comunidade',
            communityCoverUrl:
              comm?.iconUrl ||
              comm?.avatarUrl ||
              comm?.coverUrl ||
              comm?.bannerUrl ||
              '',
            communityCreatorId: comm?.creatorId || '',
          };

          return {
            favId: rec.id,
            savedAt: rec.savedAt,
            post: item,
          };
        } else {
          const postSnap = await getDoc(doc(db, 'fluxPosts', rec.postId));
          if (!postSnap.exists()) return null;

          const postData = postSnap.data() as CommunityPost;

          const commId = postData.communityId || '';
          let commName = rec.communityName || '';
          let commCover = '';
          let commCreatorId = '';

          if (commId) {
            let comm = communityCache.get(commId);
            if (comm === undefined) {
              try {
                const cSnap = await getDoc(doc(db, 'communities', commId));
                comm = cSnap.exists() ? (cSnap.data() as Community) : null;
                communityCache.set(commId, comm);
              } catch {
                comm = null;
              }
            }
            if (comm) {
              commName = comm.name;
              commCover =
                comm.iconUrl ||
                comm.avatarUrl ||
                comm.coverUrl ||
                comm.bannerUrl ||
                '';
              commCreatorId = comm.creatorId;
            }
          }

          const item: FluxFeedItem = {
            ...postData,
            id: postData.id || postSnap.id,
            communityId: commId,
            postSource: 'flux',
            communityName: commName || undefined,
            communityCoverUrl: commCover || undefined,
            communityCreatorId: commCreatorId || undefined,
          };

          return {
            favId: rec.id,
            savedAt: rec.savedAt,
            post: item,
          };
        }
      } catch (err) {
        console.warn('[SavedPosts] Could not resolve saved post:', rec.id, err);
        return null;
      }
    })
  );

  return resolved.filter((r): r is SavedPostResolvedItem => r !== null);
}

/**
 * Cleans up any legacy permanent `blockedUserIds` entry if present, since the "X" button
 * now only temporarily dismisses posts with automatic fallback so Flux is never empty.
 */
export async function clearLegacyBlockedPostFlag(
  item: FluxFeedItem,
  currentUserId?: string
): Promise<void> {
  if (!currentUserId || !item.blockedUserIds?.includes(currentUserId)) return;

  const postRef =
    item.postSource === 'community' && item.communityId
      ? doc(db, 'communities', item.communityId, 'posts', item.id)
      : doc(db, 'fluxPosts', item.id);

  try {
    await updateDoc(postRef, {
      blockedUserIds: arrayRemove(currentUserId),
    });
  } catch {
    // ignore
  }
}

export async function deleteFluxPostItem(item: FluxFeedItem): Promise<void> {
  const postRef =
    item.postSource === 'community' && item.communityId
      ? doc(db, 'communities', item.communityId, 'posts', item.id)
      : doc(db, 'fluxPosts', item.id);

  const path =
    item.postSource === 'community' && item.communityId
      ? `communities/${item.communityId}/posts/${item.id}`
      : `fluxPosts/${item.id}`;

  try {
    await deleteDoc(postRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function updateFluxPostContent(
  item: FluxFeedItem,
  newContent: string
): Promise<string> {
  const trimmed = newContent.trim();
  const editedAt = new Date().toISOString();
  const postRef =
    item.postSource === 'community' && item.communityId
      ? doc(db, 'communities', item.communityId, 'posts', item.id)
      : doc(db, 'fluxPosts', item.id);

  const path =
    item.postSource === 'community' && item.communityId
      ? `communities/${item.communityId}/posts/${item.id}`
      : `fluxPosts/${item.id}`;

  try {
    await updateDoc(postRef, {
      content: trimmed,
      editedAt,
    });
    return editedAt;
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function voteFluxCommunityPoll(
  item: FluxFeedItem,
  optionId: string,
  currentUserId: string
): Promise<CommunityPoll | null> {
  if (!item.poll) return null;
  const alreadyVoted =
    item.poll.voterIds?.includes(currentUserId) ||
    item.poll.options.some((o) => o.voterIds?.includes(currentUserId));
  if (alreadyVoted) return item.poll;

  const updatedOptions: PollOption[] = item.poll.options.map((opt) =>
    opt.id === optionId
      ? {
          ...opt,
          votesCount: (opt.votesCount || 0) + 1,
          voterIds: [...(opt.voterIds || []), currentUserId],
        }
      : opt
  );

  const nextPoll: CommunityPoll = {
    question: item.poll.question,
    options: updatedOptions,
    totalVotes: (item.poll.totalVotes || 0) + 1,
    voterIds: [...(item.poll.voterIds || []), currentUserId],
  };

  const postRef =
    item.postSource === 'community' && item.communityId
      ? doc(db, 'communities', item.communityId, 'posts', item.id)
      : doc(db, 'fluxPosts', item.id);
  const path =
    item.postSource === 'community' && item.communityId
      ? `communities/${item.communityId}/posts/${item.id}`
      : `fluxPosts/${item.id}`;

  try {
    await updateDoc(postRef, { poll: nextPoll });
    return nextPoll;
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function joinCommunityFromFlux(
  communityId: string,
  userId: string,
  userProfile?: UserProfile | null
): Promise<'active' | 'pending'> {
  const commRef = doc(db, 'communities', communityId);
  const commSnap = await getDoc(commRef);
  if (!commSnap.exists()) {
    throw new Error('Comunidade não encontrada.');
  }
  const comm = commSnap.data() as Community;
  if (comm.bannedUserIds?.includes(userId)) {
    throw new Error('Você não tem permissão para participar desta comunidade.');
  }

  const memberRef = doc(db, 'communities', communityId, 'members', userId);
  const existingMember = await getDoc(memberRef);
  if (existingMember.exists()) {
    const status = (existingMember.data() as Partial<CommunityMember>)?.status;
    return status === 'pending' ? 'pending' : 'active';
  }

  const requiresApproval = Boolean(comm.isPrivate && comm.creatorId !== userId);
  const targetStatus: CommunityMember['status'] = requiresApproval ? 'pending' : 'active';

  const memberData: CommunityMember = {
    id: userId,
    communityId,
    userId,
    userName: userProfile?.displayName || 'Leitor',
    userPhoto: userProfile?.photoURL || '',
    role: 'member',
    status: targetStatus,
    joinedAt: new Date().toISOString(),
  };

  try {
    await setDoc(memberRef, sanitizeFirestoreData(memberData));
    if (!requiresApproval) {
      await updateDoc(commRef, {
        membersCount: (comm.membersCount || 0) + 1,
      });
    }
  } catch (err) {
    handleFirestoreError(
      err,
      OperationType.CREATE,
      `communities/${communityId}/members/${userId}`
    );
  }

  if (requiresApproval) {
    if (comm.creatorId && comm.creatorId !== userId) {
      await sendNotification(
        comm.creatorId,
        'community_join',
        'Solicitação para comunidade privada',
        `${userProfile?.displayName || 'Um leitor'} solicitou entrada em "${comm.name}".`,
        `/comunidade/${communityId}`
      );
    }
    return 'pending';
  }

  await awardXp(userId, 15, `join_comm_${communityId}`, `Entrou no grupo: ${comm.name}`);
  return 'active';
}
