import { initializeApp } from 'firebase/app';
import {
  browserLocalPersistence,
  browserPopupRedirectResolver,
  browserSessionPersistence,
  getAuth,
  indexedDBLocalPersistence,
  initializeAuth,
  inMemoryPersistence,
  PopupRedirectResolver,
} from 'firebase/auth';
import { doc, getDocFromServer, getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

/**
 * Patches two critical issues in `firebase@12.19.0` `BrowserPopupRedirectResolver`:
 * 1. `_isIframeWebStorageSupported` in firebase@12.19.0 lacks a `return;` before `_fail("internal-error")`
 *    and rejects valid `window.opener` popups in cross-origin iframes / Safari / Brave when 3rd-party
 *    storage is partitioned. Since popup auth relays via `window.opener` postMessage (`gapi.iframes`),
 *    reporting `cb(true)` cleanly avoids false `auth/web-storage-unsupported` & `auth/internal-error` aborts.
 * 2. `_shouldInitProactively` is enabled across all browsers/iframes so `__/auth/iframe` and `gapi.iframes`
 *    initialize at app startup instead of adding a 1.5–4s async delay on the user's click gesture.
 */
function hardenPopupRedirectResolver(resolverClass: unknown): PopupRedirectResolver {
  const ctor = resolverClass as { prototype?: Record<string, any> } | null;
  const proto = ctor?.prototype;
  if (proto && !proto.__kordelHardened) {
    Object.defineProperty(proto, '__kordelHardened', {
      value: true,
      configurable: true,
    });

    Object.defineProperty(proto, '_shouldInitProactively', {
      get() {
        return true;
      },
      configurable: true,
    });

    proto._isIframeWebStorageSupported = function (_auth: unknown, cb: (supported: boolean) => void) {
      try {
        cb(true);
      } catch {
        // ignore callback errors
      }
    };
  }
  return resolverClass as PopupRedirectResolver;
}

export const kordelPopupRedirectResolver: PopupRedirectResolver =
  hardenPopupRedirectResolver(browserPopupRedirectResolver);

interface PreOpenedPopupSlot {
  win: Window;
  createdAt: number;
  restoreWindowOpen: () => void;
}

let pendingPopupSlot: PreOpenedPopupSlot | null = null;

/**
 * Closes and cleans up any unconsumed pre-opened popup window if `signInWithPopup` fails early.
 */
export function cleanupUnusedPreOpenedPopup(closeWindow = true): void {
  if (!pendingPopupSlot) return;
  const slot = pendingPopupSlot;
  pendingPopupSlot = null;
  try {
    slot.restoreWindowOpen();
  } catch {
    // ignore
  }
  if (closeWindow) {
    try {
      if (slot.win && slot.win !== window && !slot.win.closed) {
        slot.win.close();
      }
    } catch {
      // ignore
    }
  }
}

/**
 * Opens the Google OAuth popup window synchronously (0ms) inside the user's click handler
 * so transient user activation (`navigator.userActivation`) is never lost while Firebase
 * computes the `/__/auth/handler` OAuth URL asynchronously.
 */
export function prepareSynchronousGooglePopup(): void {
  if (typeof window === 'undefined') return;

  cleanupUnusedPreOpenedPopup(true);

  const width = 500;
  const height = 620;
  const availWidth = window.screen?.availWidth || window.innerWidth || 1024;
  const availHeight = window.screen?.availHeight || window.innerHeight || 768;
  const left = Math.max(Math.round((availWidth - width) / 2), 0);
  const top = Math.max(Math.round((availHeight - height) / 2), 0);
  const features = `location=yes,resizable=yes,statusbar=yes,toolbar=no,scrollbars=yes,width=${width},height=${height},top=${top},left=${left}`;
  const popupName = `kordel_google_auth_${Date.now()}`;

  const nativeOpen = window.open.bind(window);
  let preWin: Window | null = null;

  try {
    preWin = nativeOpen('about:blank', popupName, features);
  } catch {
    preWin = null;
  }

  // Guard against broken mobile WebViews that return the current window or block popups
  if (!preWin || preWin === window) {
    return;
  }

  const originalWindowOpen = window.open;
  let restored = false;

  const restoreWindowOpen = () => {
    if (restored) return;
    restored = true;
    if (window.open === patchedWindowOpen) {
      window.open = originalWindowOpen;
    }
  };

  const safetyTimer = window.setTimeout(() => {
    cleanupUnusedPreOpenedPopup(false);
  }, 12000);

  const patchedWindowOpen: typeof window.open = function (
    url?: string | URL,
    target?: string,
    windowFeatures?: string
  ): Window | null {
    const urlStr = url ? String(url) : '';
    const isFirebaseAuthPopup =
      urlStr.includes('/__/auth/handler') ||
      urlStr.includes('accounts.google.com') ||
      urlStr.includes('firebaseapp.com');

    if (pendingPopupSlot && isFirebaseAuthPopup) {
      const slot = pendingPopupSlot;
      pendingPopupSlot = null;
      window.clearTimeout(safetyTimer);
      restoreWindowOpen();

      if (slot.win && slot.win !== window && !slot.win.closed) {
        try {
          slot.win.location.href = urlStr;
          slot.win.focus();
          return slot.win;
        } catch {
          // Fall through to native open if navigation failed
        }
      }
    }

    return originalWindowOpen.call(window, url, target, windowFeatures);
  };

  window.open = patchedWindowOpen;
  pendingPopupSlot = {
    win: preWin,
    createdAt: Date.now(),
    restoreWindowOpen: () => {
      window.clearTimeout(safetyTimer);
      restoreWindowOpen();
    },
  };
}

/* CRITICAL: The app will break without this line passing firestoreDatabaseId */
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = (() => {
  try {
    return initializeAuth(app, {
      persistence: [
        indexedDBLocalPersistence,
        browserLocalPersistence,
        browserSessionPersistence,
        inMemoryPersistence,
      ],
      popupRedirectResolver: kordelPopupRedirectResolver,
    });
  } catch {
    return getAuth(app);
  }
})();

// Proactively warm Firebase Auth iframe & origin validation in background on startup
if (typeof window !== 'undefined') {
  setTimeout(() => {
    try {
      const internalAuth = auth as unknown as {
        _popupRedirectResolver?: {
          _initialize?: (a: unknown) => Promise<unknown>;
          _originValidation?: (a: unknown) => Promise<unknown>;
        };
      };
      const resolver = internalAuth._popupRedirectResolver;
      if (resolver?._initialize) {
        resolver._initialize(auth).catch(() => {});
      }
      if (resolver?._originValidation) {
        resolver._originValidation(auth).catch(() => {});
      }
    } catch {
      // ignore pre-warm errors
    }
  }, 50);
}

export const storage = getStorage(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Strips all undefined fields recursively from an object so Firestore setDoc/updateDoc doesn't reject it.
 */
export function sanitizeFirestoreData<T extends Record<string, any>>(data: T): T {
  if (data === null || data === undefined) return data;
  if (Array.isArray(data)) {
    return data.map((item) => (typeof item === 'object' && item !== null ? sanitizeFirestoreData(item) : item)) as any;
  }
  const result: any = {};
  for (const [key, value] of Object.entries(data)) {
    if (value === undefined) {
      continue;
    }
    if (value !== null && typeof value === 'object' && !(value instanceof Date)) {
      result[key] = sanitizeFirestoreData(value);
    } else {
      result[key] = value;
    }
  }
  return result;
}

// Validate connection on startup as mandated by Skill
export async function testFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or waiting for network.');
    }
  }
}

testFirestoreConnection();
