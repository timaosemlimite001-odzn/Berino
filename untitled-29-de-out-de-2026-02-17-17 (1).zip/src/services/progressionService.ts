import {
  arrayUnion,
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { Book, KardTransaction, NotificationType, UserProfile } from '../types';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { ALL_ACHIEVEMENTS, ALL_MISSIONS, calculateLevelFromXp } from './xpLevels';
import { isSubscriptionActive } from './subscriptionService';
import { creditKards } from './kardsService';

// Send a real notification to a user
export async function sendNotification(
  userId: string,
  type: NotificationType,
  title: string,
  message: string,
  linkUrl: string = ''
) {
  if (!userId || !auth.currentUser) return;
  try {
    const notifId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const notifRef = doc(db, 'notifications', notifId);
    await setDoc(notifRef, {
      id: notifId,
      userId,
      type,
      title,
      message,
      linkUrl,
      read: false,
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    console.warn('Failed to send notification:', error);
  }
}

// Award XP to user, update level and cycle, check achievements, and notify
export async function awardXp(
  userId: string,
  amount: number,
  sourceKey: string, // e.g. "read_chapter_chap123"
  sourceDescription: string
): Promise<void> {
  const path = `users/${userId}`;
  try {
    // Check idempotency if sourceKey provided
    if (sourceKey) {
      const logDocRef = doc(db, 'users', userId, 'xpLogs', sourceKey);
      const existingLog = await getDoc(logDocRef);
      if (existingLog.exists()) {
        // Already awarded for this unique action
        return;
      }
      // Record this XP grant
      await setDoc(logDocRef, {
        sourceKey,
        amount,
        sourceDescription,
        awardedAt: new Date().toISOString(),
      });
    }

    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    if (!userSnap.exists()) return;

    const data = userSnap.data() as UserProfile;

    // Backend validation: Gamification (XP, levels) is strictly reserved for active Assinatura Leitor (R$ 4,90/mês).
    // "Se ele não tem o plano ele perdeu acesso a sistema de gamificação as missões de XP sumiram e ele não ganha mais XP, o nível dele zera também."
    const isLeitor = isSubscriptionActive(data, 'leitor');
    if (!isLeitor) {
      // Non-subscribers do not receive gamification XP under any circumstances
      return;
    }

    const currentXp = data.xp || 0;
    const newTotalXp = currentXp + amount;
    const prevLevel = data.level || 1;
    const prevCycle = data.progressionCycle || 0;

    const { level: newLevel, didCompleteCycle, excessXp } = calculateLevelFromXp(newTotalXp);

    let updatedLevel = newLevel;
    let updatedCycle = prevCycle;
    let updatedXp = newTotalXp;

    if (didCompleteCycle) {
      updatedCycle = prevCycle + 1;
      updatedLevel = 1;
      updatedXp = excessXp;

      await sendNotification(
        userId,
        'level_up',
        'Ciclo do Nível 33 Completado!',
        `Parabéns! Você alcançou o ápice literário e iniciou o Ciclo ${updatedCycle + 1}. Seu legado está gravado na história do KORDEL!`,
        '/ranking'
      );
    } else if (newLevel > prevLevel) {
      await sendNotification(
        userId,
        'level_up',
        `Novo Nível Alcançado: Nível ${newLevel}!`,
        `Você avançou para o nível ${newLevel}. Continue lendo e escrevendo para desbloquear novas honrarias!`,
        '/perfil'
      );
    }

    await updateDoc(userRef, {
      xp: updatedXp,
      level: updatedLevel,
      progressionCycle: updatedCycle,
      updatedAt: new Date().toISOString(),
    });

  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// Unlock an achievement for user if not already unlocked
export async function checkAndUnlockAchievement(
  userId: string,
  achievementId: string
): Promise<void> {
  try {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    if (!userSnap.exists()) return;

    const user = userSnap.data() as UserProfile;
    const currentAchievements = user.achievements || [];

    if (currentAchievements.includes(achievementId)) {
      return; // Already unlocked
    }

    const achievement = ALL_ACHIEVEMENTS.find((a) => a.id === achievementId);
    if (!achievement) return;

    const updates: Record<string, any> = {
      achievements: arrayUnion(achievementId),
      updatedAt: new Date().toISOString(),
    };

    if (achievement.titleReward) {
      updates.titles = arrayUnion(achievement.titleReward);
      if (!user.activeTitle) {
        updates.activeTitle = achievement.titleReward;
      }
    }

    await updateDoc(userRef, updates);

    // Award XP for the achievement
    if (achievement.xpReward > 0) {
      await awardXp(
        userId,
        achievement.xpReward,
        `achievement_${achievementId}`,
        `Conquista: ${achievement.title}`
      );
    }

    // Send notification
    await sendNotification(
      userId,
      'achievement',
      `Nova Conquista: ${achievement.title}!`,
      `Você desbloqueou uma conquista literária! ${achievement.titleReward ? `Título concedido: "${achievement.titleReward}"` : ''}`,
      '/conquistas'
    );
  } catch (error) {
    console.error('Error unlocking achievement:', error);
  }
}

/**
 * Evaluates real platform data for a writer and unlocks earned milestones
 * (books, chapters, views, likes, readers, followers, communities, boosts, ratings, featured status, instagram)
 * STRICT RULES:
 * - Unlocking writer achievements is exclusive to active Assinatura Escritor subscribers.
 * - Already unlocked achievements are NEVER deleted.
 */
export async function evaluateWriterAchievements(userId: string): Promise<void> {
  try {
    // 0. Verify active Escritor subscription on backend
    const userDocRef = doc(db, 'users', userId);
    const userDocSnap = await getDoc(userDocRef);
    if (!userDocSnap.exists()) return;

    const userProfile = userDocSnap.data() as UserProfile;
    if (!isSubscriptionActive(userProfile, 'escritor')) {
      // Benefit is locked while subscription is not active
      return;
    }

    // 1. Fetch user's books
    const booksQuery = query(collection(db, 'books'), where('authorId', '==', userId));
    const booksSnap = await getDocs(booksQuery);
    const booksCount = booksSnap.size;

    let totalViews = 0;
    let totalLikes = 0;
    let totalReaders = 0;
    let totalChapters = 0;
    let completedCount = 0;
    let hasHighRating = false;
    let hasBoostedBook = false;

    booksSnap.forEach((docSnap) => {
      const b = docSnap.data() as Book;
      totalViews += b.viewsCount || 0;
      totalLikes += b.likesCount || 0;
      totalReaders += b.readersCount || 0;
      totalChapters += b.chaptersCount || 0;
      if (b.status === 'completed') completedCount++;
      if (b.isBoosted) hasBoostedBook = true;
      if (b.ratingCount && b.ratingCount >= 5 && (b.ratingSum / b.ratingCount) >= 4.5) {
        hasHighRating = true;
      }
    });

    // 2. Fetch user's communities
    const commsQuery = query(collection(db, 'communities'), where('creatorId', '==', userId));
    const commsSnap = await getDocs(commsQuery);
    const commsCount = commsSnap.size;
    let hasTenMembers = false;
    let hasTwentyFiveMembers = false;
    let hasTwentyPosts = false;

    commsSnap.forEach((docSnap) => {
      const c = docSnap.data();
      const mCount = c.membersCount || 0;
      const pCount = c.postsCount || c.userPostsCount || 0;
      if (mCount >= 10) hasTenMembers = true;
      if (mCount >= 25) hasTwentyFiveMembers = true;
      if (pCount >= 20) hasTwentyPosts = true;
    });

    // 3. Check boosts in boosts collection
    if (!hasBoostedBook) {
      const boostsQuery = query(collection(db, 'boosts'), where('authorId', '==', userId));
      const boostsSnap = await getDocs(boostsQuery);
      if (boostsSnap.size > 0) hasBoostedBook = true;
    }

    // 4. Check if featured in settings/featuredBooks
    let isFeatured = false;
    try {
      const featSnap = await getDoc(doc(db, 'settings', 'featuredBooks'));
      if (featSnap.exists()) {
        const featData = featSnap.data();
        const featIds = featData.bookIds || [];
        booksSnap.forEach((bDoc) => {
          if (featIds.includes(bDoc.id)) isFeatured = true;
        });
      }
    } catch {}

    // 5. Check if featured in Instagram spotlights
    let isInstagramSpotlight = false;
    try {
      const igSnap = await getDoc(doc(db, 'settings', 'instagramSpotlights'));
      if (igSnap.exists()) {
        const igData = igSnap.data();
        const authors = igData.authorIds || [];
        const books = igData.bookIds || [];
        if (authors.includes(userId)) isInstagramSpotlight = true;
        booksSnap.forEach((bDoc) => {
          if (books.includes(bDoc.id)) isInstagramSpotlight = true;
        });
      }
    } catch {}

    const followersCount = userProfile.followersCount || 0;

    // Evaluate real conditions and unlock achievements idempotently
    if (booksCount >= 1) await checkAndUnlockAchievement(userId, 'first_published_book');
    if (booksCount >= 3) await checkAndUnlockAchievement(userId, 'writer_three_books');
    if (totalChapters >= 5) await checkAndUnlockAchievement(userId, 'author_five_chapters');
    if (completedCount >= 1) await checkAndUnlockAchievement(userId, 'first_completed_work');
    if (completedCount >= 3) await checkAndUnlockAchievement(userId, 'writer_three_completed');
    if (totalViews >= 100) await checkAndUnlockAchievement(userId, 'writer_100_views');
    if (totalViews >= 500) await checkAndUnlockAchievement(userId, 'writer_500_views');
    if (totalViews >= 1000) await checkAndUnlockAchievement(userId, 'writer_1000_views');
    if (totalReaders >= 50) await checkAndUnlockAchievement(userId, 'writer_50_readers');
    if (totalReaders >= 200) await checkAndUnlockAchievement(userId, 'writer_200_readers');
    if (totalLikes >= 50) await checkAndUnlockAchievement(userId, 'writer_50_likes');
    if (totalLikes >= 200) await checkAndUnlockAchievement(userId, 'writer_200_likes');
    if (followersCount >= 10) await checkAndUnlockAchievement(userId, 'writer_ten_followers');
    if (followersCount >= 50) await checkAndUnlockAchievement(userId, 'writer_fifty_followers');
    if (hasHighRating) await checkAndUnlockAchievement(userId, 'writer_high_rating');
    if (hasBoostedBook) await checkAndUnlockAchievement(userId, 'writer_first_boost');
    if (isFeatured) await checkAndUnlockAchievement(userId, 'featured_week_book');
    if (isInstagramSpotlight) await checkAndUnlockAchievement(userId, 'instagram_spotlight_author');
    if (commsCount >= 1) await checkAndUnlockAchievement(userId, 'community_leader_author');
    if (hasTenMembers) await checkAndUnlockAchievement(userId, 'community_ten_members');
    if (hasTwentyFiveMembers) await checkAndUnlockAchievement(userId, 'community_twenty_five_members');
    if (hasTwentyPosts) await checkAndUnlockAchievement(userId, 'community_twenty_posts');
  } catch (err) {
    console.warn('Error evaluating writer achievements:', err);
  }
}

/**
 * Claims mission rewards (XP + Kards) for active Leitor subscribers
 */
export async function claimMissionReward(
  userId: string,
  missionId: string
): Promise<{ success: boolean; message: string }> {
  const userRef = doc(db, 'users', userId);
  const userSnap = await getDoc(userRef);
  if (!userSnap.exists()) throw new Error('Usuário não encontrado.');
  const user = userSnap.data() as UserProfile;

  if (!isSubscriptionActive(user, 'leitor')) {
    throw new Error(
      'Apenas assinantes com a Assinatura Leitor ativa (R$ 4,90/mês) têm acesso ao sistema de missões e gamificação.'
    );
  }

  const mission = ALL_MISSIONS.find((m) => m.id === missionId);
  if (!mission) throw new Error('Missão não encontrada.');

  const missionProgressRef = doc(db, 'users', userId, 'missions', missionId);
  const progSnap = await getDoc(missionProgressRef);
  if (progSnap.exists() && progSnap.data().rewardClaimed) {
    throw new Error('Recompensa desta missão já foi reivindicada neste período.');
  }

  await setDoc(
    missionProgressRef,
    {
      missionId,
      rewardClaimed: true,
      claimedAt: new Date().toISOString(),
    },
    { merge: true }
  );

  if (mission.xpReward > 0) {
    await awardXp(
      userId,
      mission.xpReward,
      `mission_${missionId}_${new Date().toISOString().substring(0, 10)}`,
      `Missão: ${mission.title}`
    );
  }

  if (mission.kardReward > 0) {
    await creditKards(userId, mission.kardReward, 'reward', `Recompensa de Missão: ${mission.title}`);
  }

  return {
    success: true,
    message: `Recompensa da missão "${mission.title}" resgatada com sucesso!`,
  };
}
