import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db } from './firebase';
import { Book, BookBoostRecord, UserProfile, WriterBoostQuota } from '../types';
import { sendNotification } from './progressionService';

export const BOOST_DURATION_DAYS = 7;
export const MONTHLY_BOOST_ALLOWANCE = 2;

/**
 * Returns current monthly boost quota and active boosts for the writer
 */
export async function getUserBoostStatus(userId: string): Promise<WriterBoostQuota> {
  const currentCycle = new Date().toISOString().substring(0, 7); // e.g. "2026-10"
  let usedCount = 0;
  const activeBoosts: BookBoostRecord[] = [];
  const now = Date.now();

  try {
    const boostsRef = collection(db, 'boosts');
    const q = query(boostsRef, where('authorId', '==', userId));
    const snap = await getDocs(q);

    snap.forEach((docSnap) => {
      const data = docSnap.data() as BookBoostRecord;
      // Count boosts used in this cycle
      if (data.cycleMonth === currentCycle || (data.activatedAt && data.activatedAt.startsWith(currentCycle))) {
        usedCount++;
      }

      // Check if actively running (7 days)
      if (data.expiresAt && new Date(data.expiresAt).getTime() > now) {
        activeBoosts.push(data);
      }
    });
  } catch (err) {
    console.warn('Error fetching user boost status:', err);
  }

  const availableCount = Math.max(0, MONTHLY_BOOST_ALLOWANCE - usedCount);

  return {
    totalAllowed: MONTHLY_BOOST_ALLOWANCE,
    usedCount,
    availableCount,
    activeBoosts,
  };
}

/**
 * Activates a 7-day boost on a chosen book for an active Escritor subscriber.
 * Automatically validates subscription, monthly quota, and dates.
 */
export async function activateBookBoost(
  user: UserProfile,
  bookId: string
): Promise<{ success: boolean; boost: BookBoostRecord; message: string }> {
  // 1. Verify active Escritor subscription on backend
  const sub = user.subscription;
  const nowTime = Date.now();
  const isEscritorActive =
    sub &&
    sub.status === 'active' &&
    (sub.planId === 'escritor' || sub.planId === 'kardel_escritor') &&
    new Date(sub.currentPeriodEnd).getTime() > nowTime;

  if (!isEscritorActive) {
    throw new Error(
      'Apenas assinantes com a Assinatura Escritor ativa (R$ 13,49/mês) podem impulsionar obras.'
    );
  }

  // 2. Check monthly quota
  const quota = await getUserBoostStatus(user.id);
  if (quota.availableCount <= 0) {
    throw new Error(
      `Limite atingido: você já utilizou os ${MONTHLY_BOOST_ALLOWANCE} impulsionamentos disponíveis para o seu ciclo mensal atual.`
    );
  }

  // 3. Verify book ownership and readiness
  const bookRef = doc(db, 'books', bookId);
  const bookSnap = await getDoc(bookRef);
  if (!bookSnap.exists()) {
    throw new Error('Obra literária não encontrada.');
  }

  const bookData = bookSnap.data() as Book;
  if (bookData.authorId !== user.id) {
    throw new Error('Você só pode impulsionar obras de sua própria autoria.');
  }

  if (bookData.status === 'draft') {
    throw new Error('Apenas obras publicadas ou concluídas podem ser impulsionadas.');
  }

  // Check if book is already boosted
  if (bookData.isBoosted && bookData.boostExpiresAt) {
    const expTime = new Date(bookData.boostExpiresAt).getTime();
    if (expTime > nowTime) {
      const expFormatted = new Date(bookData.boostExpiresAt).toLocaleDateString('pt-BR');
      throw new Error(
        `Esta obra já possui um impulsionamento ativo até ${expFormatted}. Escolha outra obra ou aguarde o término.`
      );
    }
  }

  // 4. Calculate activation and exact 7-day expiration
  const activatedAt = new Date().toISOString();
  const expiresAt = new Date(nowTime + BOOST_DURATION_DAYS * 24 * 60 * 60 * 1000).toISOString();
  const cycleMonth = activatedAt.substring(0, 7);
  const boostId = `boost_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  const boostRecord: BookBoostRecord = {
    id: boostId,
    bookId: bookData.id,
    bookTitle: bookData.title,
    bookCoverUrl: bookData.coverUrl || '',
    authorId: user.id,
    authorName: user.displayName,
    activatedAt,
    expiresAt,
    status: 'active',
    cycleMonth,
  };

  // 5. Persist boost record in Firestore
  const boostRef = doc(db, 'boosts', boostId);
  await setDoc(boostRef, boostRecord);

  // 6. Update book status in Firestore
  await updateDoc(bookRef, {
    isBoosted: true,
    boostedAt: activatedAt,
    boostExpiresAt: expiresAt,
    updatedAt: activatedAt,
  });

  // 7. Update user profile subscription boost tracking
  try {
    const userRef = doc(db, 'users', user.id);
    await updateDoc(userRef, {
      'subscription.boostsUsedThisCycle': quota.usedCount + 1,
      'subscription.lastBoostCycle': cycleMonth,
      updatedAt: activatedAt,
    });
  } catch (err) {
    console.warn('Could not update user boost counter in profile:', err);
  }

  // 8. Send notification
  await sendNotification(
    user.id,
    'benefit',
    'Obra Impulsionada com Sucesso!',
    `Sua obra "${bookData.title}" foi impulsionada por 7 dias (até ${new Date(expiresAt).toLocaleDateString('pt-BR')}) com destaque especial na plataforma.`,
    `/livro/${bookData.id}`
  );

  return {
    success: true,
    boost: boostRecord,
    message: `A obra "${bookData.title}" foi impulsionada com sucesso por 7 dias!`,
  };
}

/**
 * Checks if a book is currently actively boosted
 */
export function isBookCurrentlyBoosted(book: { isBoosted?: boolean; boostExpiresAt?: string }): boolean {
  if (!book.isBoosted || !book.boostExpiresAt) return false;
  return new Date(book.boostExpiresAt).getTime() > Date.now();
}
