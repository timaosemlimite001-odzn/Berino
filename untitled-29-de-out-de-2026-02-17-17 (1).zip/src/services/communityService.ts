import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  setDoc,
} from 'firebase/firestore';
import { db, sanitizeFirestoreData } from './firebase';

/**
 * Permanently deletes a community and all nested resources:
 * - Subcollection 'posts' (and their nested 'comments')
 * - Subcollection 'members'
 * - App settings 'featuredCommunities' reference if present
 * - The community document itself
 */
export async function deleteCommunityCascade(communityId: string): Promise<void> {
  if (!communityId) return;

  // 1. Delete all posts and their nested comments
  try {
    const postsSnap = await getDocs(collection(db, 'communities', communityId, 'posts'));
    for (const postDoc of postsSnap.docs) {
      try {
        const commentsSnap = await getDocs(
          collection(db, 'communities', communityId, 'posts', postDoc.id, 'comments')
        );
        for (const commentDoc of commentsSnap.docs) {
          await deleteDoc(commentDoc.ref);
        }
      } catch (err) {
        console.warn('Warning: Could not delete some comments for post', postDoc.id, err);
      }
      await deleteDoc(postDoc.ref);
    }
  } catch (err) {
    console.warn('Warning: Error while cleaning community posts:', err);
  }

  // 2. Delete all members in subcollection
  try {
    const membersSnap = await getDocs(collection(db, 'communities', communityId, 'members'));
    for (const memberDoc of membersSnap.docs) {
      await deleteDoc(memberDoc.ref);
    }
  } catch (err) {
    console.warn('Warning: Error while cleaning community members:', err);
  }

  // 3. Delete the community document itself
  await deleteDoc(doc(db, 'communities', communityId));

  // 4. Remove from featured communities setting if it was featured on the Home
  try {
    const featRef = doc(db, 'settings', 'featuredCommunities');
    const featSnap = await getDoc(featRef);
    if (featSnap.exists()) {
      const data = featSnap.data();
      const currentIds: string[] = data?.communityIds || [];
      if (currentIds.includes(communityId)) {
        const updatedIds = currentIds.filter((id) => id !== communityId);
        const currentComms = (data?.communities || []).filter(
          (c: any) => c.communityId !== communityId
        );
        await setDoc(
          featRef,
          sanitizeFirestoreData({
            id: 'featuredCommunities',
            communityIds: updatedIds,
            communities: currentComms,
            updatedAt: new Date().toISOString(),
          }),
          { merge: true }
        );
      }
    }
  } catch (err) {
    console.warn('Warning: Could not remove community from featured list:', err);
  }
}
