import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  setDoc,
  updateDoc,
  query,
  where,
} from 'firebase/firestore';
import { KardPackage, PixOrder, PixOrderStatus, PixTransactionData } from '../types';
import { getApiBaseUrl } from './apiConfig';
import { db, handleFirestoreError, OperationType } from './firebase';
import { creditKards } from './kardsService';

const LOCAL_STORAGE_KEY_PREFIX = 'kordel_pix_orders_';

/**
 * Lê pedidos salvos em localStorage para redundância e tolerância a recarregamento
 */
export function getLocalOrders(userId: string): PixOrder[] {
  if (!userId) return [];
  try {
    const raw = localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}${userId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.warn('[pixService] Falha ao ler localStorage de pedidos Pix:', err);
  }
  return [];
}

/**
 * Salva ou atualiza pedido no localStorage
 */
export function saveLocalOrder(userId: string, order: PixOrder) {
  if (!userId || !order?.txId) return;
  try {
    const current = getLocalOrders(userId);
    const index = current.findIndex((o) => o.txId === order.txId);
    if (index >= 0) {
      current[index] = { ...current[index], ...order };
    } else {
      current.unshift(order);
    }
    localStorage.setItem(
      `${LOCAL_STORAGE_KEY_PREFIX}${userId}`,
      JSON.stringify(current.slice(0, 25))
    );
  } catch (err) {
    console.warn('[pixService] Falha ao salvar pedido no localStorage:', err);
  }
}

/**
 * Cria ou inicializa uma nova cobrança Pix
 */
export async function createPixOrder(
  pkg: { id: string; kards: number; bonus?: number; priceBrl: number; title: string },
  user: { uid: string; email?: string | null }
): Promise<PixTransactionData> {
  const totalKards = pkg.kards + (pkg.bonus || 0);
  const apiBase = getApiBaseUrl();

  const payload = {
    packageId: pkg.id,
    kards: totalKards,
    amountBrl: pkg.priceBrl,
    title: pkg.title,
    userId: user.uid,
    userEmail: user.email || '',
  };

  const res = await fetch(`${apiBase}/api/pix/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Erro ao gerar cobrança Pix instantânea.');
  }

  const data: PixTransactionData = await res.json();

  const orderDoc: PixOrder = {
    id: data.txId,
    txId: data.txId,
    userId: user.uid,
    userEmail: user.email || '',
    packageId: pkg.id,
    kards: totalKards,
    amountBrl: pkg.priceBrl,
    title: pkg.title,
    status: 'pending' as PixOrderStatus,
    pixKey: data.pixKey || '',
    merchantName: data.merchantName || 'GB Payment',
    brCode: data.brCode,
    createdAt: new Date().toISOString(),
    expiresAt: data.expiresAt,
  };

  // Salva no localStorage imediatamente
  saveLocalOrder(user.uid, orderDoc);

  // Registra no Firestore para escuta em tempo real e auditoria
  try {
    const orderRef = doc(db, 'pixOrders', data.txId);
    await setDoc(orderRef, orderDoc);
  } catch (fsErr) {
    console.warn(
      '[pixService] Não foi possível persistir doc no Firestore (regras ou conexão):',
      fsErr
    );
  }

  return data;
}

/**
 * Consulta a verificação da transação Pix no backend com suporte a fallback de dados
 */
export async function verifyPixPayment(
  txId: string,
  userId: string,
  receiptCode?: string,
  orderFallback?: PixOrder | null
): Promise<{
  verified: boolean;
  paid: boolean;
  status: PixOrderStatus;
  kards?: number;
  message: string;
}> {
  const apiBase = getApiBaseUrl();

  const res = await fetch(`${apiBase}/api/pix/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      txId,
      userId,
      receiptCode: receiptCode?.trim() || undefined,
      orderFallback: orderFallback || undefined,
    }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || errData.message || 'Falha ao consultar verificação bancária.');
  }

  const result = await res.json();

  // Atualiza cache local com o status retornado
  if (result.status) {
    const local = getLocalOrders(userId);
    const existing = local.find((o) => o.txId === txId);
    if (existing) {
      saveLocalOrder(userId, {
        ...existing,
        status: result.status,
        paidAt: result.paid ? new Date().toISOString() : existing.paidAt,
      });
    }
  }

  return result;
}

/**
 * Envia código de autenticação do comprovante para conferência bancária e liberação
 */
export async function submitPixReceipt(
  txId: string,
  receiptCode: string,
  userId: string,
  orderFallback?: PixOrder | null
): Promise<{ paid: boolean; message: string }> {
  const cleanCode = (receiptCode || '').trim().toUpperCase().replace(/[^A-Z0-9\-\.]/g, '');
  if (!cleanCode || cleanCode.length < 10) {
    throw new Error('O código de comprovante é obrigatório e deve ter pelo menos 10 caracteres alfanuméricos.');
  }

  const apiBase = getApiBaseUrl();

  // Envia para validação na API
  const res = await fetch(`${apiBase}/api/pix/receipt`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ txId, receiptCode: cleanCode, userId, orderFallback }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || errData.message || 'Erro ao validar comprovante bancário.');
  }

  const data = await res.json();
  const isPaid = Boolean(data.paid);

  // Atualiza Local Storage
  const local = getLocalOrders(userId);
  const existing = local.find((o) => o.txId === txId);
  if (existing) {
    saveLocalOrder(userId, {
      ...existing,
      receiptCode: cleanCode,
      receiptSentAt: new Date().toISOString(),
      status: isPaid ? 'paid' : 'under_review',
      paidAt: isPaid ? new Date().toISOString() : existing.paidAt,
    });
  }

  // Atualiza Firestore
  try {
    const orderRef = doc(db, 'pixOrders', txId);
    await updateDoc(orderRef, {
      receiptCode: cleanCode,
      receiptSentAt: new Date().toISOString(),
      status: isPaid ? 'paid' : 'under_review',
      paidAt: isPaid ? new Date().toISOString() : undefined,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('[pixService] Erro ao atualizar comprovante no Firestore:', err);
  }

  return {
    paid: isPaid,
    message: data.message || 'Comprovante bancário processado com sucesso!',
  };
}

/**
 * Aprova manualmente uma ordem Pix (Apenas Desenvolvedores/Administradores)
 */
export async function approvePixOrder(
  txId: string,
  adminUserId: string,
  orderFallback?: PixOrder | null
): Promise<void> {
  const apiBase = getApiBaseUrl();

  const res = await fetch(`${apiBase}/api/pix/confirm`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ txId, adminUserId, orderFallback }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || 'Erro ao aprovar ordem Pix.');
  }

  // Atualiza Local Storage
  const local = getLocalOrders(adminUserId);
  const existing = local.find((o) => o.txId === txId);
  if (existing) {
    saveLocalOrder(adminUserId, {
      ...existing,
      status: 'paid',
      paidAt: new Date().toISOString(),
      verifiedBy: adminUserId,
    });
  }

  // Atualiza Firestore
  try {
    const orderRef = doc(db, 'pixOrders', txId);
    await updateDoc(orderRef, {
      status: 'paid',
      paidAt: new Date().toISOString(),
      verifiedBy: adminUserId,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('[pixService] Erro ao atualizar aprovação no Firestore:', err);
  }
}

/**
 * Rejeita uma cobrança Pix (Apenas Desenvolvedores/Administradores)
 */
export async function rejectPixOrder(
  txId: string,
  adminUserId: string,
  reason?: string
): Promise<void> {
  const apiBase = getApiBaseUrl();

  const res = await fetch(`${apiBase}/api/pix/reject`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ txId, adminUserId, reason }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || 'Erro ao recusar ordem Pix.');
  }

  try {
    const orderRef = doc(db, 'pixOrders', txId);
    await updateDoc(orderRef, {
      status: 'rejected',
      adminNotes: reason || 'Recusado pela moderação',
      verifiedBy: adminUserId,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('[pixService] Erro ao atualizar rejeição no Firestore:', err);
  }
}

/**
 * Busca todas as ordens Pix para exibição no painel do desenvolvedor
 */
export async function fetchAllPixOrders(): Promise<PixOrder[]> {
  try {
    const apiBase = getApiBaseUrl();
    const res = await fetch(`${apiBase}/api/pix/orders`);
    if (res.ok) {
      const serverList = await res.json();
      if (Array.isArray(serverList) && serverList.length > 0) {
        return serverList;
      }
    }
  } catch (err) {
    console.warn('[pixService] Falha ao consultar ordens via API backend, buscando no Firestore:', err);
  }

  try {
    const q = query(collection(db, 'pixOrders'));
    const snap = await getDocs(q);
    const list: PixOrder[] = [];
    snap.forEach((d) => list.push(d.data() as PixOrder));
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (err) {
    console.error('[pixService] Erro ao ler ordens Pix do Firestore:', err);
    return [];
  }
}

/**
 * Efetua a liberação dos Kards no saldo do usuário e marca a ordem como completed
 */
export async function claimAndCreditPixOrder(
  order: PixOrder,
  userId: string
): Promise<{ success: boolean; kardsAdded: number }> {
  try {
    await creditKards(
      userId,
      order.kards,
      'kard_purchase',
      `Compra de ${order.kards} Kards via Pix Instantâneo (TXID: ${order.txId})`,
      order.txId
    );
  } catch (err: any) {
    // Se já foi processada anteriormente, é seguro continuar e marcar como concluída
    if (!err?.message?.includes('já foi processada')) {
      throw err;
    }
  }

  // Atualiza Firestore para completed
  try {
    const orderRef = doc(db, 'pixOrders', order.txId);
    await updateDoc(orderRef, {
      status: 'completed',
      completedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('[pixService] Erro ao marcar status completed no Firestore:', err);
  }

  // Atualiza Local Storage
  saveLocalOrder(userId, {
    ...order,
    status: 'completed',
  });

  return { success: true, kardsAdded: order.kards };
}

/**
 * Cancela ou descarta uma ordem pendente
 */
export async function cancelPixOrder(txId: string, userId: string): Promise<void> {
  try {
    const orderRef = doc(db, 'pixOrders', txId);
    await updateDoc(orderRef, {
      status: 'expired',
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('[pixService] Erro ao cancelar ordem no Firestore:', err);
  }

  const local = getLocalOrders(userId);
  const item = local.find((o) => o.txId === txId);
  if (item) {
    saveLocalOrder(userId, { ...item, status: 'expired' });
  }
}

/**
 * Busca todas as ordens Pix do usuário (mesclando Firestore, cache de servidor e LocalStorage)
 */
export async function getUserPixOrders(userId: string): Promise<PixOrder[]> {
  if (!userId) return [];

  const localList = getLocalOrders(userId);
  const ordersMap = new Map<string, PixOrder>();

  // 1. Carrega do localStorage
  localList.forEach((o) => ordersMap.set(o.txId, o));

  // 2. Carrega do Firestore
  try {
    const q = query(collection(db, 'pixOrders'), where('userId', '==', userId));
    const snap = await getDocs(q);
    snap.forEach((d) => {
      const data = d.data() as PixOrder;
      if (data && data.txId) {
        ordersMap.set(data.txId, {
          ...(ordersMap.get(data.txId) || {}),
          ...data,
        });
      }
    });
  } catch (err) {
    console.warn('[pixService] Falha ao carregar ordens do Firestore:', err);
  }

  // 3. Carrega do servidor
  try {
    const apiBase = getApiBaseUrl();
    const res = await fetch(`${apiBase}/api/pix/orders?userId=${userId}`).catch(() => null);
    if (res && res.ok) {
      const data = await res.json().catch(() => null);
      if (data && Array.isArray(data.orders)) {
        data.orders.forEach((o: any) => {
          if (o && o.txId && (o.userId === userId || !o.userId)) {
            const existing = ordersMap.get(o.txId);
            ordersMap.set(o.txId, {
              ...(existing || {}),
              ...o,
            });
          }
        });
      }
    }
  } catch (_) {}

  const list = Array.from(ordersMap.values());
  list.sort((a, b) => {
    const tA = new Date(a.createdAt).getTime() || 0;
    const tB = new Date(b.createdAt).getTime() || 0;
    return tB - tA;
  });

  return list;
}

/**
 * Escuta em tempo real todas as ordens Pix do usuário
 */
export function subscribeUserPixOrders(
  userId: string,
  onUpdate: (orders: PixOrder[]) => void
): () => void {
  if (!userId) {
    onUpdate([]);
    return () => {};
  }

  // Emite dados locais primeiro para renderização instantânea
  onUpdate(getLocalOrders(userId));

  try {
    const q = query(collection(db, 'pixOrders'), where('userId', '==', userId));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const localList = getLocalOrders(userId);
        const ordersMap = new Map<string, PixOrder>();
        localList.forEach((o) => ordersMap.set(o.txId, o));

        snap.forEach((d) => {
          const data = d.data() as PixOrder;
          if (data && data.txId) {
            ordersMap.set(data.txId, {
              ...(ordersMap.get(data.txId) || {}),
              ...data,
            });
          }
        });

        const list = Array.from(ordersMap.values());
        list.sort((a, b) => {
          const tA = new Date(a.createdAt).getTime() || 0;
          const tB = new Date(b.createdAt).getTime() || 0;
          return tB - tA;
        });

        onUpdate(list);
      },
      (err) => {
        console.warn('[pixService] Erro no snapshot de pixOrders do usuário:', err);
      }
    );

    return unsub;
  } catch (err) {
    console.warn('[pixService] Falha ao assinar pixOrders:', err);
    return () => {};
  }
}

/**
 * Procura um pedido pendente recente não expirado para reaproveitar
 */
export async function findRecentActiveOrder(
  userId: string,
  packageId?: string
): Promise<PixOrder | null> {
  const orders = await getUserPixOrders(userId);
  const now = Date.now();

  const active = orders.find((o) => {
    const expiresMs = new Date(o.expiresAt).getTime();
    const isNotExpired = expiresMs > now;
    const isPendingOrReview = o.status === 'pending' || o.status === 'under_review';
    const matchesPkg = !packageId || o.packageId === packageId;
    return isNotExpired && isPendingOrReview && matchesPkg;
  });

  return active || null;
}

/**
 * Escuta em tempo real o status de uma ordem Pix específica
 */
export function subscribePixOrder(txId: string, onUpdate: (order: PixOrder) => void): () => void {
  const orderRef = doc(db, 'pixOrders', txId);
  return onSnapshot(
    orderRef,
    (snap) => {
      if (snap.exists()) {
        onUpdate(snap.data() as PixOrder);
      }
    },
    (err) => {
      console.warn('[pixService] Snapshot error on pixOrders:', err);
    }
  );
}
