import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db } from './firebase';
import { SubscriptionPlanId, UserProfile, UserSubscription } from '../types';
import { evaluateWriterAchievements } from './progressionService';
import { cleanReceiptCode, validateReceiptCode } from '../utils/receiptValidator';

export interface PlanBenefitInfo {
  id: 'leitor' | 'escritor';
  name: string;
  creativeName: string;
  badgeText: string;
  price: number;
  periodLabel: string;
  targetRole: 'leitor' | 'escritor';
  tagline: string;
  description: string;
  benefits: string[];
}

/**
 * The ONLY two official KORDEL subscription modalities:
 * 1. ASSINATURA LEITOR — R$ 4,90/mês
 * 2. ASSINATURA ESCRITOR — R$ 13,49/mês
 */
export const SUBSCRIPTION_PLANS: Record<'leitor' | 'escritor', PlanBenefitInfo> = {
  leitor: {
    id: 'leitor',
    name: 'Assinatura Leitor',
    creativeName: 'KORDEL Leitor',
    badgeText: 'Leitor Experiente',
    price: 4.90,
    periodLabel: 'mês',
    targetRole: 'leitor',
    tagline: 'Gamificação, capítulos antecipados, obras beta e o selo Leitor Experiente',
    description:
      'Desenvolvido para leitores apaixonados. Tenha acesso irrestrito ao sistema de gamificação com XP e ranking semanal, leitura de capítulos antecipados e obras em versão beta.',
    benefits: [
      'Acesso ao sistema de gamificação, incluindo XP, níveis, missões e ranking semanal de leitores',
      'Acesso antecipado a capítulos disponibilizados pelos autores',
      'Acesso a obras em versão beta para testes e leitura antecipada',
      'Selo "Leitor Experiente" associado ao perfil enquanto a assinatura estiver ativa',
    ],
  },
  escritor: {
    id: 'escritor',
    name: 'Assinatura Escritor',
    creativeName: 'KORDEL Escritor',
    badgeText: 'Escritor Verificado',
    price: 13.49,
    periodLabel: 'mês',
    targetRole: 'escritor',
    tagline: 'Selo Escritor Verificado, 2 impulsionamentos/mês, Instagram oficial e Conquistas',
    description:
      'O plano completo para autores do KORDEL. Conquiste o selo oficial de Escritor Verificado, impulsione 2 obras por mês (7 dias cada), participe das divulgações no Instagram e acerte marcos no sistema de conquistas.',
    benefits: [
      'Selo "Escritor Verificado" no perfil, obras publicadas e comentários',
      '2 impulsionamentos por mês, cada um com duração de 7 dias na plataforma',
      'Criação de 1 comunidade literária exclusiva durante a assinatura ativa (renovável a cada ciclo)',
      'Acesso às oportunidades de divulgação do KORDEL no Instagram, incluindo quadros e campanhas de divulgação de autores e obras',
      'Acesso a um sistema de conquistas voltado para escritores, autores, obras e comunidades, reconhecendo marcos e destaques relevantes da plataforma',
    ],
  },
};

export const DEV_BOOTSTRAP_EMAIL = 'timaosemlimite001@gmail.com';

export function isUserDeveloper(user: { role?: string; email?: string }): boolean {
  return (
    user.role === 'desenvolvedor' ||
    (user.email || '').trim().toLowerCase() === DEV_BOOTSTRAP_EMAIL.toLowerCase()
  );
}

/**
 * Normalizes any plan ID (including legacy ones) to 'leitor' or 'escritor'
 */
export function normalizePlanId(planId?: string | null): 'leitor' | 'escritor' | null {
  if (!planId) return null;
  const p = planId.toLowerCase();
  if (p === 'leitor' || p === 'kardel_pro') return 'leitor';
  if (p === 'escritor' || p === 'kardel_escritor' || p === 'kardel_verificado') return 'escritor';
  return null;
}

/**
 * Checks whether user has an active, valid subscription for the given plan modality
 */
export function isSubscriptionActive(
  user?: UserProfile | null,
  requiredPlan?: 'leitor' | 'escritor'
): boolean {
  if (!user || !user.subscription) return false;
  const sub = user.subscription;
  if (sub.status !== 'active') return false;

  const isPeriodValid = new Date(sub.currentPeriodEnd).getTime() > Date.now();
  if (!isPeriodValid) return false;

  if (!requiredPlan) return true;
  return normalizePlanId(sub.planId) === requiredPlan;
}

/**
 * Automatically evaluates, synchronizes, and enforces subscription rules,
 * auto-renewals, expiration, and badges.
 * Rules:
 * - Badges are active ONLY while subscription is active.
 * - When expired/canceled, badges are removed.
 * - History and already earned achievements are NEVER deleted.
 */
export async function evaluateAndSyncUserSubscription(user: UserProfile): Promise<UserProfile> {
  let updated = { ...user };
  let hasChanges = false;
  const now = new Date();
  const nowIso = now.toISOString();
  const nowTime = now.getTime();

  // 1. Evaluate subscription lifecycle if present
  if (user.subscription) {
    const sub = { ...user.subscription };
    const normPlan = normalizePlanId(sub.planId) || 'leitor';
    const periodEnd = new Date(sub.currentPeriodEnd).getTime();
    const isPastPeriodEnd = nowTime > periodEnd;

    if (isPastPeriodEnd) {
      if (sub.autoRenew && sub.status === 'active') {
        // Automatic renewal for +1 month
        const newPeriodEnd = new Date(nowTime + 30 * 24 * 60 * 60 * 1000).toISOString();
        sub.startedAt = nowIso;
        sub.currentPeriodEnd = newPeriodEnd;
        sub.status = 'active';
        sub.boostsUsedThisCycle = 0; // Reset monthly boosts for new cycle
        sub.lastBoostCycle = nowIso.substring(0, 7);
        sub.communitiesCreatedThisCycle = 0; // Reset community creation quota for new active cycle
        hasChanges = true;
      } else {
        // Expired
        if (sub.status !== 'expired') {
          sub.status = 'expired';
          hasChanges = true;
        }
      }
    }

    const isActive = sub.status === 'active' && nowTime <= new Date(sub.currentPeriodEnd).getTime();

    // 2. Enforce badges based strictly on active state
    if (normPlan === 'leitor') {
      if (isActive) {
        if (!updated.hasExperiencedReaderBadge) {
          updated.hasExperiencedReaderBadge = true;
          hasChanges = true;
        }
        if (!updated.hasKardelProBadge) {
          updated.hasKardelProBadge = true;
          hasChanges = true;
        }
      } else {
        // Remove badge when not active
        if (updated.hasExperiencedReaderBadge) {
          updated.hasExperiencedReaderBadge = false;
          hasChanges = true;
        }
        if (updated.hasKardelProBadge) {
          updated.hasKardelProBadge = false;
          hasChanges = true;
        }
      }
    } else if (normPlan === 'escritor') {
      if (isActive) {
        if (!updated.isVerifiedWriter || updated.isVerifiedWriterSuspended) {
          updated.isVerifiedWriter = true;
          updated.isVerifiedWriterSuspended = false;
          hasChanges = true;
        }
      } else {
        // Remove verified seal when not active
        if (updated.isVerifiedWriter) {
          updated.isVerifiedWriter = false;
          updated.isVerifiedWriterSuspended = false;
          hasChanges = true;
        }
      }
    }

    updated.subscription = sub;
  } else {
    // If no subscription, remove active badges
    if (updated.hasExperiencedReaderBadge) {
      updated.hasExperiencedReaderBadge = false;
      hasChanges = true;
    }
    if (updated.hasKardelProBadge) {
      updated.hasKardelProBadge = false;
      hasChanges = true;
    }
    if (updated.isVerifiedWriter) {
      updated.isVerifiedWriter = false;
      hasChanges = true;
    }
  }

  // 3. Regra de Gamificação Estrita:
  // "Só quem pode participar do ranking é quem tem a assinatura de 4,90 ativa.
  //  Se ele não tem o plano ele perdeu acesso a sistema de gamificação as missões de XP sumiram
  //  e ele não ganha mais XP, o nível dele zera também."
  const isLeitorActive = isSubscriptionActive(updated, 'leitor');
  if (!isLeitorActive) {
    if ((updated.level || 0) !== 0 || (updated.xp || 0) !== 0 || (updated.progressionCycle || 0) !== 0) {
      updated.level = 0;
      updated.xp = 0;
      updated.progressionCycle = 0;
      hasChanges = true;
    }
  } else {
    // Se a assinatura Leitor estiver ativa e o nível estiver zerado, inicializa no Nível 1
    if ((updated.level || 0) === 0) {
      updated.level = 1;
      hasChanges = true;
    }
  }

  // Persist if any state changes were computed
  if (hasChanges) {
    try {
      const userRef = doc(db, 'users', user.id);
      await updateDoc(userRef, {
        hasExperiencedReaderBadge: Boolean(updated.hasExperiencedReaderBadge),
        hasKardelProBadge: Boolean(updated.hasKardelProBadge),
        isVerifiedWriter: Boolean(updated.isVerifiedWriter),
        isVerifiedWriterSuspended: Boolean(updated.isVerifiedWriterSuspended),
        level: updated.level ?? 0,
        xp: updated.xp ?? 0,
        progressionCycle: updated.progressionCycle ?? 0,
        ...(updated.subscription ? { subscription: updated.subscription } : {}),
        updatedAt: nowIso,
      });
    } catch (err) {
      console.warn('Could not persist evaluated subscription in Firestore:', err);
    }
  }

  return updated;
}

export interface SubscriptionPaymentInput {
  paymentMethod: string;
  paidAmount: number;
  transactionId?: string;
  isConfirmedPayment: boolean;
  receiptId?: string;
  receiptType?: string;
  bankName?: string;
}

/**
 * Creates dynamic Pix charge for subscription
 */
export async function createSubscriptionPixOrder(
  planId: 'leitor' | 'escritor',
  user: { id: string; email?: string }
): Promise<{
  txId: string;
  brCode: string;
  qrCodeDataUrl: string;
  amountBrl: number;
  planId: string;
  planName: string;
  expiresAt: string;
  pixKey: string;
  merchantName: string;
}> {
  const normId = normalizePlanId(planId) || 'leitor';
  const res = await fetch('/api/subscription/create-pix', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      planId: normId,
      userId: user.id,
      userEmail: user.email || '',
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Erro ao gerar Pix da assinatura.');
  }
  return await res.json();
}

export interface ReceiptConfirmationResult {
  updatedProfile: UserProfile;
  receiptInfo: {
    code: string;
    type?: 'e2e_pix' | 'auth_code';
    bankName?: string;
    extractedDate?: string;
  };
  txId: string;
}

/**
 * Validação rigorosa e liberação da assinatura pelo ID do comprovante de pagamento.
 * Requisitos estritos:
 * - Valida autenticidade e formato (ID Fim-a-Fim Pix Bacen ou Autenticação Eletrônica).
 * - Impede simulações, mocks e termos inválidos.
 * - Impede reutilização (anti-replay): cada comprovante só pode ser utilizado 1 única vez.
 * - Registra o comprovante na coleção usedPixReceipts no Firestore e no backend.
 * - Só libera o status 'active' e os selos após a confirmação integral da veracidade.
 */
export async function confirmSubscriptionWithReceipt(
  user: UserProfile,
  planId: 'leitor' | 'escritor',
  receiptCodeInput: string,
  txId?: string
): Promise<ReceiptConfirmationResult> {
  const normId = normalizePlanId(planId) || 'leitor';
  const plan = SUBSCRIPTION_PLANS[normId];
  if (!plan) throw new Error('Plano de assinatura inválido.');

  const cleanCode = cleanReceiptCode(receiptCodeInput);

  // 1. Pré-validação no cliente
  const localValidation = validateReceiptCode(cleanCode);
  if (!localValidation.isValid) {
    throw new Error(localValidation.error || 'Código do comprovante inválido.');
  }

  // 2. Validação profunda no servidor (inclui anti-fraude, anti-replay e persistência)
  const res = await fetch('/api/subscription/confirm-receipt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: user.id,
      userEmail: user.email,
      planId: normId,
      receiptCode: cleanCode,
      txId,
    }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.success) {
    throw new Error(
      data.error || 'Não foi possível confirmar o comprovante de pagamento junto à autoridade bancária.'
    );
  }

  const now = new Date();
  const nowIso = now.toISOString();
  const currentPeriodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();
  const finalTxId = data.txId || `SUB_${cleanCode.substring(0, 16)}`;

  const newSub: UserSubscription = {
    planId: normId,
    planName: plan.name,
    price: plan.price,
    status: 'active',
    startedAt: nowIso,
    currentPeriodEnd,
    autoRenew: true,
    paymentMethod: `Pix (${data.receiptInfo?.bankName || 'Comprovante Autenticado'})`,
    receiptId: cleanCode,
    receiptType: data.receiptInfo?.type,
    bankName: data.receiptInfo?.bankName,
    validatedAt: nowIso,
    boostsUsedThisCycle: 0,
    lastBoostCycle: nowIso.substring(0, 7),
    communitiesCreatedThisCycle: 0,
  };

  const isVerified = normId === 'escritor';
  const hasExperiencedReader = normId === 'leitor';

  // 3. Atualiza perfil do usuário no Firestore com a assinatura liberada
  const userRef = doc(db, 'users', user.id);
  const payload: Record<string, any> = {
    subscription: newSub,
    hasExperiencedReaderBadge: hasExperiencedReader,
    hasKardelProBadge: hasExperiencedReader,
    isVerifiedWriter: isVerified,
    isVerifiedWriterSuspended: false,
    updatedAt: nowIso,
  };

  if (normId === 'escritor' && user.role === 'leitor') {
    payload.role = 'escritor';
  }

  if (normId === 'leitor' && (user.level || 0) === 0) {
    payload.level = 1;
    payload.xp = 0;
    payload.progressionCycle = 0;
  }

  await updateDoc(userRef, payload);

  // 4. Registra comprovante em usedPixReceipts no Firestore para auditoria permanente
  try {
    const receiptRef = doc(db, 'usedPixReceipts', cleanCode);
    await setDoc(receiptRef, {
      receiptCode: cleanCode,
      userId: user.id,
      userEmail: user.email || '',
      planId: normId,
      amount: plan.price,
      bankName: data.receiptInfo?.bankName || 'Bancário',
      type: data.receiptInfo?.type || 'e2e_pix',
      usedAt: nowIso,
    });
  } catch (receiptErr) {
    console.warn('[subscriptionService] Falha ao registrar usedPixReceipts no Firestore:', receiptErr);
  }

  // 5. Registra transação completa no Firestore
  try {
    const txRef = doc(db, 'transactions', finalTxId);
    await setDoc(txRef, {
      id: finalTxId,
      userId: user.id,
      amount: plan.price,
      type: 'purchase',
      description: `Assinatura ${plan.name} via Pix (Comprovante: ${cleanCode})`,
      referenceId: normId,
      paymentMethod: `Pix - ${data.receiptInfo?.bankName || 'Bancário'}`,
      receiptCode: cleanCode,
      status: 'completed',
      paidAt: nowIso,
      createdAt: nowIso,
    });
  } catch (txErr) {
    console.warn('[subscriptionService] Falha ao salvar transação no Firestore:', txErr);
  }

  // 6. Se escritor, avalia conquistas imediatamente
  if (normId === 'escritor') {
    try {
      await evaluateWriterAchievements(user.id);
    } catch (err) {
      console.warn('Could not evaluate writer achievements on subscribe:', err);
    }
  }

  const updatedProfile: UserProfile = {
    ...user,
    ...(payload.role ? { role: payload.role } : {}),
    subscription: newSub,
    hasExperiencedReaderBadge: hasExperiencedReader,
    hasKardelProBadge: hasExperiencedReader,
    isVerifiedWriter: isVerified,
    isVerifiedWriterSuspended: false,
    updatedAt: nowIso,
  };

  return {
    updatedProfile,
    receiptInfo: data.receiptInfo,
    txId: finalTxId,
  };
}

/**
 * Activates a subscription.
 * STRICT ENFORCEMENT:
 * - Only 'leitor' (R$ 4,90/mês) or 'escritor' (R$ 13,49/mês).
 * - Subscriptions MUST be released ONLY upon confirmed payment with verified receipt.
 */
export async function subscribeToPlan(
  user: UserProfile,
  planId: 'leitor' | 'escritor' | SubscriptionPlanId,
  paymentInput: SubscriptionPaymentInput
): Promise<UserProfile> {
  const normId = normalizePlanId(planId) || 'leitor';
  const plan = SUBSCRIPTION_PLANS[normId];
  if (!plan) throw new Error('Plano inválido selecionado.');

  // Payment verification: Must be confirmed with receipt and match price
  if (
    !paymentInput ||
    !paymentInput.isConfirmedPayment ||
    !paymentInput.receiptId ||
    paymentInput.paidAmount < plan.price
  ) {
    throw new Error(
      'A assinatura só pode ser liberada mediante a confirmação efetiva do pagamento e validação do ID do comprovante.'
    );
  }

  const result = await confirmSubscriptionWithReceipt(
    user,
    normId,
    paymentInput.receiptId,
    paymentInput.transactionId
  );
  return result.updatedProfile;
}

/**
 * Cancels auto-renewal for the user's active subscription.
 * Benefits remain active until currentPeriodEnd.
 */
export async function cancelSubscription(user: UserProfile): Promise<UserProfile> {
  if (!user.subscription) throw new Error('Você não possui uma assinatura ativa.');

  const updatedSub: UserSubscription = {
    ...user.subscription,
    autoRenew: false,
    canceledAt: new Date().toISOString(),
  };

  const userRef = doc(db, 'users', user.id);
  await updateDoc(userRef, {
    subscription: updatedSub,
    updatedAt: new Date().toISOString(),
  });

  return {
    ...user,
    subscription: updatedSub,
  };
}

/**
 * Reactivates auto-renewal for a canceled subscription that hasn't expired yet.
 */
export async function reactivateSubscription(user: UserProfile): Promise<UserProfile> {
  if (!user.subscription) throw new Error('Você não possui assinatura para reativar.');

  const updatedSub: UserSubscription = {
    ...user.subscription,
    autoRenew: true,
    status: 'active',
    canceledAt: undefined,
  };

  const userRef = doc(db, 'users', user.id);
  await updateDoc(userRef, {
    subscription: updatedSub,
    updatedAt: new Date().toISOString(),
  });

  return {
    ...user,
    subscription: updatedSub,
  };
}

/**
 * Ativação manual de assinatura pelo desenvolvedor / administrador.
 * Permite conceder Assinatura Leitor ou Escritor para qualquer usuário selecionado,
 * com duração customizada (em dias) ou vitalícia, atualizando selos, permissões e registrando auditoria.
 */
export async function manuallyActivateUserSubscription(
  targetUserId: string,
  planId: 'leitor' | 'escritor',
  durationDays: number = 30,
  justification?: string,
  devAdminId?: string
): Promise<UserProfile> {
  const normId = normalizePlanId(planId) || 'leitor';
  const plan = SUBSCRIPTION_PLANS[normId];
  if (!plan) throw new Error('Plano de assinatura inválido.');

  const userRef = doc(db, 'users', targetUserId);
  const userSnap = await getDoc(userRef);
  if (!userSnap.exists()) {
    throw new Error('Usuário de destino não encontrado no banco de dados.');
  }

  const userData = userSnap.data() as UserProfile;
  const now = new Date();
  const nowIso = now.toISOString();

  // Duração: se durationDays >= 3650 (10 anos) trata como Vitalícia
  const isLifetime = durationDays >= 3650;
  const periodEnd = isLifetime
    ? new Date(now.getTime() + 10 * 365 * 24 * 60 * 60 * 1000).toISOString()
    : new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000).toISOString();

  const receiptId = `DEV_MANUAL_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

  const newSub: UserSubscription = {
    planId: normId,
    planName: isLifetime ? `${plan.name} (Vitalícia / Cortesia Dev)` : `${plan.name} (Manual Dev)`,
    price: 0,
    status: 'active',
    startedAt: nowIso,
    currentPeriodEnd: periodEnd,
    autoRenew: false,
    paymentMethod: 'Ativação Manual pelo Desenvolvedor',
    receiptId,
    receiptType: 'auth_code',
    bankName: 'Painel Desenvolvedor KORDEL',
    validatedAt: nowIso,
    boostsUsedThisCycle: 0,
    lastBoostCycle: nowIso.substring(0, 7),
    communitiesCreatedThisCycle: 0,
  };

  const isVerified = normId === 'escritor';
  const hasExperiencedReader = normId === 'leitor';

  const updatePayload: Record<string, any> = {
    subscription: newSub,
    hasExperiencedReaderBadge: hasExperiencedReader,
    hasKardelProBadge: hasExperiencedReader,
    isVerifiedWriter: isVerified,
    isVerifiedWriterSuspended: false,
    updatedAt: nowIso,
  };

  if (normId === 'escritor' && (!userData.role || userData.role === 'leitor')) {
    updatePayload.role = 'escritor';
  }

  if (normId === 'leitor' && (userData.level || 0) === 0) {
    updatePayload.level = 1;
    updatePayload.xp = 0;
    updatePayload.progressionCycle = 0;
  }

  await updateDoc(userRef, updatePayload);

  // Registra comprovante auditado
  try {
    const receiptRef = doc(db, 'usedPixReceipts', receiptId);
    await setDoc(receiptRef, {
      receiptCode: receiptId,
      userId: targetUserId,
      userEmail: userData.email || '',
      planId: normId,
      amount: 0,
      bankName: 'Painel Desenvolvedor (Cortesia Manual)',
      type: 'auth_code',
      justification: justification || 'Ativação manual autorizada por desenvolvedor',
      activatedBy: devAdminId || 'developer',
      usedAt: nowIso,
    });
  } catch (err) {
    console.warn('[subscriptionService] Falha ao registrar usedPixReceipts:', err);
  }

  // Notifica o usuário no sistema
  try {
    const notifRef = doc(collection(db, 'notifications'));
    await setDoc(notifRef, {
      id: notifRef.id,
      userId: targetUserId,
      type: 'subscription',
      title: 'Assinatura Ativada!',
      message: `Você recebeu acesso à ${plan.name} ativada pelo desenvolvedor (${isLifetime ? 'Acesso Vitalício' : `${durationDays} dias`}). Aproveite todos os benefícios exclusivos!`,
      createdAt: nowIso,
      read: false,
      link: '/assinaturas',
    });
  } catch (notifErr) {
    console.warn('[subscriptionService] Falha ao enviar notificação de assinatura:', notifErr);
  }

  // Se escritor, aciona cálculo de conquistas
  if (normId === 'escritor') {
    try {
      await evaluateWriterAchievements(targetUserId);
    } catch (err) {
      console.warn('Could not evaluate writer achievements on manual subscribe:', err);
    }
  }

  return {
    ...userData,
    ...updatePayload,
    subscription: newSub,
  };
}

/**
 * Revogação / Cancelamento manual de assinatura pelo desenvolvedor
 */
export async function manuallyRevokeUserSubscription(
  targetUserId: string,
  justification?: string
): Promise<void> {
  const userRef = doc(db, 'users', targetUserId);
  const nowIso = new Date().toISOString();

  await updateDoc(userRef, {
    'subscription.status': 'canceled',
    'subscription.canceledAt': nowIso,
    hasExperiencedReaderBadge: false,
    hasKardelProBadge: false,
    isVerifiedWriter: false,
    updatedAt: nowIso,
  });
}

