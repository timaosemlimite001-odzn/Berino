import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  query,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db } from './firebase';
import { UserProfile } from '../types';

export interface PublicUserProfile {
  id: string;
  uniqueId: string;
  username: string;
  displayName: string;
  photoURL?: string;
  bio?: string;
  role: string;
  level: number;
  xp: number;
  activeTitle?: string;
  titles: string[];
  achievements: string[];
  hasExperiencedReaderBadge: boolean;
  isVerifiedWriter: boolean;
  followersCount?: number;
  followingCount?: number;
  createdAt: string;
}

export interface UserAdminMetrics {
  userId: string;
  displayName: string;
  username: string;
  uniqueId: string;
  createdAt: string;
  likesReceived: number;
  dislikesReceived: number;
  booksRead: number;
  reportsReceived: number;
  status: 'Ativo' | 'Banido' | 'Silenciado';
  isSilenced: boolean;
  isBanned: boolean;
  role: string;
  profile: UserProfile;
}

/**
 * Generates a permanent unique ID like KRD-74921
 */
export function generatePermanentUniqueId(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let randomPart = '';
  for (let i = 0; i < 5; i++) {
    randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `KRD-${randomPart}`;
}

/**
 * Ensures the user has a permanent unique ID and username.
 */
export async function ensureUserUniqueId(user: UserProfile): Promise<UserProfile> {
  if (user.uniqueId && user.username) {
    return user;
  }

  let uniqueId = user.uniqueId;
  if (!uniqueId) {
    uniqueId = generatePermanentUniqueId();
  }

  let username = user.username;
  if (!username) {
    const base = (user.displayName || 'usuario')
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '')
      .slice(0, 15);
    username = `@${base || 'leitor'}_${uniqueId.replace('KRD-', '').toLowerCase()}`;
  }

  try {
    const userRef = doc(db, 'users', user.id);
    await updateDoc(userRef, {
      uniqueId,
      username,
      updatedAt: new Date().toISOString(),
    });
    return { ...user, uniqueId, username };
  } catch (err) {
    console.warn('Could not update user uniqueId in Firestore:', err);
    return { ...user, uniqueId, username };
  }
}

/**
 * Validates a username string according to requirements:
 * - Must NOT contain uppercase letters
 * - No spaces allowed between words
 * - Must be a combination of lowercase letters, numbers, and allowed characters (_, ., -)
 * - Minimum 3 characters, maximum 25 characters
 */
export function validateUsernameFormat(raw: string): { valid: boolean; error?: string; formatted: string } {
  const trimmed = (raw || '').trim();
  const withoutAt = trimmed.startsWith('@') ? trimmed.slice(1) : trimmed;

  if (!withoutAt) {
    return { valid: false, error: 'O nome de usuário não pode ficar vazio.', formatted: '' };
  }

  // Check for uppercase letters
  if (/[A-Z]/.test(withoutAt)) {
    return { valid: false, error: 'Não são permitidas letras maiúsculas no nome de usuário.', formatted: '' };
  }

  // Check for whitespace
  if (/\s/.test(withoutAt)) {
    return { valid: false, error: 'O nome de usuário não pode conter espaços entre as palavras.', formatted: '' };
  }

  // Allowed characters: lowercase letters, numbers, and allowed characters (_, ., -)
  const validCharsRegex = /^[a-z0-9_.-]+$/;
  if (!validCharsRegex.test(withoutAt)) {
    return {
      valid: false,
      error: 'Use apenas letras minúsculas, números e caracteres como ponto (.), underline (_) ou hífen (-).',
      formatted: '',
    };
  }

  if (withoutAt.length < 3) {
    return { valid: false, error: 'O nome de usuário deve conter no mínimo 3 caracteres.', formatted: '' };
  }

  if (withoutAt.length > 25) {
    return { valid: false, error: 'O nome de usuário deve conter no máximo 25 caracteres.', formatted: '' };
  }

  return { valid: true, formatted: `@${withoutAt}` };
}

/**
 * Checks if a username is already in use by another user in Firestore.
 */
export async function checkUsernameAvailability(usernameWithAt: string, currentUserId: string): Promise<boolean> {
  const formatted = usernameWithAt.toLowerCase().trim();
  const withoutAt = formatted.startsWith('@') ? formatted.slice(1) : formatted;

  try {
    // Check both variations (@handle and handle) to guarantee uniqueness across all users
    const qWithAt = query(collection(db, 'users'), where('username', '==', `@${withoutAt}`), limit(2));
    const snapWithAt = await getDocs(qWithAt);
    const existsWithAt = snapWithAt.docs.some((d) => d.id !== currentUserId);
    if (existsWithAt) return false;

    const qPlain = query(collection(db, 'users'), where('username', '==', withoutAt), limit(2));
    const snapPlain = await getDocs(qPlain);
    const existsPlain = snapPlain.docs.some((d) => d.id !== currentUserId);
    if (existsPlain) return false;

    return true;
  } catch (err) {
    console.error('Error checking username availability:', err);
    // If query fails, permit save or surface error
    return true;
  }
}

/**
 * Sanitizes a profile so no private data (email, kards, etc.) is exposed.
 */
export function sanitizePublicProfile(user: UserProfile): PublicUserProfile {
  return {
    id: user.id,
    uniqueId: user.uniqueId || `KRD-${user.id.slice(0, 5).toUpperCase()}`,
    username: user.username || `@${(user.displayName || 'usuario').toLowerCase().replace(/\s+/g, '_')}`,
    displayName: user.displayName || 'Leitor',
    photoURL: user.photoURL,
    bio: user.bio,
    role: user.role,
    level: typeof user.level === 'number' ? user.level : 0,
    xp: user.xp || 0,
    activeTitle: user.activeTitle,
    titles: user.titles || [],
    achievements: user.achievements || [],
    hasExperiencedReaderBadge: Boolean(user.hasExperiencedReaderBadge),
    isVerifiedWriter: Boolean(user.isVerifiedWriter),
    followersCount: typeof user.followersCount === 'number' ? Math.max(0, user.followersCount) : 0,
    followingCount: typeof user.followingCount === 'number' ? Math.max(0, user.followingCount) : 0,
    createdAt: user.createdAt || new Date().toISOString(),
  };
}

/**
 * Fetches a user's document and returns sanitized public profile information
 */
export async function fetchPublicUserProfile(userId: string): Promise<PublicUserProfile | null> {
  if (!userId) return null;
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (!userDoc.exists()) return null;
    return sanitizePublicProfile(userDoc.data() as UserProfile);
  } catch (err) {
    console.error('Error fetching public user profile:', err);
    return null;
  }
}

/**
 * Search users by name, username, or unique permanent ID.
 * Returns only safe, public profile information.
 */
export async function searchPublicUsers(searchTerm: string, maxResults = 10): Promise<PublicUserProfile[]> {
  const term = searchTerm.trim();
  if (!term) return [];

  const cleanTerm = term.toUpperCase();
  const lowerTerm = term.toLowerCase().replace(/^@/, '');

  try {
    const usersRef = collection(db, 'users');
    const usersSnap = await getDocs(query(usersRef, limit(100)));
    const results: PublicUserProfile[] = [];

    usersSnap.forEach((docSnap) => {
      const u = docSnap.data() as UserProfile;
      if (u.isBanned) return;

      const uId = (u.uniqueId || '').toUpperCase();
      const uName = (u.displayName || '').toLowerCase();
      const uHandle = (u.username || '').toLowerCase().replace(/^@/, '');

      const matchesUniqueId = uId.includes(cleanTerm);
      const matchesName = uName.includes(lowerTerm);
      const matchesHandle = uHandle.includes(lowerTerm);

      if (matchesUniqueId || matchesName || matchesHandle) {
        results.push(sanitizePublicProfile(u));
      }
    });

    return results.slice(0, maxResults);
  } catch (err) {
    console.error('Error searching public users:', err);
    return [];
  }
}

/**
 * Computes real statistics for the developer users table:
 * - Real likes received on books and community posts
 * - Real dislikes received
 * - Real books read from user library
 * - Real reports received
 */
export async function calculateRealUserMetrics(user: UserProfile): Promise<UserAdminMetrics> {
  let likesReceived = 0;
  let dislikesReceived = 0;
  let booksRead = 0;
  let reportsReceived = 0;

  try {
    // 1. Likes received on author books
    const booksQuery = query(collection(db, 'books'), where('authorId', '==', user.id));
    const booksSnap = await getDocs(booksQuery);
    booksSnap.forEach((bDoc) => {
      const bData = bDoc.data();
      likesReceived += Number(bData.likesCount || 0);
    });

    // 2. Books read in user's library
    try {
      const libQuery = query(collection(db, 'libraries', user.id, 'items'));
      const libSnap = await getDocs(libQuery);
      libSnap.forEach((lDoc) => {
        const item = lDoc.data();
        if (item.status === 'completed' || (item.progressPercent && item.progressPercent >= 100)) {
          booksRead += 1;
        }
      });
    } catch {
      // ignore
    }

    // 3. Reports against this user
    try {
      const repQuery = query(collection(db, 'reports'), where('reportedUserId', '==', user.id));
      const repSnap = await getDocs(repQuery);
      reportsReceived = repSnap.size;
    } catch {
      // ignore
    }
  } catch (err) {
    console.warn(`Error gathering metrics for user ${user.id}:`, err);
  }

  const isSilenced = Boolean((user as any).isSilenced);
  const isBanned = Boolean(user.isBanned);
  const status: 'Ativo' | 'Banido' | 'Silenciado' = isBanned
    ? 'Banido'
    : isSilenced
    ? 'Silenciado'
    : 'Ativo';

  return {
    userId: user.id,
    displayName: user.displayName || 'Sem nome',
    username: user.username || `@usuario_${user.id.slice(0, 5)}`,
    uniqueId: user.uniqueId || `KRD-${user.id.slice(0, 5).toUpperCase()}`,
    createdAt: user.createdAt,
    likesReceived,
    dislikesReceived,
    booksRead,
    reportsReceived,
    status,
    isSilenced,
    isBanned,
    role: user.role,
    profile: user,
  };
}

// In-memory avatar & badge cache for fast reactive resolution across all feeds, posts, books & comments
export interface UserBadgeData {
  id: string;
  displayName: string;
  photoURL?: string;
  hasExperiencedReaderBadge: boolean;
  isVerifiedWriter: boolean;
  hasKardelProBadge?: boolean;
  showProBorder?: boolean;
  equippedTitles?: string[];
  role: string;
}

const userPhotoCache = new Map<string, string>();
const userBadgeDataCache = new Map<string, UserBadgeData>();
const photoListeners = new Map<string, Set<(photo: string) => void>>();
const badgeDataListeners = new Map<string, Set<(data: UserBadgeData) => void>>();
const activeUnsubscribes = new Map<string, () => void>();

export function getUserCachedPhoto(userId: string): string | undefined {
  return userPhotoCache.get(userId) || userBadgeDataCache.get(userId)?.photoURL;
}

export function getUserCachedName(userId: string): string | undefined {
  return userBadgeDataCache.get(userId)?.displayName;
}

export function getUserCachedData(userId: string): UserBadgeData | undefined {
  return userBadgeDataCache.get(userId);
}

export function setUserCachedData(userId: string, data: Partial<UserBadgeData>) {
  const existing = userBadgeDataCache.get(userId) || {
    id: userId,
    displayName: 'Leitor',
    hasExperiencedReaderBadge: false,
    isVerifiedWriter: false,
    role: 'leitor',
  };
  const updated: UserBadgeData = { ...existing, ...data };
  userBadgeDataCache.set(userId, updated);
  if (data.photoURL !== undefined) {
    userPhotoCache.set(userId, data.photoURL);
  }

  const bListeners = badgeDataListeners.get(userId);
  if (bListeners) {
    bListeners.forEach((cb) => {
      try {
        cb(updated);
      } catch (err) {
        console.error('Error in badge listener:', err);
      }
    });
  }

  if (data.photoURL !== undefined) {
    const pListeners = photoListeners.get(userId);
    if (pListeners) {
      pListeners.forEach((cb) => {
        try {
          cb(data.photoURL || '');
        } catch (err) {
          console.error('Error in photo listener:', err);
        }
      });
    }
  }
}

export function setUserCachedPhoto(userId: string, photo: string) {
  setUserCachedData(userId, { photoURL: photo });
}

function ensureUserFirestoreSubscription(userId: string) {
  if (activeUnsubscribes.has(userId)) return;

  const unsub = onSnapshot(
    doc(db, 'users', userId),
    (snap) => {
      if (snap.exists()) {
        const u = snap.data() as UserProfile;
        const freshData: UserBadgeData = {
          id: userId,
          displayName: u.displayName || 'Leitor',
          photoURL: u.photoURL || '',
          hasExperiencedReaderBadge: Boolean(u.hasExperiencedReaderBadge),
          isVerifiedWriter: Boolean(u.isVerifiedWriter && !u.isVerifiedWriterSuspended),
          hasKardelProBadge: Boolean(u.hasKardelProBadge),
          showProBorder: Boolean(u.showProBorder ?? u.hasKardelProBadge),
          equippedTitles: u.equippedTitles || (u.activeTitle ? [u.activeTitle] : []),
          role: u.role || 'leitor',
        };
        setUserCachedData(userId, freshData);
      }
    },
    (err) => {
      console.warn('Realtime subscription note for user:', userId, err);
    }
  );

  activeUnsubscribes.set(userId, unsub);
}

export function subscribeUserPhoto(
  userId: string,
  callback: (photo: string) => void
): () => void {
  const cached = getUserCachedPhoto(userId);
  if (cached !== undefined) {
    callback(cached);
  }

  if (!photoListeners.has(userId)) {
    photoListeners.set(userId, new Set());
  }
  const set = photoListeners.get(userId)!;
  set.add(callback);

  ensureUserFirestoreSubscription(userId);

  return () => {
    set.delete(callback);
    if (set.size === 0) {
      photoListeners.delete(userId);
    }
  };
}

export function subscribeUserData(
  userId: string,
  callback: (data: UserBadgeData) => void
): () => void {
  const cached = userBadgeDataCache.get(userId);
  if (cached) {
    callback(cached);
  }

  if (!badgeDataListeners.has(userId)) {
    badgeDataListeners.set(userId, new Set());
  }
  const set = badgeDataListeners.get(userId)!;
  set.add(callback);

  ensureUserFirestoreSubscription(userId);

  return () => {
    set.delete(callback);
    if (set.size === 0) {
      badgeDataListeners.delete(userId);
    }
  };
}

/**
 * Propagates updated profile data (displayName, photoURL, username) to author books, created communities, posts, and in-memory caches.
 */
export async function syncUserProfileAcrossContent(
  userId: string,
  updates: { displayName?: string; photoURL?: string; username?: string }
) {
  if (!userId) return;

  // 1. Update in-memory cache immediately so all mounted components reflect changes in real time
  setUserCachedData(userId, {
    ...(updates.displayName ? { displayName: updates.displayName } : {}),
    ...(updates.photoURL !== undefined ? { photoURL: updates.photoURL } : {}),
  });

  // 2. Update author's books
  try {
    const booksQuery = query(collection(db, 'books'), where('authorId', '==', userId));
    const booksSnap = await getDocs(booksQuery);
    for (const bDoc of booksSnap.docs) {
      const bookPayload: Record<string, any> = {};
      if (updates.displayName) {
        bookPayload.authorName = updates.displayName;
        bookPayload.author = updates.displayName;
      }
      if (updates.photoURL !== undefined) bookPayload.authorPhoto = updates.photoURL;
      if (Object.keys(bookPayload).length > 0) {
        updateDoc(bDoc.ref, bookPayload).catch(() => {});
      }
    }
  } catch (err) {
    console.warn('Sync books profile note:', err);
  }

  // 3. Update communities where creatorId == userId
  try {
    const commsQuery = query(collection(db, 'communities'), where('creatorId', '==', userId));
    const commsSnap = await getDocs(commsQuery);
    for (const cDoc of commsSnap.docs) {
      const commPayload: Record<string, any> = {};
      if (updates.displayName) commPayload.creatorName = updates.displayName;
      if (updates.photoURL !== undefined) commPayload.creatorPhoto = updates.photoURL;
      if (Object.keys(commPayload).length > 0) {
        updateDoc(cDoc.ref, commPayload).catch(() => {});
      }
    }
  } catch (err) {
    console.warn('Sync communities creator note:', err);
  }

  // 4. Update community posts and comments created by this author
  try {
    const allCommsSnap = await getDocs(collection(db, 'communities'));
    for (const cDoc of allCommsSnap.docs) {
      const postsQuery = query(
        collection(db, 'communities', cDoc.id, 'posts'),
        where('authorId', '==', userId)
      );
      getDocs(postsQuery).then((postsSnap) => {
        for (const pDoc of postsSnap.docs) {
          const postPayload: Record<string, any> = {};
          if (updates.displayName) postPayload.authorName = updates.displayName;
          if (updates.photoURL !== undefined) postPayload.authorPhoto = updates.photoURL;
          if (Object.keys(postPayload).length > 0) {
            updateDoc(pDoc.ref, postPayload).catch(() => {});
          }
        }
      }).catch(() => {});

      // Also sync user's comments across posts in active communities
      const allPostsInCommQuery = query(collection(db, 'communities', cDoc.id, 'posts'), limit(30));
      getDocs(allPostsInCommQuery).then((postListSnap) => {
        for (const postDoc of postListSnap.docs) {
          const userCommentsQuery = query(
            collection(db, 'communities', cDoc.id, 'posts', postDoc.id, 'comments'),
            where('userId', '==', userId)
          );
          getDocs(userCommentsQuery).then((commentsSnap) => {
            for (const commentDoc of commentsSnap.docs) {
              const commentPayload: Record<string, any> = {};
              if (updates.displayName) commentPayload.userName = updates.displayName;
              if (updates.photoURL !== undefined) commentPayload.userPhoto = updates.photoURL;
              if (Object.keys(commentPayload).length > 0) {
                updateDoc(commentDoc.ref, commentPayload).catch(() => {});
              }
            }
          }).catch(() => {});
        }
      }).catch(() => {});
    }
  } catch (err) {
    console.warn('Sync posts author note:', err);
  }
}

/**
 * Propagates updated profile photo to author books and communities
 */
export async function syncUserProfilePhotoAcrossContent(userId: string, newPhotoURL: string) {
  return syncUserProfileAcrossContent(userId, { photoURL: newPhotoURL });
}

/**
 * Exact 3-day activity window used in the Developer Panel:
 * Passed 3 consecutive days without accessing the platform = Inactive.
 */
export const THREE_DAYS_ACTIVITY_MS = 3 * 24 * 60 * 60 * 1000;

export interface PlatformActivityStatus {
  isActive: boolean;
  isBanned: boolean;
  isSilenced: boolean;
  lastAccessTime: number;
  createdTime: number;
  inactiveDurationLabel: string;
  activeRecencyLabel: string;
  tenureLabel: string;
}

/**
 * Evaluates a user's platform activity status using the exact same fields and 3-day criteria
 * used in the Developer Area (`DeveloperAdminView`).
 */
export function getUserPlatformActivityStatus(
  u: Partial<UserProfile> | null | undefined
): PlatformActivityStatus {
  const now = Date.now();
  if (!u) {
    return {
      isActive: false,
      isBanned: false,
      isSilenced: false,
      lastAccessTime: 0,
      createdTime: now,
      inactiveDurationLabel: 'Sem registro de acesso',
      activeRecencyLabel: '',
      tenureLabel: '1 dia',
    };
  }

  const isBanned = Boolean(u.isBanned);
  const isSilenced = Boolean((u as any).isSilenced);

  // Exact priority order from DeveloperAdminView: lastActiveAt -> lastLoginAt -> updatedAt -> createdAt
  const lastAccessIso =
    u.lastActiveAt || u.lastLoginAt || u.updatedAt || u.createdAt;
  const lastAccessTime = lastAccessIso ? new Date(lastAccessIso).getTime() : 0;
  const validAccessTime = Number.isNaN(lastAccessTime) ? 0 : lastAccessTime;
  const timeSinceAccess =
    validAccessTime > 0 ? Math.max(0, now - validAccessTime) : Infinity;

  // Active if not banned and accessed within 3 consecutive days
  const isActive =
    !isBanned && validAccessTime > 0 && timeSinceAccess <= THREE_DAYS_ACTIVITY_MS;

  const createdRaw = u.createdAt ? new Date(u.createdAt).getTime() : now;
  const createdTime = Number.isNaN(createdRaw) ? now : createdRaw;
  const tenureMs = Math.max(0, now - createdTime);

  let inactiveDurationLabel = '';
  let activeRecencyLabel = 'Acesso recente';

  if (isActive) {
    const diffHours = Math.floor(timeSinceAccess / (60 * 60 * 1000));
    if (diffHours < 1) {
      activeRecencyLabel = 'Ativo agora';
    } else if (diffHours < 24) {
      activeRecencyLabel = `Acesso há ${diffHours}h`;
    } else {
      const diffDays = Math.floor(diffHours / 24);
      activeRecencyLabel = `Acesso há ${diffDays} ${diffDays === 1 ? 'dia' : 'dias'}`;
    }
  } else if (!isBanned) {
    if (!Number.isFinite(timeSinceAccess)) {
      inactiveDurationLabel = 'Inativo';
    } else {
      const diffDays = Math.floor(timeSinceAccess / (24 * 60 * 60 * 1000));
      if (diffDays <= 0) {
        inactiveDurationLabel = 'Inativo há menos de 1 dia';
      } else if (diffDays < 30) {
        inactiveDurationLabel = `Inativo há ${diffDays} ${
          diffDays === 1 ? 'dia' : 'dias'
        }`;
      } else if (diffDays < 365) {
        const months = Math.floor(diffDays / 30);
        inactiveDurationLabel = `Inativo há ${months} ${
          months === 1 ? 'mês' : 'meses'
        }`;
      } else {
        const years = Math.floor(diffDays / 365);
        inactiveDurationLabel = `Inativo há ${years} ${
          years === 1 ? 'ano' : 'anos'
        }`;
      }
    }
  }

  let tenureLabel = '';
  const tenureDays = Math.floor(tenureMs / (24 * 60 * 60 * 1000));
  if (tenureDays < 30) {
    const d = Math.max(1, tenureDays);
    tenureLabel = `${d} ${d === 1 ? 'dia' : 'dias'}`;
  } else if (tenureDays < 365) {
    const m = Math.floor(tenureDays / 30);
    tenureLabel = `${m} ${m === 1 ? 'mês' : 'meses'}`;
  } else {
    const y = Math.floor(tenureDays / 365);
    tenureLabel = `${y} ${y === 1 ? 'ano' : 'anos'}`;
  }

  return {
    isActive,
    isBanned,
    isSilenced,
    lastAccessTime: validAccessTime,
    createdTime,
    inactiveDurationLabel,
    activeRecencyLabel,
    tenureLabel,
  };
}

/**
 * Fetches user documents from Firestore for a list of userIds and computes each user's
 * platform activity status using the exact Developer Area criteria.
 */
export async function fetchUsersActivityMap(
  userIds: string[]
): Promise<
  Record<
    string,
    {
      profile: Partial<UserProfile> | null;
      activity: PlatformActivityStatus;
    }
  >
> {
  const uniqueIds = Array.from(new Set(userIds.filter(Boolean)));
  const result: Record<
    string,
    { profile: Partial<UserProfile> | null; activity: PlatformActivityStatus }
  > = {};

  await Promise.all(
    uniqueIds.map(async (uid) => {
      try {
        const snap = await getDoc(doc(db, 'users', uid));
        if (snap.exists()) {
          const data = snap.data() as UserProfile;
          result[uid] = {
            profile: data,
            activity: getUserPlatformActivityStatus(data),
          };
        } else {
          result[uid] = {
            profile: null,
            activity: getUserPlatformActivityStatus(null),
          };
        }
      } catch {
        result[uid] = {
          profile: null,
          activity: getUserPlatformActivityStatus(null),
        };
      }
    })
  );

  return result;
}

