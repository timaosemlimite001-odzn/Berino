import {
  createUserWithEmailAndPassword,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  User,
} from 'firebase/auth';
import {
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import {
  auth,
  cleanupUnusedPreOpenedPopup,
  db,
  handleFirestoreError,
  kordelPopupRedirectResolver,
  OperationType,
  prepareSynchronousGooglePopup,
  sanitizeFirestoreData,
} from '../services/firebase';
import { evaluateAndSyncUserSubscription } from '../services/subscriptionService';
import {
  googleAuthFlowManager,
  GoogleAuthFlowMode,
  GoogleAuthFlowState,
  useGoogleAuthFlow,
} from '../services/googleAuthFlowManager';
import { ensureUserUniqueId, generatePermanentUniqueId, syncUserProfileAcrossContent } from '../services/userService';
import { UserProfile } from '../types';

export interface GoogleRegistrationMeta {
  displayName?: string;
  role?: 'leitor' | 'escritor';
}

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isDeveloper: boolean;
  googleAuthFlow: GoogleAuthFlowState;
  isGoogleAuthPending: boolean;
  cancelGoogleAuthFlow: () => void;
  loginWithGoogle: (loginHint?: string, registrationMeta?: GoogleRegistrationMeta) => Promise<void>;
  switchGoogleAccount: (loginHint?: string) => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (
    email: string,
    pass: string,
    displayName: string,
    role: 'leitor' | 'escritor'
  ) => Promise<void>;
  sendResetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUserProfileData: (data: Partial<UserProfile>) => Promise<void>;
  loginAsDeveloperPreview: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const BOOTSTRAP_DEV_EMAIL = 'timaosemlimite001@gmail.com';
const LEGACY_DEV_SESSION_KEY = 'kordel_dev_session_v1';

interface PendingRegistrationMeta {
  email?: string;
  displayName?: string;
  role?: 'leitor' | 'escritor';
}

function buildProvisionalProfile(user: User): UserProfile {
  const normalizedEmail = (user.email || '').trim();
  const isDevEmail = normalizedEmail.toLowerCase() === BOOTSTRAP_DEV_EMAIL.toLowerCase();
  const fallbackName =
    user.displayName ||
    normalizedEmail.split('@')[0] ||
    (isDevEmail ? 'Desenvolvedor Kordel' : 'Leitor Kordel');
  const handleBase = fallbackName
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '')
    .slice(0, 15);
  const nowIso = new Date().toISOString();

  return {
    id: user.uid,
    uniqueId: `KRD-${user.uid.slice(0, 5).toUpperCase()}`,
    username: `@${handleBase || 'leitor'}`,
    email: normalizedEmail,
    displayName: fallbackName,
    photoURL: user.photoURL || '',
    bio: '',
    role: isDevEmail ? 'desenvolvedor' : 'leitor',
    kards: 0,
    xp: 0,
    level: 1,
    progressionCycle: 0,
    titles: ['Leitor Curioso'],
    activeTitle: 'Leitor Curioso',
    achievements: [],
    hasExperiencedReaderBadge: false,
    isVerifiedWriter: isDevEmail,
    isBanned: false,
    lastActiveAt: nowIso,
    lastLoginAt: nowIso,
    createdAt: nowIso,
    updatedAt: nowIso,
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const googleAuthFlow = useGoogleAuthFlow();
  const lastSubEvaluationRef = useRef<number>(0);
  const profileUnsubRef = useRef<(() => void) | null>(null);
  const activeUidRef = useRef<string | null>(null);
  const pendingRegistrationRef = useRef<PendingRegistrationMeta | null>(null);

  const cleanupProfileListener = () => {
    if (profileUnsubRef.current) {
      try {
        profileUnsubRef.current();
      } catch {
        // ignore
      }
      profileUnsubRef.current = null;
    }
  };

  // Synchronize Firebase Auth state with Firestore User Document without mutating persistence mid-session
  useEffect(() => {
    try {
      localStorage.removeItem(LEGACY_DEV_SESSION_KEY);
    } catch {
      // ignore
    }

    // Consume any pending OAuth redirect result if a mobile browser/WebView returned via redirect
    getRedirectResult(auth, kordelPopupRedirectResolver).catch((err) => {
      if (err?.code && err.code !== 'auth/no-auth-event') {
        console.warn('Redirect auth result check note:', err);
      }
    });

    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      cleanupProfileListener();

      if (user) {
        const isAccountSwitch = activeUidRef.current !== user.uid;
        activeUidRef.current = user.uid;
        setCurrentUser(user);

        if (isAccountSwitch) {
          lastSubEvaluationRef.current = 0;
          setUserProfile((prev) =>
            prev && prev.id === user.uid ? prev : buildProvisionalProfile(user)
          );
        }
        googleAuthFlowManager.notifyAuthUserReady(user.uid);

        const userDocRef = doc(db, 'users', user.uid);

        profileUnsubRef.current = onSnapshot(
          userDocRef,
          async (snap) => {
            if (activeUidRef.current !== user.uid) return;

            if (snap.exists()) {
              const data = snap.data() as UserProfile;
              const normalizedEmail = (user.email || data.email || '').trim();
              const isDevEmail =
                normalizedEmail.toLowerCase() === BOOTSTRAP_DEV_EMAIL.toLowerCase();

              if (isDevEmail && data.role !== 'desenvolvedor') {
                try {
                  await updateDoc(userDocRef, {
                    role: 'desenvolvedor',
                    isBanned: false,
                    email: normalizedEmail,
                    updatedAt: new Date().toISOString(),
                  });
                  await setDoc(
                    doc(db, 'admins', user.uid),
                    {
                      email: normalizedEmail,
                      grantedAt: new Date().toISOString(),
                    },
                    { merge: true }
                  );
                } catch (elevateErr) {
                  console.warn('Auto elevate developer note:', elevateErr);
                }
              }

              if (!data.uniqueId || !data.username) {
                ensureUserUniqueId(data).catch(() => {});
              }

              const now = Date.now();
              const lastActiveTime = data.lastActiveAt ? new Date(data.lastActiveAt).getTime() : 0;
              const needsEmailSync = Boolean(user.email && data.email !== user.email);
              if (!data.lastActiveAt || now - lastActiveTime > 1000 * 60 * 60 || needsEmailSync) {
                const currentIso = new Date().toISOString();
                updateDoc(userDocRef, {
                  ...(user.email ? { email: user.email } : {}),
                  lastActiveAt: currentIso,
                  lastLoginAt: currentIso,
                  updatedAt: currentIso,
                }).catch((err) => console.warn('Could not update lastActiveAt:', err));
              }

              if (now - lastSubEvaluationRef.current > 1000 * 60 * 2) {
                lastSubEvaluationRef.current = now;
                evaluateAndSyncUserSubscription(data).catch((err) =>
                  console.warn('Subscription sync note:', err)
                );
              }

              if (activeUidRef.current !== user.uid) return;
              setUserProfile({
                ...data,
                id: user.uid,
                email: normalizedEmail,
              });
            } else {
              const normalizedEmail = (user.email || '').trim();
              const isDevEmail =
                normalizedEmail.toLowerCase() === BOOTSTRAP_DEV_EMAIL.toLowerCase();
              const pendingMeta =
                pendingRegistrationRef.current &&
                (!pendingRegistrationRef.current.email ||
                  pendingRegistrationRef.current.email.toLowerCase() === normalizedEmail.toLowerCase())
                  ? pendingRegistrationRef.current
                  : null;
              pendingRegistrationRef.current = null;

              const chosenDisplayName =
                pendingMeta?.displayName?.trim() ||
                user.displayName ||
                normalizedEmail.split('@')[0] ||
                (isDevEmail ? 'Desenvolvedor Kordel' : 'Leitor Kordel');
              const chosenRole = isDevEmail
                ? 'desenvolvedor'
                : pendingMeta?.role || 'leitor';

              const uniqueId = generatePermanentUniqueId();
              const handleBase = (chosenDisplayName || normalizedEmail.split('@')[0] || 'leitor')
                .toLowerCase()
                .replace(/[^a-z0-9_]/g, '')
                .slice(0, 15);
              const username = `@${handleBase || 'leitor'}_${uniqueId.replace('KRD-', '').toLowerCase()}`;

              const currentIso = new Date().toISOString();
              const newProfile: UserProfile = {
                id: user.uid,
                uniqueId,
                username,
                email: normalizedEmail,
                displayName: chosenDisplayName,
                photoURL: user.photoURL || '',
                bio: isDevEmail ? 'Administrador e desenvolvedor da plataforma KORDEL.' : '',
                role: chosenRole,
                kards: isDevEmail ? 500 : 50,
                xp: 0,
                level: 1,
                progressionCycle: 0,
                titles: isDevEmail
                  ? ['Desenvolvedor Soberano', 'Leitor Curioso']
                  : ['Leitor Curioso'],
                activeTitle: isDevEmail ? 'Desenvolvedor Soberano' : 'Leitor Curioso',
                achievements: [],
                hasExperiencedReaderBadge: false,
                isVerifiedWriter: isDevEmail,
                isBanned: false,
                lastActiveAt: currentIso,
                lastLoginAt: currentIso,
                createdAt: currentIso,
                updatedAt: currentIso,
              };

              try {
                const cleanProfile = sanitizeFirestoreData(newProfile);
                await setDoc(userDocRef, cleanProfile, { merge: true });
                if (isDevEmail) {
                  try {
                    await setDoc(
                      doc(db, 'admins', user.uid),
                      {
                        email: normalizedEmail,
                        grantedAt: currentIso,
                      },
                      { merge: true }
                    );
                  } catch (adminErr) {
                    console.warn('Admin registry note:', adminErr);
                  }
                }
              } catch (err) {
                console.warn('User profile creation firestore note:', err);
              }

              if (activeUidRef.current !== user.uid) return;
              setUserProfile(newProfile);
            }
            googleAuthFlowManager.notifyAuthUserReady(user.uid);
            setLoading(false);
          },
          (error) => {
            console.warn('Snapshot error on user doc:', error);
            googleAuthFlowManager.notifyAuthUserReady(user.uid);
            setLoading(false);
          }
        );
      } else {
        activeUidRef.current = null;
        lastSubEvaluationRef.current = 0;
        googleAuthFlowManager.notifyAuthUserReady(null);
        setCurrentUser(null);
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => {
      cleanupProfileListener();
      unsubscribeAuth();
    };
  }, []);

  /**
   * Executes Google Account Picker synchronously within the user's click gesture,
   * opening the popup window at 0ms so transient user activation is never lost,
   * then locks UI interactions via `googleAuthFlowManager` until settled.
   */
  const performGoogleSignIn = (
    loginHint?: string,
    mode: GoogleAuthFlowMode = 'login',
    registrationMeta?: GoogleRegistrationMeta
  ): Promise<void> => {
    if (googleAuthFlowManager.getState().isPending) {
      const busyErr: Error & { code?: string } = new Error(
        'Já existe uma autenticação Google em andamento. Aguarde a conclusão na janela aberta.'
      );
      busyErr.code = 'auth/cancelled-popup-request';
      return Promise.reject(busyErr);
    }

    if (registrationMeta && (registrationMeta.displayName || registrationMeta.role)) {
      pendingRegistrationRef.current = {
        email: loginHint?.trim() || undefined,
        displayName: registrationMeta.displayName?.trim() || undefined,
        role: registrationMeta.role,
      };
    }

    const provider = new GoogleAuthProvider();
    provider.addScope('email');
    provider.addScope('profile');
    const customParams: Record<string, string> = {
      prompt: 'select_account',
    };
    if (loginHint && loginHint.trim().includes('@')) {
      customParams.login_hint = loginHint.trim();
    }
    provider.setCustomParameters(customParams);

    // 1. Open popup window synchronously at t=0ms on the user click gesture
    prepareSynchronousGooglePopup();

    // 2. Invoke signInWithPopup with hardened resolver (hands off to the 0ms pre-opened window)
    const popupPromise = signInWithPopup(auth, provider, kordelPopupRedirectResolver).catch(
      (err) => {
        cleanupUnusedPreOpenedPopup(true);
        throw err;
      }
    );

    // 3. Engage custom state manager to lock UI interactions until settled
    return googleAuthFlowManager.trackAuthPromise(popupPromise, { mode, loginHint });
  };

  const loginWithGoogle = (
    loginHint?: string,
    registrationMeta?: GoogleRegistrationMeta
  ): Promise<void> => {
    return performGoogleSignIn(loginHint, 'login', registrationMeta);
  };

  const switchGoogleAccount = (loginHint?: string): Promise<void> => {
    // Do NOT detach current listener before popup confirms — if user cancels chooser, current account stays intact;
    // when user picks another account, onAuthStateChanged atomically switches listeners and state.
    return performGoogleSignIn(loginHint, 'switch');
  };

  const loginWithEmail = async (email: string, pass: string) => {
    const trimmedEmail = email.trim();

    try {
      await signInWithEmailAndPassword(auth, trimmedEmail, pass);
    } catch (err: any) {
      if (err?.code === 'auth/operation-not-allowed') {
        const customErr: any = new Error(
          `Seu e-mail (${trimmedEmail}) está ativo! Para entrar agora com 1 clique, utilize a autenticação oficial do Google com este e-mail abaixo.`
        );
        customErr.code = 'auth/operation-not-allowed';
        throw customErr;
      }
      if (err?.code === 'auth/user-disabled') {
        const customErr: any = new Error(
          'Esta credencial por senha está temporariamente indisponível; utilize o botão "Continuar com Google" para acessar sua conta.'
        );
        customErr.code = err.code;
        throw customErr;
      }
      if (
        err?.code === 'auth/user-not-found' ||
        err?.code === 'auth/wrong-password' ||
        err?.code === 'auth/invalid-credential'
      ) {
        const customErr: any = new Error(
          'E-mail ou senha incorretos. Caso sua conta tenha sido criada pelo Google, clique em "Continuar com Google" acima.'
        );
        customErr.code = err.code;
        throw customErr;
      }
      if (err?.code === 'auth/too-many-requests') {
        const customErr: any = new Error(
          'Muitas tentativas seguidas. Aguarde alguns instantes ou entre imediatamente com o Google.'
        );
        customErr.code = err.code;
        throw customErr;
      }
      throw err;
    }
  };

  const registerWithEmail = async (
    email: string,
    pass: string,
    displayName: string,
    role: 'leitor' | 'escritor'
  ) => {
    const trimmedEmail = email.trim();
    const trimmedName = displayName.trim() || 'Leitor Kordel';

    pendingRegistrationRef.current = {
      email: trimmedEmail,
      displayName: trimmedName,
      role,
    };

    try {
      const cred = await createUserWithEmailAndPassword(auth, trimmedEmail, pass);
      if (trimmedName) {
        updateProfile(cred.user, { displayName: trimmedName }).catch(() => {});
      }
    } catch (authErr: any) {
      pendingRegistrationRef.current = null;
      if (authErr?.code === 'auth/operation-not-allowed') {
        const err: any = new Error(
          `Seu e-mail (${trimmedEmail}) está ativo e pronto para uso! Clique no botão abaixo para criar e acessar sua conta com 1 clique via Google.`
        );
        err.code = 'auth/operation-not-allowed';
        throw err;
      }
      if (authErr?.code === 'auth/email-already-in-use') {
        const err: any = new Error(
          'Este e-mail já está cadastrado no KORDEL. Acesse a aba "Entrar" com sua senha ou entre com 1 clique pelo Google.'
        );
        err.code = authErr.code;
        throw err;
      }
      if (authErr?.code === 'auth/weak-password') {
        const err: any = new Error('A senha deve conter no mínimo 6 caracteres.');
        err.code = authErr.code;
        throw err;
      }
      if (authErr?.code === 'auth/invalid-email') {
        const err: any = new Error('Formato de e-mail inválido.');
        err.code = authErr.code;
        throw err;
      }
      throw authErr;
    }
  };

  const sendResetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  };

  const loginAsDeveloperPreview = (): Promise<void> => {
    return performGoogleSignIn(BOOTSTRAP_DEV_EMAIL, 'developer');
  };

  const logout = async () => {
    cleanupProfileListener();
    activeUidRef.current = null;
    lastSubEvaluationRef.current = 0;
    try {
      localStorage.removeItem(LEGACY_DEV_SESSION_KEY);
    } catch {
      // ignore
    }
    try {
      await signOut(auth);
    } catch (err) {
      console.warn('Sign-out notice:', err);
    }
    setCurrentUser(null);
    setUserProfile(null);
  };

  const updateUserProfileData = async (data: Partial<UserProfile>) => {
    if (!currentUser && !userProfile) return;
    const uid = currentUser?.uid || userProfile?.id;
    if (!uid) return;
    const path = `users/${uid}`;

    setUserProfile((prev) => (prev ? { ...prev, ...data } : null));

    try {
      const userRef = doc(db, 'users', uid);
      await updateDoc(userRef, {
        ...data,
        updatedAt: new Date().toISOString(),
      });

      if (data.displayName || data.photoURL !== undefined || data.username) {
        syncUserProfileAcrossContent(uid, {
          displayName: data.displayName,
          photoURL: data.photoURL,
          username: data.username,
        }).catch(() => {});
      }
    } catch (error: any) {
      if (
        error instanceof Error &&
        error.message.includes('Missing or insufficient permissions')
      ) {
        handleFirestoreError(error, OperationType.UPDATE, path);
      }
      console.warn('Update user profile sync note:', error);
    }
  };

  const isDeveloper =
    userProfile?.role === 'desenvolvedor' ||
    (currentUser?.email || '').trim().toLowerCase() === BOOTSTRAP_DEV_EMAIL.toLowerCase();

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        isDeveloper,
        googleAuthFlow,
        isGoogleAuthPending: googleAuthFlow.isPending,
        cancelGoogleAuthFlow: googleAuthFlowManager.cancelActiveFlow,
        loginWithGoogle,
        switchGoogleAccount,
        loginWithEmail,
        registerWithEmail,
        sendResetPassword,
        logout,
        updateUserProfileData,
        loginAsDeveloperPreview,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
