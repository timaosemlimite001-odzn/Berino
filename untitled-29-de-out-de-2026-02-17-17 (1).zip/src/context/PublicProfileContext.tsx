import React, { createContext, useContext, useState } from 'react';
import { PublicProfileModal } from '../components/PublicProfileModal';
import {
  fetchPublicUserProfile,
  PublicUserProfile,
  sanitizePublicProfile,
} from '../services/userService';
import { UserProfile } from '../types';

interface PublicProfileContextType {
  openUserProfile: (userOrId: string | PublicUserProfile | UserProfile | undefined | null) => Promise<void>;
  closeUserProfile: () => void;
}

const PublicProfileContext = createContext<PublicProfileContextType | undefined>(undefined);

interface PublicProfileProviderProps {
  children: React.ReactNode;
  onSelectBook?: (bookId: string) => void;
  onOpenAuth?: () => void;
}

export const PublicProfileProvider: React.FC<PublicProfileProviderProps> = ({
  children,
  onSelectBook,
  onOpenAuth,
}) => {
  const [selectedUser, setSelectedUser] = useState<PublicUserProfile | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const openUserProfile = async (
    userOrId: string | PublicUserProfile | UserProfile | undefined | null
  ) => {
    if (!userOrId) return;

    if (typeof userOrId === 'string') {
      const profile = await fetchPublicUserProfile(userOrId);
      if (profile) {
        setSelectedUser(profile);
        setIsOpen(true);
      }
    } else {
      const sanitized = sanitizePublicProfile(userOrId as UserProfile);
      setSelectedUser(sanitized);
      setIsOpen(true);

      // Refresh in background for newest counts
      fetchPublicUserProfile(userOrId.id).then((fresh) => {
        if (fresh) setSelectedUser(fresh);
      });
    }
  };

  const closeUserProfile = () => {
    setIsOpen(false);
    setSelectedUser(null);
  };

  return (
    <PublicProfileContext.Provider value={{ openUserProfile, closeUserProfile }}>
      {children}
      <PublicProfileModal
        user={selectedUser}
        isOpen={isOpen}
        onClose={closeUserProfile}
        onSelectBook={onSelectBook}
        onOpenAuth={onOpenAuth}
      />
    </PublicProfileContext.Provider>
  );
};

export const usePublicProfile = () => {
  const context = useContext(PublicProfileContext);
  if (!context) {
    throw new Error('usePublicProfile must be used within a PublicProfileProvider');
  }
  return context;
};
