import React, { createContext, useContext, useEffect, useState } from 'react';

export type AppTheme = 'dark';

interface ThemeContextType {
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  toggleTheme: () => void;
  isDark: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = 'kordel_theme_mode';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Always dark mode across the entire app
  const [theme] = useState<AppTheme>('dark');

  const applyThemeToDOM = () => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;

    root.classList.remove('light', 'sepia');
    root.classList.add('dark');
    root.setAttribute('data-theme', 'dark');
    root.style.colorScheme = 'dark';
  };

  useEffect(() => {
    applyThemeToDOM();
    localStorage.setItem(THEME_STORAGE_KEY, 'dark');
  }, []);

  const setTheme = (_newTheme: AppTheme) => {
    // Permanent dark mode as requested
    applyThemeToDOM();
  };

  const toggleTheme = () => {
    // Permanent dark mode as requested
    applyThemeToDOM();
  };

  return (
    <ThemeContext.Provider
      value={{
        theme: 'dark',
        setTheme,
        toggleTheme,
        isDark: true,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
