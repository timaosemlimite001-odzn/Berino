import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { auth, db } from '../services/firebase';
import { NotificationItem, NotificationType } from '../types';
import { useAuth } from './AuthContext';

interface NotificationContextType {
  notifications: NotificationItem[];
  unreadCount: number;
  activeBanner: NotificationItem | null;
  dismissBanner: () => void;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  onNavigateToNotification?: (url: string) => void;
  setNavigateHandler: (fn: (url: string) => void) => void;
  addToast: (toast: {
    id?: string;
    type: NotificationType;
    title: string;
    message: string;
    linkUrl?: string;
  }) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [remoteNotifications, setRemoteNotifications] = useState<NotificationItem[]>([]);
  const [localToasts, setLocalToasts] = useState<NotificationItem[]>([]);
  const [activeBanner, setActiveBanner] = useState<NotificationItem | null>(null);
  const [navigateHandler, setNavigateHandlerState] = useState<((url: string) => void) | null>(null);

  const localToastIdsRef = useRef<Set<string>>(new Set());
  const remoteNotificationsRef = useRef<NotificationItem[]>([]);
  const lastKnownNotifIdRef = useRef<string | null>(null);

  useEffect(() => {
    if (!currentUser?.uid) {
      remoteNotificationsRef.current = [];
      lastKnownNotifIdRef.current = null;
      setRemoteNotifications([]);
      setLocalToasts([]);
      localToastIdsRef.current.clear();
      setActiveBanner(null);
      return;
    }

    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', currentUser.uid),
      orderBy('createdAt', 'desc'),
      limit(30)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: NotificationItem[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as NotificationItem;
          items.push({
            ...data,
            id: docSnap.id,
          });
        });

        if (items.length > 0) {
          const newest = items[0];
          const prevKnownId = lastKnownNotifIdRef.current;
          if (!newest.read && prevKnownId && newest.id !== prevKnownId) {
            const relevantTypes: NotificationType[] = [
              'comment',
              'reply',
              'system',
              'level_up',
              'achievement',
              'new_title',
              'kards_received',
              'kards_spent',
              'kards_purchase',
              'beta_event',
              'community_join',
            ];
            if (relevantTypes.includes(newest.type)) {
              setActiveBanner(newest);
            }
          }
          lastKnownNotifIdRef.current = newest.id;
        }

        remoteNotificationsRef.current = items;
        setRemoteNotifications(items);
      },
      (err) => {
        console.warn('Error fetching notifications:', err);
      }
    );

    return () => unsubscribe();
  }, [currentUser?.uid]);

  // Merge local ephemeral toasts and Firestore notifications cleanly
  const notifications = useMemo(() => {
    const remoteIds = new Set(remoteNotifications.map((n) => n.id));
    const uniqueLocal = localToasts.filter((t) => !remoteIds.has(t.id));
    return [...uniqueLocal, ...remoteNotifications].sort(
      (a, b) =>
        new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }, [localToasts, remoteNotifications]);

  // Auto-dismiss top banner after 6 seconds
  useEffect(() => {
    if (activeBanner) {
      const timer = setTimeout(() => {
        setActiveBanner(null);
      }, 6000);
      return () => clearTimeout(timer);
    }
  }, [activeBanner]);

  const dismissBanner = useCallback(() => {
    setActiveBanner(null);
  }, []);

  const markAsRead = useCallback(
    async (id: string) => {
      if (!id) return;

      // Read snapshot state BEFORE optimistic mutation so we know if a remote write is needed
      const remoteTarget = remoteNotificationsRef.current.find((n) => n.id === id);
      const wasAlreadyRead = Boolean(remoteTarget?.read);

      // Optimistic local state update
      setLocalToasts((prev) =>
        prev.map((n) => (n.id === id ? { ...n, read: true } : n))
      );
      setRemoteNotifications((prev) => {
        const next = prev.map((n) => (n.id === id ? { ...n, read: true } : n));
        remoteNotificationsRef.current = next;
        return next;
      });
      setActiveBanner((prev) => (prev && prev.id === id ? { ...prev, read: true } : prev));

      // Ephemeral toasts created via addToast only exist in memory, never in Firestore
      if (localToastIdsRef.current.has(id)) {
        return;
      }

      const liveUid = auth.currentUser?.uid;
      if (
        !liveUid ||
        !currentUser?.uid ||
        liveUid !== currentUser.uid ||
        !remoteTarget ||
        remoteTarget.userId !== liveUid ||
        wasAlreadyRead
      ) {
        return;
      }

      try {
        const ref = doc(db, 'notifications', id);
        await updateDoc(ref, { read: true });
      } catch (err) {
        console.warn('Could not persist notification read status:', err);
      }
    },
    [currentUser?.uid]
  );

  const markAllAsRead = useCallback(async () => {
    const liveUid = auth.currentUser?.uid;
    const unreadRemote =
      liveUid && currentUser?.uid && liveUid === currentUser.uid
        ? remoteNotificationsRef.current.filter(
            (n) =>
              !n.read &&
              Boolean(n.id) &&
              !localToastIdsRef.current.has(n.id) &&
              n.userId === liveUid
          )
        : [];

    setLocalToasts((prev) => prev.map((n) => ({ ...n, read: true })));
    setRemoteNotifications((prev) => {
      const next = prev.map((n) => ({ ...n, read: true }));
      remoteNotificationsRef.current = next;
      return next;
    });

    if (unreadRemote.length === 0) return;

    try {
      const batch = writeBatch(db);
      unreadRemote.forEach((n) => {
        const ref = doc(db, 'notifications', n.id);
        batch.update(ref, { read: true });
      });
      await batch.commit();
    } catch (err) {
      console.warn('Could not persist mark all notifications as read:', err);
    }
  }, [currentUser?.uid]);

  const setNavigateHandler = useCallback((fn: (url: string) => void) => {
    setNavigateHandlerState(() => fn);
  }, []);

  const addToast = useCallback(
    (toast: {
      id?: string;
      type: NotificationType;
      title: string;
      message: string;
      linkUrl?: string;
    }) => {
      const toastId =
        toast.id || `toast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      localToastIdsRef.current.add(toastId);

      const item: NotificationItem = {
        id: toastId,
        userId: currentUser?.uid || 'anonymous',
        type: toast.type,
        title: toast.title,
        message: toast.message,
        linkUrl: toast.linkUrl,
        read: false,
        createdAt: new Date().toISOString(),
      };
      setActiveBanner(item);
      setLocalToasts((prev) => [item, ...prev.slice(0, 19)]);
    },
    [currentUser?.uid]
  );

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  const contextValue = useMemo(
    () => ({
      notifications,
      unreadCount,
      activeBanner,
      dismissBanner,
      markAsRead,
      markAllAsRead,
      onNavigateToNotification: navigateHandler || undefined,
      setNavigateHandler,
      addToast,
    }),
    [
      notifications,
      unreadCount,
      activeBanner,
      dismissBanner,
      markAsRead,
      markAllAsRead,
      navigateHandler,
      setNavigateHandler,
      addToast,
    ]
  );

  return (
    <NotificationContext.Provider value={contextValue}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
