import React, { createContext, useContext, useEffect, useState } from 'react';
import { doc, getDoc, onSnapshot, setDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { useAuth } from './AuthContext';
import { BookOpen, Feather, Flame, Sparkles, ScrollText, Crown } from 'lucide-react';

export interface BrandingData {
  appName: string;
  logoUrl?: string;
  logoType: 'icon' | 'image';
  logoIconName?: 'BookOpen' | 'Feather' | 'Flame' | 'Sparkles' | 'ScrollText' | 'Crown';
  tagline: string;
  shortDescription?: string;
  updatedAt?: string;
  updatedBy?: string;
}

const DEFAULT_BRANDING: BrandingData = {
  appName: 'KORDEL',
  logoUrl: '',
  logoType: 'icon',
  logoIconName: 'BookOpen',
  tagline: 'Plataforma soberana de leitura & publicação independente',
  shortDescription: 'Plataforma soberana de leitura & publicação independente. Valorizando a literatura autoral, a métrica dos versos e a voz livre dos escritores e leitores independentes.',
};

interface BrandingContextType {
  branding: BrandingData;
  loading: boolean;
  updateBranding: (data: Partial<BrandingData>) => Promise<void>;
  resetToDefault: () => Promise<void>;
  isDevModalOpen: boolean;
  setIsDevModalOpen: (open: boolean) => void;
}

const BrandingContext = createContext<BrandingContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'kordel_branding_settings_v1';

export const BrandingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isDeveloper, currentUser } = useAuth();
  const [isDevModalOpen, setIsDevModalOpen] = useState(false);

  // Initialize from localStorage for instantaneous rendering without layout shift
  const [branding, setBranding] = useState<BrandingData>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (cached) {
        return { ...DEFAULT_BRANDING, ...JSON.parse(cached) };
      }
    } catch {
      // fallback
    }
    return DEFAULT_BRANDING;
  });

  const [loading, setLoading] = useState(true);

  // Subscribe to realtime changes from Firestore `settings/branding`
  useEffect(() => {
    const brandingRef = doc(db, 'settings', 'branding');

    const unsubscribe = onSnapshot(
      brandingRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const remoteData = snapshot.data() as BrandingData;
          const merged: BrandingData = {
            appName: (remoteData.appName || DEFAULT_BRANDING.appName).trim(),
            logoUrl: remoteData.logoUrl || '',
            logoType: remoteData.logoType || (remoteData.logoUrl ? 'image' : 'icon'),
            logoIconName: remoteData.logoIconName || 'BookOpen',
            tagline: remoteData.tagline || DEFAULT_BRANDING.tagline,
            shortDescription: remoteData.shortDescription || DEFAULT_BRANDING.shortDescription,
            updatedAt: remoteData.updatedAt,
            updatedBy: remoteData.updatedBy,
          };
          setBranding(merged);
          try {
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(merged));
          } catch {
            // ignore
          }
        }
        setLoading(false);
      },
      (error) => {
        console.warn('Realtime branding listener note:', error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Sync document title dynamically
  useEffect(() => {
    if (branding.appName) {
      const currentTitle = document.title;
      if (!currentTitle || currentTitle.includes('KORDEL') || currentTitle.includes(branding.appName)) {
        document.title = `${branding.appName} — Leitura & Obras Independentes`;
      }
    }
  }, [branding.appName]);

  const updateBranding = async (data: Partial<BrandingData>) => {
    if (!isDeveloper) {
      throw new Error('Apenas o desenvolvedor tem permissão para alterar a marca e logo.');
    }

    const updated: BrandingData = {
      ...branding,
      ...data,
      appName: (data.appName || branding.appName || 'KORDEL').trim(),
      updatedAt: new Date().toISOString(),
      updatedBy: currentUser?.email || 'desenvolvedor',
    };

    setBranding(updated);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }

    const brandingRef = doc(db, 'settings', 'branding');
    await setDoc(brandingRef, updated, { merge: true });
  };

  const resetToDefault = async () => {
    if (!isDeveloper) {
      throw new Error('Apenas o desenvolvedor tem permissão para resetar a marca.');
    }
    setBranding(DEFAULT_BRANDING);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(DEFAULT_BRANDING));
    } catch {
      // ignore
    }
    const brandingRef = doc(db, 'settings', 'branding');
    await setDoc(brandingRef, DEFAULT_BRANDING);
  };

  return (
    <BrandingContext.Provider
      value={{
        branding,
        loading,
        updateBranding,
        resetToDefault,
        isDevModalOpen,
        setIsDevModalOpen,
      }}
    >
      {children}
    </BrandingContext.Provider>
  );
};

export const useBranding = () => {
  const context = useContext(BrandingContext);
  if (!context) {
    throw new Error('useBranding must be used within a BrandingProvider');
  }
  return context;
};

/**
 * Reusable dynamic App Logo component that handles custom image URL or stylized icon/monogram
 */
export const AppLogoIcon: React.FC<{
  className?: string;
  sizeClass?: string;
  imageClass?: string;
}> = ({ className = '', sizeClass = 'h-10 w-10', imageClass = 'h-10 w-10' }) => {
  const { branding } = useBranding();

  if (branding.logoType === 'image' && branding.logoUrl) {
    return (
      <div
        className={`relative shrink-0 overflow-hidden rounded-xl border border-[#FF57B2]/70 shadow-[0_0_12px_rgba(255,87,178,0.3)] bg-[#202020] flex items-center justify-center p-1 ${imageClass} ${className}`}
      >
        <img
          src={branding.logoUrl}
          alt={branding.appName}
          className="h-full w-full object-contain"
          onError={(e) => {
            // fallback gracefully to icon if image fails to load
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </div>
    );
  }

  // Render selected or default icon with calming ocean-sky gradient and pure white icon
  const iconProps = { className: 'h-5 w-5 text-white' };
  let IconComponent = <BookOpen {...iconProps} />;

  if (branding.logoIconName === 'Feather') IconComponent = <Feather {...iconProps} />;
  else if (branding.logoIconName === 'Flame') IconComponent = <Flame {...iconProps} />;
  else if (branding.logoIconName === 'Sparkles') IconComponent = <Sparkles {...iconProps} />;
  else if (branding.logoIconName === 'ScrollText') IconComponent = <ScrollText {...iconProps} />;
  else if (branding.logoIconName === 'Crown') IconComponent = <Crown {...iconProps} />;

  return (
    <div
      className={`relative shrink-0 flex items-center justify-center rounded-xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-sm shadow-[#FF57B2]/40 border border-[#FF57B2] hover:shadow-[0_0_18px_rgba(255,87,178,0.65)] transition duration-300 ${sizeClass} ${className}`}
    >
      {IconComponent}
      {/* Subtle glowing reflection line */}
      <div className="absolute inset-x-0 top-0 h-[30%] bg-gradient-to-b from-white/35 to-transparent rounded-t-xl pointer-events-none" />
    </div>
  );
};
