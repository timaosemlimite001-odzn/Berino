import React, { useEffect, useState } from 'react';
import { Instagram, Twitter, Youtube, MessageSquare, Github, Pencil } from 'lucide-react';
import { AuthModal } from './components/AuthModal';
import { Navbar } from './components/Navbar';
import { NotificationDrawer, NotificationToastBanner } from './components/NotificationCenter';
import { SearchModal } from './components/SearchModal';
import { TermsPrivacyModal } from './components/TermsPrivacyModal';
import { DeveloperBrandModal } from './components/DeveloperBrandModal';
import { GoogleAuthPendingOverlay } from './components/GoogleAuthPendingOverlay';
import { AmbientOceanAtmosphere } from './components/AmbientOceanAtmosphere';
import { AuthProvider, useAuth } from './context/AuthContext';
import { BrandingProvider, useBranding, AppLogoIcon } from './context/BrandingContext';
import { NotificationProvider, useNotifications } from './context/NotificationContext';
import { PublicProfileProvider } from './context/PublicProfileContext';
import { ThemeProvider } from './context/ThemeContext';
import { getApiBaseUrl } from './services/apiConfig';
import { initializeCapacitorApp } from './services/capacitorService';
import { creditKards } from './services/kardsService';
import { AchievementsView } from './views/AchievementsView';
import { AuthorStudioView } from './views/AuthorStudioView';
import { BookDetailsView } from './views/BookDetailsView';
import { DeveloperAdminView } from './views/DeveloperAdminView';
import { ExploreBooksView } from './views/ExploreBooksView';
import { HomeView } from './views/HomeView';
import { SubscriptionsView } from './views/SubscriptionsView';
import { LibraryView } from './views/LibraryView';
import { ProfileView } from './views/ProfileView';
import { ReaderView } from './views/ReaderView';
import { RankingView } from './views/RankingView';
import { FluxFeedItem } from './types';
import { SocialSubPage, SocialView } from './views/SocialView';

function AppContent() {
  const { currentUser, isDeveloper, isGoogleAuthPending } = useAuth();
  const { branding } = useBranding();
  const { addToast } = useNotifications();

  // Navigation State
  const [activeTab, setActiveTab] = useState<string>('home');
  const [socialSubPage, setSocialSubPage] = useState<SocialSubPage>('flux');
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null);
  const [readerChapterNumber, setReaderChapterNumber] = useState<number>(1);
  const [selectedCommunityId, setSelectedCommunityId] = useState<string | undefined>(undefined);
  const [selectedFluxPostItem, setSelectedFluxPostItem] = useState<FluxFeedItem | null>(null);
  const [fluxReturnTarget, setFluxReturnTarget] = useState<'communities' | 'library'>('communities');

  // Modals & Drawers
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [notificationDrawerOpen, setNotificationDrawerOpen] = useState(false);
  const [termsModalOpen, setTermsModalOpen] = useState(false);
  const [termsModalTab, setTermsModalTab] = useState<'terms' | 'privacy' | 'guidelines'>('terms');
  const [devBrandModalOpen, setDevBrandModalOpen] = useState(false);

  const handleOpenTerms = (tab: 'terms' | 'privacy' | 'guidelines' = 'terms') => {
    setTermsModalTab(tab);
    setTermsModalOpen(true);
  };

  // Handle Stripe Success Callback on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const stripeSuccess = params.get('stripe_success');
    const sessionId = params.get('session_id');
    const kardsParam = params.get('kards');
    const pkgParam = params.get('pkg');

    const stripeCancel = params.get('stripe_cancel');

    if (stripeCancel === 'true') {
      addToast({
        id: `stripe_cancel_${Date.now()}`,
        type: 'system',
        title: 'Pagamento Cancelado',
        message: 'A operação de compra de Kards foi cancelada ou não concluída no Stripe.',
      });
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    if (stripeSuccess === 'true' && sessionId) {
      // Store in sessionStorage to ensure verification survives auth loading delay
      sessionStorage.setItem('pending_stripe_session', JSON.stringify({ sessionId, kards: kardsParam }));
    }

    const pendingSessionRaw = sessionStorage.getItem('pending_stripe_session');
    if (pendingSessionRaw && currentUser) {
      const { sessionId: sId, kards: kCount } = JSON.parse(pendingSessionRaw);
      const verifyPayment = async () => {
        try {
          const apiBase = getApiBaseUrl();
          const res = await fetch(`${apiBase}/api/verify-stripe-payment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sessionId: sId }),
          });

          if (!res.ok) {
            throw new Error('Falha ao verificar pagamento no servidor');
          }

          const data = await res.json();
          if (data.paid) {
            const kardCount = parseInt(
              String(data.kards || kCount || data.metadata?.kards || '0'),
              10
            );
            if (kardCount > 0) {
              await creditKards(
                currentUser.uid,
                kardCount,
                'kard_purchase',
                `Compra de ${kardCount} Kards via Stripe (Sessão: ${sId.slice(0, 12)}...)`,
                sId
              );
              addToast({
                id: `stripe_${Date.now()}`,
                type: 'achievement',
                title: 'Pagamento Confirmado!',
                message: `Seu saldo foi creditado com ${kardCount} Kards com sucesso.`,
              });
            }
          }
        } catch (err) {
          console.error('Failed to verify Stripe payment session:', err);
        } finally {
          sessionStorage.removeItem('pending_stripe_session');
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      };

      verifyPayment();
    }
  }, [currentUser, addToast]);

  // Initialize native Capacitor mobile integrations & deep-link params
  useEffect(() => {
    initializeCapacitorApp();
    const params = new URLSearchParams(window.location.search);
    const commParam = params.get('comunidade');
    const fluxParam = params.get('flux');
    if (commParam) {
      setSelectedCommunityId(commParam);
      setSocialSubPage('communities');
      setActiveTab('social');
    } else if (fluxParam) {
      setSocialSubPage('flux');
      setActiveTab('social');
    }
  }, []);

  // When switching from a developer account to a regular account, return cleanly to home tab
  useEffect(() => {
    if ((activeTab === 'admin' || activeTab === 'developer') && !isDeveloper) {
      setActiveTab('home');
    }
  }, [activeTab, isDeveloper]);

  const handleNavigateTab = (tab: string) => {
    if (tab === 'communities') {
      setSelectedCommunityId(undefined);
      setFluxReturnTarget('communities');
      setSocialSubPage('communities');
      setActiveTab('social');
    } else if (tab === 'social') {
      setSelectedCommunityId(undefined);
      setFluxReturnTarget('communities');
      setSocialSubPage('flux');
      setActiveTab('social');
    } else {
      setActiveTab(tab);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAuth = (tab: 'login' | 'register' = 'login') => {
    setAuthModalTab(tab);
    setAuthModalOpen(true);
  };

  const handleSelectBook = (bookId: string) => {
    setSelectedBookId(bookId);
    setActiveTab('book_details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleReadBook = (bookId: string, chapterNumber = 1) => {
    setSelectedBookId(bookId);
    setReaderChapterNumber(chapterNumber);
    setActiveTab('reader');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    try {
      const activeEvent = {
        bookId,
        currentChapterNumber: chapterNumber,
        openedAt: Date.now(),
      };
      localStorage.setItem('kordel_last_opened_reading', JSON.stringify(activeEvent));
    } catch {}
  };

  const handleSelectCommunity = (communityId: string) => {
    setSelectedCommunityId(communityId);
    setSocialSubPage('communities');
    setActiveTab('social');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenFluxWithPost = (postItem?: FluxFeedItem) => {
    setFluxReturnTarget(activeTab === 'library' ? 'library' : 'communities');
    setSelectedFluxPostItem(postItem || null);
    setSocialSubPage('flux');
    setActiveTab('social');
    window.scrollTo({ top: 0, behavior: 'auto' });
  };

  const handleBackFromFlux = () => {
    if (fluxReturnTarget === 'library') {
      setFluxReturnTarget('communities');
      setActiveTab('library');
    } else {
      setSocialSubPage('communities');
    }
  };

  const isSocialActive = activeTab === 'social' || activeTab === 'communities';
  const isFluxFullViewport = isSocialActive && socialSubPage === 'flux';

  return (
    <PublicProfileProvider
      onSelectBook={handleSelectBook}
      onOpenAuth={() => handleOpenAuth('login')}
    >
      <div
        aria-busy={isGoogleAuthPending}
        className={`${
          isFluxFullViewport
            ? 'h-[100dvh] overflow-hidden'
            : 'min-h-screen overflow-x-clip'
        } bg-[#202020] text-white flex flex-col font-sans selection:bg-[#FF57B2] selection:text-white relative ${
          isGoogleAuthPending ? 'pointer-events-none select-none' : ''
        }`}
      >
        {/* Atmosfera suave e discreta: nuvens e águas calmas de oceano */}
        <AmbientOceanAtmosphere />

        {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        hideTopHeader={isSocialActive}
        hideFloatingDock={isSocialActive && socialSubPage === 'flux'}
        onNavigate={handleNavigateTab}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenNotifications={() => setNotificationDrawerOpen(true)}
        onOpenAuth={handleOpenAuth}
      />

      {/* Main View Container */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <HomeView
            onSelectBook={handleSelectBook}
            onReadBook={handleReadBook}
            onNavigateTab={handleNavigateTab}
            onExplore={() => setActiveTab('explore')}
            onOpenAuth={handleOpenAuth}
            onSelectCommunity={handleSelectCommunity}
          />
        )}

        {activeTab === 'explore' && (
          <ExploreBooksView onSelectBook={handleSelectBook} />
        )}

        {activeTab === 'book_details' && selectedBookId && (
          <BookDetailsView
            bookId={selectedBookId}
            onBack={() => setActiveTab('explore')}
            onReadBook={handleReadBook}
            onOpenAuth={() => handleOpenAuth('login')}
            onNavigateTab={handleNavigateTab}
          />
        )}

        {activeTab === 'reader' && selectedBookId && (
          <ReaderView
            bookId={selectedBookId}
            initialChapterNumber={readerChapterNumber}
            onBackToBook={() => setActiveTab('book_details')}
            onOpenAuth={() => handleOpenAuth('login')}
            onNavigateTab={handleNavigateTab}
          />
        )}

        {activeTab === 'library' && (
          <LibraryView
            onSelectBook={handleSelectBook}
            onReadBook={handleReadBook}
            onExplore={() => setActiveTab('explore')}
            onOpenAuth={() => handleOpenAuth('login')}
            onOpenCommunity={handleSelectCommunity}
            onOpenFluxPost={handleOpenFluxWithPost}
          />
        )}

        {activeTab === 'studio' && (
          <AuthorStudioView
            onOpenAuth={() => handleOpenAuth('register')}
            onPreviewBook={handleSelectBook}
            onNavigateTab={handleNavigateTab}
          />
        )}

        {isSocialActive && (
          <SocialView
            subPage={socialSubPage}
            onChangeSubPage={(sub) => {
              setSocialSubPage(sub);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onBackFromFlux={handleBackFromFlux}
            initialCommunityId={selectedCommunityId}
            onClearInitialCommunity={() => setSelectedCommunityId(undefined)}
            initialFluxPost={selectedFluxPostItem}
            onClearInitialFluxPost={() => setSelectedFluxPostItem(null)}
            onOpenCommunityFromFlux={handleSelectCommunity}
            onOpenAuth={() => handleOpenAuth('login')}
            onNavigateHome={() => handleNavigateTab('home')}
            onNavigateTab={handleNavigateTab}
          />
        )}

        {activeTab === 'ranking' && (
          <RankingView onNavigateTab={handleNavigateTab} />
        )}

        {activeTab === 'achievements' && (
          <AchievementsView
            onOpenAuth={() => handleOpenAuth('login')}
            onNavigateTab={handleNavigateTab}
          />
        )}

        {(activeTab === 'subscriptions' || activeTab === 'kard_store') && (
          <SubscriptionsView
            onOpenAuth={() => handleOpenAuth('login')}
            onNavigateTab={handleNavigateTab}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView
            onOpenAuth={() => handleOpenAuth('login')}
            onNavigateTab={handleNavigateTab}
          />
        )}

        {(activeTab === 'admin' || activeTab === 'developer') && isDeveloper && <DeveloperAdminView />}
      </main>

      {/* Footer (Oculto dentro da área Social e leitor) */}
      {!isSocialActive && activeTab !== 'reader' && (
        <footer className="mt-16 border-t border-zinc-800 bg-[#202020] py-12 text-zinc-300 relative overflow-hidden">
        {/* Linha sutil Hot Pink no topo do rodapé */}
        <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#FF57B2]/40 to-transparent pointer-events-none" />
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          {/* Sessão Centralizada: Nome da Plataforma e Quem Somos */}
          <div className="flex flex-col items-center text-center max-w-2xl mx-auto pb-8 border-b border-zinc-800">
            <div className="flex items-center justify-center gap-2.5 mb-2.5">
              <AppLogoIcon sizeClass="h-9 w-9" imageClass="h-9 w-9" />
              <span className="font-display font-black text-2xl tracking-tight text-white">
                {branding.appName}
              </span>
              {isDeveloper && (
                <button
                  type="button"
                  onClick={() => setDevBrandModalOpen(true)}
                  className="rounded-lg p-1 text-zinc-400 hover:text-[#FF57B2] hover:bg-zinc-800 transition cursor-pointer"
                  title="Alterar Logo e Nome do App (Exclusivo Desenvolvedor)"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
            <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed font-literary max-w-xl">
              {branding.shortDescription || 'Plataforma soberana de leitura & publicação independente. Valorizando a literatura autoral, a métrica dos versos e a voz livre dos escritores e leitores independentes.'}
            </p>

            {/* Termos e Políticas */}
            <div className="mt-5 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs font-semibold text-zinc-400">
              <button
                type="button"
                onClick={() => handleOpenTerms('terms')}
                className="hover:text-[#FF57B2] transition cursor-pointer"
              >
                Termos de Uso
              </button>
              <span className="text-zinc-700 select-none">•</span>
              <button
                type="button"
                onClick={() => handleOpenTerms('privacy')}
                className="hover:text-[#FF57B2] transition cursor-pointer"
              >
                Políticas de Privacidade
              </button>
              <span className="text-zinc-700 select-none">•</span>
              <button
                type="button"
                onClick={() => handleOpenTerms('guidelines')}
                className="hover:text-[#FF57B2] transition cursor-pointer"
              >
                Diretrizes da Comunidade
              </button>
            </div>

            {/* Redes Sociais */}
            <div className="mt-6 flex items-center justify-center gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram KORDEL"
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#262626] text-zinc-300 hover:text-[#FF57B2] hover:border-[#FF57B2]/40 transition shadow-2xs border border-zinc-800"
                title="Siga no Instagram"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="X / Twitter KORDEL"
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#262626] text-zinc-300 hover:text-[#FF57B2] hover:border-[#FF57B2]/40 transition shadow-2xs border border-zinc-800"
                title="Siga no X / Twitter"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="https://discord.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Discord da Comunidade KORDEL"
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#262626] text-zinc-300 hover:text-[#FF57B2] hover:border-[#FF57B2]/40 transition shadow-2xs border border-zinc-800"
                title="Junte-se à Comunidade no Discord"
              >
                <MessageSquare className="h-4 w-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Canal no YouTube"
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#262626] text-zinc-300 hover:text-[#FF57B2] hover:border-[#FF57B2]/40 transition shadow-2xs border border-zinc-800"
                title="Canal no YouTube"
              >
                <Youtube className="h-4 w-4" />
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Código aberto e ecossistema KORDEL"
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#262626] text-zinc-300 hover:text-[#FF57B2] hover:border-[#FF57B2]/40 transition shadow-2xs border border-zinc-800"
                title="Comunidade de Leitores e Autores"
              >
                <Github className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-500 gap-4">
            <p>© {new Date().getFullYear()} {branding.appName}. Todos os direitos literários reservados aos respectivos autores.</p>
            <p className="flex items-center gap-1.5">
              <span>Construído para valorizar escritores e leitores independentes</span>
              <span className="text-[#FF57B2] font-bold">♥</span>
            </p>
          </div>
        </div>
      </footer>
      )}

      {/* Global Modals & Drawers */}
      <NotificationToastBanner
        onNavigate={(path) => {
          if (path.startsWith('/livro/')) {
            const id = path.replace('/livro/', '');
            handleSelectBook(id);
          } else if (path.startsWith('/comunidade/')) {
            const id = path.replace('/comunidade/', '');
            handleSelectCommunity(id);
          } else if (path === '/conquistas') {
            setActiveTab('achievements');
          } else if (path === '/ranking') {
            setActiveTab('ranking');
          } else if (path === '/assinaturas' || path === '/planos' || path === '/kards') {
            setActiveTab('subscriptions');
          }
        }}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialTab={authModalTab}
      />

      <SearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectBook={handleSelectBook}
        onSelectCommunity={handleSelectCommunity}
      />

      <NotificationDrawer
        isOpen={notificationDrawerOpen}
        onClose={() => setNotificationDrawerOpen(false)}
      />

      <TermsPrivacyModal
        isOpen={termsModalOpen}
        onClose={() => setTermsModalOpen(false)}
        initialTab={termsModalTab}
      />

      {/* Modal de Personalização de Marca & Logo — Exclusivo do Desenvolvedor */}
      {isDeveloper && (
        <DeveloperBrandModal
          isOpen={devBrandModalOpen}
          onClose={() => setDevBrandModalOpen(false)}
        />
      )}
    </div>

      {/* Escudo global de bloqueio de interações durante autenticação Google pendente */}
      <GoogleAuthPendingOverlay />
    </PublicProfileProvider>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrandingProvider>
          <NotificationProvider>
            <AppContent />
          </NotificationProvider>
        </BrandingProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
