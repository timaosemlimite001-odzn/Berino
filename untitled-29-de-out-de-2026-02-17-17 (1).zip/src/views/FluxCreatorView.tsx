import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  EyeOff,
  Highlighter,
  Image as ImageIcon,
  Italic,
  Loader2,
  Lock,
  Mic,
  Move,
  Music,
  Pause,
  Play,
  Plus,
  SlidersHorizontal,
  Square,
  Strikethrough,
  Trash2,
  Type,
  Underline,
  Upload,
  Users,
  Volume2,
  X,
} from 'lucide-react';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { getStoryFontClass, mapStoryPtToPx } from '../components/FluxStoryStage';
import {
  AdjustedImageOutput,
  ImagePostAdjusterModal,
} from '../components/ImagePostAdjusterModal';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { publishFluxPost } from '../services/fluxService';
import {
  Community,
  FluxFeedItem,
  FluxStoryTextLayer,
  PostImageFormat,
  StoryFontStyle,
  StoryTextAlign,
} from '../types';
import {
  FLUX_AUDIO_PRESETS,
  buildFluxAudioPresetFile,
} from '../utils/fluxAudioPresets';

interface CreatorMediaEntry {
  id: string;
  originalFile: File;
  originalUrl: string;
  file: File;
  previewUrl: string;
  isVideo: boolean;
  zoom: number;
  panX: number;
  panY: number;
}

interface CreatorAudioEntry {
  file: File;
  previewUrl: string;
  title: string;
  sourceType: 'upload' | 'recording' | 'library';
  presetId?: string;
  durationSec: number;
  startSec: number;
  endSec: number;
  volume: number;
}

interface FluxCreatorViewProps {
  publishableCommunities: Community[];
  onBack: () => void;
  onPublished: (item: FluxFeedItem) => void;
  onOpenAuth: () => void;
}

const STORY_COLORS = ['#FFFFFF', '#FF66C4', '#FFB3E0', '#E4E4E7', '#A1A1AA'];
const STORY_FONTS: { id: StoryFontStyle; label: string }[] = [
  { id: 'sans', label: 'Fonte' },
  { id: 'literary', label: 'Literária' },
  { id: 'display', label: 'Destaque' },
  { id: 'mono', label: 'Máquina' },
];
const STORY_SIZES_PT = [12, 14, 16, 20, 24, 28];

function formatSecondsMmSs(sec: number): string {
  const safe = Math.max(0, Math.floor(Number.isFinite(sec) ? sec : 0));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

function createDefaultTextLayer(index = 0): FluxStoryTextLayer {
  return {
    id: `txt_${Date.now()}_${index}_${Math.random().toString(36).slice(2, 6)}`,
    text: '',
    x: 50,
    y: index === 0 ? 50 : Math.min(82, 35 + index * 18),
    fontStyle: 'sans',
    fontSizePt: 16,
    color: '#FFFFFF',
    underline: false,
    italic: false,
    uppercase: false,
    strikethrough: false,
    align: 'center',
    hasBackdrop: false,
  };
}

export const FluxCreatorView: React.FC<FluxCreatorViewProps> = ({
  publishableCommunities,
  onBack,
  onPublished,
  onOpenAuth,
}) => {
  const { currentUser, userProfile } = useAuth();
  const { addToast } = useNotifications();

  const [activeTool, setActiveTool] = useState<
    'textos' | 'descricao' | 'audio'
  >('textos');
  const [textLayers, setTextLayers] = useState<FluxStoryTextLayer[]>(() => [
    createDefaultTextLayer(0),
  ]);
  const [activeLayerId, setActiveLayerId] = useState<string>(
    () => textLayers[0]?.id || ''
  );

  // Media state (optional images/videos behind Story text or standalone)
  const [mediaFiles, setMediaFiles] = useState<CreatorMediaEntry[]>([]);
  const [activeMediaIdx, setActiveMediaIdx] = useState(0);
  const [imageFormat, setImageFormat] = useState<PostImageFormat>('story');
  const [adjusterOpen, setAdjusterOpen] = useState(false);
  const [adjusterInitialId, setAdjusterInitialId] = useState<string | undefined>(
    undefined
  );

  // Audio state (selected during Flux post editing)
  const [selectedAudio, setSelectedAudio] = useState<CreatorAudioEntry | null>(
    null
  );
  const [isPreviewPlaying, setIsPreviewPlaying] = useState(false);
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  // Description & Community Destination + Post Privacy/Hiding options
  const [description, setDescription] = useState('');
  const [selectedCommunityId, setSelectedCommunityId] = useState<string>('');
  const [postIsPrivate, setPostIsPrivate] = useState(false);
  const [postIsHiddenFromNonMembers, setPostIsHiddenFromNonMembers] =
    useState(false);

  const [publishing, setPublishing] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioFileInputRef = useRef<HTMLInputElement>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const recordingChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);
  const recordingDiscardRef = useRef<boolean>(false);

  const canvasRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const dragStateRef = useRef<{
    layerId: string;
    startClientX: number;
    startClientY: number;
    origX: number;
    origY: number;
    moved: boolean;
  } | null>(null);

  const activeLayer = useMemo(
    () =>
      textLayers.find((l) => l.id === activeLayerId) || textLayers[0] || null,
    [textLayers, activeLayerId]
  );

  const imageEntriesOnly = useMemo(
    () => mediaFiles.filter((m) => !m.isVideo),
    [mediaFiles]
  );

  const stopActiveRecordingStream = () => {
    if (recordingTimerRef.current !== null) {
      window.clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
  };

  // Cleanup object URLs & active microphone/audio on unmount
  useEffect(() => {
    return () => {
      recordingDiscardRef.current = true;
      if (
        mediaRecorderRef.current &&
        mediaRecorderRef.current.state !== 'inactive'
      ) {
        try {
          mediaRecorderRef.current.stop();
        } catch {
          // ignore
        }
      }
      stopActiveRecordingStream();
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
      }
    };
  }, []);

  // Sync live volume changes to preview audio element
  useEffect(() => {
    if (previewAudioRef.current && selectedAudio) {
      previewAudioRef.current.volume = Math.max(
        0.05,
        Math.min(1, selectedAudio.volume)
      );
    }
  }, [selectedAudio?.volume]);

  const attachNewAudioEntry = (entry: CreatorAudioEntry, autoPlay = true) => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
    }
    if (selectedAudio?.previewUrl) {
      URL.revokeObjectURL(selectedAudio.previewUrl);
    }
    setSelectedAudio(entry);
    setIsPreviewPlaying(false);
    if (autoPlay) {
      window.setTimeout(() => {
        const el = previewAudioRef.current;
        if (!el) return;
        el.volume = entry.volume;
        try {
          el.currentTime = entry.startSec;
        } catch {
          // ignore before metadata
        }
        el.play()
          .then(() => setIsPreviewPlaying(true))
          .catch(() => setIsPreviewPlaying(false));
      }, 60);
    }
  };

  const handleRemoveAudio = () => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
    }
    if (selectedAudio?.previewUrl) {
      URL.revokeObjectURL(selectedAudio.previewUrl);
    }
    setSelectedAudio(null);
    setIsPreviewPlaying(false);
  };

  const handleSelectAudioFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!currentUser) {
      onOpenAuth();
      e.target.value = '';
      return;
    }

    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      addToast({
        id: `flux_audio_size_${Date.now()}`,
        type: 'system',
        title: 'Arquivo muito grande',
        message: 'Escolha um arquivo de áudio de até 15MB.',
      });
      return;
    }

    const cleanTitle =
      file.name
        .replace(/\.(mp3|m4a|wav|ogg|aac|webm|flac)$/i, '')
        .replace(/[_-]+/g, ' ')
        .trim()
        .slice(0, 70) || 'Áudio enviado';

    const previewUrl = URL.createObjectURL(file);
    attachNewAudioEntry(
      {
        file,
        previewUrl,
        title: cleanTitle,
        sourceType: 'upload',
        durationSec: 30,
        startSec: 0,
        endSec: 30,
        volume: 0.85,
      },
      true
    );
    setActiveTool('audio');
  };

  const handlePickPresetTrack = (presetId: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    try {
      const built = buildFluxAudioPresetFile(presetId);
      const previewUrl = URL.createObjectURL(built.file);
      attachNewAudioEntry(
        {
          file: built.file,
          previewUrl,
          title: built.title,
          sourceType: 'library',
          presetId,
          durationSec: built.durationSec,
          startSec: 0,
          endSec: built.durationSec,
          volume: 0.85,
        },
        true
      );
    } catch {
      addToast({
        id: `flux_preset_err_${Date.now()}`,
        type: 'system',
        title: 'Erro ao carregar trilha',
        message: 'Não foi possível preparar a trilha sonora selecionada.',
      });
    }
  };

  const handleStartVoiceRecording = async () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (isRecordingAudio) return;

    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices?.getUserMedia ||
      typeof MediaRecorder === 'undefined'
    ) {
      addToast({
        id: `flux_mic_unsup_${Date.now()}`,
        type: 'system',
        title: 'Gravação indisponível',
        message:
          'Seu navegador não suporta gravação direta. Envie um arquivo de áudio do dispositivo.',
      });
      return;
    }

    try {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        setIsPreviewPlaying(false);
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      recordingChunksRef.current = [];
      recordingDiscardRef.current = false;

      const preferredTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/mp4',
        'audio/ogg',
      ];
      const chosenMime =
        preferredTypes.find((t) => MediaRecorder.isTypeSupported(t)) || '';

      const recorder = chosenMime
        ? new MediaRecorder(stream, { mimeType: chosenMime })
        : new MediaRecorder(stream);

      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          recordingChunksRef.current.push(ev.data);
        }
      };

      const startedAt = Date.now();
      recorder.onstop = () => {
        const elapsedSec = Math.max(
          1,
          Math.round((Date.now() - startedAt) / 1000)
        );
        stopActiveRecordingStream();
        setIsRecordingAudio(false);

        if (
          recordingDiscardRef.current ||
          recordingChunksRef.current.length === 0
        ) {
          recordingChunksRef.current = [];
          return;
        }

        const actualMime =
          recorder.mimeType || chosenMime || 'audio/webm';
        const ext = actualMime.includes('mp4')
          ? 'm4a'
          : actualMime.includes('ogg')
          ? 'ogg'
          : 'webm';

        const blob = new Blob(recordingChunksRef.current, {
          type: actualMime.startsWith('video/')
            ? actualMime.replace('video/', 'audio/')
            : actualMime,
        });
        recordingChunksRef.current = [];

        const recFile = new File([blob], `narracao_flux_${Date.now()}.${ext}`, {
          type: blob.type || 'audio/webm',
        });
        const previewUrl = URL.createObjectURL(recFile);

        attachNewAudioEntry(
          {
            file: recFile,
            previewUrl,
            title: `Narração de ${userProfile?.displayName || 'Autor'}`,
            sourceType: 'recording',
            durationSec: elapsedSec,
            startSec: 0,
            endSec: Math.min(60, elapsedSec),
            volume: 0.95,
          },
          true
        );
      };

      recorder.start(250);
      setRecordingSeconds(0);
      setIsRecordingAudio(true);

      recordingTimerRef.current = window.setInterval(() => {
        const secs = Math.floor((Date.now() - startedAt) / 1000);
        setRecordingSeconds(secs);
        if (secs >= 60 && mediaRecorderRef.current?.state === 'recording') {
          mediaRecorderRef.current.stop();
        }
      }, 300);
    } catch {
      stopActiveRecordingStream();
      setIsRecordingAudio(false);
      addToast({
        id: `flux_mic_denied_${Date.now()}`,
        type: 'system',
        title: 'Permissão de microfone',
        message:
          'Autorize o uso do microfone no navegador para gravar sua voz ou envie um arquivo de áudio.',
      });
    }
  };

  const handleStopVoiceRecording = (discard = false) => {
    recordingDiscardRef.current = discard;
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== 'inactive'
    ) {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        stopActiveRecordingStream();
        setIsRecordingAudio(false);
      }
    } else {
      stopActiveRecordingStream();
      setIsRecordingAudio(false);
    }
  };

  const togglePreviewPlayback = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    const el = previewAudioRef.current;
    if (!el || !selectedAudio) return;

    if (!el.paused) {
      el.pause();
      setIsPreviewPlaying(false);
    } else {
      el.volume = selectedAudio.volume;
      if (
        el.currentTime < selectedAudio.startSec ||
        el.currentTime >= selectedAudio.endSec
      ) {
        try {
          el.currentTime = selectedAudio.startSec;
        } catch {
          // ignore
        }
      }
      el.play()
        .then(() => setIsPreviewPlaying(true))
        .catch(() => setIsPreviewPlaying(false));
    }
  };

  const handlePreviewLoadedMetadata = () => {
    const el = previewAudioRef.current;
    if (!el || !selectedAudio) return;
    const rawDur = el.duration;
    if (Number.isFinite(rawDur) && rawDur > 0.3) {
      const roundedDur = Math.round(rawDur * 10) / 10;
      setSelectedAudio((prev) => {
        if (!prev) return prev;
        const clampedStart = Math.min(
          prev.startSec,
          Math.max(0, roundedDur - 1)
        );
        const clampedEnd = Math.min(
          roundedDur,
          Math.max(clampedStart + 1, Math.min(60, roundedDur))
        );
        return {
          ...prev,
          durationSec: roundedDur,
          startSec: clampedStart,
          endSec: clampedEnd,
        };
      });
    }
  };

  const handlePreviewTimeUpdate = () => {
    const el = previewAudioRef.current;
    if (!el || !selectedAudio) return;
    if (
      selectedAudio.endSec > selectedAudio.startSec &&
      el.currentTime >= selectedAudio.endSec - 0.08
    ) {
      el.currentTime = selectedAudio.startSec;
      if (el.paused && isPreviewPlaying) {
        el.play().catch(() => {});
      }
    }
  };

  const updateActiveLayer = (
    updater: (prev: FluxStoryTextLayer) => FluxStoryTextLayer
  ) => {
    if (!activeLayer) return;
    setTextLayers((prev) =>
      prev.map((layer) =>
        layer.id === activeLayer.id ? updater(layer) : layer
      )
    );
  };

  const handleAddTextLayer = () => {
    if (textLayers.length >= 6) return;
    const nextLayer = createDefaultTextLayer(textLayers.length);
    setTextLayers((prev) => [...prev, nextLayer]);
    setActiveLayerId(nextLayer.id);
    setActiveTool('textos');
    window.setTimeout(() => {
      textareaRef.current?.focus();
    }, 40);
  };

  const handleDeleteActiveLayer = () => {
    if (!activeLayer) return;
    if (textLayers.length <= 1) {
      updateActiveLayer((l) => ({ ...l, text: '', x: 50, y: 50 }));
      return;
    }
    const remaining = textLayers.filter((l) => l.id !== activeLayer.id);
    setTextLayers(remaining);
    setActiveLayerId(remaining[remaining.length - 1]?.id || '');
  };

  // Pointer dragging for positioning Story text anywhere over the image or dark canvas
  const startDraggingLayer = (
    layer: FluxStoryTextLayer,
    clientX: number,
    clientY: number
  ) => {
    setActiveLayerId(layer.id);
    dragStateRef.current = {
      layerId: layer.id,
      startClientX: clientX,
      startClientY: clientY,
      origX: layer.x,
      origY: layer.y,
      moved: false,
    };

    const onMove = (cx: number, cy: number) => {
      const st = dragStateRef.current;
      const box = canvasRef.current;
      if (!st || !box) return;
      const rect = box.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return;

      const dx = cx - st.startClientX;
      const dy = cy - st.startClientY;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) {
        st.moved = true;
      }

      const nextX = Math.max(
        10,
        Math.min(90, st.origX + (dx / rect.width) * 100)
      );
      const nextY = Math.max(
        10,
        Math.min(90, st.origY + (dy / rect.height) * 100)
      );

      setTextLayers((prev) =>
        prev.map((item) =>
          item.id === st.layerId ? { ...item, x: nextX, y: nextY } : item
        )
      );
    };

    const handleMouseMove = (ev: MouseEvent) => {
      ev.preventDefault();
      onMove(ev.clientX, ev.clientY);
    };

    const handleTouchMove = (ev: TouchEvent) => {
      if (ev.touches.length !== 1) return;
      if (ev.cancelable) ev.preventDefault();
      onMove(ev.touches[0].clientX, ev.touches[0].clientY);
    };

    const handleEnd = () => {
      dragStateRef.current = null;
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleEnd);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleEnd);
      window.removeEventListener('touchcancel', handleEnd);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleEnd);
    window.addEventListener('touchmove', handleTouchMove, { passive: false });
    window.addEventListener('touchend', handleEnd);
    window.addEventListener('touchcancel', handleEnd);
  };

  const handleSelectFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!currentUser) {
      onOpenAuth();
      e.target.value = '';
      return;
    }

    const picked = Array.from(e.target.files || []);
    if (picked.length === 0) return;

    const created: CreatorMediaEntry[] = picked
      .slice(0, 8 - mediaFiles.length)
      .map((file, idx) => {
        const isVideo =
          file.type.toLowerCase().startsWith('video/') ||
          /\.(mp4|webm|mov)$/i.test(file.name);
        const url = URL.createObjectURL(file);
        return {
          id: `flux_creator_media_${Date.now()}_${idx}_${Math.random()
            .toString(36)
            .slice(2, 6)}`,
          originalFile: file,
          originalUrl: url,
          file,
          previewUrl: url,
          isVideo,
          zoom: 1,
          panX: 0,
          panY: 0,
        };
      });

    const nextList = [...mediaFiles, ...created].slice(0, 8);
    setMediaFiles(nextList);
    setActiveMediaIdx(nextList.length - created.length);

    e.target.value = '';
  };

  const handleRemoveCurrentMedia = () => {
    const target = mediaFiles[activeMediaIdx];
    if (!target) return;
    if (target.previewUrl && target.previewUrl !== target.originalUrl) {
      URL.revokeObjectURL(target.previewUrl);
    }
    if (target.originalUrl) {
      URL.revokeObjectURL(target.originalUrl);
    }
    const next = mediaFiles.filter((_, idx) => idx !== activeMediaIdx);
    setMediaFiles(next);
    setActiveMediaIdx(Math.max(0, Math.min(activeMediaIdx, next.length - 1)));
  };

  const handleConfirmAdjustedImages = (result: {
    format: PostImageFormat;
    adjustedImages: AdjustedImageOutput[];
  }) => {
    setImageFormat(result.format);
    const byId = new Map(result.adjustedImages.map((a) => [a.id, a]));
    setMediaFiles((prev) =>
      prev.map((item) => {
        if (item.isVideo) return item;
        const adj = byId.get(item.id);
        if (!adj) return item;
        if (item.previewUrl && item.previewUrl !== item.originalUrl) {
          URL.revokeObjectURL(item.previewUrl);
        }
        return {
          ...item,
          file: adj.adjustedFile,
          previewUrl: adj.adjustedPreviewUrl,
          zoom: adj.zoom,
          panX: adj.panX,
          panY: adj.panY,
        };
      })
    );
    setAdjusterOpen(false);
  };

  const handleBackSafe = () => {
    if (isRecordingAudio) {
      handleStopVoiceRecording(true);
    }
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
    }
    if (selectedAudio?.previewUrl) {
      URL.revokeObjectURL(selectedAudio.previewUrl);
    }
    onBack();
  };

  const handlePublish = async () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (publishing) return;

    if (isRecordingAudio) {
      addToast({
        id: `flux_rec_active_${Date.now()}`,
        type: 'system',
        title: 'Gravação em andamento',
        message: 'Finalize a gravação de áudio antes de publicar.',
      });
      return;
    }

    const nonEmptyLayers = textLayers.filter((l) => l.text.trim().length > 0);
    if (
      nonEmptyLayers.length === 0 &&
      mediaFiles.length === 0 &&
      !description.trim() &&
      !selectedAudio
    ) {
      addToast({
        id: `flux_creator_empty_${Date.now()}`,
        type: 'system',
        title: 'Adicione conteúdo à publicação',
        message:
          'Escreva um texto no quadro Story, escolha uma imagem, adicione um áudio ou preencha a descrição antes de publicar.',
      });
      return;
    }

    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      setIsPreviewPlaying(false);
    }

    setPublishing(true);
    try {
      const targetCommunity = selectedCommunityId
        ? publishableCommunities.find((c) => c.id === selectedCommunityId) ||
          null
        : null;

      const hasImages = mediaFiles.some((m) => !m.isVideo);

      const createdItem = await publishFluxPost({
        authorId: currentUser.uid,
        authorName: userProfile?.displayName || 'Autor KORDEL',
        authorPhoto: userProfile?.photoURL || '',
        authorTitle: userProfile?.activeTitle || '',
        content: description.trim(),
        files: mediaFiles.map((m) => m.file),
        imageFormat: hasImages ? imageFormat : 'story',
        storyCanvas:
          nonEmptyLayers.length > 0
            ? {
                backgroundColor: '#262626',
                texts: nonEmptyLayers,
              }
            : undefined,
        audioInput: selectedAudio
          ? {
              file: selectedAudio.file,
              title: selectedAudio.title.trim() || 'Áudio original',
              sourceType: selectedAudio.sourceType,
              durationSec: selectedAudio.durationSec,
              startSec: selectedAudio.startSec,
              endSec: selectedAudio.endSec,
              volume: selectedAudio.volume,
            }
          : null,
        community: targetCommunity,
        isPrivate: targetCommunity ? postIsPrivate : false,
        isHiddenFromNonMembers: targetCommunity
          ? postIsHiddenFromNonMembers
          : false,
      });

      mediaFiles.forEach((f) => {
        if (f.previewUrl && f.previewUrl !== f.originalUrl) {
          URL.revokeObjectURL(f.previewUrl);
        }
        if (f.originalUrl) {
          URL.revokeObjectURL(f.originalUrl);
        }
      });

      if (selectedAudio?.previewUrl) {
        URL.revokeObjectURL(selectedAudio.previewUrl);
      }

      addToast({
        id: `flux_created_${Date.now()}`,
        type: 'achievement',
        title: 'Publicado no Flux!',
        message: 'Sua publicação já está disponível em tela cheia no Flux.',
      });

      onPublished(createdItem);
    } catch (err: any) {
      addToast({
        id: `flux_creator_err_${Date.now()}`,
        type: 'system',
        title: 'Erro ao publicar',
        message: err?.message || 'Não foi possível concluir a publicação.',
      });
    } finally {
      setPublishing(false);
    }
  };

  const activeMedia = mediaFiles[activeMediaIdx];

  const cycleColor = () => {
    if (!activeLayer) return;
    const idx = STORY_COLORS.indexOf(activeLayer.color);
    const nextColor = STORY_COLORS[(idx + 1) % STORY_COLORS.length];
    updateActiveLayer((l) => ({ ...l, color: nextColor }));
  };

  const cycleFont = () => {
    if (!activeLayer) return;
    const idx = STORY_FONTS.findIndex((f) => f.id === activeLayer.fontStyle);
    const nextFont = STORY_FONTS[(idx + 1) % STORY_FONTS.length].id;
    updateActiveLayer((l) => ({ ...l, fontStyle: nextFont }));
  };

  const cycleFontSize = () => {
    if (!activeLayer) return;
    const idx = STORY_SIZES_PT.indexOf(activeLayer.fontSizePt);
    const nextSize =
      STORY_SIZES_PT[(idx >= 0 ? idx + 1 : 2) % STORY_SIZES_PT.length];
    updateActiveLayer((l) => ({ ...l, fontSizePt: nextSize }));
  };

  const cycleAlign = () => {
    if (!activeLayer) return;
    const order: StoryTextAlign[] = ['center', 'left', 'right'];
    const idx = order.indexOf(activeLayer.align || 'center');
    const nextAlign = order[(idx + 1) % order.length];
    updateActiveLayer((l) => ({ ...l, align: nextAlign }));
  };

  const currentFontLabel =
    STORY_FONTS.find((f) => f.id === activeLayer?.fontStyle)?.label || 'Fonte';

  const buildTextDecoration = (layer: FluxStoryTextLayer): string => {
    const parts: string[] = [];
    if (layer.underline) parts.push('underline');
    if (layer.strikethrough) parts.push('line-through');
    return parts.length > 0 ? parts.join(' ') : 'none';
  };

  return (
    <div className="h-[100dvh] w-full overflow-hidden bg-[#1D1D1D] text-white flex flex-col justify-between select-none">
      {/* Hidden Preview Audio Element for Post Editor */}
      {selectedAudio && (
        <audio
          ref={previewAudioRef}
          src={selectedAudio.previewUrl}
          preload="metadata"
          onLoadedMetadata={handlePreviewLoadedMetadata}
          onTimeUpdate={handlePreviewTimeUpdate}
          onEnded={() => {
            const el = previewAudioRef.current;
            if (!el || !selectedAudio) return;
            el.currentTime = selectedAudio.startSec;
            el.play().catch(() => setIsPreviewPlaying(false));
          }}
          onPlay={() => setIsPreviewPlaying(true)}
          onPause={() => setIsPreviewPlaying(false)}
          className="hidden"
        />
      )}

      {/* 1. TOP HEADER BAR — Pink Back Button on Left + Pink "Publicar" on Right */}
      <header className="w-full shrink-0 bg-[#232323] border-b border-zinc-800/70">
        <div className="w-full max-w-[500px] mx-auto px-4 py-3 flex items-center justify-between">
          <button
            type="button"
            onClick={handleBackSafe}
            disabled={publishing}
            className="h-10 w-10 rounded-full bg-[#FF66C4] hover:bg-[#FF57B2] text-[#181818] flex items-center justify-center transition active:scale-95 cursor-pointer disabled:opacity-50"
            aria-label="Voltar ao Flux"
            title="Voltar ao Flux"
          >
            <ArrowLeft className="h-5 w-5 stroke-[2.8]" />
          </button>

          <button
            type="button"
            onClick={handlePublish}
            disabled={publishing}
            className="min-h-[40px] px-2 text-[#FF66C4] hover:text-[#FF80C5] font-extrabold text-lg sm:text-xl tracking-tight transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {publishing && <Loader2 className="h-4 w-4 animate-spin" />}
            <span>{publishing ? 'Publicando...' : 'Publicar'}</span>
          </button>
        </div>
      </header>

      {/* 2. CENTRAL STORY CANVAS (Supports Images, Overlaid Draggable Text, Audio, or Text-Only Story) */}
      <div className="flex-1 min-h-0 w-full max-w-[500px] mx-auto px-5 py-2.5 flex flex-col items-center justify-center overflow-hidden">
        <div
          ref={canvasRef}
          onClick={() => {
            if (activeTool === 'textos') {
              textareaRef.current?.focus();
            }
          }}
          className="relative w-full h-full max-h-[560px] rounded-[24px] bg-[#262626] overflow-hidden shadow-2xl flex items-center justify-center"
        >
          {/* Media Layer */}
          {activeMedia && (
            <>
              {activeMedia.isVideo ? (
                <video
                  key={activeMedia.previewUrl}
                  src={activeMedia.previewUrl}
                  controls
                  playsInline
                  muted={Boolean(selectedAudio)}
                  className="h-full w-full object-cover"
                />
              ) : (
                <img
                  key={activeMedia.previewUrl}
                  src={activeMedia.previewUrl}
                  alt="Prévia da mídia"
                  draggable={false}
                  className="h-full w-full object-cover pointer-events-none select-none"
                />
              )}

              {/* Subtle scrim when text layers exist on top of image */}
              {textLayers.some((l) => l.text.trim().length > 0) && (
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/30 via-black/15 to-black/40" />
              )}

              {/* Top Media Quick Controls (Adjust Framing / Remove Media / Counter) */}
              <div className="absolute top-3 inset-x-3 z-30 flex items-center justify-between gap-2 pointer-events-auto">
                <div className="flex items-center gap-1.5">
                  {!activeMedia.isVideo && imageEntriesOnly.length > 0 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setAdjusterInitialId(activeMedia.id);
                        setAdjusterOpen(true);
                      }}
                      className="inline-flex items-center gap-1.5 rounded-full bg-black/65 hover:bg-black/85 backdrop-blur-xs px-3 py-1.5 text-[11px] font-bold text-white border border-white/15 transition cursor-pointer"
                    >
                      <SlidersHorizontal className="h-3.5 w-3.5 text-[#FF66C4]" />
                      <span>Ajustar</span>
                    </button>
                  )}
                  {mediaFiles.length > 1 && (
                    <span className="rounded-full bg-black/65 backdrop-blur-xs px-2.5 py-1 text-[11px] font-bold text-zinc-200 tabular-nums">
                      {activeMediaIdx + 1}/{mediaFiles.length}
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRemoveCurrentMedia();
                  }}
                  className="h-8 w-8 rounded-full bg-black/65 hover:bg-black/85 backdrop-blur-xs text-white flex items-center justify-center border border-white/15 transition cursor-pointer"
                  title="Remover esta mídia"
                  aria-label="Remover esta mídia"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Multi-media navigation arrows */}
              {mediaFiles.length > 1 && (
                <>
                  {activeMediaIdx > 0 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMediaIdx((p) => p - 1);
                      }}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 z-30 h-8 w-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center cursor-pointer"
                      aria-label="Mídia anterior"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </button>
                  )}
                  {activeMediaIdx < mediaFiles.length - 1 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveMediaIdx((p) => p + 1);
                      }}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 z-30 h-8 w-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center cursor-pointer"
                      aria-label="Próxima mídia"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  )}
                </>
              )}
            </>
          )}

          {/* Story Text Layers (Editable & Draggable) */}
          {textLayers.map((layer) => {
            const isSelected = activeLayer?.id === layer.id;
            const pxSize = mapStoryPtToPx(layer.fontSizePt);
            const showLayer =
              (isSelected && activeTool === 'textos') ||
              layer.text.trim().length > 0 ||
              (!activeMedia && !selectedAudio && textLayers.length === 1);

            if (!showLayer) return null;

            return (
              <div
                key={layer.id}
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveLayerId(layer.id);
                  setActiveTool('textos');
                }}
                style={{
                  left: `${layer.x}%`,
                  top: `${layer.y}%`,
                  transform: 'translate(-50%, -50%)',
                  width: '84%',
                }}
                className={`absolute z-20 flex flex-col items-center ${
                  isSelected && activeTool === 'textos'
                    ? 'ring-1 ring-white/20 rounded-2xl'
                    : ''
                }`}
              >
                {/* Drag Handle when layer has text or media behind it */}
                {isSelected &&
                  activeTool === 'textos' &&
                  (layer.text.trim().length > 0 || Boolean(activeMedia)) && (
                    <div
                      onMouseDown={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        startDraggingLayer(layer, e.clientX, e.clientY);
                      }}
                      onTouchStart={(e) => {
                        if (e.touches.length === 1) {
                          e.stopPropagation();
                          startDraggingLayer(
                            layer,
                            e.touches[0].clientX,
                            e.touches[0].clientY
                          );
                        }
                      }}
                      className="mb-1.5 inline-flex items-center gap-1 rounded-full bg-black/65 px-2.5 py-0.5 text-[10px] font-semibold text-zinc-200 cursor-grab active:cursor-grabbing border border-white/15"
                      title="Arraste para mover o texto na imagem"
                    >
                      <Move className="h-3 w-3 text-[#FF66C4]" />
                      <span>Mover</span>
                    </div>
                  )}

                {isSelected && activeTool === 'textos' ? (
                  <textarea
                    ref={textareaRef}
                    value={layer.text}
                    onChange={(e) => {
                      const val = e.target.value;
                      setTextLayers((prev) =>
                        prev.map((item) =>
                          item.id === layer.id ? { ...item, text: val } : item
                        )
                      );
                    }}
                    rows={Math.min(
                      10,
                      Math.max(2, layer.text.split('\n').length)
                    )}
                    maxLength={1200}
                    placeholder={
                      activeMedia
                        ? 'Digite um texto sobre a imagem...'
                        : 'Toque para escrever no quadro Story ou adicione mídia/áudio abaixo...'
                    }
                    style={{
                      color: layer.color || '#FFFFFF',
                      fontSize: `${pxSize}px`,
                      textAlign: layer.align || 'center',
                      textDecoration: buildTextDecoration(layer),
                      fontStyle: layer.italic ? 'italic' : 'normal',
                      textTransform: layer.uppercase ? 'uppercase' : 'none',
                      textShadow: layer.hasBackdrop
                        ? 'none'
                        : '0 2px 10px rgba(0,0,0,0.65)',
                    }}
                    className={`w-full resize-none bg-transparent focus:outline-none placeholder:text-zinc-400/75 leading-relaxed select-text ${getStoryFontClass(
                      layer.fontStyle
                    )} ${
                      layer.hasBackdrop
                        ? 'rounded-2xl bg-black/70 backdrop-blur-xs px-3.5 py-2.5'
                        : 'px-2 py-1'
                    }`}
                  />
                ) : (
                  <p
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startDraggingLayer(layer, e.clientX, e.clientY);
                    }}
                    onTouchStart={(e) => {
                      if (e.touches.length === 1) {
                        e.stopPropagation();
                        startDraggingLayer(
                          layer,
                          e.touches[0].clientX,
                          e.touches[0].clientY
                        );
                      }
                    }}
                    style={{
                      color: layer.color || '#FFFFFF',
                      fontSize: `${pxSize}px`,
                      textAlign: layer.align || 'center',
                      textDecoration: buildTextDecoration(layer),
                      fontStyle: layer.italic ? 'italic' : 'normal',
                      textTransform: layer.uppercase ? 'uppercase' : 'none',
                      textShadow: layer.hasBackdrop
                        ? 'none'
                        : '0 2px 10px rgba(0,0,0,0.65)',
                    }}
                    className={`w-full whitespace-pre-wrap break-words leading-relaxed cursor-grab ${getStoryFontClass(
                      layer.fontStyle
                    )} ${
                      layer.hasBackdrop
                        ? 'rounded-2xl bg-black/70 backdrop-blur-xs px-3.5 py-2.5'
                        : 'px-2 py-1'
                    }`}
                  >
                    {layer.text}
                  </p>
                )}
              </div>
            );
          })}

          {/* Audio-Only Stage Preview when audio is attached and no image/text is typed yet */}
          {!activeMedia &&
            selectedAudio &&
            activeTool !== 'textos' &&
            textLayers.every((l) => l.text.trim().length === 0) && (
              <button
                type="button"
                onClick={togglePreviewPlayback}
                className="relative z-10 flex flex-col items-center justify-center gap-3 px-6 py-6 text-center cursor-pointer"
              >
                <div className="h-20 w-20 rounded-full bg-[#1D1D1D] border border-[#FF66C4]/50 flex items-center justify-center shadow-lg">
                  {isPreviewPlaying ? (
                    <Pause className="h-8 w-8 text-[#FF66C4]" />
                  ) : (
                    <Play className="h-8 w-8 text-[#FF66C4] translate-x-0.5" />
                  )}
                </div>
                <div className="space-y-0.5 max-w-[240px]">
                  <p className="text-sm font-bold text-white truncate">
                    {selectedAudio.title || 'Áudio original'}
                  </p>
                  <p className="text-xs text-zinc-400">
                    Toque em Textos ou na galeria se quiser combinar com imagem
                  </p>
                </div>
              </button>
            )}

          {/* Attached Audio Badge on Story Canvas */}
          {selectedAudio && (
            <div className="absolute bottom-3 inset-x-3 z-30 flex items-center justify-between gap-2 pointer-events-none">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  if (activeTool !== 'audio') {
                    setActiveTool('audio');
                  } else {
                    togglePreviewPlayback(e);
                  }
                }}
                className="pointer-events-auto max-w-[82%] min-h-[34px] rounded-xl bg-black/70 hover:bg-black/85 backdrop-blur-xs border border-white/15 px-3 py-1.5 flex items-center gap-2 text-left transition cursor-pointer"
                title="Configurar ou ouvir áudio da publicação"
              >
                <Music className="h-3.5 w-3.5 text-[#FF66C4] shrink-0" />
                <span className="text-xs font-semibold text-white truncate">
                  {selectedAudio.title || 'Áudio original'}
                </span>
                <span className="text-[11px] text-zinc-400 tabular-nums shrink-0">
                  {formatSecondsMmSs(selectedAudio.startSec)}–
                  {formatSecondsMmSs(selectedAudio.endSec)}
                </span>
              </button>

              <button
                type="button"
                onClick={togglePreviewPlayback}
                className="pointer-events-auto h-8 w-8 rounded-full bg-black/70 hover:bg-black/85 backdrop-blur-xs border border-white/15 text-white flex items-center justify-center transition cursor-pointer shrink-0"
                title={isPreviewPlaying ? 'Pausar prévia' : 'Ouvir prévia'}
                aria-label={isPreviewPlaying ? 'Pausar prévia' : 'Ouvir prévia'}
              >
                {isPreviewPlaying ? (
                  <Pause className="h-3.5 w-3.5 text-[#FF66C4]" />
                ) : (
                  <Play className="h-3.5 w-3.5 text-white translate-x-0.5" />
                )}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 3. BOTTOM CONTROLS & RICH STORY + AUDIO TOOLBAR */}
      <div className="shrink-0 w-full max-w-[500px] mx-auto px-4 pb-4 space-y-2.5">
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime"
          onChange={handleSelectFiles}
          className="hidden"
        />

        <input
          ref={audioFileInputRef}
          type="file"
          accept="audio/*,.mp3,.m4a,.wav,.ogg,.aac,.webm"
          onChange={handleSelectAudioFile}
          className="hidden"
        />

        {/* Row 1: [Descrição]   [Textos]   [Áudio]   [Gallery Icon] */}
        <div className="flex items-center justify-center gap-2 sm:gap-2.5">
          <button
            type="button"
            onClick={() =>
              setActiveTool((prev) =>
                prev === 'descricao' ? 'textos' : 'descricao'
              )
            }
            className={`min-h-[42px] px-4 rounded-full bg-[#262626] text-white font-extrabold text-xs sm:text-sm transition cursor-pointer border-[1.5px] flex items-center gap-1.5 ${
              activeTool === 'descricao'
                ? 'border-[#FF66C4]'
                : description.trim()
                ? 'border-zinc-600'
                : 'border-transparent hover:border-zinc-700'
            }`}
          >
            <span>Descrição</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTool('textos');
              window.setTimeout(() => textareaRef.current?.focus(), 30);
            }}
            className={`min-h-[42px] px-5 rounded-full bg-[#262626] text-white font-extrabold text-xs sm:text-sm transition cursor-pointer border-[1.5px] ${
              activeTool === 'textos'
                ? 'border-[#FF66C4]'
                : 'border-transparent hover:border-zinc-700'
            }`}
          >
            Textos
          </button>

          <button
            type="button"
            onClick={() =>
              setActiveTool((prev) => (prev === 'audio' ? 'textos' : 'audio'))
            }
            className={`min-h-[42px] px-4 rounded-full bg-[#262626] text-white font-extrabold text-xs sm:text-sm transition cursor-pointer border-[1.5px] flex items-center gap-1.5 ${
              activeTool === 'audio'
                ? 'border-[#FF66C4]'
                : selectedAudio
                ? 'border-[#FF66C4]/65 text-[#FF66C4]'
                : 'border-transparent hover:border-zinc-700'
            }`}
            title="Escolher ou gravar áudio para a publicação"
          >
            <Music className="h-4 w-4 text-[#FF66C4] shrink-0" />
            <span>Áudio</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className={`min-h-[42px] min-w-[48px] px-3.5 rounded-full bg-[#262626] text-white flex items-center justify-center transition cursor-pointer border-[1.5px] ${
              mediaFiles.length > 0
                ? 'border-[#FF66C4]'
                : 'border-transparent hover:border-zinc-700'
            }`}
            title="Adicionar imagens ou vídeos"
            aria-label="Adicionar imagens ou vídeos"
          >
            <ImageIcon className="h-5 w-5 text-white" />
          </button>
        </div>

        {/* Row 2A: Rich Typography Toolbar when "Textos" is active */}
        {activeTool === 'textos' && activeLayer && (
          <div className="rounded-2xl bg-[#262626] px-3 py-2 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar border border-zinc-800/80">
            {/* Color A */}
            <button
              type="button"
              onClick={cycleColor}
              className="min-h-[36px] min-w-[34px] px-1.5 rounded-lg hover:bg-zinc-800 flex flex-col items-center justify-center cursor-pointer shrink-0"
              title="Alternar cor do texto"
            >
              <span className="text-sm font-extrabold leading-none text-white">
                A
              </span>
              <span
                style={{ backgroundColor: activeLayer.color || '#FFFFFF' }}
                className="mt-1 h-1 w-4 rounded-full"
              />
            </button>

            {/* Font Family */}
            <button
              type="button"
              onClick={cycleFont}
              className="min-h-[36px] px-2 rounded-lg hover:bg-zinc-800 text-sm font-extrabold text-white whitespace-nowrap cursor-pointer shrink-0"
              title="Alternar fonte"
            >
              {currentFontLabel}
            </button>

            {/* Font Size pt */}
            <button
              type="button"
              onClick={cycleFontSize}
              className="min-h-[36px] px-2 rounded-lg hover:bg-zinc-800 text-xs font-extrabold text-white whitespace-nowrap tabular-nums cursor-pointer shrink-0"
              title="Alternar tamanho do texto"
            >
              {activeLayer.fontSizePt} pt
            </button>

            {/* Underline */}
            <button
              type="button"
              onClick={() =>
                updateActiveLayer((l) => ({ ...l, underline: !l.underline }))
              }
              className={`min-h-[36px] min-w-[34px] rounded-lg flex items-center justify-center transition cursor-pointer shrink-0 ${
                activeLayer.underline
                  ? 'bg-[#FF66C4]/20 text-[#FF66C4]'
                  : 'text-white hover:bg-zinc-800'
              }`}
              title="Sublinhado"
            >
              <Underline className="h-4 w-4 stroke-[2.4]" />
            </button>

            {/* Italic */}
            <button
              type="button"
              onClick={() =>
                updateActiveLayer((l) => ({ ...l, italic: !l.italic }))
              }
              className={`min-h-[36px] min-w-[34px] rounded-lg flex items-center justify-center transition cursor-pointer shrink-0 ${
                activeLayer.italic
                  ? 'bg-[#FF66C4]/20 text-[#FF66C4]'
                  : 'text-white hover:bg-zinc-800'
              }`}
              title="Itálico"
            >
              <Italic className="h-4 w-4 stroke-[2.4]" />
            </button>

            {/* Uppercase TT */}
            <button
              type="button"
              onClick={() =>
                updateActiveLayer((l) => ({ ...l, uppercase: !l.uppercase }))
              }
              className={`min-h-[36px] min-w-[34px] rounded-lg flex items-center justify-center transition cursor-pointer shrink-0 ${
                activeLayer.uppercase
                  ? 'bg-[#FF66C4]/20 text-[#FF66C4]'
                  : 'text-white hover:bg-zinc-800'
              }`}
              title="Maiúsculas"
            >
              <Type className="h-4 w-4 stroke-[2.4]" />
            </button>

            {/* Strikethrough */}
            <button
              type="button"
              onClick={() =>
                updateActiveLayer((l) => ({
                  ...l,
                  strikethrough: !l.strikethrough,
                }))
              }
              className={`min-h-[36px] min-w-[34px] rounded-lg flex items-center justify-center transition cursor-pointer shrink-0 ${
                activeLayer.strikethrough
                  ? 'bg-[#FF66C4]/20 text-[#FF66C4]'
                  : 'text-white hover:bg-zinc-800'
              }`}
              title="Tachado"
            >
              <Strikethrough className="h-4 w-4 stroke-[2.4]" />
            </button>

            {/* Alignment */}
            <button
              type="button"
              onClick={cycleAlign}
              className="min-h-[36px] min-w-[34px] rounded-lg text-white hover:bg-zinc-800 flex items-center justify-center transition cursor-pointer shrink-0"
              title="Alinhamento do texto"
            >
              {activeLayer.align === 'left' ? (
                <AlignLeft className="h-4 w-4 stroke-[2.4]" />
              ) : activeLayer.align === 'right' ? (
                <AlignRight className="h-4 w-4 stroke-[2.4]" />
              ) : (
                <AlignCenter className="h-4 w-4 stroke-[2.4]" />
              )}
            </button>

            {/* Text Backdrop Highlight */}
            <button
              type="button"
              onClick={() =>
                updateActiveLayer((l) => ({
                  ...l,
                  hasBackdrop: !l.hasBackdrop,
                }))
              }
              className={`min-h-[36px] min-w-[34px] rounded-lg flex items-center justify-center transition cursor-pointer shrink-0 ${
                activeLayer.hasBackdrop
                  ? 'bg-[#FF66C4]/20 text-[#FF66C4]'
                  : 'text-white hover:bg-zinc-800'
              }`}
              title="Fundo de contraste no texto"
            >
              <Highlighter className="h-4 w-4 stroke-[2.2]" />
            </button>

            {/* Add / Clear Extra Text Layer */}
            <button
              type="button"
              onClick={handleAddTextLayer}
              disabled={textLayers.length >= 6}
              className="min-h-[36px] min-w-[34px] rounded-lg text-[#FF66C4] hover:bg-zinc-800 flex items-center justify-center transition cursor-pointer shrink-0 disabled:opacity-40"
              title="Adicionar nova camada de texto"
            >
              <Plus className="h-4 w-4 stroke-[2.6]" />
            </button>

            {(textLayers.length > 1 || activeLayer.text.trim().length > 0) && (
              <button
                type="button"
                onClick={handleDeleteActiveLayer}
                className="min-h-[36px] min-w-[34px] rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 flex items-center justify-center transition cursor-pointer shrink-0"
                title="Limpar ou remover camada selecionada"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        )}

        {/* Row 2B: Description & Optional Community + Privacy Panel when "Descrição" is active */}
        {activeTool === 'descricao' && (
          <div className="rounded-2xl bg-[#262626] p-3.5 space-y-2.5 border border-zinc-800/90">
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={4000}
              placeholder="Escreva a descrição que ficará logo abaixo da publicação no Flux..."
              className="w-full resize-none rounded-xl bg-[#1D1D1D] border border-zinc-700/80 px-3 py-2 text-xs sm:text-sm text-white placeholder:text-zinc-500 focus:border-[#FF66C4] focus:outline-none select-text"
            />

            {publishableCommunities.length > 0 && (
              <div className="space-y-2 pt-1">
                <div className="flex items-center gap-2">
                  <Users className="h-3.5 w-3.5 text-[#FF66C4] shrink-0" />
                  <select
                    value={selectedCommunityId}
                    onChange={(e) => setSelectedCommunityId(e.target.value)}
                    className="flex-1 rounded-xl bg-[#1D1D1D] border border-zinc-700/80 px-2.5 py-1.5 text-xs text-white [color-scheme:dark] focus:border-[#FF66C4] focus:outline-none cursor-pointer"
                  >
                    <option value="">Publicar somente no Flux geral</option>
                    {publishableCommunities.map((c) => (
                      <option key={c.id} value={c.id}>
                        Comunidade: {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedCommunityId && (
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => setPostIsPrivate((p) => !p)}
                      className={`inline-flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-bold border transition cursor-pointer ${
                        postIsPrivate
                          ? 'bg-[#FF66C4]/20 border-[#FF66C4] text-white'
                          : 'bg-[#1D1D1D] border-zinc-700 text-zinc-300'
                      }`}
                    >
                      <Lock className="h-3 w-3 text-[#FF66C4]" />
                      <span>Privar post (só membros)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setPostIsHiddenFromNonMembers((p) => !p)
                      }
                      className={`inline-flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-bold border transition cursor-pointer ${
                        postIsHiddenFromNonMembers
                          ? 'bg-[#FF66C4]/20 border-[#FF66C4] text-white'
                          : 'bg-[#1D1D1D] border-zinc-700 text-zinc-300'
                      }`}
                    >
                      <EyeOff className="h-3 w-3 text-[#FF66C4]" />
                      <span>Ocultar p/ não-membros</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Row 2C: Audio Selection, Recording, Presets & Trim Panel when "Áudio" is active */}
        {activeTool === 'audio' && (
          <div className="rounded-2xl bg-[#262626] p-3 space-y-2.5 border border-zinc-800/90">
            {isRecordingAudio ? (
              <div className="flex items-center justify-between gap-3 rounded-xl bg-[#1D1D1D] border border-[#FF66C4]/50 px-3.5 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Mic className="h-4 w-4 text-[#FF66C4] shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white">
                      Gravando áudio...
                    </p>
                    <p className="text-[11px] text-zinc-400 tabular-nums">
                      {formatSecondsMmSs(recordingSeconds)} / 1:00
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleStopVoiceRecording(true)}
                    className="min-h-[34px] px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 transition cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={() => handleStopVoiceRecording(false)}
                    className="min-h-[34px] px-3.5 rounded-lg bg-[#FF66C4] hover:bg-[#FF57B2] text-[#181818] text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Square className="h-3 w-3 fill-current" />
                    <span>Concluir</span>
                  </button>
                </div>
              </div>
            ) : selectedAudio ? (
              <div className="space-y-2.5">
                {/* Active Track Controls: Play/Pause + Editable Title + Replace + Delete */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={togglePreviewPlayback}
                    className="h-9 w-9 rounded-full bg-[#FF66C4] hover:bg-[#FF57B2] text-[#181818] flex items-center justify-center transition cursor-pointer shrink-0"
                    title={isPreviewPlaying ? 'Pausar' : 'Reproduzir trecho'}
                    aria-label={
                      isPreviewPlaying ? 'Pausar' : 'Reproduzir trecho'
                    }
                  >
                    {isPreviewPlaying ? (
                      <Pause className="h-4 w-4 fill-current" />
                    ) : (
                      <Play className="h-4 w-4 fill-current translate-x-0.5" />
                    )}
                  </button>

                  <input
                    type="text"
                    value={selectedAudio.title}
                    maxLength={80}
                    onChange={(e) =>
                      setSelectedAudio((prev) =>
                        prev ? { ...prev, title: e.target.value } : prev
                      )
                    }
                    placeholder="Nome do áudio ou trilha..."
                    className="flex-1 min-w-0 rounded-xl bg-[#1D1D1D] border border-zinc-700/80 px-3 py-1.5 text-xs font-semibold text-white placeholder:text-zinc-500 focus:border-[#FF66C4] focus:outline-none select-text"
                  />

                  <button
                    type="button"
                    onClick={() => audioFileInputRef.current?.click()}
                    className="h-9 px-2.5 rounded-xl bg-[#1D1D1D] hover:bg-zinc-800 border border-zinc-700/80 text-xs font-semibold text-zinc-200 flex items-center gap-1 transition cursor-pointer shrink-0"
                    title="Trocar arquivo de áudio"
                  >
                    <Upload className="h-3.5 w-3.5 text-[#FF66C4]" />
                    <span className="hidden sm:inline">Trocar</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleRemoveAudio}
                    className="h-9 w-9 rounded-xl bg-[#1D1D1D] hover:bg-zinc-800 border border-zinc-700/80 text-zinc-400 hover:text-white flex items-center justify-center transition cursor-pointer shrink-0"
                    title="Remover áudio"
                    aria-label="Remover áudio"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>

                {/* Snippet Start & Volume Sliders */}
                <div className="grid grid-cols-2 gap-3 pt-0.5">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-zinc-400">
                      <span>Trecho</span>
                      <span className="tabular-nums text-zinc-200 font-semibold">
                        {formatSecondsMmSs(selectedAudio.startSec)} –{' '}
                        {formatSecondsMmSs(selectedAudio.endSec)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={Math.max(
                        0,
                        Math.floor((selectedAudio.durationSec || 12) - 2)
                      )}
                      step={0.5}
                      value={selectedAudio.startSec}
                      onChange={(e) => {
                        const nextStart = parseFloat(e.target.value) || 0;
                        setSelectedAudio((prev) => {
                          if (!prev) return prev;
                          const clipLen = Math.max(
                            3,
                            Math.min(30, prev.durationSec - nextStart)
                          );
                          return {
                            ...prev,
                            startSec: nextStart,
                            endSec: Math.min(
                              prev.durationSec,
                              nextStart + clipLen
                            ),
                          };
                        });
                        if (previewAudioRef.current) {
                          try {
                            previewAudioRef.current.currentTime = nextStart;
                          } catch {
                            // ignore
                          }
                        }
                      }}
                      className="w-full accent-[#FF66C4] cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-zinc-400">
                      <span className="flex items-center gap-1">
                        <Volume2 className="h-3 w-3 text-[#FF66C4]" />
                        Volume
                      </span>
                      <span className="tabular-nums text-zinc-200 font-semibold">
                        {Math.round(selectedAudio.volume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.1}
                      max={1}
                      step={0.05}
                      value={selectedAudio.volume}
                      onChange={(e) => {
                        const nextVol = parseFloat(e.target.value) || 0.85;
                        setSelectedAudio((prev) =>
                          prev ? { ...prev, volume: nextVol } : prev
                        );
                      }}
                      className="w-full accent-[#FF66C4] cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            ) : (
              /* Source Picker: Upload Audio File | Record Voice | KORDEL Literary Soundtracks */
              <div className="space-y-2.5">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => audioFileInputRef.current?.click()}
                    className="min-h-[40px] rounded-xl bg-[#1D1D1D] hover:bg-zinc-800 border border-zinc-700/80 px-3 py-2 flex items-center justify-center gap-2 text-xs font-bold text-white transition cursor-pointer"
                  >
                    <Upload className="h-4 w-4 text-[#FF66C4] shrink-0" />
                    <span>Enviar arquivo</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleStartVoiceRecording}
                    className="min-h-[40px] rounded-xl bg-[#1D1D1D] hover:bg-zinc-800 border border-zinc-700/80 px-3 py-2 flex items-center justify-center gap-2 text-xs font-bold text-white transition cursor-pointer"
                  >
                    <Mic className="h-4 w-4 text-[#FF66C4] shrink-0" />
                    <span>Gravar voz</span>
                  </button>
                </div>

                {/* Built-in Literary Soundtracks Horizontal Selector */}
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-0.5">
                  {FLUX_AUDIO_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handlePickPresetTrack(preset.id)}
                      className="shrink-0 rounded-xl bg-[#1D1D1D] hover:bg-zinc-800 border border-zinc-700/70 hover:border-[#FF66C4]/60 px-3 py-1.5 text-left transition cursor-pointer"
                    >
                      <p className="text-xs font-bold text-white whitespace-nowrap">
                        {preset.title}
                      </p>
                      <p className="text-[10px] text-zinc-400 whitespace-nowrap">
                        {preset.subtitle}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Image Framing Adjuster Modal */}
      {imageEntriesOnly.length > 0 && (
        <ImagePostAdjusterModal
          isOpen={adjusterOpen}
          initialFormat={imageFormat}
          initialActiveId={adjusterInitialId}
          images={imageEntriesOnly.map((img) => ({
            id: img.id,
            originalFile: img.originalFile,
            originalUrl: img.originalUrl,
            zoom: img.zoom,
            panX: img.panX,
            panY: img.panY,
          }))}
          onClose={() => setAdjusterOpen(false)}
          onConfirm={handleConfirmAdjustedImages}
        />
      )}
    </div>
  );
};

