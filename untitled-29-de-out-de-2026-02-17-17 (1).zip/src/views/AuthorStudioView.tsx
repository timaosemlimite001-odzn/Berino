import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  setDoc,
  updateDoc,
  where
} from 'firebase/firestore';
import {
  AlertCircle,
  BookCheck,
  BookOpen,
  CheckCircle,
  CheckCircle2,
  Clock,
  Eye,
  Feather,
  FileText,
  Plus,
  Save,
  Sparkles,
  Trash2,
  Upload,
  UserCheck,
  Users,
  X,
  Coins,
  Rocket,
  Zap
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { db, sanitizeFirestoreData } from '../services/firebase';
import { awardXp, checkAndUnlockAchievement, sendNotification } from '../services/progressionService';
import { KARD_COSTS, spendKards } from '../services/kardsService';
import { uploadFileToStorage } from '../services/storageService';
import { activateBookBoost } from '../services/boostService';
import { isSubscriptionActive } from '../services/subscriptionService';
import { BetaApplication, Book, BookStatus, Chapter, ContentRating, PublishStatus } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';

interface AuthorStudioViewProps {
  onOpenAuth: () => void;
  onPreviewBook: (bookId: string) => void;
  onNavigateTab?: (tab: string) => void;
}

const AVAILABLE_GENRES = [
  'Cordel',
  'Romance',
  'Fantasia',
  'Ficção Científica',
  'Suspense & Mistério',
  'Poesia',
  'Folclore & Lendas',
  'Drama',
  'Aventura',
];

export const AuthorStudioView: React.FC<AuthorStudioViewProps> = ({
  onOpenAuth,
  onPreviewBook,
  onNavigateTab,
}) => {
  const { currentUser, userProfile, updateUserProfileData } = useAuth();
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);

  // Selected book for editing / managing chapters
  const [activeBook, setActiveBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [betaApplications, setBetaApplications] = useState<BetaApplication[]>([]);

  // Modals
  const [showBookModal, setShowBookModal] = useState(false);
  const [editingBookId, setEditingBookId] = useState<string | null>(null);
  const [showChapterModal, setShowChapterModal] = useState(false);
  const [editingChapterId, setEditingChapterId] = useState<string | null>(null);
  const [bookToDelete, setBookToDelete] = useState<Book | null>(null);
  const [isDeletingBook, setIsDeletingBook] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState('');

  // Book form state
  const [bookTitle, setBookTitle] = useState('');
  const [bookSynopsis, setBookSynopsis] = useState('');
  const [bookGenres, setBookGenres] = useState<string[]>(['Cordel']);
  const [bookClassification, setBookClassification] = useState<ContentRating>('Livre');
  const [bookStatus, setBookStatus] = useState<BookStatus>('published');
  const [isBeta, setIsBeta] = useState(false);
  const [betaSpots, setBetaSpots] = useState(5);
  const [betaDeadline, setBetaDeadline] = useState('');
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [coverPreviewUrl, setCoverPreviewUrl] = useState('');
  const [savingBook, setSavingBook] = useState(false);
  const [bookSaveError, setBookSaveError] = useState('');

  // Chapter form state
  const [chapNumber, setChapNumber] = useState(1);
  const [chapTitle, setChapTitle] = useState('');
  const [chapContent, setChapContent] = useState('');
  const [chapStatus, setChapStatus] = useState<PublishStatus>('published');
  const [isChapEarlyAccess, setIsChapEarlyAccess] = useState(false);
  const [savingChapter, setSavingChapter] = useState(false);

  // Boost state
  const [boostingBook, setBoostingBook] = useState(false);
  const [boostFeedback, setBoostFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  // 1. Fetch author's books
  useEffect(() => {
    if (!currentUser) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'books'),
      where('authorId', '==', currentUser.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(
      q,
      (snap) => {
        const list: Book[] = [];
        snap.forEach((d) => list.push(d.data() as Book));
        setBooks(list);
        setLoading(false);
      },
      (err) => {
        console.error('Error loading author books:', err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  // 2. Fetch chapters & beta applications for active book
  useEffect(() => {
    if (!activeBook) {
      setChapters([]);
      setBetaApplications([]);
      return;
    }

    // Chapters
    const chQuery = query(
      collection(db, 'books', activeBook.id, 'chapters'),
      orderBy('chapterNumber', 'asc')
    );
    const unsubCh = onSnapshot(chQuery, (snap) => {
      const list: Chapter[] = [];
      snap.forEach((d) => list.push(d.data() as Chapter));
      setChapters(list);
    });

    // Beta applications (scoped by authorId to satisfy security rules)
    const betaQuery =
      currentUser && activeBook.authorId === currentUser.uid
        ? query(
            collection(db, 'betaApplications'),
            where('authorId', '==', currentUser.uid)
          )
        : query(
            collection(db, 'betaApplications'),
            where('bookId', '==', activeBook.id)
          );
    const unsubBeta = onSnapshot(
      betaQuery,
      (snap) => {
        const list: BetaApplication[] = [];
        snap.forEach((d) => {
          const data = d.data() as BetaApplication;
          if (data.bookId === activeBook.id) {
            list.push({ ...data, id: data.id || d.id });
          }
        });
        setBetaApplications(list);
      },
      (err) => {
        console.warn('Error listening to beta applications:', err);
      }
    );

    return () => {
      unsubCh();
      unsubBeta();
    };
  }, [activeBook, currentUser?.uid]);

  // Open book modal for create or edit
  const handleOpenBookModal = (bookToEdit?: Book) => {
    setBookSaveError('');
    if (bookToEdit) {
      setEditingBookId(bookToEdit.id);
      setBookTitle(bookToEdit.title);
      setBookSynopsis(bookToEdit.synopsis);
      setBookGenres(bookToEdit.genres || ['Cordel']);
      setBookClassification(bookToEdit.classification);
      setBookStatus(bookToEdit.status);
      setIsBeta(Boolean(bookToEdit.isBeta));
      setBetaSpots(bookToEdit.betaSpots || 5);
      setBetaDeadline(bookToEdit.betaDeadline || '');
      setCoverPreviewUrl(bookToEdit.coverUrl || '');
    } else {
      setEditingBookId(null);
      setBookTitle('');
      setBookSynopsis('');
      setBookGenres(['Cordel']);
      setBookClassification('Livre');
      setBookStatus('published');
      setIsBeta(false);
      setBetaSpots(5);
      setBetaDeadline('');
      setCoverPreviewUrl('');
    }
    setCoverFile(null);
    setShowBookModal(true);
  };

  const handleSaveBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!bookTitle.trim()) return;

    setSavingBook(true);
    setBookSaveError('');
    try {
      const bookId = editingBookId || `book_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      let coverUrl = coverPreviewUrl || '';

      // Handle real Firebase Storage upload if new file provided
      if (coverFile) {
        coverUrl = await uploadFileToStorage(coverFile, 'covers', bookId);
      }

      const bookData: Book = {
        id: bookId,
        title: bookTitle.trim(),
        synopsis: bookSynopsis.trim(),
        coverUrl: coverUrl || '',
        authorId: currentUser.uid,
        authorName: userProfile?.displayName || 'Escritor Independente',
        authorPhoto: userProfile?.photoURL || '',
        genres: bookGenres,
        classification: bookClassification,
        status: bookStatus,
        chaptersCount: activeBook?.chaptersCount || 0,
        viewsCount: activeBook?.viewsCount || 0,
        readersCount: activeBook?.readersCount || 0,
        likesCount: activeBook?.likesCount || 0,
        ratingSum: activeBook?.ratingSum || 0,
        ratingCount: activeBook?.ratingCount || 0,
        isBeta: Boolean(isBeta),
        betaSpots: isBeta ? (Number(betaSpots) || 5) : 0,
        betaAcceptedCount: activeBook?.betaAcceptedCount || 0,
        betaDeadline: (isBeta && betaDeadline) ? betaDeadline : '',
        createdAt: activeBook?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const payload = sanitizeFirestoreData(bookData);
      await setDoc(doc(db, 'books', bookId), payload, { merge: true });

      // If new book, award XP and check achievement, auto-classify user as escritor
      if (!editingBookId) {
        if (userProfile?.role === 'leitor') {
          await updateUserProfileData({ role: 'escritor' });
        }

        await awardXp(
          currentUser.uid,
          300,
          `publish_book_${bookId}`,
          `Publicação do livro: "${bookData.title}"`
        );
        await checkAndUnlockAchievement(currentUser.uid, 'first_published_book');
      }

      setShowBookModal(false);
      setActiveBook(bookData);
    } catch (err: any) {
      console.error('Error saving book:', err);
      setBookSaveError(err.message || 'Erro ao salvar obra.');
    } finally {
      setSavingBook(false);
    }
  };

  // Open chapter modal
  const handleOpenChapterModal = (chap?: Chapter) => {
    if (chap) {
      setEditingChapterId(chap.id);
      setChapNumber(chap.chapterNumber);
      setChapTitle(chap.title);
      setChapContent(chap.content);
      setChapStatus(chap.status || 'published');
      setIsChapEarlyAccess(Boolean(chap.isEarlyAccess));
    } else {
      setEditingChapterId(null);
      setChapNumber((chapters.length || 0) + 1);
      setChapTitle('');
      setChapContent('');
      setChapStatus('published');
      setIsChapEarlyAccess(false);
    }
    setShowChapterModal(true);
  };

  const handleSaveChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !activeBook) return;
    if (!chapTitle.trim() || !chapContent.trim()) return;

    setSavingChapter(true);
    try {
      const chapId = editingChapterId || `chap_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const wordsCount = chapContent.trim().split(/\s+/).length;

      const chapData: Chapter = {
        id: chapId,
        bookId: activeBook.id,
        authorId: currentUser.uid,
        chapterNumber: chapNumber,
        title: chapTitle.trim(),
        content: chapContent,
        status: chapStatus,
        isEarlyAccess: Boolean(isChapEarlyAccess),
        commentsCount: 0,
        wordsCount,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const payload = sanitizeFirestoreData(chapData);
      await setDoc(doc(db, 'books', activeBook.id, 'chapters', chapId), payload, { merge: true });

      // Update book's chapter count
      const newCount = editingChapterId ? chapters.length : chapters.length + 1;
      await updateDoc(doc(db, 'books', activeBook.id), {
        chaptersCount: newCount,
        updatedAt: new Date().toISOString(),
      });

      // Award author XP for writing chapter
      if (!editingChapterId) {
        await awardXp(
          currentUser.uid,
          50,
          `publish_chap_${chapId}`,
          `Publicação de capítulo: "${chapData.title}"`
        );
        if (newCount >= 5) {
          await checkAndUnlockAchievement(currentUser.uid, 'author_five_chapters');
        }
      }

      setShowChapterModal(false);
    } catch (err) {
      console.error('Error saving chapter:', err);
    } finally {
      setSavingChapter(false);
    }
  };

  // Beta Candidate status change
  const handleUpdateBetaStatus = async (app: BetaApplication, newStatus: 'approved' | 'rejected') => {
    if (!activeBook) return;
    try {
      await updateDoc(doc(db, 'betaApplications', app.id), {
        status: newStatus,
        updatedAt: new Date().toISOString(),
      });

      // If approved, increment book's accepted count
      if (newStatus === 'approved') {
        await updateDoc(doc(db, 'books', activeBook.id), {
          betaAcceptedCount: (activeBook.betaAcceptedCount || 0) + 1,
        });

        // Notify the accepted reader
        await sendNotification(
          app.readerId,
          'beta_event',
          `Candidatura Aprovada em "${activeBook.title}"!`,
          `O autor aprovou sua participação como Leitor Beta! Seu acesso à obra já está liberado.`,
          `/livro/${activeBook.id}`
        );
      }
    } catch (err) {
      console.error('Error updating beta status:', err);
    }
  };

  // Toggle book completed status (qualifies author for KARDEL Escritor plan)
  const handleToggleBookCompleted = async (book: Book, newStatus: 'completed' | 'published') => {
    try {
      await updateDoc(doc(db, 'books', book.id), {
        status: newStatus,
        updatedAt: new Date().toISOString(),
      });
      setActiveBook((prev) => (prev && prev.id === book.id ? { ...prev, status: newStatus } : prev));
      setBooks((prev) =>
        prev.map((b) => (b.id === book.id ? { ...b, status: newStatus } : b))
      );
    } catch (err) {
      console.error('Error updating book status:', err);
    }
  };

  // Boost active book for 7 days (Assinatura Escritor)
  const handleBoostActiveBook = async () => {
    if (!activeBook || !userProfile) return;
    setBoostFeedback(null);
    const isEscritor = isSubscriptionActive(userProfile, 'escritor');
    if (!isEscritor) {
      setBoostFeedback({
        type: 'error',
        msg: 'O impulsionamento (2 por mês, 7 dias cada) é exclusivo para assinantes da Assinatura Escritor ativa (R$ 13,49/mês).',
      });
      return;
    }

    setBoostingBook(true);
    try {
      const res = await activateBookBoost(userProfile, activeBook.id);
      setActiveBook((prev) =>
        prev && prev.id === activeBook.id
          ? { ...prev, isBoosted: true, boostExpiresAt: res.boost.expiresAt }
          : prev
      );
      setBooks((prev) =>
        prev.map((b) =>
          b.id === activeBook.id ? { ...b, isBoosted: true, boostExpiresAt: res.boost.expiresAt } : b
        )
      );
      setBoostFeedback({ type: 'success', msg: res.message });
    } catch (err: any) {
      setBoostFeedback({ type: 'error', msg: err.message || 'Erro ao impulsionar obra.' });
    } finally {
      setBoostingBook(false);
    }
  };

  // Confirm delete book (Author self-deletion)
  const handleConfirmDeleteBook = async () => {
    if (!bookToDelete || !currentUser) return;
    setIsDeletingBook(true);
    try {
      const bookId = bookToDelete.id;

      // 1. Delete all chapters under the book
      try {
        const chaptersSnap = await getDocs(collection(db, 'books', bookId, 'chapters'));
        for (const chDoc of chaptersSnap.docs) {
          await deleteDoc(chDoc.ref);
        }
      } catch (chErr) {
        console.warn('Warning cleaning book chapters:', chErr);
      }

      // 2. Delete all reviews under the book
      try {
        const reviewsSnap = await getDocs(collection(db, 'books', bookId, 'reviews'));
        for (const revDoc of reviewsSnap.docs) {
          await deleteDoc(revDoc.ref);
        }
      } catch (revErr) {
        console.warn('Warning cleaning book reviews:', revErr);
      }

      // 3. Delete the book document
      await deleteDoc(doc(db, 'books', bookId));

      // 4. Update UI state
      if (activeBook?.id === bookId) {
        setActiveBook(null);
        setChapters([]);
      }
      setBooks((prev) => prev.filter((b) => b.id !== bookId));
      if (showBookModal && editingBookId === bookId) {
        setShowBookModal(false);
      }

      setFeedbackMessage(`A obra "${bookToDelete.title}" foi excluída com sucesso.`);
      setTimeout(() => setFeedbackMessage(''), 5000);
      setBookToDelete(null);
    } catch (err: any) {
      console.error('Error deleting book:', err);
      setFeedbackMessage('Erro ao excluir obra: ' + (err.message || 'Falha ao processar exclusão.'));
      setTimeout(() => setFeedbackMessage(''), 5000);
    } finally {
      setIsDeletingBook(false);
    }
  };

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <Feather className="mx-auto h-12 w-12 text-[#FF57B2] mb-3" />
        <h2 className="text-xl font-black text-white font-display">Estúdio do Autor</h2>
        <p className="text-xs text-zinc-300 mt-1 mb-6">
          Publique seus próprios livros e cordéis, gerencie capítulos, crie vagas de Leitor Beta e acompanhe seus leitores.
        </p>
        <button
          onClick={onOpenAuth}
          className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-6 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
        >
          Entrar como Escritor
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8 space-y-8 text-white">
      {/* Feedback banner */}
      {feedbackMessage && (
        <div className="flex items-center gap-3 rounded-2xl bg-[#262626] p-4 border border-[#FF57B2]/50 text-white text-xs font-bold animate-in fade-in">
          <CheckCircle className="h-5 w-5 shrink-0 text-[#FF57B2]" />
          <span>{feedbackMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-[#FF57B2] text-xs font-bold uppercase tracking-wider mb-1">
            <Feather className="h-4 w-4" />
            <span>Painel Literário</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-display">
            Estúdio do Autor
          </h1>
          <p className="text-xs sm:text-sm text-zinc-300 mt-1">
            Crie, edite, publique capítulos e gerencie candidaturas de Leitores Beta de suas obras.
          </p>
        </div>

        <button
          onClick={() => handleOpenBookModal()}
          className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>Criar Nova Obra</span>
        </button>
      </div>

      {/* Main layout: Books sidebar + Active Book workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Author's Book List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white font-display">
              Minhas Obras ({books.length})
            </h3>
          </div>

          {loading ? (
            <div className="py-12 text-center text-xs text-zinc-400">Carregando suas obras...</div>
          ) : books.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-[#FF57B2]/40 p-8 text-center bg-[#202020]">
              <BookOpen className="mx-auto h-8 w-8 text-[#FF57B2] mb-2" />
              <p className="text-xs font-bold text-zinc-200">Nenhuma obra criada</p>
              <p className="text-[11px] text-zinc-400 mt-1">
                Comece seu legado literário criando seu primeiro cordel ou livro autoral.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {books.map((b) => (
                <div
                  key={b.id}
                  onClick={() => setActiveBook(b)}
                  className={`flex items-center gap-3 rounded-2xl p-3 cursor-pointer transition border ${
                    activeBook?.id === b.id
                      ? 'border-[#FF57B2] bg-[#262626] shadow-xs'
                      : 'border-zinc-800 bg-[#202020] hover:border-[#FF57B2]/60'
                  }`}
                >
                  <div className="h-16 w-11 shrink-0 overflow-hidden rounded-lg bg-[#181818] border border-zinc-800 shadow-2xs">
                    {b.coverUrl ? (
                      <img src={b.coverUrl} alt={b.title} className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-[#262626] text-[#FF57B2] font-bold text-xs">
                        {b.title.charAt(0)}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-xs sm:text-sm text-white truncate font-literary">
                      {b.title}
                    </h4>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-zinc-400">
                      <span
                        className={`capitalize font-bold px-1.5 py-0.5 rounded text-[10px] border ${
                          b.status === 'completed'
                            ? 'bg-[#FF57B2]/20 text-[#FF80C5] border-[#FF57B2]/40'
                            : b.status === 'published'
                            ? 'bg-[#262626] text-[#FF57B2] border-zinc-700'
                            : 'bg-[#181818] text-zinc-400 border-zinc-800'
                        }`}
                      >
                        {b.status === 'completed' ? '✓ Concluída' : b.status === 'published' ? 'Em Andamento' : b.status}
                      </span>
                      <span>•</span>
                      <span>{b.chaptersCount || 0} capítulos</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setBookToDelete(b);
                    }}
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-[#FF80C5] hover:bg-[#2B2B2B] transition cursor-pointer"
                    title={`Excluir "${b.title}"`}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Active Book Chapters & Beta Management */}
        <div className="lg:col-span-2 space-y-6">
          {activeBook ? (
            <div className="space-y-6">
              {/* Active Book Header */}
              <div className="rounded-3xl bg-[#202020] p-6 shadow-xs border border-zinc-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase border ${
                        activeBook.status === 'completed'
                          ? 'bg-[#FF57B2]/20 text-[#FF80C5] border-[#FF57B2]/40'
                          : activeBook.status === 'published'
                          ? 'bg-[#FF57B2]/15 text-[#FF57B2] border-[#FF57B2]/30'
                          : 'bg-[#181818] text-zinc-400 border-zinc-800'
                      }`}
                    >
                      {activeBook.status === 'completed'
                        ? '✓ Obra Concluída'
                        : activeBook.status === 'published'
                        ? 'Em Andamento'
                        : activeBook.status}
                    </span>
                    {activeBook.isBeta && (
                      <span className="rounded-md bg-[#262626] text-[#FF80C5] border border-[#FF57B2]/40 px-2 py-0.5 text-[10px] font-bold">
                        ★ Leitura Beta Ativa
                      </span>
                    )}
                  </div>
                  <h2 className="text-xl font-black text-white font-display">
                    {activeBook.title}
                  </h2>
                  <p className="text-xs text-zinc-400 mt-1 tabular-nums">
                    {activeBook.viewsCount || 0} visualizações • {activeBook.readersCount || 0} leitores • {activeBook.likesCount || 0} curtidas
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Quick Toggle Completed / In Progress */}
                  {activeBook.status === 'completed' ? (
                    <button
                      type="button"
                      onClick={() => handleToggleBookCompleted(activeBook, 'published')}
                      className="flex items-center gap-1.5 rounded-xl border border-[#FF57B2]/50 bg-[#262626] text-[#FF80C5] px-3.5 py-2 text-xs font-bold hover:bg-[#2B2B2B] transition cursor-pointer"
                      title="Obra concluída. Clique para retornar para 'Em Andamento' se desejar."
                    >
                      <CheckCircle2 className="h-4 w-4 text-[#FF57B2]" />
                      <span>Concluída ✓</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleToggleBookCompleted(activeBook, 'completed')}
                      className="flex items-center gap-1.5 rounded-xl border border-[#FF57B2]/50 bg-[#262626] hover:bg-[#2B2B2B] text-[#FF80C5] px-3.5 py-2 text-xs font-bold transition cursor-pointer shadow-xs"
                      title="Marcar esta obra como Concluída (cumpre o requisito para o plano KARDEL Escritor)"
                    >
                      <BookCheck className="h-4 w-4 text-[#FF57B2]" />
                      <span>Concluir Obra</span>
                    </button>
                  )}

                  <button
                    onClick={() => onPreviewBook(activeBook.id)}
                    className="rounded-xl border border-zinc-700 bg-[#262626] px-3.5 py-2 text-xs font-bold text-zinc-200 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                  >
                    Ver na Plataforma
                  </button>
                  <button
                    onClick={() => handleOpenBookModal(activeBook)}
                    className="rounded-xl border border-zinc-700 bg-[#181818] px-3.5 py-2 text-xs font-bold text-white hover:border-[#FF57B2]/60 transition cursor-pointer"
                  >
                    Editar Obra
                  </button>
                  <button
                    onClick={() => setBookToDelete(activeBook)}
                    className="flex items-center gap-1.5 rounded-xl border border-zinc-700 bg-[#1A1A1A] px-3 py-2 text-xs font-bold text-zinc-300 hover:border-[#FF57B2]/60 hover:text-[#FF80C5] transition cursor-pointer"
                    title="Excluir Obra"
                  >
                    <Trash2 className="h-4 w-4" />
                    <span className="hidden sm:inline">Excluir Obra</span>
                  </button>
                </div>
              </div>

              {/* Chapters Management */}
              <div className="rounded-3xl bg-[#202020] p-6 shadow-xs border border-zinc-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-base text-white font-display">
                      Capítulos da Obra ({chapters.length})
                    </h3>
                    <p className="text-xs text-zinc-400">
                      Organize e publique os episódios do seu cordel.
                    </p>
                  </div>

                  <button
                    onClick={() => handleOpenChapterModal()}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Adicionar Capítulo</span>
                  </button>
                </div>

                {chapters.length === 0 ? (
                  <div className="py-8 text-center text-xs text-zinc-400">
                    Nenhum capítulo cadastrado nesta obra.
                  </div>
                ) : (
                  <div className="divide-y divide-zinc-800">
                    {chapters.map((chap) => (
                      <div
                        key={chap.id}
                        className="flex items-center justify-between py-3 px-2 hover:bg-[#262626] rounded-xl transition"
                      >
                        <div className="flex items-center gap-3">
                          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#262626] border border-zinc-700 font-bold text-xs text-[#FF57B2] tabular-nums">
                            {chap.chapterNumber}
                          </span>
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h4 className="font-semibold text-xs sm:text-sm text-white font-literary">
                                {chap.title}
                              </h4>
                              {chap.isEarlyAccess && (
                                <span className="rounded-md bg-[#262626] text-[#FF80C5] border border-[#FF57B2]/40 px-1.5 py-0.5 text-[9px] font-bold inline-flex items-center gap-0.5">
                                  <Zap className="h-2.5 w-2.5 text-[#FF57B2]" />
                                  Acesso Antecipado (Leitor)
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-zinc-400 tabular-nums">
                              {chap.wordsCount || 0} palavras • {chap.status}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleOpenChapterModal(chap)}
                            className="rounded-lg border border-zinc-700 bg-[#262626] px-2.5 py-1 text-xs font-semibold text-zinc-200 hover:border-[#FF57B2]/60 hover:text-white transition cursor-pointer"
                          >
                            Editar
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Beta Reader Applications Management (if beta enabled) */}
              {activeBook.isBeta && (
                <div className="rounded-3xl bg-[#202020] p-6 shadow-xs border border-zinc-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-base text-white font-display">
                        Candidaturas de Leitor Beta ({betaApplications.length})
                      </h3>
                      <p className="text-xs text-zinc-400">
                        Selecione leitores elegíveis para revisar suas obras em primeira mão.
                      </p>
                    </div>
                  </div>

                  {betaApplications.length === 0 ? (
                    <div className="py-6 text-center text-xs text-zinc-400">
                      Nenhuma candidatura recebida até o momento.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {betaApplications.map((app) => (
                        <div
                          key={app.id}
                          className="rounded-2xl border border-zinc-800 p-4 space-y-2 bg-[#262626]"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-white">{app.readerName}</span>
                              <span className="rounded-md bg-[#181818] border border-zinc-700 px-1.5 py-0.5 text-[9px] font-semibold text-zinc-300">
                                Nível {app.readerLevel}
                              </span>
                              {app.hasExperiencedBadge && (
                                <span className="rounded-md bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40 px-1.5 py-0.5 text-[9px] font-bold">
                                  ★ Leitor Experiente
                                </span>
                              )}
                            </div>
                            <span className="rounded-md px-2 py-0.5 text-[10px] font-bold uppercase bg-[#181818] border border-zinc-700 text-[#FF57B2]">
                              {app.status}
                            </span>
                          </div>

                          <p className="text-xs text-zinc-300 font-literary italic">
                            "{app.motivation}"
                          </p>

                          {app.status === 'applied' && (
                            <div className="flex justify-end gap-2 pt-2 border-t border-zinc-800">
                              <button
                                onClick={() => handleUpdateBetaStatus(app, 'rejected')}
                                className="rounded-xl border border-zinc-700 bg-[#1A1A1A] px-3 py-1 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                              >
                                Recusar
                              </button>
                              <button
                                onClick={() => handleUpdateBetaStatus(app, 'approved')}
                                className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-3 py-1 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
                              >
                                Aprovar Leitor Beta
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-12 text-center text-zinc-400">
              <BookOpen className="mx-auto h-12 w-12 text-zinc-600 mb-2" />
              <p className="text-xs">Selecione uma obra ao lado para gerenciar capítulos ou crie uma nova.</p>
            </div>
          )}
        </div>
      </div>

      {/* Book Create / Edit Modal */}
      {showBookModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-lg rounded-3xl bg-[#202020] border border-zinc-800 p-6 shadow-2xl my-8 text-white">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-lg text-white font-display">
                {editingBookId ? 'Editar Obra Literária' : 'Nova Obra Literária'}
              </h3>
              <button
                onClick={() => setShowBookModal(false)}
                className="rounded-xl p-1 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBook} className="mt-4 space-y-4 text-xs">
              {!editingBookId && (
                <div className="flex items-center justify-between rounded-2xl border border-[#FF57B2]/40 bg-[#262626] p-3.5">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white font-black text-xs shadow-xs">
                      <Sparkles className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-bold text-white text-xs">
                        Publicação 100% Gratuita na KARDEL
                      </p>
                      <p className="text-[11px] text-zinc-300">
                        Ao publicar sua primeira obra, você é classificado automaticamente como <strong>Escritor</strong>!
                      </p>
                    </div>
                  </div>
                  <span className="rounded-full bg-[#FF57B2]/20 border border-[#FF57B2]/40 px-2.5 py-0.5 text-[10px] font-bold text-[#FF80C5]">
                    Gratuito
                  </span>
                </div>
              )}

              {bookSaveError && (
                <div className="rounded-xl bg-[#262626] p-3 border border-[#FF57B2]/50 text-[#FF80C5] flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 shrink-0 text-[#FF57B2]" />
                  <p>{bookSaveError}</p>
                </div>
              )}

              {/* Title */}
              <div>
                <label className="block font-semibold text-zinc-200 mb-1">Título da Obra</label>
                <input
                  type="text"
                  required
                  value={bookTitle}
                  onChange={(e) => setBookTitle(e.target.value)}
                  placeholder="Ex: O Romance do Pavão Misterioso"
                  className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none"
                />
              </div>

              {/* Cover Upload */}
              <div>
                <label className="block font-semibold text-zinc-200 mb-1">
                  Capa do Livro (Upload Real para Firebase Storage)
                </label>
                <div className="flex items-center gap-4">
                  {coverPreviewUrl ? (
                    <div className="relative group">
                      <img
                        src={coverPreviewUrl}
                        alt="Preview da capa"
                        className="h-24 w-16 rounded-xl object-cover border border-zinc-700 shadow-xs"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setCoverFile(null);
                          setCoverPreviewUrl('');
                        }}
                        className="absolute -top-1.5 -right-1.5 bg-[#FF57B2] text-white rounded-full p-1 hover:bg-[#FF40A4] shadow cursor-pointer"
                        title="Remover capa"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ) : null}
                  <label className="flex items-center gap-2 rounded-xl border border-dashed border-[#FF57B2]/60 px-4 py-2.5 hover:border-[#FF57B2] bg-[#181818] cursor-pointer transition">
                    <span className="text-xs font-semibold text-zinc-200">
                      {coverPreviewUrl ? 'Trocar Capa (JPG, PNG, WEBP)' : 'Selecionar Capa (JPG, PNG, WEBP)'}
                    </span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setCoverFile(file);
                          setCoverPreviewUrl(URL.createObjectURL(file));
                        }
                      }}
                    />
                  </label>
                </div>
              </div>

              {/* Synopsis */}
              <div>
                <label className="block font-semibold text-zinc-200 mb-1">Sinopse / Descrição</label>
                <textarea
                  required
                  rows={4}
                  value={bookSynopsis}
                  onChange={(e) => setBookSynopsis(e.target.value)}
                  placeholder="Apresente a essência da sua história aos leitores..."
                  className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none"
                />
              </div>

              {/* Genres */}
              <div>
                <label className="block font-semibold text-zinc-200 mb-1">Gêneros / Temas</label>
                <div className="flex flex-wrap gap-1.5">
                  {AVAILABLE_GENRES.map((g) => {
                    const isSelected = bookGenres.includes(g);
                    return (
                      <button
                        key={g}
                        type="button"
                        onClick={() => {
                          if (isSelected) {
                            setBookGenres(bookGenres.filter((item) => item !== g));
                          } else {
                            setBookGenres([...bookGenres, g]);
                          }
                        }}
                        className={`rounded-xl px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                          isSelected
                            ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs'
                            : 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:border-[#FF57B2]/50 hover:text-white'
                        }`}
                      >
                        {g}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Classification & Status */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-zinc-200 mb-1">Classificação Indicativa</label>
                  <select
                    value={bookClassification}
                    onChange={(e) => setBookClassification(e.target.value as ContentRating)}
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2 text-xs text-white focus:border-[#FF57B2] focus:outline-none [color-scheme:dark]"
                  >
                    <option value="Livre">Livre para todos os públicos</option>
                    <option value="12+">12+</option>
                    <option value="14+">14+</option>
                    <option value="16+">16+</option>
                    <option value="18+">18+</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-zinc-200 mb-1">Status da Obra</label>
                  <select
                    value={bookStatus}
                    onChange={(e) => setBookStatus(e.target.value as PublishStatus)}
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2 text-xs text-white focus:border-[#FF57B2] focus:outline-none [color-scheme:dark]"
                  >
                    <option value="published">Em Andamento (Publicado)</option>
                    <option value="completed">Concluída (Finalizada)</option>
                    <option value="draft">Rascunho Privado</option>
                    <option value="archived">Arquivado</option>
                  </select>
                </div>
              </div>

              {/* Beta Reader Configuration */}
              <div className="rounded-2xl border border-[#FF57B2]/40 bg-[#262626] p-3 space-y-3">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-[#FF80C5]">
                  <input
                    type="checkbox"
                    checked={isBeta}
                    onChange={(e) => setIsBeta(e.target.checked)}
                    className="rounded accent-[#FF57B2]"
                  />
                  <span>Disponibilizar para Leitura Beta (Obra em Teste)</span>
                </label>

                {isBeta && (
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="block font-semibold text-zinc-200 mb-1">Número de Vagas</label>
                      <input
                        type="number"
                        min={1}
                        max={50}
                        value={betaSpots}
                        onChange={(e) => setBetaSpots(Number(e.target.value))}
                        className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2 text-xs font-bold text-white tabular-nums focus:border-[#FF57B2] focus:outline-none [color-scheme:dark]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-zinc-200 mb-1">Prazo de Candidatura</label>
                      <input
                        type="date"
                        value={betaDeadline}
                        onChange={(e) => setBetaDeadline(e.target.value)}
                        className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2 text-xs text-white focus:border-[#FF57B2] focus:outline-none [color-scheme:dark]"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-zinc-800">
                {editingBookId ? (
                  <button
                    type="button"
                    onClick={() => {
                      const target = books.find((b) => b.id === editingBookId) || activeBook;
                      if (target) {
                        setShowBookModal(false);
                        setBookToDelete(target);
                      }
                    }}
                    className="flex items-center gap-1.5 text-xs font-bold text-zinc-400 hover:text-[#FF80C5] transition cursor-pointer self-start sm:self-auto"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Excluir esta obra definitivamente</span>
                  </button>
                ) : (
                  <div />
                )}
                <div className="flex justify-end gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => setShowBookModal(false)}
                    className="rounded-xl px-4 py-2 font-semibold text-zinc-300 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={savingBook}
                    className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2 font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer"
                  >
                    {savingBook ? 'Salvando...' : 'Salvar Obra'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Chapter Create / Edit Modal */}
      {showChapterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-2xl rounded-3xl bg-[#202020] border border-zinc-800 p-6 shadow-2xl my-8 text-white">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-lg text-white font-display">
                {editingChapterId ? 'Editar Capítulo' : 'Novo Capítulo'}
              </h3>
              <button
                onClick={() => setShowChapterModal(false)}
                className="rounded-xl p-1 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveChapter} className="mt-4 space-y-4 text-xs">
              <div className="grid grid-cols-4 gap-3">
                <div>
                  <label className="block font-semibold text-zinc-200 mb-1">Número</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={chapNumber}
                    onChange={(e) => setChapNumber(Number(e.target.value))}
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs font-bold text-white tabular-nums placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none [color-scheme:dark]"
                  />
                </div>
                <div className="col-span-3">
                  <label className="block font-semibold text-zinc-200 mb-1">Título do Capítulo</label>
                  <input
                    type="text"
                    required
                    value={chapTitle}
                    onChange={(e) => setChapTitle(e.target.value)}
                    placeholder="Ex: No Meio do Sertão Brabo"
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-zinc-200 mb-1">
                  Conteúdo do Capítulo (Versos, Prosa ou Poesia de Cordel)
                </label>
                <textarea
                  required
                  rows={12}
                  value={chapContent}
                  onChange={(e) => setChapContent(e.target.value)}
                  placeholder="Escreva sua obra aqui..."
                  className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-3 text-xs text-white placeholder-zinc-500 font-literary leading-relaxed focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none"
                />
              </div>

              {/* Early Access Chapter Toggle */}
              <label className="flex items-start gap-2.5 p-3 rounded-2xl bg-[#262626] border border-[#FF57B2]/40 cursor-pointer hover:border-[#FF57B2] transition">
                <input
                  type="checkbox"
                  checked={isChapEarlyAccess}
                  onChange={(e) => setIsChapEarlyAccess(e.target.checked)}
                  className="mt-0.5 rounded accent-[#FF57B2]"
                />
                <div className="space-y-0.5 text-xs">
                  <span className="font-bold text-[#FF80C5] flex items-center gap-1.5">
                    <Zap className="h-3.5 w-3.5 text-[#FF57B2]" />
                    Disponibilizar em Acesso Antecipado
                  </span>
                  <p className="text-[11px] text-zinc-300 leading-relaxed">
                    Este capítulo ficará disponível antecipadamente de forma exclusiva para leitores com a Assinatura Leitor ativa (R$ 4,90/mês).
                  </p>
                </div>
              </label>

              <div className="flex justify-end gap-2 pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setShowChapterModal(false)}
                  className="rounded-xl px-4 py-2 font-semibold text-zinc-300 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={savingChapter}
                  className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2 font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer"
                >
                  {savingChapter ? 'Salvando...' : 'Publicar Capítulo (+50 XP)'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirm Book Deletion Modal */}
      <ConfirmModal
        isOpen={Boolean(bookToDelete)}
        onClose={() => {
          if (!isDeletingBook) setBookToDelete(null);
        }}
        onConfirm={handleConfirmDeleteBook}
        title={`Excluir "${bookToDelete?.title}"?`}
        message={`Tem certeza de que deseja apagar esta obra permanentemente? Todos os capítulos, estatísticas e leituras serão removidos de forma irreversível.`}
        confirmText="Excluir Obra"
        cancelText="Cancelar"
        variant="danger"
        isLoading={isDeletingBook}
      />
    </div>
  );
};
