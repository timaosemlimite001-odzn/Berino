import { collection, deleteDoc, doc, getDocs, orderBy, query } from 'firebase/firestore';
import {
  ArrowUpRight,
  Bookmark,
  BookMarked,
  BookOpen,
  Film,
  Heart,
  MessageCircle,
  Trash2,
  Users,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { FluxCommentsModal } from '../components/FluxCommentsModal';
import { UserAvatar } from '../components/UserAvatar';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db } from '../services/firebase';
import {
  extractPostMediaItems,
  fetchUserSavedPosts,
  formatRelativeTimePt,
  removeUserSavedPostByFavId,
  toggleFluxPostLike,
} from '../services/fluxService';
import {
  FluxFeedItem,
  LibraryItem,
  LibraryStatus,
  SavedPostResolvedItem,
} from '../types';

interface LibraryViewProps {
  onSelectBook: (bookId: string) => void;
  onReadBook: (bookId: string, chapterNumber?: number) => void;
  onExplore: () => void;
  onOpenAuth: () => void;
  onOpenCommunity?: (communityId: string) => void;
  onOpenFluxPost?: (postItem?: FluxFeedItem) => void;
}

type SavedSubCategory = 'all_saved' | 'books' | 'posts';

export const LibraryView: React.FC<LibraryViewProps> = ({
  onSelectBook,
  onReadBook,
  onExplore,
  onOpenAuth,
  onOpenCommunity,
  onOpenFluxPost,
}) => {
  const { currentUser } = useAuth();
  const { openUserProfile } = usePublicProfile();
  const { addToast } = useNotifications();

  const [items, setItems] = useState<LibraryItem[]>([]);
  const [savedPosts, setSavedPosts] = useState<SavedPostResolvedItem[]>([]);
  const [activeFilter, setActiveFilter] = useState<'all' | LibraryStatus>('all');
  const [savedCategory, setSavedCategory] = useState<SavedSubCategory>('all_saved');
  const [loading, setLoading] = useState(true);
  const [loadingSavedPosts, setLoadingSavedPosts] = useState(false);
  const [commentsModalPost, setCommentsModalPost] = useState<FluxFeedItem | null>(
    null
  );

  useEffect(() => {
    if (!currentUser) {
      setItems([]);
      setSavedPosts([]);
      setLoading(false);
      return;
    }

    let cancelled = false;
    const loadLibraryAndSavedPosts = async () => {
      setLoading(true);
      setLoadingSavedPosts(true);
      try {
        const q = query(
          collection(db, 'libraries', currentUser.uid, 'items'),
          orderBy('lastReadAt', 'desc')
        );
        const [snap, resolvedPosts] = await Promise.all([
          getDocs(q),
          fetchUserSavedPosts(currentUser.uid),
        ]);

        if (!cancelled) {
          const list: LibraryItem[] = [];
          snap.forEach((d) => list.push(d.data() as LibraryItem));
          setItems(list);
          setSavedPosts(resolvedPosts);
        }
      } catch (err) {
        console.error('Error loading library:', err);
      } finally {
        if (!cancelled) {
          setLoading(false);
          setLoadingSavedPosts(false);
        }
      }
    };

    loadLibraryAndSavedPosts();
    return () => {
      cancelled = true;
    };
  }, [currentUser?.uid]);

  // Refresh saved posts whenever user switches into 'saved' filter so newly saved posts appear immediately
  useEffect(() => {
    if (!currentUser || activeFilter !== 'saved') return;
    let cancelled = false;
    setLoadingSavedPosts(true);
    fetchUserSavedPosts(currentUser.uid)
      .then((resolved) => {
        if (!cancelled) setSavedPosts(resolved);
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setLoadingSavedPosts(false);
      });
    return () => {
      cancelled = true;
    };
  }, [activeFilter, currentUser?.uid]);

  const handleRemoveBook = async (bookId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) return;

    try {
      await deleteDoc(doc(db, 'libraries', currentUser.uid, 'items', bookId));
      setItems((prev) => prev.filter((i) => i.bookId !== bookId));
      addToast({
        id: `rm_lib_book_${bookId}_${Date.now()}`,
        type: 'system',
        title: 'Livro removido',
        message: 'A obra foi removida da sua biblioteca.',
      });
    } catch (err) {
      console.error('Error removing item from library:', err);
    }
  };

  const handleRemoveSavedPost = async (
    favId: string,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    if (!currentUser) return;

    const previous = savedPosts;
    setSavedPosts((prev) => prev.filter((item) => item.favId !== favId));

    try {
      await removeUserSavedPostByFavId(currentUser.uid, favId);
      addToast({
        id: `rm_saved_post_${favId}_${Date.now()}`,
        type: 'system',
        title: 'Publicação removida dos salvos',
        message: 'O item foi retirado de Publicações Salvas.',
      });
    } catch (err) {
      console.error('Error removing saved post:', err);
      setSavedPosts(previous);
    }
  };

  const handleToggleSavedPostLike = async (
    entry: SavedPostResolvedItem,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    try {
      const result = await toggleFluxPostLike(entry.post, currentUser.uid);
      setSavedPosts((prev) =>
        prev.map((s) =>
          s.favId === entry.favId
            ? {
                ...s,
                post: {
                  ...s.post,
                  likesCount: result.likesCount,
                  likedUserIds: result.likedUserIds,
                },
              }
            : s
        )
      );
    } catch (err) {
      console.error('Error liking saved post:', err);
    }
  };

  const savedBooks = items.filter((item) => item.status === 'saved');

  const filteredItems = items.filter((item) => {
    if (activeFilter === 'all') return true;
    return item.status === activeFilter;
  });

  const renderBookCard = (item: LibraryItem) => (
    <div
      key={item.bookId}
      onClick={() => onSelectBook(item.bookId)}
      className="group flex gap-4 rounded-3xl bg-[#202020] p-4 shadow-xs border border-zinc-800 hover:border-[#FF57B2]/50 hover:shadow-md transition cursor-pointer text-white"
    >
      {/* Cover */}
      <div className="h-32 w-20 shrink-0 overflow-hidden rounded-2xl bg-zinc-900 shadow-2xs border border-zinc-700/60">
        {item.bookCover ? (
          <img
            src={item.bookCover}
            alt={item.bookTitle}
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-zinc-900 p-2 text-center text-white font-literary font-bold text-xs">
            {item.bookTitle.charAt(0)}
          </div>
        )}
      </div>

      {/* Details & Progress */}
      <div className="flex-1 min-w-0 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between gap-2">
            <span className="text-[#FF57B2] text-[11px] font-bold tracking-wide">
              {item.status === 'reading' && 'Em Leitura'}
              {item.status === 'completed' && 'Concluído'}
              {item.status === 'favorite' && 'Favorito'}
              {item.status === 'saved' && 'Livro Salvo'}
            </span>

            <button
              type="button"
              onClick={(e) => handleRemoveBook(item.bookId, e)}
              className="text-zinc-400 hover:text-[#FF80C5] p-1 transition cursor-pointer"
              title="Remover da Biblioteca"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>

          <h3 className="font-bold text-white text-sm font-literary truncate mt-1 group-hover:text-[#FF57B2] transition">
            {item.bookTitle}
          </h3>
          <p className="text-xs text-zinc-400 truncate">{item.authorName}</p>
        </div>

        {/* Progress bar */}
        <div className="space-y-1.5 pt-2">
          <div className="flex items-center justify-between text-[11px] text-zinc-400 tabular-nums">
            <span>Cap. {item.currentChapterNumber || 1}</span>
            <span className="font-bold text-zinc-200">{item.progressPercent || 0}%</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-zinc-800">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#FF57B2] to-[#E03595] transition-all duration-300"
              style={{ width: `${item.progressPercent || 0}%` }}
            />
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onReadBook(item.bookId, item.currentChapterNumber || 1);
            }}
            className="mt-2 w-full rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] py-1.5 text-center text-xs font-bold text-white transition cursor-pointer"
          >
            Continuar Leitura
          </button>
        </div>
      </div>
    </div>
  );

  const renderSavedPostCard = (entry: SavedPostResolvedItem) => {
    const { post, favId } = entry;
    const mediaList = extractPostMediaItems(post);
    const primaryMedia = mediaList[0];
    const hasLiked = Boolean(
      currentUser && post.likedUserIds?.includes(currentUser.uid)
    );
    const isCommunityOrigin =
      post.postSource === 'community' && Boolean(post.communityId);

    const handleOpenOrigin = () => {
      if (isCommunityOrigin && post.communityId && onOpenCommunity) {
        onOpenCommunity(post.communityId);
      } else if (onOpenFluxPost) {
        onOpenFluxPost(post);
      }
    };

    return (
      <article
        key={favId}
        onClick={handleOpenOrigin}
        className="group flex flex-col justify-between rounded-3xl bg-[#202020] p-4 border border-zinc-800 hover:border-[#FF57B2]/50 transition cursor-pointer text-white space-y-3"
      >
        <div className="space-y-3">
          {/* Header: Author + Origin + Remove */}
          <div className="flex items-start justify-between gap-2.5">
            <div className="flex items-center gap-2.5 min-w-0">
              <UserAvatar
                userId={post.authorId}
                userName={post.authorName}
                photoURL={post.authorPhoto}
                sizeClass="h-9 w-9 shrink-0"
                onClick={() => {
                  openUserProfile(post.authorId);
                }}
                title={`Perfil de ${post.authorName}`}
              />
              <div className="min-w-0">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    openUserProfile(post.authorId);
                  }}
                  className="block max-w-full truncate text-left text-xs sm:text-sm font-bold text-white hover:text-[#FF57B2] transition cursor-pointer"
                >
                  {post.authorName || 'Leitor'}
                </button>
                <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 truncate">
                  {isCommunityOrigin ? (
                    <span className="inline-flex items-center gap-1 text-[#FF57B2] font-semibold truncate">
                      <Users className="h-3 w-3 shrink-0" />
                      <span className="truncate">
                        {post.communityName || 'Comunidade'}
                      </span>
                    </span>
                  ) : (
                    <span className="text-[#FF66C4] font-semibold">Flux</span>
                  )}
                  <span aria-hidden="true">·</span>
                  <span className="shrink-0">
                    {formatRelativeTimePt(post.createdAt)}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={(e) => handleRemoveSavedPost(favId, e)}
              className="rounded-xl p-1.5 text-[#FF57B2] hover:bg-zinc-800 hover:text-[#FF80C5] transition cursor-pointer shrink-0"
              title="Remover das publicações salvas"
              aria-label="Remover das publicações salvas"
            >
              <Bookmark className="h-4 w-4 fill-[#FF57B2]" />
            </button>
          </div>

          {/* Media Thumbnail if present */}
          {primaryMedia && (
            <div className="relative h-40 w-full overflow-hidden rounded-2xl bg-[#181818] border border-zinc-800/80 flex items-center justify-center">
              {primaryMedia.type === 'video' ? (
                <div className="relative h-full w-full flex items-center justify-center bg-black">
                  <video
                    src={primaryMedia.url}
                    preload="metadata"
                    muted
                    playsInline
                    className="h-full w-full object-cover opacity-85"
                  />
                  <div className="absolute bottom-2 right-2 flex items-center gap-1 rounded-lg bg-black/75 px-2 py-1 text-[10px] font-bold text-white">
                    <Film className="h-3 w-3 text-[#FF57B2]" />
                    <span>Vídeo</span>
                  </div>
                </div>
              ) : (
                <img
                  src={primaryMedia.url}
                  alt={`Mídia de ${post.authorName}`}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
                />
              )}
              {mediaList.length > 1 && (
                <span className="absolute top-2 right-2 rounded-lg bg-black/75 px-2 py-0.5 text-[10px] font-bold text-white tabular-nums">
                  1/{mediaList.length}
                </span>
              )}
            </div>
          )}

          {/* Post Content */}
          {post.content && (
            <p className="text-xs sm:text-[13px] text-zinc-200 leading-relaxed line-clamp-4 whitespace-pre-wrap break-words">
              {post.content}
            </p>
          )}

          {post.poll && (
            <div className="rounded-2xl bg-[#191919] border border-zinc-800 px-3 py-2 text-xs text-zinc-300">
              <strong className="text-[#FF57B2] block text-[11px]">
                Enquete:
              </strong>
              <span className="line-clamp-2">{post.poll.question}</span>
            </div>
          )}
        </div>

        {/* Footer Actions: Like, Comments, Open Origin */}
        <div className="flex items-center justify-between border-t border-zinc-800 pt-3 text-xs">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={(e) => handleToggleSavedPostLike(entry, e)}
              className={`inline-flex items-center gap-1.5 font-semibold transition cursor-pointer tabular-nums ${
                hasLiked
                  ? 'text-[#FF57B2]'
                  : 'text-zinc-400 hover:text-[#FF57B2]'
              }`}
              title="Curtir publicação"
            >
              <Heart
                className={`h-4 w-4 ${
                  hasLiked ? 'fill-[#FF57B2] text-[#FF57B2]' : ''
                }`}
              />
              <span>{post.likesCount || 0}</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setCommentsModalPost(post);
              }}
              className="inline-flex items-center gap-1.5 font-semibold text-zinc-400 hover:text-white transition cursor-pointer tabular-nums"
              title="Ver comentários"
            >
              <MessageCircle className="h-4 w-4" />
              <span>{post.commentsCount || 0}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleOpenOrigin();
            }}
            className="inline-flex items-center gap-1 font-bold text-[#FF57B2] hover:underline transition cursor-pointer whitespace-nowrap"
          >
            <span>
              {isCommunityOrigin ? 'Abrir na Comunidade' : 'Abrir no Flux'}
            </span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </article>
    );
  };

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <BookMarked className="mx-auto h-12 w-12 text-[#FF57B2] mb-3" />
        <h2 className="text-xl font-black text-white font-display">
          Minha Biblioteca
        </h2>
        <p className="text-xs text-zinc-400 mt-1 mb-6">
          Faça login para acompanhar seu progresso de leitura, livros salvos, publicações salvas e favoritos.
        </p>
        <button
          onClick={onOpenAuth}
          className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-6 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
        >
          Entrar ou Criar Conta
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-[#FF57B2] text-xs font-bold uppercase tracking-wider mb-1">
            <BookMarked className="h-4 w-4" />
            <span>Coleção Pessoal</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-display">
            Minha Biblioteca
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Acompanhe suas obras em andamento, livros concluídos, favoritos e itens salvos.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap gap-1.5 bg-[#202020] p-1 rounded-2xl border border-zinc-800">
          {[
            { id: 'all', label: 'Todos' },
            { id: 'reading', label: 'Em Leitura' },
            { id: 'completed', label: 'Concluídos' },
            { id: 'favorite', label: 'Favoritos' },
            {
              id: 'saved',
              label: `Salvos (${savedBooks.length + savedPosts.length})`,
            },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveFilter(tab.id as any)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition cursor-pointer whitespace-nowrap tabular-nums ${
                activeFilter === tab.id
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {loading ? (
        <div className="py-20 text-center text-xs text-zinc-400">
          Carregando biblioteca...
        </div>
      ) : activeFilter === 'saved' ? (
        /* =====================================================================
           SALVOS — Two Categories: 1) Livros Salvos  |  2) Publicações Salvas
           ===================================================================== */
        <div className="space-y-8">
          {/* Category Switcher inside Salvos */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-display">
                Itens Salvos
              </h2>
              <p className="text-xs text-zinc-400">
                Classificados entre livros salvos do acervo e publicações salvas das Comunidades e do Flux.
              </p>
            </div>

            <div className="inline-flex items-center gap-1 rounded-xl bg-[#1A1A1A] p-1 border border-zinc-800 self-start">
              {[
                {
                  id: 'all_saved' as SavedSubCategory,
                  label: 'Todas as Categorias',
                },
                {
                  id: 'books' as SavedSubCategory,
                  label: `Livros Salvos (${savedBooks.length})`,
                },
                {
                  id: 'posts' as SavedSubCategory,
                  label: `Publicações Salvas (${savedPosts.length})`,
                },
              ].map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSavedCategory(cat.id)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition cursor-pointer whitespace-nowrap tabular-nums ${
                    savedCategory === cat.id
                      ? 'bg-[#2B2B2B] text-[#FF57B2] font-bold border border-[#FF57B2]/40'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* CATEGORY 1: LIVROS SALVOS */}
          {(savedCategory === 'all_saved' || savedCategory === 'books') && (
            <section className="space-y-4">
              <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2.5">
                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-[#FF57B2]" />
                  <h3 className="text-sm sm:text-base font-bold text-white font-display">
                    Livros Salvos
                  </h3>
                  <span className="text-xs text-zinc-400 tabular-nums">
                    · {savedBooks.length}{' '}
                    {savedBooks.length === 1 ? 'obra' : 'obras'}
                  </span>
                </div>
              </div>

              {savedBooks.length === 0 ? (
                <div className="rounded-3xl border border-dashed border-zinc-800 bg-[#202020] p-8 text-center">
                  <BookOpen className="mx-auto h-9 w-9 text-zinc-600 mb-2" />
                  <h4 className="font-bold text-white text-sm font-display">
                    Nenhum livro salvo
                  </h4>
                  <p className="text-xs text-zinc-400 mt-1 mb-4 max-w-sm mx-auto">
                    Use o botão &ldquo;Salvar Livro&rdquo; na página de detalhes de qualquer obra para guardá-la nesta categoria.
                  </p>
                  <button
                    type="button"
                    onClick={onExplore}
                    className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
                  >
                    Explorar Livros
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {savedBooks.map((item) => renderBookCard(item))}
                </div>
              )}
            </section>
          )}

          {/* CATEGORY 2: PUBLICAÇÕES SALVAS */}
          {(savedCategory === 'all_saved' || savedCategory === 'posts') && (
            <section className="space-y-4">
              <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2.5">
                <div className="flex items-center gap-2">
                  <Bookmark className="h-4 w-4 text-[#FF57B2]" />
                  <h3 className="text-sm sm:text-base font-bold text-white font-display">
                    Publicações Salvas
                  </h3>
                  <span className="text-xs text-zinc-400 tabular-nums">
                    · {savedPosts.length}{' '}
                    {savedPosts.length === 1 ? 'publicação' : 'publicações'}
                  </span>
                </div>
              </div>

              {loadingSavedPosts ? (
                <div className="py-10 text-center text-xs text-zinc-400">
                  Carregando publicações salvas...
                </div>
              ) : savedPosts.length === 0 ? (
                <div className="rounded-3xl border border-dashed border-zinc-800 bg-[#202020] p-8 text-center">
                  <Bookmark className="mx-auto h-9 w-9 text-zinc-600 mb-2" />
                  <h4 className="font-bold text-white text-sm font-display">
                    Nenhuma publicação salva
                  </h4>
                  <p className="text-xs text-zinc-400 mt-1 mb-4 max-w-sm mx-auto">
                    Toque no ícone de salvar nas publicações das Comunidades ou do Flux para guardá-las aqui.
                  </p>
                  {onOpenFluxPost && (
                    <button
                      type="button"
                      onClick={() => onOpenFluxPost()}
                      className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
                    >
                      Explorar Área Social
                    </button>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {savedPosts.map((entry) => renderSavedPostCard(entry))}
                </div>
              )}
            </section>
          )}
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-zinc-800 bg-[#202020] p-12 text-center">
          <BookOpen className="mx-auto h-12 w-12 text-zinc-600 mb-3" />
          <h3 className="font-bold text-white text-base font-display">
            Nenhuma obra nesta lista
          </h3>
          <p className="text-xs text-zinc-400 mt-1 mb-6 max-w-sm mx-auto">
            Você ainda não possui livros nesta categoria. Explore o acervo e comece uma nova história!
          </p>
          <button
            type="button"
            onClick={onExplore}
            className="rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
          >
            Explorar Acervo Literário
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {filteredItems.map((item) => renderBookCard(item))}
        </div>
      )}

      {/* Comments Modal for Saved Publications */}
      <FluxCommentsModal
        isOpen={Boolean(commentsModalPost)}
        post={commentsModalPost}
        onClose={() => setCommentsModalPost(null)}
        onOpenAuth={onOpenAuth}
        onCommentsCountChange={(targetPost, nextCount) => {
          setSavedPosts((prev) =>
            prev.map((s) =>
              s.post.id === targetPost.id &&
              s.post.postSource === targetPost.postSource
                ? { ...s, post: { ...s.post, commentsCount: nextCount } }
                : s
            )
          );
          setCommentsModalPost((prev) =>
            prev ? { ...prev, commentsCount: nextCount } : null
          );
        }}
      />
    </div>
  );
};
