import { doc, getDoc } from 'firebase/firestore';
import {
  AlertTriangle,
  ArrowLeft,
  Bookmark,
  ChevronsDown,
  Edit2,
  Loader2,
  MessageCircle,
  MoreHorizontal,
  Plus,
  RefreshCw,
  Share2,
  ThumbsUp,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ConfirmModal } from '../components/ConfirmModal';
import { FluxCommentsModal } from '../components/FluxCommentsModal';
import { FluxStoryStage } from '../components/FluxStoryStage';
import { ReportModal } from '../components/ReportModal';
import { UserAvatar } from '../components/UserAvatar';
import { UserBadges } from '../components/UserBadges';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db } from '../services/firebase';
import {
  FluxEngine,
  clearLegacyBlockedPostFlag,
  deleteFluxPostItem,
  extractPostMediaItems,
  formatRelativeTimePt,
  getFavoriteDocId,
  getFluxItemKey,
  joinCommunityFromFlux,
  subscribeUserFavoritePostIds,
  toggleFluxPostFavorite,
  toggleFluxPostLike,
  updateFluxPostContent,
  voteFluxCommunityPoll,
} from '../services/fluxService';
import { Community, CommunityMember, FluxFeedItem } from '../types';
import { FluxCreatorView } from './FluxCreatorView';

interface FluxViewProps {
  onBack: () => void;
  onOpenAuth: () => void;
  onOpenCommunity: (communityId: string) => void;
  initialPost?: FluxFeedItem | null;
  onClearInitialPost?: () => void;
}

interface FluxSequenceSlot {
  slotId: string;
  item: FluxFeedItem;
}

/**
 * Pink infinity-loop intertwined arrows icon beside "CRIAR FLUX" in the top pill button,
 * matching the visual reference design.
 */
const FluxInfinityIcon: React.FC<{ className?: string }> = ({
  className = 'h-5 w-8',
}) => (
  <svg
    viewBox="0 0 44 26"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <path
      d="M12.5 5.5C7.8 5.5 4.5 8.8 4.5 13C4.5 17.2 7.8 20.5 12.5 20.5C16.8 20.5 19.6 17.4 22 13C24.4 8.6 27.2 5.5 31.5 5.5C36.2 5.5 39.5 8.8 39.5 13C39.5 17.2 36.2 20.5 31.5 20.5C27.2 20.5 24.4 17.4 22 13C19.6 8.6 16.8 5.5 12.5 5.5Z"
      stroke="#FF66C4"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M27.5 10.5H34.5M34.5 10.5L31.8 8M34.5 10.5L31.8 13"
      stroke="#FF66C4"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M16.5 15.5H9.5M9.5 15.5L12.2 13M9.5 15.5L12.2 18"
      stroke="#FF66C4"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const fluxCardVariants = {
  initial: (dir: number) => ({
    y: dir >= 0 ? '100%' : '-100%',
    opacity: 0.85,
  }),
  animate: {
    y: 0,
    opacity: 1,
  },
  exit: (dir: number) => ({
    y: dir >= 0 ? '-100%' : '100%',
    opacity: 0.35,
  }),
};

export const FluxView: React.FC<FluxViewProps> = ({
  onBack,
  onOpenAuth,
  onOpenCommunity,
  initialPost,
  onClearInitialPost,
}) => {
  const { currentUser, userProfile, isDeveloper } = useAuth();
  const { openUserProfile } = usePublicProfile();
  const { addToast } = useNotifications();

  // Persistent FluxEngine instance per FluxView mount
  const engineRef = useRef<FluxEngine | null>(null);
  if (!engineRef.current) {
    engineRef.current = new FluxEngine();
  }
  const engine = engineRef.current;
  engine.setDeveloperFlag(Boolean(isDeveloper));

  const slotCounterRef = useRef(0);
  const wrapItemsInSlots = useCallback(
    (items: FluxFeedItem[]): FluxSequenceSlot[] =>
      items.map((item) => {
        slotCounterRef.current += 1;
        return {
          slotId: `flux_slot_${slotCounterRef.current}_${getFluxItemKey(item)}`,
          item,
        };
      }),
    []
  );

  // Redirect mode to the dedicated Story + Reels Creator page
  const [isCreatorOpen, setIsCreatorOpen] = useState(false);

  // Infinite Reels-locked sequence state
  const [sequence, setSequence] = useState<FluxSequenceSlot[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [navDirection, setNavDirection] = useState<1 | -1>(1);
  const [initialLoading, setInitialLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);

  // Per-post UI state (reset cleanly when active slot changes)
  const [mediaIndex, setMediaIndex] = useState(0);
  const [isDescriptionSheetOpen, setIsDescriptionSheetOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [isEditingPost, setIsEditingPost] = useState(false);
  const [editPostText, setEditPostText] = useState('');
  const [savingPostEdit, setSavingPostEdit] = useState(false);
  const [votingPoll, setVotingPoll] = useState(false);
  const [isAudioMuted, setIsAudioMuted] = useState(false);

  // Favorites & Community Membership state
  const [favoriteDocIds, setFavoriteDocIds] = useState<Set<string>>(new Set());
  const [joinedCommunityIds, setJoinedCommunityIds] = useState<Set<string>>(
    new Set()
  );
  const [pendingCommunityIds, setPendingCommunityIds] = useState<Set<string>>(
    new Set()
  );
  const [joiningCommunityId, setJoiningCommunityId] = useState<string | null>(
    null
  );

  // Modals (Comments, Report, Delete confirm)
  const [commentsOpenForPost, setCommentsOpenForPost] =
    useState<FluxFeedItem | null>(null);
  const [reportTarget, setReportTarget] = useState<{
    open: boolean;
    id: string;
    summary: string;
  }>({ open: false, id: '', summary: '' });
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [deletingPost, setDeletingPost] = useState(false);

  // Reels Gesture Locks & Engagement Dwell Tracking
  const transitionLockUntilRef = useRef<number>(0);
  const arrivedAtFirstPostGuardUntilRef = useRef<number>(0);
  const lastNavDirectionRef = useRef<1 | -1>(1);
  const activePostEnteredAtRef = useRef<{
    key: string;
    post: FluxFeedItem;
    enteredAt: number;
  } | null>(null);
  const wheelAccumRef = useRef<number>(0);
  const wheelResetTimerRef = useRef<number | null>(null);
  const touchGestureStartRef = useRef<{
    x: number;
    y: number;
    time: number;
  } | null>(null);

  const activeSlot: FluxSequenceSlot | undefined = sequence[currentIndex];
  const activePost: FluxFeedItem | undefined = activeSlot?.item;

  const flushActivePostDwellTelemetry = useCallback(
    (uid?: string) => {
      const prev = activePostEnteredAtRef.current;
      if (!prev) return;
      const elapsed = Date.now() - prev.enteredAt;
      if (elapsed >= 3500) {
        engine.recordEngagementSignal(prev.post, 'dwell', uid, elapsed);
      } else if (elapsed > 140 && elapsed < 1200 && lastNavDirectionRef.current === 1) {
        engine.recordEngagementSignal(prev.post, 'quick_skip', uid, elapsed);
      }
      activePostEnteredAtRef.current = null;
    },
    [engine]
  );

  // Flush dwell telemetry when closing/unmounting Flux
  useEffect(() => {
    const uid = currentUser?.uid;
    return () => {
      flushActivePostDwellTelemetry(uid);
    };
  }, [currentUser?.uid, flushActivePostDwellTelemetry]);

  // Reset per-card transient states & track dwell/seen whenever the active slot changes
  useEffect(() => {
    flushActivePostDwellTelemetry(currentUser?.uid);
    setMediaIndex(0);
    setIsDescriptionSheetOpen(false);
    setMenuOpen(false);
    setIsEditingPost(false);
    if (activePost) {
      activePostEnteredAtRef.current = {
        key: getFluxItemKey(activePost),
        post: activePost,
        enteredAt: Date.now(),
      };
      engine.markSeen(activePost, currentUser?.uid);
      if (
        currentUser?.uid &&
        activePost.blockedUserIds?.includes(currentUser.uid)
      ) {
        clearLegacyBlockedPostFlag(activePost, currentUser.uid);
      }
    }
  }, [activeSlot?.slotId, currentIndex, currentUser?.uid, flushActivePostDwellTelemetry]);

  // 1. Initial Flux Sequence Load (Runs fresh on every Flux open)
  useEffect(() => {
    let cancelled = false;
    const init = async () => {
      setInitialLoading(true);
      try {
        engine.setDeveloperFlag(Boolean(isDeveloper));
        await engine.fetchNextPoolBatch(currentUser?.uid);
        const initialSeq = await engine.generateFreshSequence(
          currentUser?.uid,
          18,
          null
        );
        if (!cancelled) {
          if (initialPost) {
            const targetKey = getFluxItemKey(initialPost);
            const deduped = initialSeq.filter(
              (item) => getFluxItemKey(item) !== targetKey
            );
            const combined =
              deduped.length > 0
                ? [initialPost, ...deduped]
                : [initialPost, initialPost];
            setSequence(wrapItemsInSlots(combined));
            setCurrentIndex(0);
            onClearInitialPost?.();
          } else {
            setSequence(wrapItemsInSlots(initialSeq));
            setCurrentIndex(0);
          }
        }
      } catch (err) {
        console.error('[FluxView] Error initializing sequence:', err);
      } finally {
        if (!cancelled) {
          setInitialLoading(false);
        }
      }
    };
    init();
    return () => {
      cancelled = true;
    };
  }, [currentUser?.uid, isDeveloper, wrapItemsInSlots]);

  // Handle jumping to an initialPost when FluxView is already mounted
  useEffect(() => {
    if (!initialPost || initialLoading) return;
    const targetKey = getFluxItemKey(initialPost);
    setIsCreatorOpen(false);
    setSequence((prev) => {
      const rest = prev.filter(
        (slot) => getFluxItemKey(slot.item) !== targetKey
      );
      const leadSlot = wrapItemsInSlots([initialPost]);
      if (rest.length === 0) {
        return [...leadSlot, ...wrapItemsInSlots([initialPost])];
      }
      return [...leadSlot, ...rest];
    });
    setCurrentIndex(0);
    onClearInitialPost?.();
  }, [initialPost, initialLoading, wrapItemsInSlots]);

  // 2. Subscribe to User's Saved/Favorite Posts
  useEffect(() => {
    if (!currentUser) {
      setFavoriteDocIds(new Set());
      return;
    }
    return subscribeUserFavoritePostIds(currentUser.uid, (ids) => {
      setFavoriteDocIds(ids);
    });
  }, [currentUser?.uid]);

  // 3. Check User Membership (active vs pending) for communities encountered in Flux
  useEffect(() => {
    if (!currentUser) {
      setJoinedCommunityIds(new Set());
      setPendingCommunityIds(new Set());
      return;
    }

    const commIdsToCheck = Array.from(
      new Set(
        [
          ...sequence
            .filter(
              (s) => s.item.postSource === 'community' && s.item.communityId
            )
            .map((s) => s.item.communityId),
          ...engine.getCommunitiesSnapshot(currentUser.uid).map((c) => c.id),
        ].filter(Boolean)
      )
    );

    if (commIdsToCheck.length === 0) return;

    let cancelled = false;
    const verifyMemberships = async () => {
      const nextJoined = new Set<string>(joinedCommunityIds);
      const nextPending = new Set<string>(pendingCommunityIds);
      let changed = false;

      await Promise.all(
        commIdsToCheck.map(async (cid) => {
          if (nextJoined.has(cid) || nextPending.has(cid)) return;
          const commObj = engine
            .getCommunitiesSnapshot(currentUser.uid)
            .find((c) => c.id === cid);
          if (commObj?.creatorId === currentUser.uid) {
            nextJoined.add(cid);
            engine.registerActiveMembership(cid, currentUser.uid);
            changed = true;
            return;
          }
          try {
            const snap = await getDoc(
              doc(db, 'communities', cid, 'members', currentUser.uid)
            );
            if (snap.exists()) {
              const mData = snap.data() as Partial<CommunityMember>;
              if (mData.status === 'pending') {
                nextPending.add(cid);
                changed = true;
              } else if (mData.status !== 'banned') {
                nextJoined.add(cid);
                engine.registerActiveMembership(cid, currentUser.uid);
                changed = true;
              }
            }
          } catch {
            // ignore
          }
        })
      );

      if (!cancelled && changed) {
        setJoinedCommunityIds(nextJoined);
        setPendingCommunityIds(nextPending);
      }
    };

    verifyMemberships();
    return () => {
      cancelled = true;
    };
  }, [currentUser?.uid, sequence.length]);

  // Publishable communities for optional community destination inside FluxCreatorView
  const publishableCommunities = useMemo<Community[]>(() => {
    if (!currentUser) return [];
    return engine.getCommunitiesSnapshot(currentUser.uid).filter((c) => {
      if (c.bannedUserIds?.includes(currentUser.uid)) return false;
      if (c.silencedUserIds?.includes(currentUser.uid)) return false;
      return (
        c.creatorId === currentUser.uid ||
        c.partialModeratorIds?.includes(currentUser.uid) ||
        isDeveloper
      );
    });
  }, [currentUser?.uid, isDeveloper, sequence.length, joinedCommunityIds.size]);

  // 4. Infinite One-Way Downward Cyclic Append
  useEffect(() => {
    if (
      initialLoading ||
      refreshing ||
      loadingMore ||
      sequence.length === 0 ||
      currentIndex < sequence.length - 4
    ) {
      return;
    }

    let cancelled = false;
    const loadNextInfiniteCycle = async () => {
      setLoadingMore(true);
      try {
        const recentWindow = new Set(
          sequence.slice(Math.max(0, sequence.length - 25)).map((s) =>
            getFluxItemKey(s.item)
          )
        );
        const lastTailKey = getFluxItemKey(
          sequence[sequence.length - 1].item
        );

        const chunk = await engine.appendInfiniteCycleChunk(
          recentWindow,
          lastTailKey,
          currentUser?.uid,
          11
        );

        if (!cancelled && chunk.length > 0) {
          const newSlots = wrapItemsInSlots(chunk);
          setSequence((prev) => [...prev, ...newSlots]);
        }
      } catch (err) {
        console.warn('[FluxView] Notice appending next cycle chunk:', err);
      } finally {
        if (!cancelled) {
          setLoadingMore(false);
        }
      }
    };

    loadNextInfiniteCycle();
    return () => {
      cancelled = true;
    };
  }, [
    currentIndex,
    sequence.length,
    initialLoading,
    refreshing,
    loadingMore,
    currentUser?.uid,
    wrapItemsInSlots,
  ]);

  // 5. Sequence Refresh & Recommendation Reorganization (Manual or Pull-Past-First-Post)
  const handleRefreshSequence = useCallback(
    async (trigger: 'manual' | 'pull_top' = 'manual') => {
      if (refreshing) return;
      flushActivePostDwellTelemetry(currentUser?.uid);
      setRefreshing(true);
      setMenuOpen(false);
      setIsEditingPost(false);
      setIsDescriptionSheetOpen(false);

      try {
        const currentLeadKey = activePost
          ? getFluxItemKey(activePost)
          : sequence[0]
          ? getFluxItemKey(sequence[0].item)
          : null;
        const freshSeq = await engine.generateFreshSequence(
          currentUser?.uid,
          18,
          currentLeadKey
        );
        const dir: 1 | -1 = trigger === 'pull_top' ? -1 : 1;
        lastNavDirectionRef.current = dir;
        setNavDirection(dir);
        setSequence(wrapItemsInSlots(freshSeq));
        setCurrentIndex(0);
        setMediaIndex(0);
        arrivedAtFirstPostGuardUntilRef.current = Date.now() + 650;
      } catch (err) {
        console.error('[FluxView] Error refreshing Flux sequence:', err);
      } finally {
        setRefreshing(false);
      }
    },
    [
      refreshing,
      flushActivePostDwellTelemetry,
      currentUser?.uid,
      activePost,
      sequence,
      engine,
      wrapItemsInSlots,
    ]
  );

  // 6A. Reels-Style Downward Commit Advance (Post stays 100% fixed until commit, then transitions to next)
  const advanceToNextPost = useCallback(() => {
    const now = Date.now();
    if (now < transitionLockUntilRef.current || refreshing) return;
    if (sequence.length === 0) return;

    transitionLockUntilRef.current = now + 440;
    lastNavDirectionRef.current = 1;

    if (currentIndex < sequence.length - 1) {
      setNavDirection(1);
      setCurrentIndex((prev) => prev + 1);
      return;
    }

    const lastKey = activePost ? getFluxItemKey(activePost) : null;
    const immediateCycle = engine.getImmediateReplacementAfterDismiss(
      lastKey,
      currentUser?.uid
    );
    if (immediateCycle.length > 0) {
      const newSlots = wrapItemsInSlots(immediateCycle);
      setNavDirection(1);
      setSequence((prev) => [...prev, ...newSlots]);
      setCurrentIndex((prev) => prev + 1);
    }
  }, [
    currentIndex,
    sequence.length,
    activePost,
    currentUser?.uid,
    engine,
    refreshing,
    wrapItemsInSlots,
  ]);

  // 6B. Reels-Style Upward Navigation (Revisits already passed posts up to index 0; if attempting to go past index 0, reorganizes recommendations)
  const retreatOrRefreshAtTop = useCallback(() => {
    const now = Date.now();
    if (now < transitionLockUntilRef.current || refreshing) return;
    if (sequence.length === 0) return;

    if (currentIndex > 0) {
      transitionLockUntilRef.current = now + 440;
      lastNavDirectionRef.current = -1;
      setNavDirection(-1);
      if (currentIndex === 1) {
        // Guard against inertial trackpad overshoot so upward scroll stops cleanly on the 1st post first
        arrivedAtFirstPostGuardUntilRef.current = now + 680;
        wheelAccumRef.current = 0;
      }
      setCurrentIndex((prev) => Math.max(0, prev - 1));
      return;
    }

    // Already at the first post shown when opening Flux (currentIndex === 0):
    // Trying to go back further upward updates the sequence and reorganizes the recommendation algorithm!
    if (now < arrivedAtFirstPostGuardUntilRef.current) return;
    transitionLockUntilRef.current = now + 520;
    wheelAccumRef.current = 0;
    void handleRefreshSequence('pull_top');
  }, [currentIndex, sequence.length, refreshing, handleRefreshSequence]);

  const isOverlayBlockingNav = Boolean(
    isCreatorOpen ||
      commentsOpenForPost ||
      reportTarget.open ||
      confirmDeleteOpen ||
      isEditingPost ||
      isDescriptionSheetOpen ||
      menuOpen
  );

  // Keyboard navigation (ArrowDown/PageDown advances; ArrowUp/PageUp goes back up to 1st post or refreshes past top)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (isOverlayBlockingNav) return;
      const tag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;

      if (e.key === 'ArrowDown' || e.key === 'PageDown') {
        if (sequence.length > 0) {
          e.preventDefault();
          advanceToNextPost();
        }
      } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
        if (sequence.length > 0) {
          e.preventDefault();
          retreatOrRefreshAtTop();
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    sequence.length,
    advanceToNextPost,
    retreatOrRefreshAtTop,
    isOverlayBlockingNav,
  ]);

  // Reels Mouse Wheel / Trackpad Commit (Supports downward advance AND upward revisit / pull-past-top refresh)
  const handleViewportWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    if (isOverlayBlockingNav || sequence.length === 0 || refreshing) return;
    const now = Date.now();
    if (now < transitionLockUntilRef.current) return;
    if (e.deltaY === 0) return;

    // Reset accumulator immediately when user reverses wheel direction
    if (
      (e.deltaY > 0 && wheelAccumRef.current < 0) ||
      (e.deltaY < 0 && wheelAccumRef.current > 0)
    ) {
      wheelAccumRef.current = 0;
    }

    wheelAccumRef.current += e.deltaY;

    if (wheelResetTimerRef.current) {
      window.clearTimeout(wheelResetTimerRef.current);
    }

    if (wheelAccumRef.current >= 80) {
      wheelAccumRef.current = 0;
      advanceToNextPost();
      return;
    }

    if (wheelAccumRef.current <= -80) {
      wheelAccumRef.current = 0;
      retreatOrRefreshAtTop();
      return;
    }

    wheelResetTimerRef.current = window.setTimeout(() => {
      wheelAccumRef.current = 0;
    }, 220);
  };

  // Reels Touch Swipe Commit (Upward swipe -> next post; Downward swipe -> previous post up to 1st, or refresh if past 1st)
  const handleViewportTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (isOverlayBlockingNav || e.touches.length !== 1) return;
    touchGestureStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY,
      time: Date.now(),
    };
  };

  const handleViewportTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (
      isOverlayBlockingNav ||
      !touchGestureStartRef.current ||
      e.changedTouches.length === 0
    ) {
      touchGestureStartRef.current = null;
      return;
    }

    const start = touchGestureStartRef.current;
    touchGestureStartRef.current = null;

    const dx = start.x - e.changedTouches[0].clientX;
    const dy = start.y - e.changedTouches[0].clientY;

    if (Math.abs(dy) <= Math.abs(dx) * 1.25) return;

    if (dy >= 48) {
      advanceToNextPost();
    } else if (dy <= -48) {
      retreatOrRefreshAtTop();
    }
  };

  // Media items of active post
  const mediaItems = useMemo(
    () => (activePost ? extractPostMediaItems(activePost) : []),
    [activePost]
  );

  const hasStoryTextLayers = Boolean(
    activePost?.storyCanvas?.texts?.some(
      (t) => typeof t.text === 'string' && t.text.trim().length > 0
    )
  );

  // 7. Redirect Callback from Dedicated FluxCreatorView
  const handleOpenCreatorPage = () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    setMenuOpen(false);
    setIsDescriptionSheetOpen(false);
    setIsCreatorOpen(true);
  };

  const handlePublishedFromCreator = (createdItem: FluxFeedItem) => {
    engine.insertNewlyPublishedItem(createdItem);
    engine.markSeen(createdItem, currentUser?.uid);
    setIsCreatorOpen(false);
    lastNavDirectionRef.current = -1;
    setNavDirection(-1);
    setSequence((prev) => {
      const newLead = wrapItemsInSlots([createdItem]);
      if (prev.length === 0) {
        return [...newLead, ...wrapItemsInSlots([createdItem])];
      }
      return [...newLead, ...prev.slice(currentIndex)];
    });
    setCurrentIndex(0);
  };

  // 8. Post Card Interactions
  const mutateItemInPlace = (
    target: FluxFeedItem,
    updater: (prev: FluxFeedItem) => FluxFeedItem
  ) => {
    const targetKey = getFluxItemKey(target);
    engine.updateItemInPool(targetKey, updater);
    setSequence((prev) =>
      prev.map((slot) =>
        getFluxItemKey(slot.item) === targetKey
          ? { ...slot, item: updater(slot.item) }
          : slot
      )
    );
  };

  const handleToggleLike = async () => {
    if (!activePost) return;
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const prevSnapshot = activePost;
    const currentlyLiked = Boolean(
      activePost.likedUserIds?.includes(currentUser.uid)
    );
    const optimisticCount = currentlyLiked
      ? Math.max(0, (activePost.likesCount || 1) - 1)
      : (activePost.likesCount || 0) + 1;
    const optimisticIds = currentlyLiked
      ? (activePost.likedUserIds || []).filter((id) => id !== currentUser.uid)
      : [...(activePost.likedUserIds || []), currentUser.uid];

    mutateItemInPlace(activePost, (p) => ({
      ...p,
      likesCount: optimisticCount,
      likedUserIds: optimisticIds,
    }));
    engine.recordEngagementSignal(
      activePost,
      currentlyLiked ? 'unlike' : 'like',
      currentUser.uid
    );

    try {
      const res = await toggleFluxPostLike(prevSnapshot, currentUser.uid);
      mutateItemInPlace(prevSnapshot, (p) => ({
        ...p,
        likesCount: res.likesCount,
        likedUserIds: res.likedUserIds,
      }));
    } catch {
      mutateItemInPlace(prevSnapshot, () => prevSnapshot);
    }
  };

  const handleToggleFavorite = async () => {
    if (!activePost) return;
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const favId = getFavoriteDocId(activePost);
    const isSaved = favoriteDocIds.has(favId);

    setFavoriteDocIds((prev) => {
      const next = new Set(prev);
      if (isSaved) next.delete(favId);
      else next.add(favId);
      return next;
    });
    engine.recordEngagementSignal(
      activePost,
      isSaved ? 'unsave' : 'save',
      currentUser.uid
    );

    try {
      const nowSaved = await toggleFluxPostFavorite(
        activePost,
        currentUser.uid,
        isSaved
      );
      addToast({
        id: `flux_fav_${Date.now()}`,
        type: 'system',
        title: nowSaved ? 'Publicação salva!' : 'Removida dos salvos',
        message: nowSaved
          ? 'Disponível em Biblioteca > Salvos > Publicações Salvas.'
          : 'Publicação removida das suas publicações salvas.',
      });
    } catch {
      setFavoriteDocIds((prev) => {
        const next = new Set(prev);
        if (isSaved) next.add(favId);
        else next.delete(favId);
        return next;
      });
    }
  };

  const handleJoinCommunity = async (communityId: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (joiningCommunityId) return;

    setJoiningCommunityId(communityId);
    try {
      const resultStatus = await joinCommunityFromFlux(
        communityId,
        currentUser.uid,
        userProfile
      );
      if (activePost && activePost.communityId === communityId) {
        engine.recordEngagementSignal(
          activePost,
          'community_join',
          currentUser.uid
        );
      }
      if (resultStatus === 'pending') {
        setPendingCommunityIds((prev) => new Set(prev).add(communityId));
        addToast({
          id: `flux_join_pend_${Date.now()}`,
          type: 'system',
          title: 'Solicitação enviada',
          message:
            'Esta comunidade é privada. Aguarde a aprovação da administração.',
        });
      } else {
        setJoinedCommunityIds((prev) => new Set(prev).add(communityId));
        engine.registerActiveMembership(communityId, currentUser.uid);
        addToast({
          id: `flux_join_${Date.now()}`,
          type: 'community_join',
          title: 'Você agora participa!',
          message: 'Entrada confirmada na comunidade.',
        });
      }
    } catch (err: any) {
      addToast({
        id: `flux_join_err_${Date.now()}`,
        type: 'system',
        title: 'Aviso',
        message: err?.message || 'Não foi possível entrar na comunidade.',
      });
    } finally {
      setJoiningCommunityId(null);
    }
  };

  const handleVotePoll = async (optionId: string) => {
    if (!activePost || !activePost.poll) return;
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (votingPoll) return;
    setVotingPoll(true);
    try {
      const updatedPoll = await voteFluxCommunityPoll(
        activePost,
        optionId,
        currentUser.uid
      );
      if (updatedPoll) {
        engine.recordEngagementSignal(
          activePost,
          'poll_vote',
          currentUser.uid
        );
        mutateItemInPlace(activePost, (p) => ({
          ...p,
          poll: updatedPoll,
        }));
      }
    } catch {
      // ignore
    } finally {
      setVotingPoll(false);
    }
  };

  const handleDismissCurrentPost = () => {
    if (!activePost) return;
    const target = activePost;
    const targetKey = getFluxItemKey(target);

    engine.markTemporarilyDismissed(target, currentUser?.uid);
    setMenuOpen(false);
    setIsDescriptionSheetOpen(false);
    lastNavDirectionRef.current = 1;
    setNavDirection(1);

    setSequence((prev) => {
      const headBefore = prev.slice(0, currentIndex);
      const afterCurrent = prev
        .slice(currentIndex + 1)
        .filter((slot) => getFluxItemKey(slot.item) !== targetKey);

      if (afterCurrent.length >= 2) {
        return [...headBefore, ...afterCurrent];
      }

      const replacementItems = engine.getImmediateReplacementAfterDismiss(
        afterCurrent.length > 0
          ? getFluxItemKey(afterCurrent[afterCurrent.length - 1].item)
          : targetKey,
        currentUser?.uid
      );
      const replacementSlots = wrapItemsInSlots(replacementItems);
      return [...headBefore, ...afterCurrent, ...replacementSlots];
    });
  };

  const handleSharePost = async () => {
    if (!activePost) return;
    setMenuOpen(false);
    engine.recordEngagementSignal(activePost, 'share', currentUser?.uid);
    const shareUrl = activePost.communityId
      ? `${window.location.origin}/?comunidade=${activePost.communityId}&post=${activePost.id}`
      : `${window.location.origin}/?flux=${activePost.id}`;

    try {
      if (navigator.share) {
        await navigator.share({
          title:
            activePost.communityName || `Flux de ${activePost.authorName}`,
          text:
            activePost.content?.slice(0, 140) ||
            'Confira esta publicação no KORDEL Flux',
          url: shareUrl,
        });
        return;
      }
    } catch {
      // fallback to clipboard
    }

    try {
      await navigator.clipboard.writeText(shareUrl);
      addToast({
        id: `flux_share_${Date.now()}`,
        type: 'system',
        title: 'Link copiado!',
        message:
          'O link da publicação foi copiado para a área de transferência.',
      });
    } catch {
      // ignore
    }
  };

  const handleSaveEditPost = async () => {
    if (!activePost || savingPostEdit) return;
    const trimmed = editPostText.trim();
    if (
      !trimmed &&
      mediaItems.length === 0 &&
      !hasStoryTextLayers &&
      !activePost.audioTrack?.url
    ) {
      return;
    }

    setSavingPostEdit(true);
    try {
      const editedAt = await updateFluxPostContent(activePost, trimmed);
      mutateItemInPlace(activePost, (p) => ({
        ...p,
        content: trimmed,
        editedAt,
      }));
      setIsEditingPost(false);
    } catch {
      addToast({
        id: `flux_edit_err_${Date.now()}`,
        type: 'system',
        title: 'Erro ao editar',
        message: 'Não foi possível salvar a alteração.',
      });
    } finally {
      setSavingPostEdit(false);
    }
  };

  const handleConfirmDeletePost = async () => {
    if (!activePost || deletingPost) return;
    setDeletingPost(true);
    const target = activePost;
    const targetKey = getFluxItemKey(target);

    try {
      await deleteFluxPostItem(target);
      engine.removeItemFromPool(targetKey);
      setConfirmDeleteOpen(false);
      setNavDirection(1);
      setSequence((prev) => {
        const next = prev.filter(
          (slot) => getFluxItemKey(slot.item) !== targetKey
        );
        if (next.length === 0) {
          const fallback = engine.getImmediateReplacementAfterDismiss(
            null,
            currentUser?.uid
          );
          return wrapItemsInSlots(fallback);
        }
        if (currentIndex >= next.length) {
          setCurrentIndex(Math.max(0, next.length - 1));
        }
        return next;
      });
      addToast({
        id: `flux_del_${Date.now()}`,
        type: 'system',
        title: 'Publicação excluída',
        message: 'A publicação foi removida permanentemente.',
      });
    } catch {
      addToast({
        id: `flux_del_err_${Date.now()}`,
        type: 'system',
        title: 'Erro ao excluir',
        message: 'Você não tem permissão ou ocorreu uma falha ao remover.',
      });
    } finally {
      setDeletingPost(false);
    }
  };

  // Computed flags for activePost
  const hasLiked = Boolean(
    currentUser && activePost?.likedUserIds?.includes(currentUser.uid)
  );
  const isSaved = Boolean(
    activePost && favoriteDocIds.has(getFavoriteDocId(activePost))
  );
  const isPostAuthor = Boolean(
    currentUser && activePost && currentUser.uid === activePost.authorId
  );
  const canDeleteActivePost = Boolean(
    currentUser &&
      activePost &&
      (isPostAuthor ||
        currentUser.uid === activePost.communityCreatorId ||
        isDeveloper)
  );

  const isMemberOfPostCommunity = Boolean(
    activePost?.communityId &&
      (joinedCommunityIds.has(activePost.communityId) ||
        (currentUser && currentUser.uid === activePost.communityCreatorId))
  );
  const isPendingInPostCommunity = Boolean(
    activePost?.communityId && pendingCommunityIds.has(activePost.communityId)
  );

  // Description / Caption logic ("... VER MAIS" matching Image 1)
  const rawContent = (activePost?.content || '').trim();
  const isLegacyPureTextStage =
    mediaItems.length === 0 && !hasStoryTextLayers && !activePost?.poll;
  const showCaptionBox =
    rawContent.length > 0 && (!isLegacyPureTextStage || rawContent.length > 260);
  const captionCharLimit = 92;
  const shouldTruncateCaption = rawContent.length > captionCharLimit;
  const shortCaptionPreview = useMemo(() => {
    if (!shouldTruncateCaption) return rawContent;
    const sliced = rawContent.slice(0, captionCharLimit);
    const lastSpace = sliced.lastIndexOf(' ');
    return (
      lastSpace > captionCharLimit * 0.6 ? sliced.slice(0, lastSpace) : sliced
    ).trimEnd();
  }, [rawContent, shouldTruncateCaption]);

  // Dedicated Creator Redirection View (Image 2 Story + Reels Editor) — placed after all hooks
  if (isCreatorOpen) {
    return (
      <FluxCreatorView
        publishableCommunities={publishableCommunities}
        onBack={() => setIsCreatorOpen(false)}
        onPublished={handlePublishedFromCreator}
        onOpenAuth={onOpenAuth}
      />
    );
  }

  return (
    <div
      onWheel={handleViewportWheel}
      onTouchStart={handleViewportTouchStart}
      onTouchEnd={handleViewportTouchEnd}
      className="h-[100dvh] w-full overflow-hidden bg-[#1D1D1D] text-white flex flex-col justify-between select-none"
    >
      {/* 1. TOP BAR — Exact Image 1 Layout (Back Pink Circle + CRIAR FLUX + Pill) */}
      <header className="w-full max-w-[500px] mx-auto shrink-0 z-20">
        <div className="rounded-b-[26px] bg-[#161616] px-4 py-3 flex items-center justify-between shadow-lg">
          <button
            type="button"
            onClick={onBack}
            className="h-10 w-10 rounded-full bg-[#FF66C4] hover:bg-[#FF57B2] text-[#181818] flex items-center justify-center transition active:scale-95 cursor-pointer shrink-0"
            title="Voltar"
            aria-label="Voltar"
          >
            <ArrowLeft className="h-5 w-5 stroke-[2.7]" />
          </button>

          <button
            type="button"
            onClick={handleOpenCreatorPage}
            className="min-h-[42px] rounded-full border-[1.5px] border-[#FF66C4] bg-[#202020] hover:bg-[#262626] pl-3.5 pr-1.5 py-1 flex items-center gap-3 transition active:scale-[0.98] cursor-pointer"
          >
            <FluxInfinityIcon className="h-5 w-8 shrink-0" />
            <span className="font-extrabold text-[13px] sm:text-sm tracking-wide text-white uppercase">
              CRIAR FLUX
            </span>
            <span className="h-7 w-7 rounded-full bg-[#FF66C4] text-[#181818] flex items-center justify-center shrink-0">
              <Plus className="h-4 w-4 stroke-[3]" />
            </span>
          </button>
        </div>
      </header>

      {/* 2. FIXED CENTERED REELS STAGE — Zero scroll, publication stays 100% locked in evidence */}
      <div className="flex-1 min-h-0 w-full max-w-[500px] mx-auto px-3 pt-2.5 pb-1 flex flex-col justify-center overflow-hidden relative">
        {initialLoading ? (
          <div className="h-full w-full rounded-[18px] bg-[#202020] p-6 flex flex-col items-center justify-center gap-3">
            <Loader2 className="h-7 w-7 animate-spin text-[#FF66C4]" />
            <p className="text-xs font-semibold text-zinc-400">
              Carregando publicações do Flux...
            </p>
          </div>
        ) : !activePost ? (
          <div className="h-full w-full rounded-[18px] bg-[#202020] p-6 flex flex-col items-center justify-center text-center gap-4">
            <FluxInfinityIcon className="h-8 w-14 mx-auto" />
            <div className="space-y-1.5 max-w-xs">
              <h3 className="text-base font-extrabold text-white">
                Nenhuma publicação no Flux ainda
              </h3>
              <p className="text-xs text-zinc-400">
                Toque em Criar Flux no topo para inaugurar o feed com textos,
                imagens e edições em formato Story.
              </p>
            </div>
            <button
              type="button"
              onClick={handleOpenCreatorPage}
              className="min-h-[42px] px-5 py-2 rounded-full bg-[#FF66C4] hover:bg-[#FF57B2] text-[#181818] text-xs font-extrabold uppercase tracking-wide transition cursor-pointer"
            >
              Criar Primeira Publicação
            </button>
          </div>
        ) : (
          <div className="relative h-full w-full overflow-hidden rounded-[18px]">
            {refreshing && (
              <div className="absolute top-2.5 left-1/2 -translate-x-1/2 z-30 rounded-full bg-[#161616]/95 border border-[#FF66C4]/50 px-3.5 py-1.5 flex items-center gap-2 shadow-lg pointer-events-none">
                <RefreshCw className="h-3.5 w-3.5 text-[#FF66C4] animate-spin" />
                <span className="text-[11px] font-bold text-white whitespace-nowrap">
                  Reorganizando recomendações...
                </span>
              </div>
            )}

            <AnimatePresence initial={false} mode="popLayout" custom={navDirection}>
              <motion.article
                key={activeSlot.slotId}
                custom={navDirection}
                variants={fluxCardVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                transition={{
                  duration: 0.32,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className="h-full w-full rounded-[18px] bg-[#202020] flex flex-col overflow-hidden relative shadow-xl"
              >
                {/* ROW A: Top-Right "..." and "X" Controls */}
                <div className="px-3.5 pt-2 pb-1.5 flex items-center justify-end gap-2 shrink-0 relative z-20">
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setMenuOpen((prev) => !prev)}
                      className="h-8 w-8 rounded-full flex items-center justify-center text-[#9E9E9E] hover:text-white hover:bg-[#2B2B2B] transition cursor-pointer"
                      title="Mais opções"
                      aria-label="Mais opções da publicação"
                    >
                      <MoreHorizontal className="h-5 w-5" />
                    </button>

                    {menuOpen && (
                      <>
                        <div
                          className="fixed inset-0 z-20"
                          onClick={() => setMenuOpen(false)}
                        />
                        <div className="absolute right-0 top-9 z-30 w-56 rounded-2xl bg-[#262626] border border-zinc-700/80 p-1.5 shadow-2xl text-xs space-y-0.5">
                          <button
                            type="button"
                            onClick={() => void handleRefreshSequence('manual')}
                            disabled={refreshing}
                            className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-zinc-200 hover:bg-[#323232] font-semibold transition cursor-pointer"
                          >
                            <RefreshCw
                              className={`h-4 w-4 text-[#FF66C4] ${
                                refreshing ? 'animate-spin' : ''
                              }`}
                            />
                            <span>Atualizar sequência</span>
                          </button>

                          <button
                            type="button"
                            onClick={handleSharePost}
                            className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-zinc-200 hover:bg-[#323232] font-semibold transition cursor-pointer"
                          >
                            <Share2 className="h-4 w-4 text-[#FF66C4]" />
                            <span>Compartilhar link</span>
                          </button>

                          {activePost.communityId && (
                            <button
                              type="button"
                              onClick={() => {
                                setMenuOpen(false);
                                onOpenCommunity(activePost.communityId);
                              }}
                              className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-zinc-200 hover:bg-[#323232] font-semibold transition cursor-pointer"
                            >
                              <Users className="h-4 w-4 text-[#FF66C4]" />
                              <span>Abrir comunidade</span>
                            </button>
                          )}

                          {isPostAuthor && (
                            <button
                              type="button"
                              onClick={() => {
                                setEditPostText(activePost.content || '');
                                setIsEditingPost(true);
                                setMenuOpen(false);
                              }}
                              className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-zinc-200 hover:bg-[#323232] font-semibold transition cursor-pointer"
                            >
                              <Edit2 className="h-4 w-4 text-zinc-300" />
                              <span>Editar descrição</span>
                            </button>
                          )}

                          {canDeleteActivePost && (
                            <button
                              type="button"
                              onClick={() => {
                                setMenuOpen(false);
                                setConfirmDeleteOpen(true);
                              }}
                              className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-[#FF80C5] hover:bg-[#323232] font-semibold transition cursor-pointer"
                            >
                              <Trash2 className="h-4 w-4 text-[#FF66C4]" />
                              <span>Excluir publicação</span>
                            </button>
                          )}

                          {!isPostAuthor && (
                            <button
                              type="button"
                              onClick={() => {
                                setMenuOpen(false);
                                setReportTarget({
                                  open: true,
                                  id: activePost.id,
                                  summary: `Publicação no Flux de ${activePost.authorName}`,
                                });
                              }}
                              className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-zinc-300 hover:bg-[#323232] font-semibold transition cursor-pointer"
                            >
                              <AlertTriangle className="h-4 w-4 text-[#FF66C4]" />
                              <span>Denunciar publicação</span>
                            </button>
                          )}
                        </div>
                      </>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleDismissCurrentPost}
                    className="h-8 w-8 rounded-full flex items-center justify-center text-[#9E9E9E] hover:text-white hover:bg-[#2B2B2B] transition cursor-pointer"
                    title="Ocultar temporariamente e passar para a próxima"
                    aria-label="Passar publicação"
                  >
                    <X className="h-5 w-5 stroke-[2.3]" />
                  </button>
                </div>

                {/* ROW B: Author / Community Header Banner (#2B2B2B) */}
                <div className="mx-3 mb-2.5 rounded-[16px] bg-[#2B2B2B] px-3 py-2 flex items-center justify-between gap-2.5 shrink-0">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {activePost.communityId ? (
                      <div className="relative shrink-0">
                        <button
                          type="button"
                          onClick={() => onOpenCommunity(activePost.communityId)}
                          className="h-10 w-10 rounded-[11px] overflow-hidden bg-[#1D1D1D] flex items-center justify-center text-[#FF66C4] font-black text-sm cursor-pointer block"
                          title={activePost.communityName || 'Abrir comunidade'}
                        >
                          {activePost.communityCoverUrl ? (
                            <img
                              src={activePost.communityCoverUrl}
                              alt={activePost.communityName || 'Comunidade'}
                              referrerPolicy="no-referrer"
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <span>
                              {(activePost.communityName || 'C')
                                .charAt(0)
                                .toUpperCase()}
                            </span>
                          )}
                        </button>
                        <div
                          onClick={() => openUserProfile(activePost.authorId)}
                          className="absolute -bottom-1 -right-1 rounded-full ring-2 ring-[#2B2B2B] cursor-pointer"
                          title={`Ver perfil de ${activePost.authorName}`}
                        >
                          <UserAvatar
                            userId={activePost.authorId}
                            userName={activePost.authorName}
                            photoURL={activePost.authorPhoto}
                            sizeClass="h-5 w-5"
                          />
                        </div>
                      </div>
                    ) : (
                      <UserAvatar
                        userId={activePost.authorId}
                        userName={activePost.authorName}
                        photoURL={activePost.authorPhoto}
                        sizeClass="h-10 w-10 shrink-0"
                        onClick={() => openUserProfile(activePost.authorId)}
                        title={`Ver perfil de ${activePost.authorName}`}
                      />
                    )}

                    <div className="min-w-0 flex-1">
                      {activePost.communityId ? (
                        <>
                          <button
                            type="button"
                            onClick={() =>
                              onOpenCommunity(activePost.communityId)
                            }
                            className="font-extrabold text-[13px] sm:text-sm text-white hover:text-[#FF66C4] truncate block text-left max-w-full transition cursor-pointer leading-tight"
                          >
                            {activePost.communityName || 'Comunidade'}
                          </button>
                          <div className="flex items-center gap-1 text-[11px] text-[#A6A6A6] truncate mt-0.5">
                            <button
                              type="button"
                              onClick={() =>
                                openUserProfile(activePost.authorId)
                              }
                              className="hover:text-white truncate cursor-pointer font-medium"
                            >
                              {activePost.authorName}
                            </button>
                            <span aria-hidden="true">•</span>
                            <span className="shrink-0">
                              {formatRelativeTimePt(activePost.createdAt)}
                            </span>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="flex items-center gap-1.5 min-w-0">
                            <button
                              type="button"
                              onClick={() =>
                                openUserProfile(activePost.authorId)
                              }
                              className="font-extrabold text-[13px] sm:text-sm text-white hover:text-[#FF66C4] truncate text-left transition cursor-pointer leading-tight"
                            >
                              {activePost.authorName}
                            </button>
                            <UserBadges
                              userId={activePost.authorId}
                              isLight={false}
                              size="xs"
                            />
                          </div>
                          <div className="flex items-center gap-1 text-[11px] text-[#A6A6A6] truncate mt-0.5">
                            {activePost.authorTitle && (
                              <>
                                <span className="truncate">
                                  {activePost.authorTitle}
                                </span>
                                <span aria-hidden="true">•</span>
                              </>
                            )}
                            <span className="shrink-0">
                              {formatRelativeTimePt(activePost.createdAt)}
                            </span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Right Community Action ("Participar" / "Solicitar" / "Membro") */}
                  {activePost.communityId && (
                    <div className="shrink-0 pl-1">
                      {isMemberOfPostCommunity ? (
                        <button
                          type="button"
                          onClick={() => onOpenCommunity(activePost.communityId)}
                          className="text-xs font-extrabold text-[#FF66C4] hover:text-[#FF57B2] px-2 py-1 transition cursor-pointer"
                        >
                          Membro
                        </button>
                      ) : isPendingInPostCommunity ? (
                        <span className="text-xs font-bold text-zinc-400 px-2 py-1">
                          Solicitado
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() =>
                            handleJoinCommunity(activePost.communityId)
                          }
                          disabled={
                            joiningCommunityId === activePost.communityId
                          }
                          className="min-h-[34px] px-2.5 py-1 text-xs sm:text-[13px] font-extrabold text-[#FF66C4] hover:text-[#FF57B2] transition disabled:opacity-50 cursor-pointer flex items-center gap-1"
                        >
                          {joiningCommunityId === activePost.communityId && (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          )}
                          <span>
                            {activePost.communityIsPrivate
                              ? 'Solicitar'
                              : 'Participar'}
                          </span>
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* ROW C: Central Visual / Story Stage (#262626) */}
                <div className="flex-1 min-h-0 mx-3 rounded-[20px] bg-[#262626] overflow-hidden relative">
                  <FluxStoryStage
                    mediaItems={mediaItems}
                    activeMediaIndex={mediaIndex}
                    onChangeMediaIndex={setMediaIndex}
                    storyCanvas={activePost.storyCanvas}
                    audioTrack={activePost.audioTrack}
                    isAudioActive={
                      !isCreatorOpen &&
                      !commentsOpenForPost &&
                      !confirmDeleteOpen
                    }
                    isAudioMuted={isAudioMuted}
                    onToggleAudioMute={(forceUnmute) =>
                      setIsAudioMuted((prev) => (forceUnmute ? false : !prev))
                    }
                    fallbackText={
                      isLegacyPureTextStage ? rawContent : undefined
                    }
                    poll={activePost.poll}
                    currentUserId={currentUser?.uid}
                    onVotePoll={handleVotePoll}
                    votingPoll={votingPoll}
                    className="h-full w-full"
                  />
                </div>

                {/* ROW D: Carousel Dots (o [===] o o o) when multiple media items exist */}
                {mediaItems.length > 1 && (
                  <div className="pt-2 pb-0.5 flex items-center justify-center gap-1.5 shrink-0">
                    {mediaItems.map((_, idx) => {
                      const isActive = idx === mediaIndex;
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setMediaIndex(idx)}
                          aria-label={`Mídia ${idx + 1}`}
                          className={`h-1.5 rounded-full transition-all cursor-pointer ${
                            isActive
                              ? 'w-5 bg-[#B8B8B8]'
                              : 'w-1.5 bg-[#686868] hover:bg-[#8A8A8A]'
                          }`}
                        />
                      );
                    })}
                  </div>
                )}

                {/* ROW E: Description Box (#2B2B2B with "... VER MAIS") */}
                {showCaptionBox && (
                  <div className="mx-3 mt-2 rounded-[15px] bg-[#2B2B2B] px-3.5 py-2.5 shrink-0">
                    <p className="text-xs sm:text-[13px] text-[#E4E4E7] leading-snug break-words select-text">
                      {shouldTruncateCaption ? (
                        <>
                          <span>{shortCaptionPreview}... </span>
                          <button
                            type="button"
                            onClick={() => {
                              engine.recordEngagementSignal(
                                activePost,
                                'open_caption',
                                currentUser?.uid
                              );
                              setIsDescriptionSheetOpen(true);
                            }}
                            className="font-extrabold text-white hover:text-[#FF66C4] uppercase text-[11px] tracking-wide transition cursor-pointer inline"
                          >
                            VER MAIS
                          </button>
                        </>
                      ) : (
                        <span>{rawContent}</span>
                      )}
                    </p>
                  </div>
                )}

                {/* Internal Card Overlay Sheet for Full Description ("VER MAIS") or Editing Description */}
                {(isDescriptionSheetOpen || isEditingPost) && (
                  <div
                    onWheel={(e) => e.stopPropagation()}
                    onTouchStart={(e) => e.stopPropagation()}
                    onTouchEnd={(e) => e.stopPropagation()}
                    className="absolute inset-x-3 top-11 bottom-16 z-30 rounded-[18px] bg-[#262626]/98 border border-zinc-700/80 p-4 flex flex-col justify-between shadow-2xl backdrop-blur-md"
                  >
                    <div className="flex items-center justify-between pb-2.5 border-b border-zinc-700/70 shrink-0">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-[#FF66C4]">
                        {isEditingPost
                          ? 'Editar Descrição'
                          : 'Descrição da Publicação'}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setIsDescriptionSheetOpen(false);
                          setIsEditingPost(false);
                        }}
                        className="h-7 w-7 rounded-full bg-[#1E1E1E] text-zinc-300 hover:text-white flex items-center justify-center cursor-pointer"
                        aria-label="Fechar descrição"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>

                    {isEditingPost ? (
                      <div className="flex-1 min-h-0 flex flex-col gap-3 pt-3">
                        <textarea
                          value={editPostText}
                          onChange={(e) => setEditPostText(e.target.value)}
                          maxLength={5000}
                          placeholder="Atualize a descrição da publicação..."
                          className="flex-1 w-full rounded-xl bg-[#1D1D1D] border border-zinc-700 p-3 text-xs sm:text-sm text-white focus:border-[#FF66C4] focus:outline-none resize-none select-text"
                        />
                        <div className="flex items-center justify-end gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => setIsEditingPost(false)}
                            className="px-3.5 py-2 rounded-xl text-xs font-bold text-zinc-300 hover:text-white cursor-pointer"
                          >
                            Cancelar
                          </button>
                          <button
                            type="button"
                            onClick={handleSaveEditPost}
                            disabled={savingPostEdit}
                            className="px-4 py-2 rounded-xl bg-[#FF66C4] hover:bg-[#FF57B2] text-[#181818] text-xs font-extrabold transition disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
                          >
                            {savingPostEdit && (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            )}
                            <span>Salvar</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex-1 min-h-0 overflow-y-auto pt-3 pr-1">
                        <p className="text-xs sm:text-sm text-zinc-100 leading-relaxed whitespace-pre-wrap select-text">
                          {rawContent}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* ROW F: Bottom Inset Solid Pink Action Bar (#FF66C4 rounded on all 4 corners) */}
                <div className="mx-3 mt-2.5 mb-2.5 rounded-[18px] bg-[#FF66C4] px-5 py-2.5 flex items-center justify-between shrink-0">
                  <div className="flex items-center gap-6">
                    {/* Like */}
                    <button
                      type="button"
                      onClick={handleToggleLike}
                      className="min-h-[32px] flex items-center gap-2 transition active:scale-95 cursor-pointer"
                      title={hasLiked ? 'Remover curtida' : 'Curtir'}
                      aria-label="Curtir publicação"
                    >
                      <ThumbsUp
                        className={`h-5 w-5 transition ${
                          hasLiked
                            ? 'fill-white text-white'
                            : 'fill-[#1D1D1D] text-[#1D1D1D]'
                        }`}
                      />
                      <span className="font-extrabold text-sm text-white tabular-nums">
                        {activePost.likesCount || 0}
                      </span>
                    </button>

                    {/* Comments */}
                    <button
                      type="button"
                      onClick={() => setCommentsOpenForPost(activePost)}
                      className="min-h-[32px] flex items-center gap-2 transition active:scale-95 cursor-pointer"
                      title="Ver comentários"
                      aria-label="Abrir comentários"
                    >
                      <MessageCircle className="h-5 w-5 fill-[#1D1D1D] text-[#1D1D1D]" />
                      <span className="font-extrabold text-sm text-white tabular-nums">
                        {activePost.commentsCount || 0}
                      </span>
                    </button>
                  </div>

                  {/* Bookmark / Save */}
                  <button
                    type="button"
                    onClick={handleToggleFavorite}
                    className="min-h-[32px] min-w-[32px] flex items-center justify-end transition active:scale-95 cursor-pointer"
                    title={isSaved ? 'Remover dos salvos' : 'Salvar publicação'}
                    aria-label="Salvar publicação"
                  >
                    <Bookmark
                      className={`h-5 w-5 transition ${
                        isSaved
                          ? 'fill-white text-white'
                          : 'fill-[#1D1D1D] text-[#1D1D1D]'
                      }`}
                    />
                  </button>
                </div>
              </motion.article>
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* 3. BOTTOM DOUBLE CHEVRON ZONE — Click or Swipe Up to Advance to Next Fixed Post */}
      <div className="w-full max-w-[500px] mx-auto h-10 shrink-0 flex items-center justify-center">
        <button
          type="button"
          onClick={advanceToNextPost}
          disabled={initialLoading || sequence.length === 0}
          className="group min-h-[38px] min-w-[64px] flex items-center justify-center text-[#9E9E9E] hover:text-white disabled:opacity-30 transition cursor-pointer"
          title="Próxima publicação"
          aria-label="Passar para a próxima publicação"
        >
          <ChevronsDown className="h-6 w-6 group-active:translate-y-0.5 transition-transform" />
        </button>
      </div>

      {/* Comments Modal */}
      {commentsOpenForPost && (
        <FluxCommentsModal
          isOpen={Boolean(commentsOpenForPost)}
          post={commentsOpenForPost}
          onClose={() => setCommentsOpenForPost(null)}
          onOpenAuth={onOpenAuth}
          onCommentsCountChange={(targetPost, nextCount) => {
            if (nextCount > (targetPost.commentsCount || 0)) {
              engine.recordEngagementSignal(
                targetPost,
                'comment',
                currentUser?.uid
              );
            }
            mutateItemInPlace(targetPost, (p) => ({
              ...p,
              commentsCount: nextCount,
            }));
            setCommentsOpenForPost((prev) =>
              prev && prev.id === targetPost.id
                ? { ...prev, commentsCount: nextCount }
                : prev
            );
          }}
        />
      )}

      {/* Report Modal */}
      <ReportModal
        isOpen={reportTarget.open}
        onClose={() => setReportTarget({ open: false, id: '', summary: '' })}
        targetId={reportTarget.id}
        targetSummary={reportTarget.summary}
        targetType="post"
      />

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmDeleteOpen}
        onClose={() => setConfirmDeleteOpen(false)}
        onConfirm={handleConfirmDeletePost}
        title="Excluir publicação?"
        message="Tem certeza que deseja excluir esta publicação permanentemente? Esta ação não poderá ser desfeita."
        confirmText="Excluir"
        cancelText="Cancelar"
        variant="danger"
        isLoading={deletingPost}
      />
    </div>
  );
};
