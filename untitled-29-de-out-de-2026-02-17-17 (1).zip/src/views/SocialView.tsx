import React, { useEffect, useState } from 'react';
import { FluxFeedItem } from '../types';
import { CommunitiesView } from './CommunitiesView';
import { FluxView } from './FluxView';

export type SocialSubPage = 'communities' | 'flux';

interface SocialViewProps {
  subPage: SocialSubPage;
  onChangeSubPage: (sub: SocialSubPage) => void;
  onBackFromFlux: () => void;
  initialCommunityId?: string;
  onClearInitialCommunity?: () => void;
  initialFluxPost?: FluxFeedItem | null;
  onClearInitialFluxPost?: () => void;
  onOpenCommunityFromFlux: (communityId: string) => void;
  onOpenAuth: () => void;
  onNavigateHome: () => void;
  onNavigateTab: (tab: string) => void;
}

export const SocialView: React.FC<SocialViewProps> = ({
  subPage,
  onChangeSubPage,
  onBackFromFlux,
  initialCommunityId,
  onClearInitialCommunity,
  initialFluxPost,
  onClearInitialFluxPost,
  onOpenCommunityFromFlux,
  onOpenAuth,
  onNavigateHome,
  onNavigateTab,
}) => {
  const [isInsideCommunityRoom, setIsInsideCommunityRoom] = useState(
    Boolean(initialCommunityId)
  );
  const [fluxSessionKey, setFluxSessionKey] = useState(0);

  useEffect(() => {
    if (subPage !== 'communities') {
      setIsInsideCommunityRoom(false);
    }
    if (subPage === 'flux') {
      setFluxSessionKey((prev) => prev + 1);
    }
  }, [subPage]);

  const showSocialTopBar = subPage === 'communities' && !isInsideCommunityRoom;

  return (
    <div
      className={
        subPage === 'flux'
          ? 'h-[100dvh] w-full overflow-hidden bg-[#1D1D1D] text-white flex flex-col'
          : 'min-h-screen bg-[#1D1D1D] text-white flex flex-col'
      }
    >
      {/* TOP SOCIAL NAVIGATION BAR — Visible on Communities listing */}
      {showSocialTopBar && (
        <header className="w-full max-w-[500px] mx-auto px-0 sm:px-0 mb-3.5 sticky top-0 z-30">
          <div className="rounded-b-[28px] bg-[#161616] px-3.5 py-3.5 sm:px-4 sm:py-4 shadow-xl border-b border-zinc-900/80">
            <nav
              aria-label="Navegação Social"
              className="flex items-center justify-between gap-2.5 sm:gap-3"
            >
              {/* INICIO */}
              <button
                type="button"
                onClick={onNavigateHome}
                className="min-h-[44px] px-4 sm:px-5 rounded-[16px] bg-[#242424] hover:bg-[#2B2B2B] border-[1.5px] border-transparent text-white font-extrabold text-xs sm:text-sm tracking-wide uppercase transition cursor-pointer shrink-0"
              >
                INICIO
              </button>

              {/* COMUNIDADES */}
              <button
                type="button"
                onClick={() => {
                  onClearInitialCommunity?.();
                  onChangeSubPage('communities');
                }}
                className={`min-h-[44px] flex-1 px-3 sm:px-5 rounded-[16px] bg-[#242424] hover:bg-[#2B2B2B] text-white font-extrabold text-xs sm:text-sm tracking-wide uppercase transition cursor-pointer border-[1.5px] ${
                  subPage === 'communities'
                    ? 'border-[#FF66C4]'
                    : 'border-transparent'
                }`}
              >
                COMUNIDADES
              </button>

              {/* FLUX */}
              <button
                type="button"
                onClick={() => {
                  onClearInitialCommunity?.();
                  onChangeSubPage('flux');
                }}
                className="min-h-[44px] px-5 sm:px-7 rounded-[16px] bg-[#242424] hover:bg-[#2B2B2B] text-white font-extrabold text-xs sm:text-sm tracking-wide uppercase transition cursor-pointer shrink-0 border-[1.5px] border-transparent hover:border-[#FF66C4]/40"
              >
                FLUX
              </button>
            </nav>
          </div>
        </header>
      )}

      {/* ACTIVE SOCIAL SUB-PAGE */}
      <div className={subPage === 'flux' ? 'flex-1 min-h-0 overflow-hidden' : 'flex-1'}>
        {subPage === 'flux' ? (
          <FluxView
            key={`flux_open_${fluxSessionKey}`}
            onBack={onBackFromFlux}
            onOpenAuth={onOpenAuth}
            initialPost={initialFluxPost}
            onClearInitialPost={onClearInitialFluxPost}
            onOpenCommunity={(communityId) => {
              onOpenCommunityFromFlux(communityId);
            }}
          />
        ) : (
          <CommunitiesView
            initialCommunityId={initialCommunityId}
            onOpenAuth={onOpenAuth}
            onNavigateTab={onNavigateTab}
            onActiveCommunityChange={(inRoom) => {
              setIsInsideCommunityRoom(inRoom);
              if (!inRoom) {
                onClearInitialCommunity?.();
              }
            }}
          />
        )}
      </div>
    </div>
  );
};
