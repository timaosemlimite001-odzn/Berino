import {
  AlertCircle,
  AlertTriangle,
  Award,
  BookCheck,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  CreditCard,
  Crown,
  ExternalLink,
  Flame,
  HelpCircle,
  Instagram,
  Lock,
  QrCode,
  RefreshCw,
  Rocket,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Star,
  Users,
  X,
  Zap,
  Building2,
  FileCheck,
  FileText,
  BadgeCheck,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../services/firebase';
import { useAuth } from '../context/AuthContext';
import {
  cancelSubscription,
  confirmSubscriptionWithReceipt,
  createSubscriptionPixOrder,
  isSubscriptionActive,
  normalizePlanId,
  reactivateSubscription,
  SUBSCRIPTION_PLANS,
} from '../services/subscriptionService';
import {
  cleanReceiptCode,
  generateTestingE2EId,
  ReceiptValidationResult,
  validateReceiptCode,
} from '../utils/receiptValidator';
import { generatePixBrCode } from '../utils/pixPayload';
import {
  activateBookBoost,
  getUserBoostStatus,
  MONTHLY_BOOST_ALLOWANCE,
} from '../services/boostService';
import { Book, BookBoostRecord, WriterBoostQuota } from '../types';

interface SubscriptionsViewProps {
  onOpenAuth: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const SubscriptionsView: React.FC<SubscriptionsViewProps> = ({
  onOpenAuth,
  onNavigateTab,
}) => {
  const { currentUser, userProfile, updateUserProfileData, isDeveloper } = useAuth();

  // Modal checkout state
  const [selectedPlanId, setSelectedPlanId] = useState<'leitor' | 'escritor' | null>(null);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'card'>('pix');
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);
  const [paymentCompletedTxId, setPaymentCompletedTxId] = useState<string>('');
  const [copiedPix, setCopiedPix] = useState(false);

  // Receipt ID Confirmation State
  const [receiptInput, setReceiptInput] = useState('');
  const [validatingReceipt, setValidatingReceipt] = useState(false);
  const [receiptLiveFeedback, setReceiptLiveFeedback] = useState<ReceiptValidationResult | null>(null);
  const [confirmedReceiptDetails, setConfirmedReceiptDetails] = useState<{
    code: string;
    type?: string;
    bankName?: string;
    extractedDate?: string;
  } | null>(null);
  const [pixSubscriptionData, setPixSubscriptionData] = useState<{
    txId: string;
    brCode: string;
    qrCodeDataUrl: string;
    amountBrl: number;
  } | null>(null);
  const [loadingPix, setLoadingPix] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Card form state
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardFormError, setCardFormError] = useState('');

  // Cancellation modal state
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [canceling, setCanceling] = useState(false);
  const [actionError, setActionError] = useState('');

  // Boost management state for Escritor subscribers
  const [boostQuota, setBoostQuota] = useState<WriterBoostQuota | null>(null);
  const [loadingBoosts, setLoadingBoosts] = useState(false);
  const [boostModalOpen, setBoostModalOpen] = useState(false);
  const [authorBooks, setAuthorBooks] = useState<Book[]>([]);
  const [loadingAuthorBooks, setLoadingAuthorBooks] = useState(false);
  const [boostingBookId, setBoostingBookId] = useState<string | null>(null);
  const [boostFeedback, setBoostFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const activeSub = userProfile?.subscription;
  const normalizedCurrentPlan = normalizePlanId(activeSub?.planId);
  const isLeitorActive = isSubscriptionActive(userProfile, 'leitor');
  const isEscritorActive = isSubscriptionActive(userProfile, 'escritor');

  // Load writer boosts if current user has active writer subscription
  const fetchBoostData = async () => {
    if (!currentUser || !isEscritorActive) return;
    setLoadingBoosts(true);
    try {
      const q = await getUserBoostStatus(currentUser.uid);
      setBoostQuota(q);
    } catch (err) {
      console.warn('Error loading boost quota:', err);
    } finally {
      setLoadingBoosts(false);
    }
  };

  useEffect(() => {
    fetchBoostData();
  }, [currentUser?.uid, isEscritorActive]);

  const handleOpenCheckout = async (planId: 'leitor' | 'escritor') => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    setActionError('');
    setCardFormError('');
    setSelectedPlanId(planId);
    setCheckoutSuccess(false);
    setPaymentCompletedTxId('');
    setCopiedPix(false);
    setReceiptInput('');
    setReceiptLiveFeedback(null);
    setConfirmedReceiptDetails(null);
    setCardNumber('');
    setCardHolder('');
    setCardExpiry('');
    setCardCvv('');
    setCheckoutModalOpen(true);
    setLoadingPix(true);

    try {
      const pData = await createSubscriptionPixOrder(planId, {
        id: currentUser.uid,
        email: currentUser.email || '',
      });
      setPixSubscriptionData(pData);
    } catch (err) {
      console.warn('Erro ao carregar Pix dinâmico, gerando fallback estrutural:', err);
      const amount = planId === 'escritor' ? 13.49 : 4.90;
      const fallbackTxId = `PIXSUB${Date.now()}`;
      const brCode = generatePixBrCode({
        pixKey: 'pix@kordel.com.br',
        merchantName: 'KORDEL ASSINATURAS',
        merchantCity: 'BRASILIA',
        amount,
        txId: fallbackTxId,
        description: `KORDEL ${planId === 'escritor' ? 'Escritor' : 'Leitor'}`,
      });
      setPixSubscriptionData({
        txId: fallbackTxId,
        brCode,
        qrCodeDataUrl: '',
        amountBrl: amount,
      });
    } finally {
      setLoadingPix(false);
    }
  };

  // Renderiza QR code Pix em canvas se houver brCode
  useEffect(() => {
    if (pixSubscriptionData?.brCode && canvasRef.current) {
      QRCode.toCanvas(
        canvasRef.current,
        pixSubscriptionData.brCode,
        {
          width: 220,
          margin: 1,
          color: {
            dark: '#141414',
            light: '#F4F4F5',
          },
        },
        (error) => {
          if (error) console.error('[SubscriptionsView] Erro ao renderizar canvas:', error);
        }
      );
    }
  }, [pixSubscriptionData?.brCode, checkoutModalOpen, paymentMethod]);

  const handleCopyPix = () => {
    const code =
      pixSubscriptionData?.brCode ||
      (selectedPlanId === 'escritor'
        ? '00020126580014br.gov.bcb.pix0136pix@kardel.com.br52040000530398654013.495802BR5920KORDEL ASSINATURAS6009SAO PAULO62070503***6304D8C4'
        : '00020126580014br.gov.bcb.pix0136pix@kardel.com.br5204000053039865404.905802BR5920KORDEL ASSINATURAS6009SAO PAULO62070503***6304D8C4');
    navigator.clipboard?.writeText(code);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 3000);
  };

  const handleReceiptInputChange = (val: string) => {
    const clean = cleanReceiptCode(val);
    setReceiptInput(clean);
    setActionError('');
    if (clean.length >= 10) {
      const res = validateReceiptCode(clean);
      setReceiptLiveFeedback(res);
    } else {
      setReceiptLiveFeedback(null);
    }
  };

  const handleFillTestReceipt = () => {
    const testCode = generateTestingE2EId('18236120'); // Nubank Bacen
    handleReceiptInputChange(testCode);
  };

  /**
   * Sistema de confirmação estrita por ID do comprovante de pagamento.
   * Apenas libera a assinatura após validação real da autenticidade e unicidade do comprovante.
   */
  const handleValidateAndConfirmReceipt = async () => {
    if (!currentUser || !userProfile || !selectedPlanId) return;

    setActionError('');
    setCardFormError('');

    const clean = cleanReceiptCode(receiptInput);
    if (!clean) {
      setActionError('Por favor, digite ou cole o ID do comprovante emitido pelo seu banco.');
      return;
    }

    const localCheck = validateReceiptCode(clean);
    if (!localCheck.isValid) {
      setActionError(localCheck.error || 'Código do comprovante inválido.');
      return;
    }

    setValidatingReceipt(true);
    try {
      const res = await confirmSubscriptionWithReceipt(
        userProfile,
        selectedPlanId,
        clean,
        pixSubscriptionData?.txId
      );

      // Atualiza perfil no AuthContext para refletir selos e assinatura ativa instantaneamente
      await updateUserProfileData({
        subscription: res.updatedProfile.subscription,
        hasExperiencedReaderBadge: res.updatedProfile.hasExperiencedReaderBadge,
        hasKardelProBadge: res.updatedProfile.hasKardelProBadge,
        isVerifiedWriter: res.updatedProfile.isVerifiedWriter,
        isVerifiedWriterSuspended: res.updatedProfile.isVerifiedWriterSuspended,
        ...(res.updatedProfile.role ? { role: res.updatedProfile.role } : {}),
      });

      setConfirmedReceiptDetails(res.receiptInfo);
      setPaymentCompletedTxId(res.txId);
      setCheckoutSuccess(true);
      fetchBoostData();
    } catch (err: any) {
      console.error('Erro na validação do comprovante:', err);
      setActionError(
        err.message || 'Falha ao validar comprovante bancário. Verifique os dados digitados.'
      );
    } finally {
      setValidatingReceipt(false);
    }
  };

  const handleCancelSub = async () => {
    if (!currentUser || !userProfile || !activeSub) return;
    setCanceling(true);
    setActionError('');
    try {
      const updatedProfile = await cancelSubscription(userProfile);
      await updateUserProfileData({
        subscription: updatedProfile.subscription,
      });
      setCancelModalOpen(false);
    } catch (err: any) {
      console.error('Error canceling subscription:', err);
      setActionError(err.message || 'Erro ao cancelar renovação da assinatura.');
    } finally {
      setCanceling(false);
    }
  };

  const handleReactivateSub = async () => {
    if (!currentUser || !userProfile || !activeSub) return;
    setActionError('');
    try {
      const updatedProfile = await reactivateSubscription(userProfile);
      await updateUserProfileData({
        subscription: updatedProfile.subscription,
      });
    } catch (err: any) {
      console.error('Error reactivating subscription:', err);
      setActionError(err.message || 'Erro ao reativar assinatura.');
    }
  };

  // Open boost selector modal and load author's published books
  const handleOpenBoostModal = async () => {
    if (!currentUser) return;
    setBoostFeedback(null);
    setBoostModalOpen(true);
    setLoadingAuthorBooks(true);
    try {
      const bRef = collection(db, 'books');
      const q = query(bRef, where('authorId', '==', currentUser.uid));
      const snap = await getDocs(q);
      const bList: Book[] = [];
      snap.forEach((d) => {
        const data = { id: d.id, ...d.data() } as Book;
        if (data.status !== 'draft') {
          bList.push(data);
        }
      });
      setAuthorBooks(bList);
    } catch (err) {
      console.error('Error loading author books for boost:', err);
    } finally {
      setLoadingAuthorBooks(false);
    }
  };

  const handleApplyBoost = async (bookId: string) => {
    if (!userProfile) return;
    setBoostingBookId(bookId);
    setBoostFeedback(null);
    try {
      const res = await activateBookBoost(userProfile, bookId);
      setBoostFeedback({ type: 'success', message: res.message });
      await fetchBoostData();
    } catch (err: any) {
      setBoostFeedback({ type: 'error', message: err.message || 'Erro ao impulsionar obra.' });
    } finally {
      setBoostingBookId(null);
    }
  };

  const leitorPlan = SUBSCRIPTION_PLANS.leitor;
  const escritorPlan = SUBSCRIPTION_PLANS.escritor;

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:py-12 space-y-10 animate-fade-in text-white">
      {/* Header */}
      <div className="text-center space-y-3 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 rounded-full bg-[#FF57B2]/15 text-[#FF57B2] px-4 py-1.5 text-xs font-black uppercase tracking-wider border border-[#FF57B2]/30 shadow-2xs">
          <Crown className="h-3.5 w-3.5 text-[#FF57B2]" />
          <span>Assinaturas Oficiais KORDEL</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-white font-display tracking-tight">
          Escolha seu Plano no KORDEL
        </h1>
        <p className="text-xs sm:text-base text-zinc-400 font-literary leading-relaxed">
          Duas modalidades exclusivas desenvolvidas sob medida para leitores assíduos e autores da literatura.
        </p>

        <div className="inline-flex items-center gap-2 text-[11px] sm:text-xs text-zinc-300 bg-[#202020] border border-zinc-800 px-4 py-2 rounded-2xl">
          <CheckCircle2 className="h-4 w-4 text-[#FF57B2] shrink-0" />
          <span>
            <strong className="text-white">Garantia KORDEL:</strong> Leitura livre de obras, publicação e comunidades permanecem gratuitas.
          </span>
        </div>
      </div>

      {/* Active Subscription Banner */}
      {activeSub && (
        <div className="rounded-3xl border border-[#FF57B2]/40 bg-[#202020] p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2.5 flex-wrap">
                <span className="text-xs uppercase font-bold text-[#FF57B2] tracking-wider">
                  Sua Assinatura Ativa
                </span>
                <span
                  className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-black uppercase tracking-wider border ${
                    activeSub.status === 'active'
                      ? 'bg-[#FF57B2]/20 text-[#FF80C5] border-[#FF57B2]/40'
                      : 'bg-[#262626] text-zinc-300 border-zinc-700'
                  }`}
                >
                  {activeSub.status === 'active' ? 'Ativa & Liberada' : activeSub.status}
                </span>

                {isEscritorActive && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-[#262626] text-[#FF80C5] px-2.5 py-0.5 text-xs font-bold border border-[#FF57B2]/30">
                    <ShieldCheck className="h-3 w-3 text-[#FF57B2]" />
                    Selo Escritor Verificado Ativo
                  </span>
                )}

                {isLeitorActive && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-[#262626] text-[#FF80C5] px-2.5 py-0.5 text-xs font-bold border border-[#FF57B2]/30">
                    <Award className="h-3 w-3 text-[#FF57B2]" />
                    Selo Leitor Experiente Ativo
                  </span>
                )}
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-white font-display">
                {activeSub.planName}
              </h2>

              <p className="text-xs text-zinc-400">
                Valor mensal: <strong className="text-white">R$ {activeSub.price.toFixed(2).replace('.', ',')} / mês</strong> • Renovação:{' '}
                <strong className="text-white">{activeSub.autoRenew ? 'Automática mensal' : 'Desativada (não renovará)'}</strong>
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {activeSub.autoRenew ? (
                <button
                  type="button"
                  onClick={() => setCancelModalOpen(true)}
                  className="rounded-2xl border border-zinc-700 bg-[#262626] px-4 py-2 text-xs font-bold text-zinc-300 hover:text-[#FF80C5] hover:border-[#FF57B2] transition cursor-pointer shadow-xs"
                >
                  Cancelar Renovação
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleReactivateSub}
                  className="rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer shadow-xs flex items-center gap-1.5"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Reativar Renovação</span>
                </button>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-zinc-800 flex flex-wrap items-center gap-6 text-xs text-zinc-400">
            <div>
              Início do Período:{' '}
              <strong className="text-white">
                {new Date(activeSub.startedAt).toLocaleDateString('pt-BR')}
              </strong>
            </div>
            <div>
              Vencimento / Próxima Cobrança:{' '}
              <strong className="text-white">
                {new Date(activeSub.currentPeriodEnd).toLocaleDateString('pt-BR')}
              </strong>
            </div>
            <div>
              Pagamento Confirmado via:{' '}
              <strong className="text-white">
                {activeSub.paymentMethod || 'Pix Instantâneo'}
              </strong>
            </div>
          </div>
        </div>
      )}

      {/* Seção Exclusiva: Painel de Impulsionamento do Escritor (Quando Assinante Escritor Ativo) */}
      {isEscritorActive && (
        <div className="rounded-3xl border-2 border-[#FF57B2]/40 bg-[#202020] p-6 sm:p-8 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-[#FF57B2]">
                <Rocket className="h-4 w-4 text-[#FF57B2]" />
                <span>Gestão de Impulsionamentos Mensais</span>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-white font-display">
                2 Impulsionamentos de 7 Dias por Ciclo
              </h3>
              <p className="text-xs text-zinc-300 font-literary leading-relaxed max-w-2xl">
                Você tem direito a <strong>2 impulsionamentos a cada mês</strong>. Cada ativação destaca sua obra com prioridade editorial no topo da plataforma por exatamente 7 dias corridos.
              </p>
            </div>

            <div className="shrink-0 flex items-center gap-3">
              <div className="text-right tabular-nums">
                <span className="text-[10px] text-zinc-400 uppercase font-bold block">Disponíveis</span>
                <span className="text-2xl font-black text-[#FF57B2] font-display">
                  {boostQuota ? boostQuota.availableCount : '2'}{' '}
                  <span className="text-xs font-normal text-zinc-400">/ 2</span>
                </span>
              </div>

              <button
                type="button"
                onClick={handleOpenBoostModal}
                disabled={boostQuota?.availableCount === 0}
                className="rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] disabled:opacity-50 text-white px-5 py-2.5 text-xs font-black uppercase tracking-wider transition shadow-md border border-[#FF57B2] cursor-pointer flex items-center gap-2"
              >
                <Rocket className="h-4 w-4" />
                <span>Escolher Obra para Impulsionar</span>
              </button>
            </div>
          </div>

          {/* Lista de Impulsionamentos Ativos no Momento */}
          {boostQuota && boostQuota.activeBoosts.length > 0 && (
            <div className="pt-3 border-t border-zinc-800 space-y-2">
              <span className="text-xs font-bold text-zinc-200">
                Obras Impulsionadas Atualmente:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {boostQuota.activeBoosts.map((boost) => {
                  const daysLeft = Math.max(
                    0,
                    Math.ceil((new Date(boost.expiresAt).getTime() - Date.now()) / (24 * 60 * 60 * 1000))
                  );

                  return (
                    <div
                      key={boost.id}
                      className="p-3.5 rounded-2xl bg-[#262626] border border-[#FF57B2]/40 flex items-center justify-between gap-3 shadow-2xs"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {boost.bookCoverUrl ? (
                          <img
                            src={boost.bookCoverUrl}
                            alt={boost.bookTitle}
                            className="h-12 w-9 rounded-lg object-cover shrink-0"
                          />
                        ) : (
                          <div className="h-12 w-9 rounded-lg bg-[#181818] flex items-center justify-center shrink-0">
                            <Rocket className="h-4 w-4 text-[#FF57B2]" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <h4 className="font-bold text-xs text-white truncate">
                            {boost.bookTitle}
                          </h4>
                          <span className="text-[11px] text-zinc-400 block">
                            Ativado em: {new Date(boost.activatedAt).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                      </div>

                      <div className="shrink-0 text-right">
                        <span className="inline-flex items-center gap-1 rounded-full bg-[#FF57B2]/20 border border-[#FF57B2]/40 text-[#FF80C5] px-2 py-0.5 text-[10px] font-bold">
                          <Clock className="h-3 w-3" />
                          {daysLeft} dia{daysLeft !== 1 ? 's' : ''} restante{daysLeft !== 1 ? 's' : ''}
                        </span>
                        <span className="text-[10px] text-zinc-400 block pt-0.5">
                          Expira: {new Date(boost.expiresAt).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Grid com APENAS as DUAS MODALIDADES OFICIAIS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
        {/* 1. ASSINATURA LEITOR — R$ 4,90/mês */}
        <div className="rounded-3xl bg-[#202020] border border-zinc-800 hover:border-[#FF57B2]/50 transition p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute inset-x-0 top-0 h-[1.5px] bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-[#262626] border border-zinc-700 text-zinc-200 px-3 py-1 text-xs font-black uppercase tracking-wider">
                  <Sparkles className="h-3.5 w-3.5 text-[#FF57B2]" />
                  <span>Para Leitores</span>
                </span>
                <span className="rounded-md bg-[#262626] border border-zinc-700 text-[#FF80C5] font-bold text-[10px] uppercase px-2.5 py-0.5 tracking-wider">
                  {leitorPlan.badgeText}
                </span>
              </div>

              <h3 className="text-2xl font-black text-white font-display">
                {leitorPlan.name}
              </h3>
              <p className="text-xs text-zinc-400 font-literary leading-relaxed">
                {leitorPlan.description}
              </p>
            </div>

            {/* Price */}
            <div className="rounded-2xl bg-[#181818] p-4 border border-zinc-800 flex items-baseline gap-2 tabular-nums">
              <span className="text-3xl sm:text-4xl font-black text-white font-display">
                R$ {leitorPlan.price.toFixed(2).replace('.', ',')}
              </span>
              <span className="text-xs text-zinc-400 font-semibold">
                / {leitorPlan.periodLabel}
              </span>
            </div>

            {/* Benefits List */}
            <div className="space-y-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider block">
                Benefícios Inclusos:
              </span>
              <ul className="space-y-2.5">
                {leitorPlan.benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs text-zinc-300">
                    <div className="rounded-full bg-[#262626] text-[#FF57B2] border border-[#FF57B2]/40 p-0.5 mt-0.5 shrink-0">
                      <Check className="h-3 w-3 stroke-[3]" />
                    </div>
                    <span className="leading-relaxed">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Action Button */}
          <div className="pt-6 mt-6 border-t border-zinc-800">
            {isLeitorActive ? (
              <button
                type="button"
                disabled
                className="w-full rounded-2xl bg-[#262626] border border-[#FF57B2]/50 text-[#FF80C5] py-3.5 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-default"
              >
                <CheckCircle2 className="h-4 w-4 text-[#FF57B2]" />
                <span>Assinatura Leitor Ativa</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleOpenCheckout('leitor')}
                className="w-full rounded-2xl bg-[#262626] hover:bg-gradient-to-r hover:from-[#FF57B2] hover:to-[#E03595] border border-[#FF57B2]/60 text-white py-3.5 text-xs font-black uppercase tracking-wider transition shadow-sm cursor-pointer flex items-center justify-center gap-2"
              >
                <Sparkles className="h-4 w-4 text-[#FF57B2]" />
                <span>Assinar Leitor (R$ 4,90/mês)</span>
              </button>
            )}
          </div>
        </div>

        {/* 2. ASSINATURA ESCRITOR — R$ 13,49/mês */}
        <div className="rounded-3xl border-2 border-[#FF57B2]/60 bg-[#262626] p-6 sm:p-8 flex flex-col justify-between shadow-[0_8px_30px_rgba(255,87,178,0.2)] relative overflow-hidden">
          <div className="absolute inset-x-0 top-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#FF80C5]/40 to-transparent pointer-events-none z-10" />
          <div className="absolute top-0 right-0 bg-[#FF57B2] text-white text-[9px] font-black uppercase tracking-widest px-4 py-1 rounded-bl-2xl border-b border-l border-[#FF57B2] z-10">
            Exclusivo Autores
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-[#FF57B2]/15 text-[#FF80C5] px-3 py-1 text-xs font-black uppercase tracking-wider border border-[#FF57B2]/30">
                  <ShieldCheck className="h-3.5 w-3.5 text-[#FF57B2]" />
                  <span>Para Autores & Obras</span>
                </span>
              </div>

              <h3 className="text-2xl font-black text-white font-display">
                {escritorPlan.name}
              </h3>
              <p className="text-xs text-zinc-300 font-literary leading-relaxed">
                {escritorPlan.description}
              </p>
            </div>

            {/* Price */}
            <div className="rounded-2xl bg-[#181818] p-4 border border-[#FF57B2]/50 flex items-baseline gap-2 shadow-xs tabular-nums">
              <span className="text-3xl sm:text-4xl font-black text-white font-display">
                R$ {escritorPlan.price.toFixed(2).replace('.', ',')}
              </span>
              <span className="text-xs text-[#FF80C5] font-semibold">
                / {escritorPlan.periodLabel}
              </span>
            </div>

            {/* Benefits List */}
            <div className="space-y-3">
              <span className="text-xs font-bold text-[#FF80C5] uppercase tracking-wider block">
                Benefícios Inclusos:
              </span>
              <ul className="space-y-2.5">
                {escritorPlan.benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs text-zinc-200">
                    <div className="rounded-full bg-[#181818] text-[#FF57B2] border border-[#FF57B2]/50 p-0.5 mt-0.5 shrink-0">
                      <Check className="h-3 w-3 stroke-[3]" />
                    </div>
                    <span className="leading-relaxed font-medium">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Action Button */}
          <div className="pt-6 mt-6 border-t border-zinc-800">
            {isEscritorActive ? (
              <button
                type="button"
                disabled
                className="w-full rounded-2xl bg-[#181818] border border-[#FF57B2]/50 text-[#FF80C5] py-3.5 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-default"
              >
                <CheckCircle2 className="h-4 w-4 text-[#FF57B2]" />
                <span>Assinatura Escritor Ativa</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleOpenCheckout('escritor')}
                className="w-full rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white py-3.5 text-xs font-black uppercase tracking-wider transition shadow-md hover:shadow-lg border border-[#FF57B2] cursor-pointer flex items-center justify-center gap-2"
              >
                <Crown className="h-4 w-4" />
                <span>Assinar Escritor (R$ 13,49/mês)</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Instagram Spotlight & Author Honors Section */}
      <div className="rounded-3xl border border-[#FF57B2]/40 bg-[#202020] p-6 sm:p-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-[#FF57B2]">
              <Instagram className="h-4 w-4" />
              <span>Divulgação Oficial no Instagram</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white font-display">
              Quadros, Campanhas e Homenagens no @kardel.oficial
            </h3>
            <p className="text-xs text-zinc-300 font-literary leading-relaxed max-w-3xl">
              Assinantes do plano <strong className="text-white">Escritor</strong> têm suas obras e trajetória literária integradas em publicações editoriais, carrosséis de recomendações e entrevistas oficiais nas redes sociais do KORDEL.
            </p>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <span className="rounded-xl bg-[#262626] border border-[#FF57B2]/40 text-[#FF80C5] font-bold px-3 py-1.5 text-xs flex items-center gap-1">
              <Sparkles className="h-3.5 w-3.5 text-[#FF57B2]" />
              <span>@kardel.oficial</span>
            </span>
          </div>
        </div>
      </div>

      {/* Modal para Escolher Obra e Aplicar Impulsionamento de 7 Dias */}
      {boostModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-fade-in">
          <div className="relative w-full max-w-lg rounded-3xl bg-[#202020] border border-zinc-800 p-6 sm:p-8 shadow-2xl space-y-5 max-h-[85vh] overflow-y-auto text-white">
            <button
              type="button"
              onClick={() => setBoostModalOpen(false)}
              className="absolute top-5 right-5 text-zinc-400 hover:text-white p-1 rounded-full hover:bg-zinc-800 transition cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1 text-xs uppercase font-bold text-[#FF57B2] tracking-wider">
                <Rocket className="h-3.5 w-3.5" />
                <span>Impulsionamento Literário de 7 Dias</span>
              </div>
              <h3 className="text-xl font-black text-white font-display">
                Escolha a Obra para Impulsionar
              </h3>
              <p className="text-xs text-zinc-400">
                Disponíveis neste ciclo:{' '}
                <strong className="text-white">{boostQuota?.availableCount || 0} de {MONTHLY_BOOST_ALLOWANCE}</strong>. A obra selecionada receberá destaque especial na vitrine por 7 dias.
              </p>
            </div>

            {boostFeedback && (
              <div className="p-3 rounded-2xl text-xs flex items-center gap-2 border border-[#FF57B2]/50 bg-[#262626] text-white">
                {boostFeedback.type === 'success' ? (
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-[#FF57B2]" />
                ) : (
                  <AlertCircle className="h-4 w-4 shrink-0 text-[#FF80C5]" />
                )}
                <span>{boostFeedback.message}</span>
              </div>
            )}

            {loadingAuthorBooks ? (
              <div className="py-8 text-center text-xs text-zinc-400 flex items-center justify-center gap-2">
                <RefreshCw className="h-4 w-4 animate-spin text-[#FF57B2]" />
                <span>Carregando suas obras publicadas...</span>
              </div>
            ) : authorBooks.length === 0 ? (
              <div className="py-6 text-center text-xs text-zinc-400 space-y-2">
                <p>Você ainda não possui obras publicadas para impulsionar.</p>
                {onNavigateTab && (
                  <button
                    type="button"
                    onClick={() => {
                      setBoostModalOpen(false);
                      onNavigateTab('author_studio');
                    }}
                    className="text-[#FF57B2] font-bold hover:underline cursor-pointer"
                  >
                    Ir para o Estúdio do Autor →
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {authorBooks.map((b) => {
                  const isCurrentlyBoosted =
                    b.isBoosted && b.boostExpiresAt && new Date(b.boostExpiresAt).getTime() > Date.now();

                  return (
                    <div
                      key={b.id}
                      className="p-3.5 rounded-2xl border border-zinc-800 bg-[#262626] flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {b.coverUrl ? (
                          <img
                            src={b.coverUrl}
                            alt={b.title}
                            className="h-12 w-9 rounded-lg object-cover shrink-0"
                          />
                        ) : (
                          <div className="h-12 w-9 rounded-lg bg-[#181818] flex items-center justify-center shrink-0">
                            <Rocket className="h-4 w-4 text-zinc-400" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <h4 className="font-bold text-xs text-white truncate">
                            {b.title}
                          </h4>
                          <span className="text-[11px] text-zinc-400 block tabular-nums">
                            {b.viewsCount || 0} visualizações • {b.likesCount || 0} curtidas
                          </span>
                        </div>
                      </div>

                      <div className="shrink-0">
                        {isCurrentlyBoosted ? (
                          <span className="inline-flex items-center gap-1 rounded-xl bg-[#FF57B2]/20 border border-[#FF57B2]/40 text-[#FF80C5] px-3 py-1.5 text-[11px] font-bold">
                            <Check className="h-3.5 w-3.5" />
                            Já Impulsionada
                          </span>
                        ) : (
                          <button
                            type="button"
                            disabled={boostingBookId === b.id || (boostQuota?.availableCount || 0) <= 0}
                            onClick={() => handleApplyBoost(b.id)}
                            className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] disabled:opacity-50 text-white px-3.5 py-1.5 text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-2xs"
                          >
                            {boostingBookId === b.id ? (
                              <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Rocket className="h-3.5 w-3.5" />
                            )}
                            <span>Impulsionar (7d)</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setBoostModalOpen(false)}
                className="px-4 py-2 text-xs font-bold text-zinc-400 hover:text-white cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Checkout Modal com Pagamento Obrigatório */}
      {checkoutModalOpen && selectedPlanId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-fade-in">
          <div className="relative w-full max-w-lg rounded-3xl bg-[#202020] border border-zinc-800 p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto text-white">
            <button
              type="button"
              onClick={() => setCheckoutModalOpen(false)}
              className="absolute top-5 right-5 text-zinc-400 hover:text-white p-1 rounded-full hover:bg-zinc-800 transition cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>

            {checkoutSuccess ? (
              <div className="text-center py-4 space-y-4 animate-fade-in">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#FF57B2]/20 border border-[#FF57B2]/40 text-[#FF57B2] shadow-inner">
                  <CheckCircle2 className="h-10 w-10" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-black uppercase tracking-wider text-[#FF80C5]">
                    Comprovante Validado & Assinatura Liberada
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white font-display">
                    {SUBSCRIPTION_PLANS[selectedPlanId].name} Ativo!
                  </h3>
                  <p className="text-xs text-zinc-300 font-literary max-w-sm mx-auto">
                    A veracidade do seu comprovante bancário foi validada e confirmada. Todos os benefícios exclusivos da assinatura já foram liberados na sua conta.
                  </p>
                </div>

                {/* Comprovante Autenticado */}
                <div className="rounded-2xl bg-[#262626] p-4 border border-zinc-800 text-left text-xs space-y-2.5">
                  <div className="flex justify-between items-center pb-2 border-b border-zinc-800">
                    <span className="text-zinc-400 font-medium">Status da Validação:</span>
                    <span className="inline-flex items-center gap-1 rounded-full bg-[#FF57B2]/20 border border-[#FF57B2]/40 px-2 py-0.5 text-[10px] font-bold text-[#FF80C5]">
                      <BadgeCheck className="h-3.5 w-3.5 text-[#FF57B2]" />
                      Autenticado e Confirmado
                    </span>
                  </div>

                  {confirmedReceiptDetails?.code && (
                    <div className="space-y-0.5">
                      <span className="text-zinc-400 text-[11px] block">ID do Comprovante Bancário:</span>
                      <strong className="text-white font-mono text-[11px] break-all block bg-[#181818] p-2 rounded-lg border border-zinc-800">
                        {confirmedReceiptDetails.code}
                      </strong>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span className="text-zinc-400">Instituição Emissora:</span>
                    <strong className="text-white">
                      {confirmedReceiptDetails?.bankName || 'Instituição Financeira Autorizada Bacen'}
                    </strong>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-zinc-400">Tipo de Autenticação:</span>
                    <span className="text-white font-medium">
                      {confirmedReceiptDetails?.type === 'e2e_pix'
                        ? 'ID Fim-a-Fim Pix do Banco Central'
                        : 'Código de Autenticação Eletrônica'}
                    </span>
                  </div>

                  {confirmedReceiptDetails?.extractedDate && (
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Data no Comprovante:</span>
                      <span className="text-white font-medium">
                        {confirmedReceiptDetails.extractedDate}
                      </span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span className="text-zinc-400">Valor Confirmado:</span>
                    <strong className="text-white">
                      R$ {SUBSCRIPTION_PLANS[selectedPlanId].price.toFixed(2).replace('.', ',')}
                    </strong>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-zinc-400">Protocolo da Plataforma:</span>
                    <code className="text-zinc-300 font-mono text-[10px]">
                      {paymentCompletedTxId}
                    </code>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setCheckoutModalOpen(false)}
                  className="w-full rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white py-3 text-xs font-bold uppercase tracking-wider hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer shadow-md"
                >
                  Concluir e Aproveitar Benefícios
                </button>
              </div>
            ) : (
              <>
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 text-xs uppercase font-bold text-[#FF57B2] tracking-wider">
                    <Lock className="h-3.5 w-3.5" />
                    <span>Confirmação Obrigatória de Pagamento</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-white font-display">
                    {SUBSCRIPTION_PLANS[selectedPlanId].name}
                  </h3>
                  <p className="text-xs text-zinc-400">
                    R$ {SUBSCRIPTION_PLANS[selectedPlanId].price.toFixed(2).replace('.', ',')} por mês • A assinatura só é liberada após a validação e confirmação da autenticidade do comprovante de pagamento
                  </p>
                </div>

                {/* Seleção do Método de Pagamento */}
                <div className="space-y-2.5">
                  <span className="text-xs font-bold text-zinc-300">
                    Forma de pagamento:
                  </span>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('pix')}
                      className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition cursor-pointer ${
                        paymentMethod === 'pix'
                          ? 'border-[#FF57B2] bg-[#262626] text-[#FF80C5] font-bold ring-2 ring-[#FF57B2]/60 shadow-xs'
                          : 'border-zinc-800 bg-[#181818] hover:bg-[#262626] text-zinc-300'
                      }`}
                    >
                      <QrCode className="h-5 w-5 shrink-0 text-[#FF57B2]" />
                      <div>
                        <div className="text-xs font-bold text-white">Pix Instantâneo</div>
                        <div className="text-[10px] opacity-70">Validação por ID do comprovante</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card')}
                      className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition cursor-pointer ${
                        paymentMethod === 'card'
                          ? 'border-[#FF57B2] bg-[#262626] text-[#FF80C5] font-bold ring-2 ring-[#FF57B2]/60 shadow-xs'
                          : 'border-zinc-800 bg-[#181818] hover:bg-[#262626] text-zinc-300'
                      }`}
                    >
                      <CreditCard className="h-5 w-5 shrink-0 text-[#FF57B2]" />
                      <div>
                        <div className="text-xs font-bold text-white">Cartão de Crédito</div>
                        <div className="text-[10px] opacity-70">Renovação recorrente</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Se PIX: QR Code, Copia e Cola e Sistema de Validação por ID */}
                {paymentMethod === 'pix' && (
                  <div className="space-y-4">
                    {/* Área do QR Code Pix */}
                    <div className="rounded-2xl border border-[#FF57B2]/50 bg-[#262626] p-4 space-y-4">
                      <div className="flex flex-col sm:flex-row items-center gap-4">
                        <div className="h-36 w-36 shrink-0 bg-[#181818] p-2 rounded-2xl border border-[#FF57B2]/60 flex flex-col items-center justify-center shadow-xs">
                          {loadingPix ? (
                            <div className="flex flex-col items-center justify-center py-6">
                              <RefreshCw className="h-6 w-6 animate-spin text-[#FF57B2] mb-1" />
                              <span className="text-[9px] text-zinc-400">Gerando Pix...</span>
                            </div>
                          ) : (
                            <>
                              <canvas ref={canvasRef} className="rounded-lg max-w-[125px] h-auto" />
                              <span className="text-[8px] font-black text-[#FF80C5] tracking-wider mt-1">PIX OFICIAL</span>
                            </>
                          )}
                        </div>

                        <div className="space-y-1.5 text-center sm:text-left text-xs">
                          <div className="inline-flex items-center gap-1.5 rounded-full bg-[#181818] text-[#FF80C5] border border-[#FF57B2]/60 px-2.5 py-0.5 text-[10px] font-black">
                            <span className="h-1.5 w-1.5 rounded-full bg-[#FF57B2] animate-ping" />
                            Aguardando pagamento & comprovante
                          </div>
                          <p className="font-bold text-white">
                            1. Pague pelo QR Code ou copie o código Pix abaixo
                          </p>
                          <p className="text-[11px] text-zinc-400">
                            Beneficiário: KORDEL ASSINATURAS LTDA • Banco Central do Brasil
                          </p>
                          <p className="text-[11px] text-zinc-400">
                            Valor exato: <strong className="text-white">R$ {SUBSCRIPTION_PLANS[selectedPlanId].price.toFixed(2).replace('.', ',')}</strong>
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleCopyPix}
                        className="w-full rounded-xl border border-[#FF57B2]/60 bg-[#181818] py-2.5 px-3 text-xs font-bold text-zinc-200 hover:bg-[#2B2B2B] hover:text-white transition flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                      >
                        {copiedPix ? (
                          <>
                            <Check className="h-4 w-4 text-[#FF57B2]" />
                            <span className="text-[#FF80C5]">Código Pix Copiado!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="h-4 w-4 text-zinc-400" />
                            <span>Copiar Código Pix Copia e Cola</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* SISTEMA DE CONFIRMAÇÃO POR ID DO COMPROVANTE DE PAGAMENTO */}
                    <div className="rounded-2xl border-2 border-[#FF57B2]/50 bg-[#262626] p-4 sm:p-5 space-y-3.5">
                      <div className="flex items-center gap-2">
                        <FileCheck className="h-5 w-5 text-[#FF57B2] shrink-0" />
                        <div>
                          <h4 className="text-xs font-black uppercase tracking-wider text-white">
                            2. Confirmação por ID do Comprovante de Pagamento
                          </h4>
                          <span className="text-[11px] text-zinc-400">
                            Obrigatório: validação de veracidade antes da liberação
                          </span>
                        </div>
                      </div>

                      {/* Orientações claras de onde encontrar o ID */}
                      <div className="rounded-xl bg-[#181818] p-3 border border-zinc-800 text-[11px] text-zinc-300 space-y-1.5 leading-relaxed">
                        <p className="font-semibold text-white">
                          Como localizar o ID no comprovante do seu banco:
                        </p>
                        <ol className="list-decimal list-inside space-y-1 text-zinc-400">
                          <li>Abra o comprovante da transferência Pix no app do seu banco (Nubank, Itaú, Bradesco, Inter, Caixa, Santander, etc.).</li>
                          <li>
                            Localize o <strong className="text-white">ID da Transação / ID Fim-a-Fim</strong> (código oficial de 32 caracteres iniciado por <strong className="text-white">"E..."</strong>) ou o <strong className="text-white">Código de Autenticação Eletrônica</strong>.
                          </li>
                          <li>Cole o código no campo abaixo para validação instantânea da veracidade.</li>
                        </ol>
                      </div>

                      {/* Campo de Entrada do ID do Comprovante */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-zinc-200 block">
                          ID da Transação Pix (ID Fim-a-Fim) ou Autenticação Bancária:
                        </label>
                        <input
                          type="text"
                          value={receiptInput}
                          onChange={(e) => handleReceiptInputChange(e.target.value)}
                          placeholder="Ex: E18236120202610011400a1b2c3d4e5f ou código de autenticação..."
                          className="w-full rounded-xl border border-zinc-700 bg-[#181818] px-3.5 py-2.5 text-xs text-white font-mono tracking-wide placeholder:font-sans placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-hidden shadow-2xs uppercase"
                        />
                      </div>

                      {/* Feedback em Tempo Real da Validação Estrutural e Institucional */}
                      {receiptLiveFeedback?.isValid ? (
                        <div className="rounded-xl bg-[#FF57B2]/15 border border-[#FF57B2]/50 p-2.5 text-xs text-[#FF80C5] flex items-start gap-2 animate-fade-in">
                          <CheckCircle2 className="h-4 w-4 shrink-0 text-[#FF57B2] mt-0.5" />
                          <div className="space-y-0.5">
                            <strong className="block text-white">Comprovante Válido: {receiptLiveFeedback.bankName}</strong>
                            <p className="text-[11px] text-zinc-200">
                              {receiptLiveFeedback.type === 'e2e_pix'
                                ? 'ID Fim-a-Fim Pix oficial do Banco Central reconhecido.'
                                : 'Código de Autenticação Eletrônica com alta variedade criptográfica.'}
                              {receiptLiveFeedback.extractedDate && (
                                <span className="block mt-0.5">Data/Hora no comprovante: {receiptLiveFeedback.extractedDate}</span>
                              )}
                            </p>
                          </div>
                        </div>
                      ) : receiptInput.length > 5 ? (
                        <div className="rounded-xl bg-[#181818] border border-[#FF57B2]/40 p-2.5 text-xs text-zinc-200 flex items-start gap-2 animate-fade-in">
                          <AlertTriangle className="h-4 w-4 shrink-0 text-[#FF80C5] mt-0.5" />
                          <div className="text-[11px]">
                            {receiptLiveFeedback?.error ||
                              'Digite o código completo com pelo menos 14 caracteres emitido pelo seu banco.'}
                          </div>
                        </div>
                      ) : null}

                      {/* Botão de Homologação para Desenvolvedor */}
                      {isDeveloper && (
                        <div className="pt-1 flex items-center justify-between">
                          <button
                            type="button"
                            onClick={handleFillTestReceipt}
                            className="text-[10px] text-[#FF80C5] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Sparkles className="h-3 w-3 text-[#FF57B2]" />
                            Homologação: Preencher ID Fim-a-Fim Válido para Teste
                          </button>
                          <span className="text-[9px] text-zinc-400">
                            (Anti-replay ativo: cada código só ativa 1 vez)
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {paymentMethod === 'card' && (
                  <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-4 space-y-3">
                    <div className="rounded-xl bg-[#181818] border border-[#FF57B2]/40 p-3 text-xs text-zinc-200 flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 shrink-0 text-[#FF57B2] mt-0.5" />
                      <div className="space-y-0.5">
                        <strong className="block text-white">Aviso sobre Pagamento por Cartão</strong>
                        <p className="text-[11px] text-zinc-300">
                          Para liberação instantânea e automática em segundos, utilize o <strong className="text-white">Pix com confirmação por ID do comprovante</strong>.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-zinc-300 block">
                        Número do Cartão
                      </label>
                      <input
                        type="text"
                        placeholder="0000 0000 0000 0000"
                        maxLength={19}
                        value={cardNumber}
                        onChange={(e) => {
                          const v = e.target.value.replace(/\D/g, '').replace(/(\d{4})/g, '$1 ').trim();
                          setCardNumber(v);
                        }}
                        className="w-full rounded-xl border border-zinc-700 bg-[#181818] px-3 py-2 text-xs text-white placeholder-zinc-500 font-mono focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-hidden"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-zinc-300 block">
                        Nome Impresso no Cartão
                      </label>
                      <input
                        type="text"
                        placeholder="NOME COMO NO CARTAO"
                        value={cardHolder}
                        onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
                        className="w-full rounded-xl border border-zinc-700 bg-[#181818] px-3 py-2 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-hidden"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-zinc-300 block">
                          Validade (MM/AA)
                        </label>
                        <input
                          type="text"
                          placeholder="MM/AA"
                          maxLength={5}
                          value={cardExpiry}
                          onChange={(e) => {
                            let v = e.target.value.replace(/\D/g, '');
                            if (v.length >= 2) v = v.substring(0, 2) + '/' + v.substring(2, 4);
                            setCardExpiry(v);
                          }}
                          className="w-full rounded-xl border border-zinc-700 bg-[#181818] px-3 py-2 text-xs text-white placeholder-zinc-500 font-mono text-center focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-hidden"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-zinc-300 block">
                          CVV
                        </label>
                        <input
                          type="password"
                          placeholder="123"
                          maxLength={4}
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                          className="w-full rounded-xl border border-zinc-700 bg-[#181818] px-3 py-2 text-xs text-white placeholder-zinc-500 font-mono text-center focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-hidden"
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('pix')}
                      className="w-full py-2 rounded-xl text-xs font-bold text-[#FF80C5] bg-[#181818] border border-[#FF57B2]/50 hover:bg-[#FF57B2]/20 transition cursor-pointer"
                    >
                      Mudar para Pix com Validação de Comprovante (Recomendado)
                    </button>
                  </div>
                )}

                {cardFormError && (
                  <div className="rounded-xl bg-[#262626] text-[#FF80C5] p-2.5 text-xs flex items-center gap-2 border border-[#FF57B2]/50">
                    <AlertTriangle className="h-4 w-4 shrink-0 text-[#FF57B2]" />
                    <span>{cardFormError}</span>
                  </div>
                )}

                {actionError && (
                  <div className="rounded-xl bg-[#262626] text-[#FF80C5] p-3 text-xs flex items-start gap-2 border border-[#FF57B2]/50">
                    <AlertCircle className="h-4 w-4 shrink-0 text-[#FF57B2] mt-0.5" />
                    <div>
                      <strong className="text-white">Não foi possível liberar a assinatura:</strong>
                      <p className="mt-0.5">{actionError}</p>
                    </div>
                  </div>
                )}

                <div className="rounded-2xl bg-[#262626] p-4 border border-zinc-800 text-xs text-zinc-400 space-y-1">
                  <div className="flex justify-between font-bold text-white">
                    <span>Total a pagar:</span>
                    <span className="text-base text-[#FF57B2] font-black tabular-nums">
                      R$ {SUBSCRIPTION_PLANS[selectedPlanId].price.toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-400">
                    A liberação é automática e imediata mediante a confirmação da autenticidade do comprovante bancário.
                  </p>
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setCheckoutModalOpen(false)}
                    className="px-4 py-2.5 text-xs text-zinc-400 hover:text-white transition cursor-pointer font-bold"
                  >
                    Voltar
                  </button>

                  <button
                    type="button"
                    disabled={validatingReceipt || (paymentMethod === 'pix' && !receiptInput.trim())}
                    onClick={handleValidateAndConfirmReceipt}
                    className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-6 py-2.5 text-xs font-black uppercase tracking-wider text-white transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-md shadow-[#FF57B2]/25"
                  >
                    {validatingReceipt ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin" />
                        <span>Validando Comprovante Bancário...</span>
                      </>
                    ) : (
                      <>
                        <FileCheck className="h-4 w-4" />
                        <span>Validar Comprovante & Liberar Assinatura</span>
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Cancellation Confirmation Modal */}
      {cancelModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-[#202020] border border-zinc-800 p-6 sm:p-8 shadow-2xl space-y-4 text-white">
            <div className="flex items-center gap-3 text-[#FF57B2]">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#262626] border border-[#FF57B2]/40">
                <AlertTriangle className="h-5 w-5 text-[#FF57B2]" />
              </div>
              <h3 className="text-lg font-bold text-white">
                Deseja cancelar a renovação?
              </h3>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed font-literary">
              Ao desativar a renovação automática, você continuará desfrutando de todos os benefícios da sua assinatura até{' '}
              <strong className="text-white">
                {activeSub?.currentPeriodEnd
                  ? new Date(activeSub.currentPeriodEnd).toLocaleDateString('pt-BR')
                  : 'o término do ciclo'}
              </strong>
              . Após essa data, os benefícios serão pausados, mas todas as suas conquistas obtidas permanecem gravadas permanentemente no seu histórico.
            </p>

            {actionError && (
              <div className="rounded-xl bg-[#262626] border border-[#FF57B2]/50 text-[#FF80C5] p-2.5 text-xs">
                {actionError}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => setCancelModalOpen(false)}
                className="px-4 py-2 text-xs font-bold text-zinc-400 hover:text-white cursor-pointer"
              >
                Manter Assinatura
              </button>
              <button
                type="button"
                disabled={canceling}
                onClick={handleCancelSub}
                className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer"
              >
                {canceling ? 'Cancelando...' : 'Confirmar Cancelamento'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
