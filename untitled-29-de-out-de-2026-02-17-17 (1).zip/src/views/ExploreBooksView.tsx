import { collection, getDocs, orderBy, query, where } from 'firebase/firestore';
import { BookOpen, Compass, Filter, Search, Sparkles, Star, Tag } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db } from '../services/firebase';
import { Book, ContentRating } from '../types';
import { UserAvatar } from '../components/UserAvatar';
import { UserBadges } from '../components/UserBadges';
import { UserDisplayName } from '../components/UserDisplayName';
import { getSynopsisPreview } from '../utils/textUtils';

interface ExploreBooksViewProps {
  onSelectBook: (bookId: string) => void;
}

const GENRES = [
  'Todos',
  'Cordel',
  'Romance',
  'Fantasia',
  'Ficção Científica',
  'Suspense & Mistério',
  'Poesia',
  'Folclore & Lendas',
  'Drama',
  'Aventura',
];

const CLASSIFICATIONS: (ContentRating | 'Todas')[] = [
  'Todas',
  'Livre',
  '12+',
  '14+',
  '16+',
  '18+',
];

export const ExploreBooksView: React.FC<ExploreBooksViewProps> = ({ onSelectBook }) => {
  const { openUserProfile } = usePublicProfile();
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('Todos');
  const [selectedClass, setSelectedClass] = useState<ContentRating | 'Todas'>('Todas');
  const [onlyBeta, setOnlyBeta] = useState(false);

  useEffect(() => {
    const fetchBooks = async () => {
      setLoading(true);
      try {
        const q = query(
          collection(db, 'books'),
          where('status', '==', 'published'),
          orderBy('createdAt', 'desc')
        );
        const snap = await getDocs(q);
        const list: Book[] = [];
        snap.forEach((d) => list.push(d.data() as Book));
        setBooks(list);
      } catch (err) {
        console.error('Error loading explore books:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchBooks();
  }, []);

  const filteredBooks = books.filter((b) => {
    const matchesSearch =
      !search ||
      b.title.toLowerCase().includes(search.toLowerCase()) ||
      b.authorName.toLowerCase().includes(search.toLowerCase()) ||
      b.synopsis?.toLowerCase().includes(search.toLowerCase());

    const matchesGenre =
      selectedGenre === 'Todos' || b.genres?.includes(selectedGenre);

    const matchesClass =
      selectedClass === 'Todas' || b.classification === selectedClass;

    const matchesBeta = !onlyBeta || b.isBeta;

    return matchesSearch && matchesGenre && matchesClass && matchesBeta;
  });

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-[#FF57B2] text-xs font-bold uppercase tracking-wider mb-1">
            <Compass className="h-4 w-4" />
            <span>Acervo Literário</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-display">
            Explorar Livros & Cordéis
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Descubra histórias originais, autores independentes e obras abertas para Leitura Beta.
          </p>
        </div>

        {/* Search input */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-3 h-4 w-4 text-zinc-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar título, autor ou tema..."
            className="w-full rounded-2xl border border-zinc-700 bg-[#202020] pl-9 pr-4 py-2.5 text-sm text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none shadow-2xs"
          />
        </div>
      </div>

      {/* Filter bars */}
      <div className="space-y-3">
        {/* Genre pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {GENRES.map((g) => (
            <button
              key={g}
              onClick={() => setSelectedGenre(g)}
              className={`shrink-0 rounded-xl px-3.5 py-1.5 text-xs font-semibold transition cursor-pointer ${
                selectedGenre === g
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs'
                  : 'bg-[#202020] border border-zinc-800 text-zinc-400 hover:text-white hover:border-[#FF57B2]/40'
              }`}
            >
              {g}
            </button>
          ))}
        </div>

        {/* Classification & Beta filter */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-2 text-xs">
            <span className="font-semibold text-zinc-400">Faixa Etária:</span>
            {CLASSIFICATIONS.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedClass(c)}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
                  selectedClass === c
                    ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white'
                    : 'bg-[#202020] text-zinc-400 hover:text-white border border-zinc-800'
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <label className="flex items-center gap-2 cursor-pointer rounded-xl border border-zinc-800 bg-[#202020] px-3 py-1.5 text-xs font-semibold text-zinc-300 hover:border-[#FF57B2] transition">
            <input
              type="checkbox"
              checked={onlyBeta}
              onChange={(e) => setOnlyBeta(e.target.checked)}
              className="rounded text-[#FF57B2] focus:ring-[#FF57B2]"
            />
            <span className="flex items-center gap-1 text-[#FF57B2] font-bold">
              ★ Somente Vagas de Leitor Beta
            </span>
          </label>
        </div>
      </div>

      {/* Books Grid */}
      {loading ? (
        <div className="py-20 text-center text-sm text-zinc-400">
          Carregando obras do acervo...
        </div>
      ) : filteredBooks.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-zinc-800 bg-[#202020] p-12 text-center">
          <BookOpen className="mx-auto h-12 w-12 text-zinc-600 mb-3" />
          <h3 className="font-bold text-white text-base">Nenhuma obra encontrada</h3>
          <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
            Tente mudar o termo de busca ou limpar os filtros de gênero e classificação.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
          {filteredBooks.map((book) => (
            <div
              key={book.id}
              onClick={() => onSelectBook(book.id)}
              className="group flex flex-col justify-between rounded-2xl bg-[#202020] p-3 shadow-xs border border-zinc-800 hover:border-[#FF57B2]/50 hover:shadow-lg hover:shadow-[#FF57B2]/10 transition cursor-pointer text-white"
            >
              <div>
                <div className="relative aspect-[2/3] w-full overflow-hidden rounded-xl bg-zinc-900 mb-3 shadow-2xs">
                  {book.coverUrl ? (
                    <img
                      src={book.coverUrl}
                      alt={book.title}
                      className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
                    />
                  ) : (
                    <div className="flex h-full w-full flex-col items-center justify-center bg-zinc-900 p-4 text-center text-white">
                      <BookOpen className="h-8 w-8 text-[#FF57B2] mb-2" />
                      <span className="font-literary text-xs font-bold line-clamp-3">
                        {book.title}
                      </span>
                    </div>
                  )}

                  {book.isBeta && (
                    <span className="absolute top-2 right-2 rounded-md bg-black/80 text-[#FF57B2] border border-[#FF57B2]/40 font-black px-1.5 py-0.5 text-[9px] uppercase tracking-wider shadow-sm">
                      Beta Reader
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-white text-sm font-literary line-clamp-1 group-hover:text-[#FF57B2] transition">
                  {book.title}
                </h3>
                <div
                  onClick={(e) => {
                    e.stopPropagation();
                    if (book.authorId) openUserProfile(book.authorId);
                  }}
                  className="flex items-center gap-1.5 text-xs text-zinc-400 truncate mt-1 hover:text-[#FF57B2] cursor-pointer transition"
                  title={`Ver perfil de ${book.authorName}`}
                >
                  <UserAvatar
                    userId={book.authorId}
                    userName={book.authorName}
                    photoURL={book.authorPhoto}
                    sizeClass="h-4.5 w-4.5"
                  />
                  <span className="text-zinc-500 shrink-0">Por</span>
                  <UserDisplayName
                    userId={book.authorId}
                    fallback={book.authorName}
                    className="font-medium text-zinc-300 hover:underline truncate"
                  />
                  <UserBadges userId={book.authorId} size="xs" isLight={false} />
                </div>
                <p className="text-xs text-zinc-400 line-clamp-2 mt-1 font-literary leading-tight">
                  {getSynopsisPreview(book.synopsis, 95)}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-zinc-800 flex items-center justify-between text-[11px]">
                <span className="flex items-center gap-1 font-semibold text-zinc-300">
                  <Star className="h-3.5 w-3.5 fill-[#FF57B2] text-[#FF57B2]" />
                  {book.ratingCount > 0 ? (book.ratingSum / book.ratingCount).toFixed(1) : 'Novo'}
                </span>
                <span className="rounded bg-zinc-800 px-1.5 py-0.5 text-[10px] font-semibold text-zinc-300 border border-zinc-700">
                  {book.classification}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
