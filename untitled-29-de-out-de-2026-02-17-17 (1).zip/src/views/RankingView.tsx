import { collection, getDocs, limit, orderBy, query } from 'firebase/firestore';
import { Award, Crown, Eye, Flame, Medal, Sparkles, Trophy, User } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { useBranding } from '../context/BrandingContext';
import { db } from '../services/firebase';
import { getXpRequiredForLevel, MAX_LEVEL } from '../services/xpLevels';
import { isSubscriptionActive } from '../services/subscriptionService';
import { UserProfile } from '../types';
import { UserAvatar } from '../components/UserAvatar';
import { UserBadges } from '../components/UserBadges';

interface RankingViewProps {
  onSelectUser?: (userId: string) => void;
  onNavigateTab?: (tab: string) => void;
}

export const RankingView: React.FC<RankingViewProps> = ({ onSelectUser, onNavigateTab }) => {
  const { currentUser, userProfile } = useAuth();
  const { branding } = useBranding();
  const { openUserProfile } = usePublicProfile();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRanking = async () => {
      setLoading(true);
      try {
        // Query users by xp descending
        const q = query(
          collection(db, 'users'),
          orderBy('xp', 'desc'),
          limit(100)
        );
        const snap = await getDocs(q);
        const list: UserProfile[] = [];
        snap.forEach((d) => list.push(d.data() as UserProfile));

        // Regra Estrita:
        // "Só quem pode participar do ranking é quem tem a assinatura de 4,90 ativa.
        //  Os demais poderão ver quem está no ranking, mas não participar..."
        const subscribersOnly = list.filter((u) => isSubscriptionActive(u, 'leitor'));

        // Sort subscribers by total progression: (cycles * maxCycleXp) + currentXP
        const cycleXpCap = getXpRequiredForLevel(MAX_LEVEL + 1);
        subscribersOnly.sort((a, b) => {
          const totalA = (a.progressionCycle || 0) * cycleXpCap + (a.xp || 0);
          const totalB = (b.progressionCycle || 0) * cycleXpCap + (b.xp || 0);
          return totalB - totalA;
        });

        setUsers(subscribersOnly);
      } catch (err) {
        console.error('Error fetching ranking:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchRanking();
  }, []);

  const isLeitorSubscriber = isSubscriptionActive(userProfile, 'leitor');

  // Apenas usuários com a assinatura ativa participam do ranking
  const currentUserRank = isLeitorSubscriber && currentUser
    ? users.findIndex((u) => u.id === currentUser.uid)
    : -1;

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="border-b border-zinc-800 pb-6 text-center sm:text-left">
        <div className="flex items-center justify-center sm:justify-start gap-2 text-[#FF57B2] text-xs font-bold uppercase tracking-wider mb-1">
          <Trophy className="h-4 w-4" />
          <span>Mural de Honra Literário</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white font-display">
          Ranking Oficial do {branding.appName}
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1 font-literary">
          Classificação dos leitores assinantes baseada exclusivamente na progressão real de leitura e XP.
        </p>
      </div>

      {/* Modo Espectador para quem NÃO tem a Assinatura Leitor de R$ 4,90 ativa */}
      {!isLeitorSubscriber && (
        <div className="rounded-3xl bg-[#202020] p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-5 border border-zinc-800">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#262626] text-[#FF57B2] font-black shadow-xs shrink-0 border border-[#FF57B2]/30">
              <Eye className="h-6 w-6 text-[#FF57B2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-[#FF57B2] bg-[#FF57B2]/15 px-2.5 py-0.5 rounded-full border border-[#FF57B2]/30">
                  Modo Espectador
                </span>
              </div>
              <p className="font-bold text-white text-sm sm:text-base font-display mt-1">
                Você está apenas visualizando o ranking
              </p>
              <p className="text-xs text-zinc-400 font-literary leading-relaxed mt-0.5">
                Apenas assinantes com o plano <strong>Assinatura Leitor (R$ 4,90/mês)</strong> participam da disputa, acumulam XP, cumprem missões e exibem seus níveis.
              </p>
            </div>
          </div>
          {onNavigateTab && (
            <button
              onClick={() => onNavigateTab('subscriptions')}
              className="shrink-0 w-full sm:w-auto rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white px-5 py-3 text-xs font-black uppercase tracking-wider transition shadow-md cursor-pointer border border-[#FF57B2]/40"
            >
              Assinar Leitor (R$ 4,90/mês) para Participar
            </button>
          )}
        </div>
      )}

      {/* Current User Rank Card (exibido APENAS para quem é assinante ativo) */}
      {currentUser && isLeitorSubscriber && (
        <div
          onClick={() => (currentUserRank >= 0 ? openUserProfile(users[currentUserRank]) : undefined)}
          className="rounded-3xl bg-gradient-to-r from-[#262626] via-[#222222] to-[#1A1A1A] p-5 text-white shadow-lg border border-[#FF57B2]/40 shadow-[0_8px_24px_rgba(255,87,178,0.15)] flex items-center justify-between cursor-pointer hover:border-[#FF57B2] transition relative overflow-hidden"
          title="Visualizar sua posição no ranking"
        >
          {/* Reflexo sutil no topo */}
          <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-[#FF57B2]/80 to-transparent pointer-events-none" />
          <div className="flex items-center gap-4">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#181818] text-lg font-black text-[#FF57B2] border border-[#FF57B2]/40 shadow-2xs">
              {currentUserRank >= 0 ? `#${currentUserRank + 1}` : '—'}
            </span>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#FF57B2] block">
                Sua Participação no Ranking Oficial
              </span>
              <div className="flex items-center gap-1.5 flex-wrap">
                <p className="text-base font-bold font-display text-white">{userProfile?.displayName}</p>
                <UserBadges
                  userId={currentUser.uid}
                  isVerified={userProfile?.isVerifiedWriter}
                  hasExperienced={userProfile?.hasExperiencedReaderBadge}
                  role={userProfile?.role}
                  size="xs"
                  isLight={false}
                />
              </div>
              <p className="text-xs text-zinc-400">
                Nível {userProfile?.level || 1} • {userProfile?.xp || 0} XP
                {(userProfile?.progressionCycle || 0) > 0 &&
                  ` • Ciclo ${(userProfile?.progressionCycle || 0) + 1}`}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-[#181818] px-3 py-1.5 text-xs font-semibold text-[#FF57B2] border border-[#FF57B2]/30 shadow-2xs">
            {userProfile?.activeTitle || 'Leitor Assinante'}
          </div>
        </div>
      )}

      {/* Leaderboard Table */}
      <div className="overflow-hidden rounded-3xl bg-[#202020] border border-zinc-800">
        <div className="border-b border-zinc-800 bg-[#262626] px-4 sm:px-6 py-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400 grid grid-cols-12 gap-2">
          <span className="col-span-2 sm:col-span-1 text-center">Pos.</span>
          <span className="col-span-6 sm:col-span-6">Leitor Assinante</span>
          <span className="col-span-2 sm:col-span-3 text-center">Nível & Ciclo</span>
          <span className="col-span-2 sm:col-span-2 text-right">XP Total</span>
        </div>

        {loading ? (
          <div className="py-16 text-center text-xs text-zinc-400">
            Carregando classificação real de assinantes...
          </div>
        ) : users.length === 0 ? (
          <div className="py-16 px-4 text-center text-xs text-zinc-400 space-y-3">
            <Trophy className="h-10 w-10 mx-auto text-zinc-600" />
            <p className="font-bold text-sm text-zinc-200">
              Nenhum leitor com Assinatura Leitor ativa ranqueado no momento.
            </p>
            <p className="text-xs text-zinc-400 max-w-md mx-auto leading-relaxed">
              O mural de honra é exclusivo para participantes com o plano <strong>Assinatura Leitor (R$ 4,90/mês)</strong>. Seja o primeiro a assinar e conquiste a primeira colocação no ranking!
            </p>
            {onNavigateTab && !isLeitorSubscriber && (
              <div className="pt-2">
                <button
                  onClick={() => onNavigateTab('subscriptions')}
                  className="rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white px-5 py-2.5 text-xs font-bold shadow-xs cursor-pointer border border-[#FF57B2]/40"
                >
                  Assinar Leitor por R$ 4,90/mês
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="divide-y divide-zinc-800">
            {users.map((u, idx) => {
              const isTop1 = idx === 0;
              const isTop2 = idx === 1;
              const isTop3 = idx === 2;
              const isMe = u.id === currentUser?.uid;

              return (
                <div
                  key={u.id}
                  onClick={() => (onSelectUser ? onSelectUser(u.id) : openUserProfile(u))}
                  className={`grid grid-cols-12 items-center gap-2 px-4 sm:px-6 py-3.5 text-xs transition cursor-pointer ${
                    isMe
                      ? 'bg-[#FF57B2]/10 font-semibold'
                      : 'hover:bg-zinc-800/40'
                  }`}
                  title={`Ver perfil de ${u.displayName}`}
                >
                  {/* Position Badge */}
                  <div className="col-span-2 sm:col-span-1 flex justify-center">
                    {isTop1 ? (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#262626] text-[#FF57B2] border border-[#FF57B2] font-black shadow-[0_0_12px_rgba(255,87,178,0.5)]">
                        <Crown className="h-4 w-4 text-[#FF57B2] fill-[#FF57B2]" />
                      </div>
                    ) : isTop2 ? (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-zinc-800 text-white font-bold shadow-xs border border-zinc-700">
                        2
                      </div>
                    ) : isTop3 ? (
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-zinc-850 text-zinc-300 font-bold shadow-xs border border-zinc-700">
                        3
                      </div>
                    ) : (
                      <span className="text-zinc-500 font-bold">#{idx + 1}</span>
                    )}
                  </div>

                  {/* User info */}
                  <div className="col-span-6 sm:col-span-6 flex items-center gap-3 min-w-0">
                    <UserAvatar
                      userId={u.id}
                      userName={u.displayName}
                      photoURL={u.photoURL}
                      sizeClass="h-8 w-8"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 truncate">
                        <span className="font-bold text-white text-xs sm:text-sm truncate">
                          {u.displayName}
                        </span>
                        <UserBadges
                          userId={u.id}
                          isVerified={u.isVerifiedWriter}
                          hasExperienced={u.hasExperiencedReaderBadge}
                          role={u.role}
                          size="xs"
                          isLight={false}
                        />
                        {isMe && (
                          <span className="rounded bg-[#FF57B2]/20 text-[#FF57B2] border border-[#FF57B2]/40 text-[9px] px-1 font-bold">
                            Você
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] text-zinc-400 truncate">
                        <span className="text-[#FF57B2] font-medium truncate">
                          {u.activeTitle || 'Leitor Assinante'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Level & Cycle */}
                  <div className="col-span-2 sm:col-span-3 text-center">
                    <span className="rounded-lg bg-zinc-800 text-[#FF57B2] border border-zinc-700 px-2 py-0.5 text-xs font-bold">
                      Nível {u.level || 1}
                    </span>
                    {(u.progressionCycle || 0) > 0 && (
                      <span className="block text-[10px] text-[#FF80C5] font-semibold mt-0.5">
                        Ciclo {(u.progressionCycle || 0) + 1}
                      </span>
                    )}
                  </div>

                  {/* XP */}
                  <div className="col-span-2 sm:col-span-2 text-right font-black text-white font-display tabular-nums">
                    {u.xp?.toLocaleString('pt-BR') || 0}{' '}
                    <span className="text-[10px] text-zinc-400 font-normal">XP</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
