import {
  AtSign,
  Award,
  Camera,
  CheckCircle2,
  Crown,
  Loader2,
  LogOut,
  Pencil,
  RefreshCw,
  Save,
  ShieldCheck,
  Sparkles,
  Star,
  Trash2,
  User as UserIcon,
  X,
  Zap,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { uploadFileToStorage } from '../services/storageService';
import {
  checkUsernameAvailability,
  syncUserProfileAcrossContent,
  syncUserProfilePhotoAcrossContent,
  validateUsernameFormat,
} from '../services/userService';
import { calculateLevelFromXp, MAX_LEVEL } from '../services/xpLevels';
import { isSubscriptionActive } from '../services/subscriptionService';

interface ProfileViewProps {
  onOpenAuth: () => void;
  onNavigateTab: (tab: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onOpenAuth, onNavigateTab }) => {
  const { currentUser, userProfile, updateUserProfileData, logout, switchGoogleAccount, isDeveloper, isGoogleAuthPending } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState(userProfile?.displayName || '');
  const [username, setUsername] = useState(
    (userProfile?.username || '').replace(/^@/, '')
  );
  const [usernameError, setUsernameError] = useState('');
  const [bio, setBio] = useState(userProfile?.bio || '');
  const [avatarPreview, setAvatarPreview] = useState(userProfile?.photoURL || '');
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [avatarError, setAvatarError] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  // Always keep avatar and form fields synchronized with persistent Firestore profile data
  useEffect(() => {
    if (userProfile && !isEditing) {
      setDisplayName(userProfile.displayName || '');
      setBio(userProfile.bio || '');
      setAvatarPreview(userProfile.photoURL || '');
      setUsername((userProfile.username || '').replace(/^@/, ''));
    }
  }, [userProfile?.photoURL, userProfile?.displayName, userProfile?.bio, userProfile?.username, isEditing]);

  const handleStartEditing = () => {
    if (userProfile) {
      setDisplayName(userProfile.displayName || '');
      setBio(userProfile.bio || '');
      setAvatarPreview(userProfile.photoURL || '');
      setUsername((userProfile.username || '').replace(/^@/, ''));
    }
    setUsernameError('');
    setAvatarError('');
    setMessage('');
    setIsEditing(true);
  };

  const handleCancelEditing = () => {
    if (userProfile) {
      setDisplayName(userProfile.displayName || '');
      setBio(userProfile.bio || '');
      setAvatarPreview(userProfile.photoURL || '');
      setUsername((userProfile.username || '').replace(/^@/, ''));
    }
    setUsernameError('');
    setAvatarError('');
    setIsEditing(false);
  };

  if (!currentUser || !userProfile) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <UserIcon className="mx-auto h-12 w-12 text-[#FF57B2] mb-3" />
        <h2 className="text-xl font-black text-white font-display">Perfil de Usuário</h2>
        <p className="text-xs text-zinc-400 mt-1 mb-6">
          Faça login para gerenciar suas informações, títulos e histórico de conquistas.
        </p>
        <button
          onClick={onOpenAuth}
          className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-6 py-2.5 text-xs font-bold text-white shadow-md hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
        >
          Entrar ou Criar Conta
        </button>
      </div>
    );
  }

  const { progressPercent, nextLevelXp } = calculateLevelFromXp(userProfile.xp || 0);

  // Pro Border eligibility & active state
  const isProEligible = Boolean(
    userProfile.hasKardelProBadge ||
    isSubscriptionActive(userProfile, 'leitor') ||
    isSubscriptionActive(userProfile, 'escritor') ||
    userProfile.role === 'desenvolvedor' ||
    isDeveloper
  );
  const isProBorderActive = Boolean(userProfile.showProBorder ?? userProfile.hasKardelProBadge);

  // Equipped titles (up to 3)
  const equippedTitles: string[] =
    userProfile.equippedTitles && userProfile.equippedTitles.length > 0
      ? userProfile.equippedTitles.slice(0, 3)
      : userProfile.activeTitle
      ? [userProfile.activeTitle]
      : ['Leitor Curioso'];

  // Available titles pool
  const defaultTitles = [
    'Leitor Curioso',
    'Explorador Literário',
    'Devorador de Páginas',
    'Mestre do Cordel',
    'Crítico Notável',
    'Lenda dos Rankings',
    'Guardião das Letras',
    'Voz do Sertão',
    'Membro de Honra',
    'Pioneiro Literário',
  ];
  const availableTitlesPool = Array.from(
    new Set([
      ...(userProfile.titles || []),
      ...(userProfile.activeTitle ? [userProfile.activeTitle] : []),
      ...defaultTitles.slice(0, Math.max(4, (userProfile.level || 1) + 2)),
    ])
  );

  // Toggle equipping title (max 3)
  const handleToggleTitle = async (title: string) => {
    let newEquipped: string[];
    if (equippedTitles.includes(title)) {
      newEquipped = equippedTitles.filter((t) => t !== title);
    } else {
      if (equippedTitles.length >= 3) {
        setMessage('Você só pode equipar até 3 títulos ao mesmo tempo. Desequipe um para equipar outro.');
        setTimeout(() => setMessage(''), 3500);
        return;
      }
      newEquipped = [...equippedTitles, title];
    }

    try {
      await updateUserProfileData({
        equippedTitles: newEquipped,
        activeTitle: newEquipped[0] || 'Leitor Curioso',
      });
      setMessage(`Títulos atualizados no seu perfil! (${newEquipped.length}/3 equipados)`);
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      console.error('Error updating equipped titles:', err);
      setMessage('Erro ao equipar título.');
    }
  };

  // Toggle Pro Energy Border
  const handleToggleProBorder = async () => {
    if (!isProEligible) {
      setMessage('A borda de energia rosa é exclusiva para assinantes KARDEL Pró.');
      setTimeout(() => setMessage(''), 3500);
      return;
    }

    try {
      const nextState = !isProBorderActive;
      await updateUserProfileData({
        showProBorder: nextState,
        hasKardelProBadge: true,
      });
      setMessage(
        nextState
          ? 'Borda de Energia Pró ativada com sucesso ao redor do seu perfil!'
          : 'Borda de Energia Pró desativada.'
      );
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      console.error('Error updating pro border:', err);
      setMessage('Erro ao atualizar borda de perfil.');
    }
  };

  // Instant real upload & Firestore persistence when user chooses a file
  const handleAvatarFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    setUploadingAvatar(true);
    setAvatarError('');
    setMessage('');

    try {
      const permanentPhotoURL = await uploadFileToStorage(file, 'avatars', currentUser.uid);

      await updateUserProfileData({ photoURL: permanentPhotoURL });
      setAvatarPreview(permanentPhotoURL);

      syncUserProfilePhotoAcrossContent(currentUser.uid, permanentPhotoURL).catch(() => {});

      setMessage('Foto de perfil atualizada e sincronizada com sucesso!');
      setTimeout(() => setMessage(''), 3000);
    } catch (err: any) {
      console.error('Error uploading avatar:', err);
      setAvatarError(err?.message || 'Falha ao enviar a imagem. Tente uma foto menor que 5MB.');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleRemovePhoto = async () => {
    if (!currentUser) return;
    setUploadingAvatar(true);
    setAvatarError('');
    try {
      await updateUserProfileData({ photoURL: '' });
      setAvatarPreview('');
      syncUserProfilePhotoAcrossContent(currentUser.uid, '').catch(() => {});
      setMessage('Foto de perfil removida com sucesso!');
      setTimeout(() => setMessage(''), 3000);
    } catch (err: any) {
      console.error('Error removing avatar:', err);
      setAvatarError('Falha ao remover a foto.');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    setUsername(raw);
    if (!raw.trim()) {
      setUsernameError('');
      return;
    }
    const val = validateUsernameFormat(raw);
    if (!val.valid) {
      setUsernameError(val.error || 'Nome de usuário inválido.');
    } else {
      setUsernameError('');
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setSaving(true);
    setMessage('');
    setUsernameError('');
    setAvatarError('');

    try {
      const validation = validateUsernameFormat(username);
      if (!validation.valid) {
        setUsernameError(validation.error || 'Nome de usuário inválido.');
        setSaving(false);
        return;
      }

      const currentHandle = (userProfile.username || '').replace(/^@/, '').toLowerCase();
      const newHandle = validation.formatted.replace(/^@/, '').toLowerCase();

      if (currentHandle !== newHandle) {
        const isAvail = await checkUsernameAvailability(validation.formatted, currentUser.uid);
        if (!isAvail) {
          setUsernameError('Este nome de usuário já está sendo usado por outro leitor.');
          setSaving(false);
          return;
        }
      }

      const trimmedName = displayName.trim();
      await updateUserProfileData({
        displayName: trimmedName,
        username: validation.formatted,
        bio: bio.trim(),
      });

      syncUserProfileAcrossContent(currentUser.uid, {
        displayName: trimmedName,
        username: validation.formatted,
        photoURL: userProfile.photoURL,
      }).catch(() => {});

      setMessage('Dados do perfil salvos com sucesso!');
      setTimeout(() => setMessage(''), 3000);
    } catch (err: any) {
      console.error('Error saving profile:', err);
      setMessage('Erro ao salvar alterações no perfil.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      {/* Profile Header Card */}
      <div className="rounded-3xl bg-[#202020] p-6 sm:p-8 shadow-xl border border-zinc-800 transition">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          {/* Avatar com Borda de Energia Rosa Emanando (Selecionável para Pró) */}
          <div className="flex flex-col items-center gap-2">
            <div className="relative group">
              {/* Outer radiating aura if Pro energy border is active */}
              {isProBorderActive && (
                <>
                  <span className="absolute -inset-2.5 rounded-full bg-gradient-to-r from-[#FF57B2] via-[#FF007A] to-[#FF80C5] opacity-80 blur-[6px] animate-pulse pointer-events-none" />
                  <span className="absolute -inset-1.5 rounded-full border-2 border-[#FF57B2] animate-ping opacity-35 pointer-events-none" />
                </>
              )}

              <div
                className={`h-28 w-28 overflow-hidden rounded-full shadow-2xl bg-zinc-900 relative z-10 ${
                  isProBorderActive
                    ? 'ring-4 ring-[#FF57B2] shadow-[0_0_24px_rgba(255,87,178,0.85)]'
                    : 'border-4 border-zinc-800'
                }`}
              >
                {avatarPreview ? (
                  <img
                    src={avatarPreview}
                    alt={userProfile.displayName}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-3xl font-black text-white font-display">
                    {userProfile.displayName?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}

                {/* Uploading overlay */}
                {uploadingAvatar && (
                  <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center text-white z-20">
                    <Loader2 className="h-6 w-6 animate-spin text-[#FF57B2] mb-1" />
                    <span className="text-[10px] font-bold">Salvando...</span>
                  </div>
                )}
              </div>

              {/* Camera icon to upload photo ONLY visible when in editing mode */}
              {isEditing && (
                <label
                  className={`absolute bottom-0 right-0 z-20 flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-lg hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer ${
                    uploadingAvatar ? 'pointer-events-none opacity-60' : ''
                  }`}
                  title="Alterar foto de perfil"
                >
                  <Camera className="h-4 w-4" />
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    disabled={uploadingAvatar}
                    onChange={handleAvatarFileChange}
                  />
                </label>
              )}
            </div>

            {/* Remove photo button ONLY visible when in editing mode */}
            {isEditing && avatarPreview && !uploadingAvatar && (
              <button
                type="button"
                onClick={handleRemovePhoto}
                className="text-[11px] text-zinc-400 hover:text-[#FF57B2] transition flex items-center gap-1 cursor-pointer pt-0.5"
              >
                <Trash2 className="h-3 w-3" />
                <span>Remover foto</span>
              </button>
            )}

            {/* Botão de Editar */}
            {!isEditing ? (
              <button
                type="button"
                onClick={handleStartEditing}
                className="mt-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white px-3.5 py-1.5 text-xs font-bold shadow-md shadow-[#FF57B2]/25 transition cursor-pointer"
              >
                <Pencil className="h-3.5 w-3.5" />
                <span>Editar Perfil</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleCancelEditing}
                className="mt-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-zinc-700 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-3 py-1.5 text-xs font-semibold transition cursor-pointer"
              >
                <X className="h-3.5 w-3.5" />
                <span>Cancelar Edição</span>
              </button>
            )}
          </div>

          {/* User Meta */}
          <div className="flex-1 text-center sm:text-left space-y-2">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <span className="rounded-lg bg-[#262626] text-[#FF57B2] px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider border border-[#FF57B2]/50">
                {userProfile.role}
              </span>
              {userProfile.hasExperiencedReaderBadge && (
                <span className="rounded-lg bg-zinc-800 text-zinc-200 px-2.5 py-0.5 text-xs font-bold flex items-center gap-1 border border-zinc-700 shadow-2xs">
                  <Star className="h-3 w-3 fill-[#FF57B2] text-[#FF57B2]" />
                  <span>Leitor Experiente</span>
                </span>
              )}
              {userProfile.isVerifiedWriter && (
                <span className="rounded-lg bg-[#262626] text-white px-2.5 py-0.5 text-xs font-bold flex items-center gap-1 border border-[#FF57B2]">
                  <ShieldCheck className="h-3.5 w-3.5 text-[#FF57B2]" />
                  <span>Escritor Verificado</span>
                </span>
              )}
            </div>

            <div className="space-y-1">
              <h1 className="text-2xl font-black text-white font-display">
                {userProfile.displayName}
              </h1>
              <div className="flex items-center justify-center sm:justify-start gap-2 mt-1">
                <span className="inline-flex items-center gap-1 rounded-md bg-[#262626] border border-[#FF57B2]/40 px-2 py-0.5 text-xs font-mono font-semibold text-[#FF57B2]">
                  <AtSign className="h-3 w-3 text-[#FF57B2]" />
                  <span>{(userProfile.username || 'usuario').replace(/^@/, '')}</span>
                </span>
                {userProfile.uniqueId && (
                  <span className="text-[10px] font-mono text-zinc-400">
                    ID: {userProfile.uniqueId}
                  </span>
                )}
              </div>
            </div>

            {/* Títulos Equipados (Até 3) */}
            <div className="space-y-1 pt-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block">
                Títulos Equipados ({equippedTitles.length}/3)
              </span>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5">
                {equippedTitles.map((title) => (
                  <span
                    key={title}
                    className="inline-flex items-center gap-1 rounded-lg bg-gradient-to-r from-[#FF57B2]/20 to-[#E03595]/10 border border-[#FF57B2]/60 px-2.5 py-0.5 text-xs font-bold text-white shadow-xs"
                  >
                    <Sparkles className="h-3 w-3 text-[#FF57B2]" />
                    <span>{title}</span>
                  </span>
                ))}
              </div>
            </div>

            <p className="text-xs text-zinc-300 font-literary max-w-xl pt-1 leading-relaxed">
              {userProfile.bio || 'Nenhuma biografia informada ainda. Clique em "Editar Perfil" para personalizar sua apresentação!'}
            </p>
          </div>

          {/* Subscription & Membership Quick Info */}
          <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-4 shrink-0 text-center sm:text-right space-y-2 min-w-[210px]">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[#FF57B2] block">
              Membresia KORDEL
            </span>
            {userProfile.subscription?.status === 'active' ? (
              <div className="space-y-1">
                <div className="flex items-center justify-center sm:justify-end gap-1.5 font-black text-sm text-white">
                  {userProfile.subscription.planId === 'escritor' || userProfile.subscription.planId === 'kardel_escritor' ? (
                    <ShieldCheck className="h-4 w-4 text-[#FF57B2]" />
                  ) : (
                    <Award className="h-4 w-4 text-[#FF57B2]" />
                  )}
                  <span>
                    {userProfile.subscription.planId === 'escritor' || userProfile.subscription.planId === 'kardel_escritor'
                      ? 'Assinatura Escritor'
                      : 'Assinatura Leitor'}
                  </span>
                </div>
                <p className="text-[10px] text-zinc-400">
                  Renovação: {new Date(userProfile.subscription.currentPeriodEnd).toLocaleDateString('pt-BR')}
                </p>
                <button
                  onClick={() => onNavigateTab('subscriptions')}
                  className="text-[11px] font-bold text-[#FF57B2] hover:underline block pt-0.5 cursor-pointer mx-auto sm:ml-auto"
                >
                  Gerenciar Assinatura →
                </button>
              </div>
            ) : (
              <div className="space-y-1">
                <div className="flex items-center justify-center sm:justify-end gap-1.5 font-bold text-xs text-zinc-300">
                  <Crown className="h-4 w-4 text-zinc-400" />
                  <span>Plano Gratuito</span>
                </div>
                <p className="text-[10px] text-zinc-400">
                  Desbloqueie missões, ranking e selos
                </p>
                <button
                  onClick={() => onNavigateTab('subscriptions')}
                  className="text-[11px] font-bold text-[#FF57B2] hover:underline block pt-0.5 cursor-pointer mx-auto sm:ml-auto"
                >
                  Conhecer Planos →
                </button>
              </div>
            )}

            {/* Borda de Energia Pró Toggle */}
            <div className="pt-2 border-t border-zinc-800">
              <button
                type="button"
                onClick={handleToggleProBorder}
                className={`w-full flex items-center justify-between gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border ${
                  isProBorderActive
                    ? 'bg-[#FF57B2]/20 border-[#FF57B2] text-white shadow-[0_0_12px_rgba(255,87,178,0.35)]'
                    : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:text-white hover:border-[#FF57B2]/40'
                }`}
                title="Borda rosa forte com energia emanando"
              >
                <div className="flex items-center gap-1.5">
                  <Zap className={`h-3.5 w-3.5 ${isProBorderActive ? 'text-[#FF57B2] animate-pulse' : 'text-zinc-500'}`} />
                  <span className="text-[11px]">Borda Pró</span>
                </div>
                <span className={`text-[10px] uppercase font-black px-1.5 py-0.2 rounded ${
                  isProBorderActive ? 'bg-[#FF57B2] text-white' : 'bg-zinc-700 text-zinc-400'
                }`}>
                  {isProBorderActive ? 'Ativada' : 'Desativada'}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Level Progression Bar */}
        {(() => {
          const isLeitor = isSubscriptionActive(userProfile, 'leitor');
          return (
            <div className="mt-8 pt-6 border-t border-zinc-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-zinc-200">
                  {isLeitor
                    ? `Nível ${userProfile.level || 1} de ${MAX_LEVEL}${
                        userProfile.progressionCycle > 0 ? ` (Ciclo ${userProfile.progressionCycle + 1})` : ''
                      }`
                    : 'Nível 0 (Plano Inativo)'}
                </span>
                <span className="text-zinc-400 font-display">
                  {isLeitor ? `${userProfile.xp || 0} / ${nextLevelXp} XP` : '0 / 0 XP'}
                </span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#262626] border border-zinc-700">
                <div
                  className={`h-full rounded-full transition-all duration-300 ${
                    isLeitor
                      ? 'bg-gradient-to-r from-[#FF57B2] to-[#FF40A4]'
                      : 'bg-zinc-600'
                  }`}
                  style={{ width: isLeitor ? `${progressPercent}%` : '0%' }}
                ></div>
              </div>
              {!isLeitor && (
                <div className="flex items-center justify-between pt-1">
                  <p className="text-[11px] text-zinc-400">
                    O sistema de gamificação, missões e ranking é exclusivo para quem tem a Assinatura Leitor (R$ 4,90/mês).
                  </p>
                  <button
                    onClick={() => onNavigateTab('subscriptions')}
                    className="text-[11px] font-bold text-[#FF57B2] hover:underline cursor-pointer ml-2 shrink-0"
                  >
                    Ativar Assinatura →
                  </button>
                </div>
              )}
            </div>
          );
        })()}
      </div>

      {/* Mensagem de Feedback */}
      {message && (
        <div className="rounded-2xl bg-zinc-900 p-4 text-xs text-[#FF57B2] font-semibold border border-[#FF57B2]/40 flex items-center gap-2.5 animate-in fade-in duration-200 shadow-md">
          <CheckCircle2 className="h-5 w-5 text-[#FF57B2] shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Painel de Equipamento de Títulos e Emblemas (Gamificação & Rankings) */}
      <div className="rounded-3xl bg-[#202020] p-6 sm:p-7 border border-zinc-800 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-zinc-800">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white font-display flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-[#FF57B2]" />
              <span>Títulos & Emblemas Conquistados</span>
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Equipe até 3 títulos desbloqueados na gamificação e rankings para exibir no seu perfil.
            </p>
          </div>
          <span className="inline-flex items-center gap-1 text-xs font-bold text-[#FF57B2] bg-[#FF57B2]/10 border border-[#FF57B2]/30 px-3 py-1 rounded-xl self-start sm:self-auto">
            <span>Equipados:</span>
            <strong className="text-white font-mono">{equippedTitles.length} / 3</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pt-1">
          {availableTitlesPool.map((title) => {
            const isEquipped = equippedTitles.includes(title);

            return (
              <button
                key={title}
                type="button"
                onClick={() => handleToggleTitle(title)}
                className={`flex items-center justify-between gap-2 rounded-2xl p-3 text-xs font-bold transition cursor-pointer border text-left ${
                  isEquipped
                    ? 'bg-gradient-to-r from-[#FF57B2]/25 to-[#E03595]/15 border-[#FF57B2] text-white shadow-[0_0_12px_rgba(255,87,178,0.25)]'
                    : 'bg-[#262626] border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <Sparkles className={`h-3.5 w-3.5 shrink-0 ${isEquipped ? 'text-[#FF57B2]' : 'text-zinc-500'}`} />
                  <span className="truncate">{title}</span>
                </div>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-lg shrink-0 uppercase tracking-wider ${
                    isEquipped
                      ? 'bg-[#FF57B2] text-white shadow-2xs'
                      : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                  }`}
                >
                  {isEquipped ? 'Equipado' : 'Equipar'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ÁREA DE EDIÇÃO DO PERFIL: DISPONÍVEL APENAS NA HORA QUE CLICAR EM EDITAR */}
      {isEditing ? (
        <div className="rounded-3xl bg-[#202020] p-6 sm:p-8 shadow-xl border-2 border-[#FF57B2]/60 space-y-5 animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-[#FF57B2]/30">
            <div className="space-y-0.5">
              <div className="inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-[#FF57B2]">
                <Pencil className="h-3 w-3" />
                <span>Modo de Edição Ativo</span>
              </div>
              <h3 className="text-lg font-bold text-white font-display">
                Opções de Edição do Perfil
              </h3>
            </div>

            <button
              type="button"
              onClick={handleCancelEditing}
              className="p-1.5 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
              title="Fechar edição"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {avatarError && (
            <div className="rounded-xl bg-[#262626] text-white p-3 text-xs border border-[#FF57B2]/60">
              {avatarError}
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-5 text-xs">
            {/* Foto do Perfil */}
            <div className="rounded-2xl bg-[#262626] p-4 border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white text-xs">
                    Foto de Perfil
                  </h4>
                  <p className="text-[11px] text-zinc-400">
                    Formatos suportados: JPG, PNG, WebP (salva e sincroniza em todo o app)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 pt-1">
                <div className="h-16 w-16 rounded-full overflow-hidden bg-zinc-900 border-2 border-zinc-700 shrink-0">
                  {avatarPreview ? (
                    <img src={avatarPreview} alt="Preview" className="h-full w-full object-cover" />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center font-bold text-white text-lg">
                      {displayName.charAt(0).toUpperCase() || 'U'}
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <label
                    className={`inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white px-3.5 py-2 text-xs font-bold transition cursor-pointer ${
                      uploadingAvatar ? 'opacity-50 pointer-events-none' : ''
                    }`}
                  >
                    <Camera className="h-3.5 w-3.5" />
                    <span>{uploadingAvatar ? 'Enviando...' : 'Escolher Nova Foto'}</span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      disabled={uploadingAvatar}
                      onChange={handleAvatarFileChange}
                    />
                  </label>

                  {avatarPreview && (
                    <button
                      type="button"
                      disabled={uploadingAvatar}
                      onClick={handleRemovePhoto}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-zinc-700 hover:bg-zinc-800 text-zinc-300 px-3 py-2 text-xs font-medium transition cursor-pointer"
                    >
                      <Trash2 className="h-3.5 w-3.5 text-zinc-400" />
                      <span>Remover Foto</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Nome ou Pseudônimo */}
            <div className="space-y-1">
              <label className="block font-semibold text-zinc-300">
                Nome ou Pseudônimo Literário (Apelido público)
              </label>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Como quer ser chamado na comunidade"
                className="w-full rounded-xl border border-zinc-700 bg-[#1A1A1A] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-hidden"
              />
            </div>

            {/* Nome de Usuário / Handle */}
            <div className="space-y-1">
              <label className="block font-semibold text-zinc-300">
                Nome de Usuário (@handle exclusivo)
              </label>
              <div className="relative flex items-center">
                <span className="absolute left-3 font-mono font-bold text-zinc-400 text-xs select-none">
                  @
                </span>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={handleUsernameChange}
                  placeholder="seu_usuario"
                  className={`w-full rounded-xl border pl-7 pr-3 py-2.5 text-xs font-mono text-white bg-[#1A1A1A] focus:outline-hidden transition ${
                    usernameError
                      ? 'border-[#FF57B2] bg-[#262626] focus:border-[#FF57B2]'
                      : 'border-zinc-700 focus:border-[#FF57B2]'
                  }`}
                />
              </div>
              <p className="text-[11px] text-zinc-400">
                Sem maiúsculas ou espaços. Use letras minúsculas, números, ponto (.), underline (_) ou hífen (-).
              </p>
              {usernameError && (
                <p className="text-[11px] font-semibold text-[#FF80C5]">
                  {usernameError}
                </p>
              )}
            </div>

            {/* Biografia Literária */}
            <div className="space-y-1">
              <label className="block font-semibold text-zinc-300">
                Biografia Literária (Apresentação para a comunidade)
              </label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Fale sobre seus livros favoritos, inspirações no cordel ou histórias..."
                className="w-full rounded-xl border border-zinc-700 bg-[#1A1A1A] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-hidden font-literary"
                maxLength={500}
              />
              <div className="flex justify-between text-[11px] text-zinc-400">
                <span>Escreva um resumo cativante sobre você</span>
                <span>{bio.length}/500</span>
              </div>
            </div>

            {/* Botões do Rodapé de Edição */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-800">
              <button
                type="button"
                onClick={handleCancelEditing}
                className="rounded-xl border border-zinc-700 px-4 py-2.5 text-zinc-400 hover:bg-zinc-800 font-semibold transition cursor-pointer"
              >
                Cancelar
              </button>

              <button
                type="submit"
                disabled={saving}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-5 py-2.5 font-bold text-white shadow-md shadow-[#FF57B2]/25 border border-[#FF57B2] transition disabled:opacity-50 cursor-pointer"
              >
                {saving ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Salvando Alterações...</span>
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    <span>Salvar Alterações</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* VISUALIZAÇÃO PADRÃO: INFORMAÇÕES DA CONTA */
        <div className="rounded-3xl bg-[#202020] p-6 sm:p-8 shadow-xl border border-zinc-800 space-y-6">
          <div className="pb-3 border-b border-zinc-800">
            <h3 className="text-base font-bold text-white font-display">
              Informações da Conta
            </h3>
            <p className="text-xs text-zinc-400">
              Para alterar seu nome, usuário, foto ou biografia, use o botão "Editar Perfil" abaixo da sua foto.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Bloco 1: Identificação Pública */}
            <div className="rounded-2xl bg-[#262626] p-4 border border-zinc-800 space-y-2">
              <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider block">
                Identificação na Plataforma
              </span>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Nome Público:</span>
                  <strong className="text-white">{userProfile.displayName}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Handle (@):</span>
                  <span className="font-mono text-[#FF57B2] font-semibold">
                    @{((userProfile.username || 'usuario')).replace(/^@/, '')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">E-mail:</span>
                  <span className="text-zinc-300 font-mono text-[11px]">
                    {currentUser.email || 'Não informado'}
                  </span>
                </div>
              </div>
            </div>

            {/* Bloco 2: Títulos e Conquistas Ativas */}
            <div className="rounded-2xl bg-[#262626] p-4 border border-zinc-800 space-y-2">
              <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider block">
                Status de Gamificação
              </span>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Nível Atual:</span>
                  <strong className="text-white">Nível {userProfile.level || 1}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Títulos Ativos:</span>
                  <span className="text-[#FF57B2] font-bold">
                    {equippedTitles.length} equipados
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Borda de Energia:</span>
                  <span className={`font-bold ${isProBorderActive ? 'text-[#FF57B2]' : 'text-zinc-500'}`}>
                    {isProBorderActive ? 'Ativada' : 'Desativada'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Biografia do Leitor */}
          <div className="rounded-2xl bg-[#262626] p-4 border border-zinc-800 space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider block">
              Biografia Literária
            </span>
            <p className="text-xs text-zinc-300 font-literary italic leading-relaxed">
              "{userProfile.bio || 'Nenhuma biografia informada ainda. Clique em Editar Perfil abaixo da sua foto para personalizar sua apresentação.'}"
            </p>
          </div>

          {/* Rodapé: Trocar de Conta Google, Acessar Outra Conta & Sair da Conta */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-zinc-800">
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                disabled={isGoogleAuthPending}
                aria-busy={isGoogleAuthPending}
                onClick={async (e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  if (isGoogleAuthPending) return;
                  const switchPromise = switchGoogleAccount();
                  try {
                    await switchPromise;
                  } catch (err: any) {
                    const code = err?.code || '';
                    if (
                      code !== 'auth/popup-closed-by-user' &&
                      code !== 'auth/cancelled-popup-request' &&
                      code !== 'auth/cancelled-by-ui-manager'
                    ) {
                      onOpenAuth();
                    }
                  }
                }}
                className="flex items-center gap-2 rounded-xl border border-zinc-700 bg-[#262626] hover:border-[#FF57B2] px-4 py-2 text-white font-semibold transition cursor-pointer text-xs disabled:opacity-50 disabled:pointer-events-none"
              >
                <RefreshCw className={`h-4 w-4 text-[#FF57B2] ${isGoogleAuthPending ? 'animate-spin' : ''}`} />
                <span>{isGoogleAuthPending ? 'Autenticando...' : 'Trocar de Conta Google'}</span>
              </button>

              <button
                type="button"
                disabled={isGoogleAuthPending}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  if (isGoogleAuthPending) return;
                  onOpenAuth();
                }}
                className="flex items-center gap-2 rounded-xl border border-zinc-700 bg-[#262626] hover:border-[#FF57B2] px-4 py-2 text-zinc-200 hover:text-white font-semibold transition cursor-pointer text-xs disabled:opacity-50 disabled:pointer-events-none"
              >
                <UserIcon className="h-4 w-4 text-[#FF80C5]" />
                <span>Acessar Outra Conta</span>
              </button>
            </div>

            <button
              type="button"
              disabled={isGoogleAuthPending}
              onClick={async (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (isGoogleAuthPending) return;
                await logout();
              }}
              className="flex items-center gap-2 rounded-xl border border-[#FF57B2]/45 bg-[#262626] px-4 py-2 text-zinc-200 hover:text-white hover:border-[#FF57B2] hover:bg-[#FF57B2]/15 font-semibold transition cursor-pointer text-xs disabled:opacity-50 disabled:pointer-events-none"
            >
              <LogOut className="h-4 w-4 text-[#FF80C5]" />
              <span>Sair da Conta</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
