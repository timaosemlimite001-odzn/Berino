import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  setDoc,
  where
} from 'firebase/firestore';
import {
  ArrowRight,
  Award,
  BookMarked,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock,
  Compass,
  Crown,
  Feather,
  Flame,
  Globe,
  Lock,
  Medal,
  ShieldCheck,
  Sparkles,
  Star,
  Trophy,
  User as UserIcon,
  LayoutGrid,
  Users,
  X
} from 'lucide-react';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useBranding } from '../context/BrandingContext';
import { db, sanitizeFirestoreData } from '../services/firebase';
import { sendNotification } from '../services/progressionService';
import { getXpRequiredForLevel, MAX_LEVEL } from '../services/xpLevels';
import { isSubscriptionActive } from '../services/subscriptionService';
import { BetaApplication, Book, Chapter, Community, LibraryItem, UserProfile } from '../types';
import { CommunityHomeCarousel } from '../components/CommunityHomeCarousel';
import { UserAvatar } from '../components/UserAvatar';
import { UserBadges } from '../components/UserBadges';
import { UserDisplayName } from '../components/UserDisplayName';
import { usePublicProfile } from '../context/PublicProfileContext';
import { getSynopsisPreview } from '../utils/textUtils';

interface HomeViewProps {
  onSelectBook: (bookId: string) => void;
  onNavigateTab?: (tab: string) => void;
  onExplore?: () => void;
  onReadBook: (bookId: string, chapterNumber?: number) => void;
  onOpenAuth: (tab?: 'login' | 'register') => void;
  onSelectCommunity?: (communityId: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectBook,
  onNavigateTab,
  onExplore,
  onReadBook,
  onOpenAuth,
  onSelectCommunity,
}) => {
  const handleExplore = onExplore || (() => onNavigateTab && onNavigateTab('explore'));
  const navigate = (tab: string) => {
    if (onNavigateTab) {
      onNavigateTab(tab);
    } else if (tab === 'explore' && onExplore) {
      onExplore();
    }
  };
  const { currentUser, userProfile, isDeveloper, isGoogleAuthPending, loginWithGoogle } = useAuth();
  const { branding } = useBranding();
  const { openUserProfile } = usePublicProfile();
  const [featuredBooks, setFeaturedBooks] = useState<Book[]>([]);
  const [popularBooks, setPopularBooks] = useState<Book[]>([]);
  const [recentBooks, setRecentBooks] = useState<Book[]>([]);
  const [bookRecentChapters, setBookRecentChapters] = useState<Record<string, Chapter[]>>({});
  const [showAllRecent, setShowAllRecent] = useState(false);
  const [betaBooks, setBetaBooks] = useState<Book[]>([]);
  const [appliedBetaBooks, setAppliedBetaBooks] = useState<Record<string, string>>({});
  const [betaModalBook, setBetaModalBook] = useState<Book | null>(null);
  const [betaMotivation, setBetaMotivation] = useState('');
  const [submittingBeta, setSubmittingBeta] = useState(false);
  const [betaSuccessToast, setBetaSuccessToast] = useState<string | null>(null);
  const [readingList, setReadingList] = useState<LibraryItem[]>([]);
  const [topRankUsers, setTopRankUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  // Destaques da Semana Carousel state & navigation
  const [featuredIndex, setFeaturedIndex] = useState(0);
  const [isFeaturedPaused, setIsFeaturedPaused] = useState(false);
  const touchStartX = useRef<number | null>(null);

  const featuredList = useMemo(() => {
    const list: Book[] = [...featuredBooks];
    for (const b of popularBooks) {
      if (list.length >= 6) break;
      if (!list.some((x) => x.id === b.id)) {
        list.push(b);
      }
    }
    for (const b of recentBooks) {
      if (list.length >= 6) break;
      if (!list.some((x) => x.id === b.id)) {
        list.push(b);
      }
    }
    if (list.length < 3) {
      const fallbacks: Book[] = [
        {
          id: 'sample-destaque-1',
          title: 'O Pavão Misterioso',
          authorId: 'auth-1',
          authorName: 'José Camelo de Melo',
          synopsis: 'Clássico imortal da literatura de cordel contando a saga do conde Evangelista e a donzela Creusa.',
          coverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
          classification: 'Livre',
          genres: ['Cordel', 'Clássico'],
          status: 'published',
          readersCount: 320,
          viewsCount: 1540,
          likesCount: 210,
          ratingSum: 98,
          ratingCount: 20,
          chaptersCount: 12,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: 'sample-destaque-2',
          title: 'A Chegada de Lampião no Inferno',
          authorId: 'auth-2',
          authorName: 'José Pacheco da Rocha',
          synopsis: 'A célebre peleja entre o Rei do Cangaço e os guardiões das profundezas em versos afiados de sextilha.',
          coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80',
          classification: '12+',
          genres: ['Cordel', 'Aventura'],
          status: 'published',
          readersCount: 280,
          viewsCount: 1320,
          likesCount: 185,
          ratingSum: 89,
          ratingCount: 18,
          chaptersCount: 8,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: 'sample-destaque-3',
          title: 'As Proezas de João Grilo',
          authorId: 'auth-3',
          authorName: 'João Ferreira de Lima',
          synopsis: 'A astúcia e inventividade do herói popular sertanejo que vence qualquer desafio com humor e inteligência.',
          coverUrl: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=600&q=80',
          classification: 'Livre',
          genres: ['Cordel', 'Humor'],
          status: 'published',
          readersCount: 245,
          viewsCount: 1150,
          likesCount: 160,
          ratingSum: 75,
          ratingCount: 15,
          chaptersCount: 10,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ];
      for (const fb of fallbacks) {
        if (list.length >= 3) break;
        if (!list.some((x) => x.id === fb.id)) {
          list.push(fb);
        }
      }
    }
    return list;
  }, [featuredBooks, popularBooks, recentBooks]);

  const handleNextFeatured = useCallback(() => {
    if (featuredList.length <= 1) return;
    setFeaturedIndex((prev) => (prev + 1) % featuredList.length);
  }, [featuredList.length]);

  const handlePrevFeatured = useCallback(() => {
    if (featuredList.length <= 1) return;
    setFeaturedIndex((prev) => (prev - 1 + featuredList.length) % featuredList.length);
  }, [featuredList.length]);

  useEffect(() => {
    if (isFeaturedPaused || featuredList.length <= 1) return;
    const timer = setInterval(() => {
      handleNextFeatured();
    }, 6500);
    return () => clearInterval(timer);
  }, [isFeaturedPaused, featuredList.length, handleNextFeatured]);

  useEffect(() => {
    if (featuredIndex >= featuredList.length && featuredList.length > 0) {
      setFeaturedIndex(0);
    }
  }, [featuredList.length, featuredIndex]);

  const handleFeaturedTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    setIsFeaturedPaused(true);
  };

  const handleFeaturedTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current !== null) {
      const diff = touchStartX.current - e.changedTouches[0].clientX;
      if (diff > 45) {
        handleNextFeatured();
      } else if (diff < -45) {
        handlePrevFeatured();
      }
      touchStartX.current = null;
    }
    setTimeout(() => setIsFeaturedPaused(false), 2500);
  };

  // Dismissed reading progress tracking: tracks bookId and the moment it was ignored.
  // Rule: It only returns if a DIFFERENT work is opened, or if the SAME work is opened to read again (openedAt > dismissedAt).
  interface DismissedReadingRecord {
    bookId: string;
    dismissedAt: number;
  }

  const [dismissedReading, setDismissedReading] = useState<DismissedReadingRecord | null>(() => {
    try {
      const stored = localStorage.getItem('kordel_dismissed_reading');
      if (stored) {
        return JSON.parse(stored) as DismissedReadingRecord;
      }
    } catch {
      return null;
    }
    return null;
  });

  const handleDismissReading = (bookId: string) => {
    const record: DismissedReadingRecord = {
      bookId,
      dismissedAt: Date.now(),
    };
    setDismissedReading(record);
    try {
      localStorage.setItem('kordel_dismissed_reading', JSON.stringify(record));
    } catch (err) {
      console.warn('Could not persist dismissed reading info:', err);
    }
  };

  const handleContinueReading = (bookId: string, chapterNumber?: number) => {
    try {
      const active = {
        bookId,
        currentChapterNumber: chapterNumber || 1,
        openedAt: Date.now(),
      };
      localStorage.setItem('kordel_last_opened_reading', JSON.stringify(active));
    } catch {}
    onReadBook(bookId, chapterNumber);
  };

  const handleOpenBookToRead = (bookId: string, chapterNumber?: number) => {
    try {
      const active = {
        bookId,
        currentChapterNumber: chapterNumber || 1,
        openedAt: Date.now(),
      };
      localStorage.setItem('kordel_last_opened_reading', JSON.stringify(active));
    } catch {}
    onReadBook(bookId, chapterNumber);
  };

  const isReadingItemVisible = useCallback(
    (item: LibraryItem & { openedAt?: number }): boolean => {
      if (!dismissedReading) return true;
      // 1. If user opened a DIFFERENT book, always return true immediately!
      if (item.bookId !== dismissedReading.bookId) {
        return true;
      }
      // 2. If it is the SAME book, return true ONLY if it was opened to read again AFTER being dismissed
      const itemTimestamp =
        item.openedAt || (item.lastReadAt ? new Date(item.lastReadAt).getTime() : 0);
      return itemTimestamp > dismissedReading.dismissedAt;
    },
    [dismissedReading]
  );

  const carouselRef = useRef<HTMLDivElement>(null);
  const betaCarouselRef = useRef<HTMLDivElement>(null);
  const [isBetaPaused, setIsBetaPaused] = useState(false);

  const scrollBetaCarousel = (direction: 'left' | 'right') => {
    if (betaCarouselRef.current) {
      const container = betaCarouselRef.current;
      const maxScroll = container.scrollWidth - container.clientWidth;
      const scrollAmount = 380;
      if (direction === 'right') {
        if (container.scrollLeft >= maxScroll - 15) {
          container.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        }
      } else {
        if (container.scrollLeft <= 15) {
          container.scrollTo({ left: maxScroll, behavior: 'smooth' });
        } else {
          container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
        }
      }
    }
  };

  // Passar automático com tempo determinado para Leituras Beta
  useEffect(() => {
    if (isBetaPaused || betaBooks.length <= 1) return;
    const timer = setInterval(() => {
      scrollBetaCarousel('right');
    }, 5500);
    return () => clearInterval(timer);
  }, [isBetaPaused, betaBooks.length]);

  const canApplyBeta = Boolean(
    isSubscriptionActive(userProfile, 'leitor') ||
      userProfile?.hasExperiencedReaderBadge ||
      isDeveloper
  );
  const [betaError, setBetaError] = useState<string | null>(null);

  const handleOpenBetaModal = (book: Book) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!canApplyBeta) {
      navigate('subscriptions');
      return;
    }
    setBetaError(null);
    setBetaModalBook(book);
    setBetaMotivation('');
  };

  const handleSubmitBeta = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !betaModalBook) return;

    setSubmittingBeta(true);
    setBetaError(null);
    try {
      const appId = `beta_${betaModalBook.id}_${currentUser.uid}`;
      const appData: BetaApplication = {
        id: appId,
        bookId: betaModalBook.id,
        bookTitle: betaModalBook.title,
        authorId: betaModalBook.authorId || '',
        readerId: currentUser.uid,
        readerName: userProfile?.displayName || currentUser.displayName || 'Leitor Experiente',
        readerEmail: currentUser.email || userProfile?.email || '',
        readerLevel: userProfile?.level || 1,
        hasExperiencedBadge: Boolean(userProfile?.hasExperiencedReaderBadge || canApplyBeta),
        motivation: betaMotivation.trim() || 'Candidatura ao Círculo de Leitura Antecipada.',
        status: 'applied',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (!betaModalBook.id.startsWith('beta-sample-')) {
        await setDoc(
          doc(db, 'betaApplications', appId),
          sanitizeFirestoreData(appData)
        );

        if (betaModalBook.authorId && betaModalBook.authorId !== currentUser.uid) {
          try {
            await sendNotification(
              betaModalBook.authorId,
              'beta_event',
              `Nova Candidatura de Leitor Beta: "${betaModalBook.title}"`,
              `${appData.readerName} se candidatou para a leitura beta de sua obra.`,
              '/estudio'
            );
          } catch (notifErr) {
            console.warn('Notice sending beta author notification:', notifErr);
          }
        }
      }

      setAppliedBetaBooks((prev) => ({
        ...prev,
        [betaModalBook.id]: 'applied',
      }));

      setBetaSuccessToast(
        `Sua solicitação de leitura antecipada para "${betaModalBook.title}" foi enviada! O autor analisará seu perfil.`
      );
      setTimeout(() => setBetaSuccessToast(null), 5000);
      setBetaModalBook(null);
    } catch (err: any) {
      console.error('Error submitting beta application:', err);
      setBetaError(
        err?.message || 'Não foi possível registrar sua candidatura no momento. Tente novamente.'
      );
    } finally {
      setSubmittingBeta(false);
    }
  };

  useEffect(() => {
    const loadHomeData = async () => {
      setLoading(true);
      try {
        // 1. Fetch recent books from Firestore
        const recentQuery = query(
          collection(db, 'books'),
          where('status', '==', 'published'),
          limit(50)
        );
        const recentSnap = await getDocs(recentQuery);
        const recentList: Book[] = [];
        recentSnap.forEach((d) => recentList.push(d.data() as Book));

        // Fetch recent chapters for each book to display and calculate latest release activity
        const chaptersMap: Record<string, Chapter[]> = {};
        await Promise.all(
          recentList.map(async (b) => {
            try {
              const chQuery = query(
                collection(db, 'books', b.id, 'chapters'),
                orderBy('chapterNumber', 'desc'),
                limit(3)
              );
              const chSnap = await getDocs(chQuery);
              const chs: Chapter[] = [];
              chSnap.forEach((cd) => chs.push(cd.data() as Chapter));
              if (chs.length > 0) {
                chaptersMap[b.id] = chs;
              }
            } catch (err) {
              try {
                const fallbackSnap = await getDocs(collection(db, 'books', b.id, 'chapters'));
                const fallbackList: Chapter[] = [];
                fallbackSnap.forEach((cd) => fallbackList.push(cd.data() as Chapter));
                fallbackList.sort((x, y) => (y.chapterNumber || 0) - (x.chapterNumber || 0));
                if (fallbackList.length > 0) {
                  chaptersMap[b.id] = fallbackList.slice(0, 3);
                }
              } catch (e2) {
                // Ignore fallback error
              }
            }
          })
        );
        setBookRecentChapters(chaptersMap);

        // Sort by most recent release (new book OR newly released chapter)
        recentList.sort((a, b) => {
          const getLatestTime = (book: Book, chs?: Chapter[]) => {
            let latest = Math.max(
              book.updatedAt ? new Date(book.updatedAt).getTime() : 0,
              book.createdAt ? new Date(book.createdAt).getTime() : 0
            );
            if (chs && chs.length > 0) {
              for (const c of chs) {
                const cTime = Math.max(
                  c.createdAt ? new Date(c.createdAt).getTime() : 0,
                  c.updatedAt ? new Date(c.updatedAt).getTime() : 0
                );
                if (cTime > latest) latest = cTime;
              }
            }
            return latest;
          };
          return getLatestTime(b, chaptersMap[b.id]) - getLatestTime(a, chaptersMap[a.id]);
        });

        setRecentBooks(recentList);

        // 2. Fetch most read books
        const popQuery = query(
          collection(db, 'books'),
          where('status', '==', 'published'),
          orderBy('viewsCount', 'desc'),
          limit(10)
        );
        const popSnap = await getDocs(popQuery);
        const popList: Book[] = [];
        popSnap.forEach((d) => popList.push(d.data() as Book));
        setPopularBooks(popList);

        // 3. Featured Books: Check developer chosen highlights from settings (up to 3)
        const chosenBooks: Book[] = [];
        try {
          const featSettingSnap = await getDoc(doc(db, 'settings', 'featuredBooks'));
          if (featSettingSnap.exists()) {
            const featData = featSettingSnap.data();
            const ids: string[] = (featData?.bookIds || []).slice(0, 3);
            for (const bId of ids) {
              const bookSnap = await getDoc(doc(db, 'books', bId));
              if (bookSnap.exists()) {
                chosenBooks.push(bookSnap.data() as Book);
              }
            }
          } else {
            // Legacy single featured book fallback
            const legacySnap = await getDoc(doc(db, 'settings', 'featuredBook'));
            if (legacySnap.exists()) {
              const featData = legacySnap.data();
              if (featData?.bookId) {
                const bookSnap = await getDoc(doc(db, 'books', featData.bookId));
                if (bookSnap.exists()) {
                  chosenBooks.push(bookSnap.data() as Book);
                }
              }
            }
          }
        } catch (featErr) {
          console.error('Error fetching developer featured book setting:', featErr);
        }

        if (chosenBooks.length > 0) {
          setFeaturedBooks(chosenBooks.slice(0, 3));
        } else if (popList.length > 0) {
          setFeaturedBooks(popList.slice(0, 3));
        } else if (recentList.length > 0) {
          setFeaturedBooks(recentList.slice(0, 3));
        } else {
          setFeaturedBooks([]);
        }

        // 4. Fetch user's active reading progress list (from Firestore or local backup)
        // RULE: Mostre somente a última obra acessada com status de leitura/leitura em andamento. Se houver mais de uma, ignore as outras.
        let items: LibraryItem[] = [];
        if (currentUser) {
          try {
            const librarySnap = await getDocs(
              collection(db, 'libraries', currentUser.uid, 'items')
            );
            librarySnap.forEach((d) => {
              const it = d.data() as LibraryItem;
              const isUnfinished =
                (it.status === 'reading' || (it.progressPercent !== undefined && it.progressPercent > 0)) &&
                it.status !== 'completed' &&
                (it.progressPercent === undefined || it.progressPercent < 100);
              if (isUnfinished) {
                items.push(it);
              }
            });
          } catch (libErr) {
            console.error('Error loading reading progress from Firestore:', libErr);
          }

          // If Firestore is empty or still synchronizing, check local backup
          if (items.length === 0) {
            try {
              const localBackup = localStorage.getItem(`kordel_last_reading_${currentUser.uid}`);
              if (localBackup) {
                const parsed = JSON.parse(localBackup) as LibraryItem;
                if (
                  parsed &&
                  parsed.status !== 'completed' &&
                  (parsed.progressPercent === undefined || parsed.progressPercent < 100)
                ) {
                  items.push(parsed);
                }
              }
            } catch {}
          }
        } else {
          // Guest reading backup
          try {
            const guestBackup = localStorage.getItem('kordel_guest_reading');
            if (guestBackup) {
              const parsed = JSON.parse(guestBackup) as LibraryItem;
              if (
                parsed &&
                parsed.status !== 'completed' &&
                (parsed.progressPercent === undefined || parsed.progressPercent < 100)
              ) {
                items.push(parsed);
              }
            }
          } catch {}
        }

        // Incorporate immediate active reading session (recorded when user opened any work to read)
        try {
          const rawActiveSession = localStorage.getItem('kordel_last_opened_reading');
          if (rawActiveSession) {
            const activeSession = JSON.parse(rawActiveSession);
            if (activeSession && activeSession.bookId) {
              const knownBook =
                chosenBooks.find((b) => b.id === activeSession.bookId) ||
                popList.find((b) => b.id === activeSession.bookId) ||
                recentList.find((b) => b.id === activeSession.bookId);

              const mergedItem: LibraryItem & { openedAt?: number } = {
                id: activeSession.bookId,
                userId: currentUser ? currentUser.uid : 'guest',
                bookId: activeSession.bookId,
                bookTitle: activeSession.bookTitle || knownBook?.title || 'Obra em Leitura',
                bookCover: activeSession.bookCover || knownBook?.coverUrl || '',
                authorName: activeSession.authorName || knownBook?.authorName || 'Autor Kordel',
                status: 'reading',
                currentChapterNumber: activeSession.currentChapterNumber || 1,
                progressPercent: activeSession.progressPercent !== undefined ? activeSession.progressPercent : 5,
                lastReadAt: activeSession.lastReadAt || new Date(activeSession.openedAt || Date.now()).toISOString(),
                openedAt: activeSession.openedAt || Date.now(),
              };

              const existingIdx = items.findIndex((it) => it.bookId === mergedItem.bookId);
              if (existingIdx >= 0) {
                items[existingIdx] = {
                  ...items[existingIdx],
                  ...mergedItem,
                  openedAt: Math.max(
                    mergedItem.openedAt || 0,
                    items[existingIdx].lastReadAt ? new Date(items[existingIdx].lastReadAt!).getTime() : 0
                  ),
                };
              } else {
                items.unshift(mergedItem);
              }
            }
          }
        } catch (activeErr) {
          console.warn('Error reading active session:', activeErr);
        }

        // Sort by most recently read / opened
        items.sort((a, b) => {
          const dateA = (a as LibraryItem & { openedAt?: number }).openedAt || (a.lastReadAt ? new Date(a.lastReadAt).getTime() : 0);
          const dateB = (b as LibraryItem & { openedAt?: number }).openedAt || (b.lastReadAt ? new Date(b.lastReadAt).getTime() : 0);
          return dateB - dateA;
        });

        // Keep ONLY the single latest accessed work
        setReadingList(items.slice(0, 1));

        // 5. Fetch Top 3 ranking users for preview (strictly active Leitor subscribers)
        try {
          const rankQuery = query(collection(db, 'users'), orderBy('xp', 'desc'), limit(50));
          const rankSnap = await getDocs(rankQuery);
          const rankList: UserProfile[] = [];
          rankSnap.forEach((d) => rankList.push(d.data() as UserProfile));
          const subscribersOnly = rankList.filter((u) => isSubscriptionActive(u, 'leitor'));
          const cycleXpCap = getXpRequiredForLevel(MAX_LEVEL + 1);
          subscribersOnly.sort((a, b) => {
            const totalA = (a.progressionCycle || 0) * cycleXpCap + (a.xp || 0);
            const totalB = (b.progressionCycle || 0) * cycleXpCap + (b.xp || 0);
            return totalB - totalA;
          });
          setTopRankUsers(subscribersOnly.slice(0, 3));
        } catch (rankErr) {
          console.error('Error loading top ranking preview:', rankErr);
        }

        // 6. Fetch Beta Books for Early Readers (Bancada dos Primeiros Leitores)
        try {
          const pubQ = query(
            collection(db, 'books'),
            where('status', '==', 'published'),
            limit(30)
          );
          const pubSnap = await getDocs(pubQ);
          const betaList: Book[] = [];
          pubSnap.forEach((d) => {
            const b = d.data() as Book;
            if (b.isBeta) {
              betaList.push(b);
            }
          });

          if (betaList.length > 0) {
            setBetaBooks(betaList);
          } else {
            // Curated showcase beta announcements with authentic author calls
            setBetaBooks([
              {
                id: 'beta-sample-1',
                authorId: 'auth-curated-1',
                authorName: 'Mestre João do Cariri',
                authorPhoto:
                  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
                title: 'Os Ecos da Caatinga Ancestral',
                synopsis:
                  'Nas veredas do sertão profundo, profecias esculpidas em xilogravuras centenárias despertam com a estiagem, desencadeando conflitos de honra e segredos de família que o tempo não conseguiu apagar.',
                coverUrl:
                  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
                genres: ['Cordel', 'Suspense & Mistério', 'Folclore & Lendas'],
                classification: '14+',
                status: 'published',
                isBeta: true,
                betaSpots: 5,
                betaAcceptedCount: 2,
                betaDeadline: 'Até preenchimento das vagas',
                readersCount: 142,
                viewsCount: 650,
                likesCount: 88,
                ratingSum: 48,
                ratingCount: 10,
                chaptersCount: 14,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              },
              {
                id: 'beta-sample-2',
                authorId: 'auth-curated-2',
                authorName: 'Clarice Fontoura',
                authorPhoto:
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
                title: 'O Enigma das Sete Colinas',
                synopsis:
                  'Em uma cidade colonial isolada por brumas persistentes, cartas anônimas revelam crimes futuros. Uma jovem arquivista precisa decifrar as metáforas antes que o último sino ressoe.',
                coverUrl:
                  'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80',
                genres: ['Fantasia', 'Suspense & Mistério', 'Drama'],
                classification: '12+',
                status: 'published',
                isBeta: true,
                betaSpots: 6,
                betaAcceptedCount: 3,
                betaDeadline: 'Próximos 10 dias',
                readersCount: 198,
                viewsCount: 820,
                likesCount: 120,
                ratingSum: 62,
                ratingCount: 13,
                chaptersCount: 18,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              },
            ]);
          }
        } catch (betaErr) {
          console.error('Error loading beta books:', betaErr);
        }
      } catch (err) {
        console.error('Error loading Home data:', err);
      } finally {
        setLoading(false);
      }
    };

    loadHomeData();
  }, [currentUser]);

  // Carregar candidaturas ativas do usuário
  useEffect(() => {
    if (!currentUser) {
      setAppliedBetaBooks({});
      return;
    }
    const loadUserApplications = async () => {
      try {
        const appsQ = query(
          collection(db, 'betaApplications'),
          where('readerId', '==', currentUser.uid)
        );
        const appsSnap = await getDocs(appsQ);
        const appMap: Record<string, string> = {};
        appsSnap.forEach((d) => {
          const app = d.data() as BetaApplication;
          appMap[app.bookId] = app.status;
        });
        setAppliedBetaBooks(appMap);
      } catch (err) {
        console.warn('Could not load user beta applications:', err);
      }
    };
    loadUserApplications();
  }, [currentUser]);

  const scrollCarousel = (direction: 'left' | 'right') => {
    if (carouselRef.current) {
      const scrollAmount = direction === 'left' ? -320 : 320;
      carouselRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Main Container */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-1 sm:pt-2 space-y-8">
        {/* Acesso Rápido via Google para visitantes não autenticados */}
        {!currentUser && (
          <section className="rounded-2xl border border-zinc-800 bg-[#181818]/95 px-4 py-3 sm:px-5 sm:py-3.5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs sm:text-sm font-bold text-white">
                Entre no {branding.appName} com sua conta Google
              </p>
              <p className="text-[11px] sm:text-xs text-zinc-400">
                Salve seu progresso de leitura, participe de comunidades e publique obras sem recarregar a página.
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                disabled={isGoogleAuthPending}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  if (isGoogleAuthPending) return;
                  onOpenAuth('register');
                }}
                className="rounded-xl border border-zinc-700 bg-[#262626] hover:border-[#FF57B2]/60 px-3.5 py-2 text-xs font-semibold text-zinc-200 hover:text-white transition cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
              >
                Criar Conta
              </button>
              <button
                type="button"
                disabled={isGoogleAuthPending}
                aria-busy={isGoogleAuthPending}
                onClick={async (e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  if (isGoogleAuthPending) return;
                  const authPromise = loginWithGoogle();
                  try {
                    await authPromise;
                  } catch (err: any) {
                    const code = err?.code || '';
                    if (
                      code !== 'auth/popup-closed-by-user' &&
                      code !== 'auth/cancelled-popup-request' &&
                      code !== 'auth/cancelled-by-ui-manager'
                    ) {
                      onOpenAuth('login');
                    }
                  }
                }}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-4 py-2 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/25 border border-[#FF57B2]/50 transition cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
              >
                <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-sm bg-white p-0.5">
                  <svg className="h-3 w-3" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                </span>
                <span>{isGoogleAuthPending ? 'Autenticando...' : 'Entrar com Google'}</span>
              </button>
            </div>
          </section>
        )}

        {/* 1. Destaques da Semana: 3 Quadrados (Esquerda, Centro em Destaque, Direita) em Carrossel */}
        {featuredList.length > 0 ? (() => {
          const prevIndex = (featuredIndex - 1 + featuredList.length) % featuredList.length;
          const currentIndex = featuredIndex;
          const nextIndex = (featuredIndex + 1) % featuredList.length;
          const prevBook = featuredList[prevIndex];
          const currentBook = featuredList[currentIndex];
          const nextBook = featuredList[nextIndex];

          return (
            <section className="relative">
              {/* Palco do Carrossel dos 3 Quadrados */}
              <div
                onMouseEnter={() => setIsFeaturedPaused(true)}
                onMouseLeave={() => setIsFeaturedPaused(false)}
                onTouchStart={handleFeaturedTouchStart}
                onTouchEnd={handleFeaturedTouchEnd}
                className="relative overflow-hidden rounded-3xl bg-[#181818]/90 p-2.5 sm:p-5 border border-zinc-800/80 shadow-2xl"
              >
                {/* Controles de Navegação (Setas) flutuantes elegantes sem ocupar espaço superior */}
                {featuredList.length > 1 && (
                  <div className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePrevFeatured();
                      }}
                      className="flex h-7 w-7 sm:h-8 sm:w-8 items-center justify-center rounded-xl bg-black/60 text-zinc-300 hover:text-[#FF57B2] hover:bg-black/85 border border-white/10 transition cursor-pointer shadow-md backdrop-blur-md"
                      title="Destaque anterior"
                      aria-label="Destaque anterior"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleNextFeatured();
                      }}
                      className="flex h-7 w-7 sm:h-8 sm:w-8 items-center justify-center rounded-xl bg-black/60 text-zinc-300 hover:text-[#FF57B2] hover:bg-black/85 border border-white/10 transition cursor-pointer shadow-md backdrop-blur-md"
                      title="Próximo destaque"
                      aria-label="Próximo destaque"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                )}
                {/* Linha superior de destaque Hot Pink */}
                <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-[#FF57B2]/80 to-transparent pointer-events-none z-10" />

                {/* Brilhos decorativos de fundo */}
                <div className="absolute -left-16 -top-16 h-48 w-48 rounded-full bg-[#FF57B2]/10 blur-3xl pointer-events-none" />
                <div className="absolute -right-16 -bottom-16 h-48 w-48 rounded-full bg-[#FF57B2]/10 blur-3xl pointer-events-none" />

                {/* Container dos 3 Cards na proporção original de capas de livros */}
                <div className="relative flex items-center justify-center gap-2 sm:gap-3 md:gap-5 py-0.5 sm:py-2">
                  {/* 1. CARD DA ESQUERDA (Capa de Livro Menor) */}
                  {prevBook && (
                    <div
                      onClick={handlePrevFeatured}
                      className="w-[22%] sm:w-[22%] max-w-[190px] aspect-[2/3] shrink-0 rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer bg-[#202020] border border-zinc-800 shadow-lg opacity-60 hover:opacity-90 scale-90 sm:scale-95 transition-all duration-500 relative group flex flex-col justify-end p-2 sm:p-3.5 text-left hover:border-[#FF57B2]/50"
                      title={`Anterior: ${prevBook.title} (clique para avançar)`}
                    >
                      {/* Capa */}
                      {prevBook.coverUrl ? (
                        <img
                          src={prevBook.coverUrl}
                          alt={prevBook.title}
                          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                      ) : (
                        <div className="absolute inset-0 bg-zinc-900 flex items-center justify-center">
                          <BookOpen className="h-8 w-8 text-zinc-600" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent pointer-events-none" />

                      {/* Legenda do Card Esquerdo */}
                      <div className="relative z-10 min-w-0">
                        <span className="text-[8px] sm:text-[9px] font-bold text-zinc-400 uppercase tracking-wider block mb-0.5 truncate">
                          Anterior
                        </span>
                        <h4 className="font-serif font-black text-xs sm:text-sm text-white line-clamp-1 leading-snug">
                          {prevBook.title}
                        </h4>
                        <p className="text-[10px] text-zinc-400 line-clamp-1">
                          {prevBook.authorName}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* 2. CARD CENTRALIZADO (Capa de Livro em Destaque Central) */}
                  {currentBook && (
                    <div
                      onClick={() => onSelectBook(currentBook.id)}
                      className="w-[44%] sm:w-[40%] max-w-[300px] aspect-[2/3] shrink-0 rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer bg-[#262626] border-2 border-[#FF57B2] shadow-[0_10px_35px_rgba(255,87,178,0.35)] scale-100 sm:scale-105 z-20 transition-all duration-500 relative group flex flex-col justify-between p-3 sm:p-5 text-left"
                      title={`Ver obra em destaque: ${currentBook.title}`}
                    >
                      {/* Brilho Superior do Card Central */}
                      <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-[#FF57B2] to-transparent z-20" />

                      {/* Capa de Alta Resolução Fundo Inteiro */}
                      {currentBook.coverUrl ? (
                        <img
                          src={currentBook.coverUrl}
                          alt={currentBook.title}
                          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                      ) : (
                        <div className="absolute inset-0 bg-zinc-900 flex items-center justify-center">
                          <BookOpen className="h-14 w-14 text-[#FF57B2]" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/55 to-black/25 pointer-events-none" />

                      {/* Topo do Card Central: Selo Destaque Hot Pink & Classificação */}
                      <div className="relative z-10 flex items-center justify-between gap-1.5">
                        <div className="inline-flex items-center gap-1 sm:gap-1.5 px-2.5 py-1 rounded-full bg-[#FF57B2] text-white text-[9px] sm:text-xs font-black uppercase tracking-wider shadow-md shadow-[#FF57B2]/40">
                          <Sparkles className="h-2.5 w-2.5 sm:h-3 sm:w-3" />
                          <span>Destaque</span>
                        </div>

                        <span className="rounded-md bg-black/75 text-zinc-200 border border-zinc-700 px-2 py-0.5 text-[9px] sm:text-[10px] font-black uppercase tracking-wider backdrop-blur-xs">
                          {currentBook.classification || 'Livre'}
                        </span>
                      </div>

                      {/* Rodapé do Card Central: Título, Sinopse e Autor */}
                      <div className="relative z-10 min-w-0 space-y-1 sm:space-y-1.5">
                        <h3 className="text-sm sm:text-base md:text-lg font-serif font-black tracking-tight text-white group-hover:text-[#FF57B2] transition-colors leading-tight line-clamp-2">
                          {currentBook.title}
                        </h3>

                        <p className="hidden sm:line-clamp-2 text-xs text-zinc-300 font-literary leading-relaxed">
                          {getSynopsisPreview(currentBook.synopsis, 120)}
                        </p>

                        <div className="pt-1 flex items-center justify-between gap-2 border-t border-white/15">
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              if (currentBook.authorId) openUserProfile(currentBook.authorId);
                            }}
                            className="flex items-center gap-1.5 min-w-0 group/author"
                            title={`Ver perfil de ${currentBook.authorName}`}
                          >
                            <UserAvatar
                              userId={currentBook.authorId}
                              userName={currentBook.authorName}
                              photoURL={currentBook.authorPhoto}
                              sizeClass="h-5 w-5 sm:h-6 sm:w-6"
                              className="ring-1 ring-zinc-700"
                            />
                            <span className="text-[11px] sm:text-xs text-white font-bold truncate group-hover/author:text-[#FF57B2] transition">
                              {currentBook.authorName}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onReadBook(currentBook.id, 1);
                            }}
                            className="inline-flex items-center gap-1 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-2.5 py-1 text-[11px] sm:text-xs font-bold text-white shadow-md shadow-[#FF57B2]/30 hover:scale-105 transition cursor-pointer"
                          >
                            <BookOpen className="h-3 w-3" />
                            <span>Ler</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* 3. CARD DA DIREITA (Capa de Livro Menor) */}
                  {nextBook && (
                    <div
                      onClick={handleNextFeatured}
                      className="w-[22%] sm:w-[22%] max-w-[190px] aspect-[2/3] shrink-0 rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer bg-[#202020] border border-zinc-800 shadow-lg opacity-60 hover:opacity-90 scale-90 sm:scale-95 transition-all duration-500 relative group flex flex-col justify-end p-2 sm:p-3.5 text-left hover:border-[#FF57B2]/50"
                      title={`Próximo: ${nextBook.title} (clique para colocar no centro)`}
                    >
                      {/* Capa */}
                      {nextBook.coverUrl ? (
                        <img
                          src={nextBook.coverUrl}
                          alt={nextBook.title}
                          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                      ) : (
                        <div className="absolute inset-0 bg-zinc-900 flex items-center justify-center">
                          <BookOpen className="h-8 w-8 text-zinc-600" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent pointer-events-none" />

                      {/* Legenda do Quadrado Direito */}
                      <div className="relative z-10 min-w-0">
                        <span className="text-[8px] sm:text-[9px] font-bold text-[#FF57B2] uppercase tracking-wider block mb-0.5 truncate">
                          Próximo
                        </span>
                        <h4 className="font-serif font-black text-xs sm:text-sm text-white line-clamp-1 leading-snug">
                          {nextBook.title}
                        </h4>
                        <p className="text-[10px] text-zinc-400 line-clamp-1">
                          {nextBook.authorName}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Indicadores de navegação (bolinhas / pills) */}
                {featuredList.length > 1 && (
                  <div className="flex items-center justify-center gap-1.5 pt-3">
                    {featuredList.map((book, dotIdx) => {
                      const isActive = featuredIndex === dotIdx;
                      return (
                        <button
                          key={book.id || dotIdx}
                          type="button"
                          onClick={() => {
                            setFeaturedIndex(dotIdx);
                            setIsFeaturedPaused(true);
                            setTimeout(() => setIsFeaturedPaused(false), 3000);
                          }}
                          className={`transition-all duration-300 rounded-full cursor-pointer ${
                            isActive
                              ? 'h-2 w-6 bg-gradient-to-r from-[#FF57B2] to-[#E03595] shadow-[0_0_8px_rgba(255,87,178,0.7)]'
                              : 'h-2 w-2 bg-zinc-700 hover:bg-[#FF57B2]/60'
                          }`}
                          aria-label={`Ir para destaque ${dotIdx + 1} de ${featuredList.length}: ${book.title}`}
                          title={`Destaque ${dotIdx + 1}: ${book.title}`}
                        />
                      );
                    })}
                  </div>
                )}
              </div>
            </section>
          );
        })() : (
          !loading && (
            <div className="rounded-3xl border border-dashed border-[#FF57B2]/30 bg-[#262626]/80 p-12 text-center shadow-lg">
              <BookOpen className="mx-auto h-12 w-12 text-[#FF57B2] mb-3 drop-shadow-[0_0_10px_rgba(255,87,178,0.4)]" />
              <h3 className="text-lg font-bold text-white font-display">
                Bem-vindo ao {branding.appName}
              </h3>
              <p className="text-sm text-zinc-400 max-w-md mx-auto mt-1 mb-6">
                Ainda não há obras publicadas na plataforma. Seja o primeiro escritor a publicar um cordel independente ou explore as comunidades!
              </p>
              <button
                type="button"
                onClick={() => navigate('studio')}
                className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-5 py-2.5 text-sm font-bold text-white shadow-md shadow-[#FF57B2]/25 border border-[#FF57B2]/40 transition cursor-pointer"
              >
                <Feather className="h-4 w-4" />
                <span>Publicar Minha Primeira Obra</span>
              </button>
            </div>
          )
        )}

        {/* 2. Barra Compacta de Retomada de Leitura (Logo Abaixo dos Destaques) */}
        {readingList.length > 0 && isReadingItemVisible(readingList[0]) && (
          <section className="relative">
            {(() => {
              const item = readingList[0];
              return (
                <div className="group relative flex items-center justify-between rounded-2xl bg-[#262626] border border-zinc-800 hover:border-[#FF57B2]/40 shadow-xl p-2.5 sm:py-3.5 sm:px-5 gap-3 sm:gap-4 transition">
                  {/* Left: Mini Capa */}
                  <div
                    onClick={() => onSelectBook(item.bookId)}
                    className="relative h-14 w-10 sm:h-16 sm:w-11 shrink-0 cursor-pointer overflow-hidden rounded-lg bg-zinc-900 border border-zinc-700/70 shadow-xs"
                    title={`Ver detalhes de "${item.bookTitle}"`}
                  >
                    {item.bookCover ? (
                      <img
                        src={item.bookCover}
                        alt={item.bookTitle}
                        className="h-full w-full object-cover transition group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-zinc-800 text-white font-bold text-xs">
                        {item.bookTitle.charAt(0)}
                      </div>
                    )}
                  </div>

                  {/* Center: Info & Barra de Progresso Compacta */}
                  <div className="flex-1 min-w-0 flex flex-col justify-center space-y-1">
                    <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                      <span className="rounded-md bg-[#FF57B2]/15 text-[#FF57B2] px-2 py-0.5 text-[10px] font-black uppercase tracking-wider border border-[#FF57B2]/30">
                        Em Leitura
                      </span>
                      <span className="text-[10px] sm:text-xs font-semibold text-zinc-300">
                        Capítulo {item.currentChapterNumber || 1}
                      </span>
                      <span className="text-[10px] text-zinc-500">•</span>
                      <span className="text-[10px] sm:text-xs font-bold text-[#FF57B2]">
                        {item.progressPercent || 0}% concluído
                      </span>
                      {item.lastReadAt && (
                        <span className="hidden md:inline-block text-[10px] text-zinc-500">
                          (Acessado em {new Date(item.lastReadAt).toLocaleDateString('pt-BR')})
                        </span>
                      )}
                    </div>

                    <div className="flex items-baseline gap-2">
                      <h3
                        onClick={() => onSelectBook(item.bookId)}
                        className="truncate text-xs sm:text-sm font-black text-white font-display hover:text-[#FF57B2] transition cursor-pointer"
                        title={item.bookTitle}
                      >
                        {item.bookTitle}
                      </h3>
                      <p className="hidden sm:inline-block truncate text-[11px] text-zinc-400 font-medium">
                        Por {item.authorName}
                      </p>
                    </div>

                    {/* Barra de Progresso Fina */}
                    <div className="h-1.5 w-full max-w-xs sm:max-w-md overflow-hidden rounded-full bg-zinc-800 border border-zinc-700/50">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[#FF57B2] to-[#E03595] shadow-[0_0_8px_rgba(255,87,178,0.5)] transition-all duration-500"
                        style={{ width: `${Math.min(item.progressPercent || 0, 100)}%` }}
                      />
                    </div>
                  </div>

                  {/* Right: Ações e Botão Fechar/Ignorar */}
                  <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleContinueReading(item.bookId, item.currentChapterNumber || 1)}
                      className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] active:scale-95 px-3 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-bold text-white shadow-md shadow-[#FF57B2]/25 border border-[#FF57B2]/40 transition cursor-pointer"
                      title="Continuar leitura de onde parou"
                    >
                      <BookOpen className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                      <span>Continuar</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectBook(item.bookId)}
                      className="hidden md:inline-block rounded-xl border border-zinc-700 bg-zinc-800/80 px-3 py-2 text-xs font-semibold text-zinc-300 hover:text-white hover:bg-zinc-700 transition cursor-pointer"
                    >
                      Detalhes
                    </button>
                    {/* Botão Ignorar / Fechar */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDismissReading(item.bookId);
                      }}
                      className="rounded-full p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
                      title="Ignorar por enquanto (volta ao abrir uma obra diferente ou reabrir para ler)"
                      aria-label="Ignorar progresso de leitura"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })()}
          </section>
        )}

        {/* 3. Prévia do Ranking (Pódio Estético em Escala Compacta) */}
        <section className="space-y-2.5">
          {/* Header idêntico à escala de Comunidades Recomendadas */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-6 w-6 sm:h-7 sm:w-7 items-center justify-center rounded-lg bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
                <Trophy className="h-3.5 w-3.5" />
              </div>
              <div>
                <h2 className="text-sm sm:text-base font-bold text-white font-display">
                  Ranking semanal dos leitores assíduos
                </h2>
              </div>
            </div>

            <button
              type="button"
              onClick={() => navigate('ranking')}
              className="text-xs font-bold text-[#FF57B2] hover:text-[#FF40A4] hover:underline flex items-center gap-1 cursor-pointer transition"
            >
              <span>Ver tudo</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {topRankUsers.length === 0 ? (
            <div
              onClick={() => navigate('ranking')}
              className="rounded-2xl border border-zinc-800 bg-[#262626] p-6 text-center text-xs text-zinc-400 shadow-xs cursor-pointer hover:border-[#FF57B2]/40 transition space-y-1.5"
            >
              <Trophy className="h-6 w-6 mx-auto text-[#FF57B2]" />
              <p className="font-bold text-white">Nenhum leitor assinante no pódio ainda</p>
              <p className="text-[11px] text-zinc-400">
                O ranking é exclusivo para quem tem a Assinatura Leitor (R$ 4,90/mês). Clique para ver as honrarias!
              </p>
            </div>
          ) : (
            (() => {
              const user1 = topRankUsers[0] || null;
              const user2 = topRankUsers[1] || null;
              const user3 = topRankUsers[2] || null;

              return (
                <div
                  onClick={() => navigate('ranking')}
                  className="rounded-2xl bg-[#262626] border border-zinc-800 hover:border-[#FF57B2]/40 shadow-xl p-2.5 sm:py-3 sm:px-4 cursor-pointer group transition"
                  title="Clique para ver o ranking completo"
                >
                  <div className="max-w-xs sm:max-w-sm mx-auto w-full">
                    <div className="grid grid-cols-3 items-end gap-2 sm:gap-4 text-center">
                      {/* 2º Lugar - Prata (Esquerda) */}
                      {user2 ? (
                        <div className="flex flex-col items-center group-hover:-translate-y-0.5 transition-transform duration-200">
                          <div className="relative mb-1">
                            <div className="relative mx-auto rounded-full ring-2 ring-zinc-500 shadow-sm">
                              <UserAvatar
                                userId={user2.id}
                                userName={user2.displayName}
                                photoURL={user2.photoURL}
                                sizeClass="h-7 w-7 sm:h-8 sm:w-8"
                              />
                            </div>
                          </div>
                          <p className="text-[11px] sm:text-xs font-bold text-zinc-200 truncate w-full px-1 leading-tight" title={user2.displayName}>
                            {user2.displayName || 'Leitor'}
                          </p>
                          <span className="text-[9px] sm:text-[10px] text-zinc-400 font-medium">
                            Nvl {user2.level || 1}
                          </span>

                          {/* Pedestal Prata */}
                          <div className="w-full mt-1.5 h-6 sm:h-7 rounded-t-lg bg-gradient-to-t from-[#1E1E1E] via-[#2A2A2A] to-[#252525] border-t-2 border-x border-zinc-600 flex items-center justify-center shadow-xs">
                            <span className="text-[11px] sm:text-xs font-black text-zinc-300 font-display">
                              2º
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center opacity-40">
                          <div className="h-7 w-7 sm:h-8 sm:w-8 rounded-full bg-zinc-800 mb-1" />
                          <span className="text-[10px] text-zinc-500">Vago</span>
                          <div className="w-full mt-1.5 h-6 sm:h-7 rounded-t-lg bg-zinc-900 border-t border-zinc-800" />
                        </div>
                      )}

                      {/* 1º Lugar - Campeão (Centro) */}
                      {user1 ? (
                        <div className="flex flex-col items-center group-hover:-translate-y-1 transition-transform duration-200 -mt-1.5">
                          <div className="relative mb-0.5">
                            <Crown className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-[#FF57B2] fill-[#FF57B2]/40 drop-shadow-xs mx-auto mb-0.5 animate-pulse" />
                            <div className="relative mx-auto rounded-full ring-2 ring-[#FF57B2] shadow-[0_0_12px_rgba(255,87,178,0.45)]">
                              <UserAvatar
                                userId={user1.id}
                                userName={user1.displayName}
                                photoURL={user1.photoURL}
                                sizeClass="h-9 w-9 sm:h-10 sm:w-10"
                              />
                            </div>
                          </div>
                          <p className="text-xs sm:text-sm font-black text-white truncate w-full px-1 leading-tight" title={user1.displayName}>
                            {user1.displayName || 'Campeão'}
                          </p>
                          <span className="text-[9px] sm:text-[10px] font-bold text-[#FF57B2]">
                            Nvl {user1.level || 1}
                          </span>

                          {/* Pedestal Campeão */}
                          <div className="w-full mt-1.5 h-9 sm:h-11 rounded-t-lg bg-gradient-to-t from-[#1E1E1E] via-[#2A2A2A] to-[#252525] border-t-2 border-x border-[#FF57B2] flex items-center justify-center gap-1 shadow-[0_0_12px_rgba(255,87,178,0.3)]">
                            <span className="text-xs sm:text-sm font-black text-[#FF57B2] font-display">
                              1º
                            </span>
                            <Trophy className="h-3 w-3 text-[#FF57B2]" />
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center opacity-40">
                          <div className="h-9 w-9 sm:h-10 sm:w-10 rounded-full bg-zinc-800 mb-1" />
                          <span className="text-[10px] text-zinc-500">Vago</span>
                          <div className="w-full mt-1.5 h-9 sm:h-11 rounded-t-lg bg-zinc-900 border-t border-zinc-800" />
                        </div>
                      )}

                      {/* 3º Lugar - Bronze (Direita) */}
                      {user3 ? (
                        <div className="flex flex-col items-center group-hover:-translate-y-0.5 transition-transform duration-200">
                          <div className="relative mb-1">
                            <div className="relative mx-auto rounded-full ring-2 ring-[#FF80C5]/50 shadow-sm">
                              <UserAvatar
                                userId={user3.id}
                                userName={user3.displayName}
                                photoURL={user3.photoURL}
                                sizeClass="h-7 w-7 sm:h-8 sm:w-8"
                              />
                            </div>
                          </div>
                          <p className="text-[11px] sm:text-xs font-bold text-zinc-200 truncate w-full px-1 leading-tight" title={user3.displayName}>
                            {user3.displayName || 'Leitor'}
                          </p>
                          <span className="text-[9px] sm:text-[10px] text-zinc-400 font-medium">
                            Nvl {user3.level || 1}
                          </span>

                          {/* Pedestal 3º Lugar */}
                          <div className="w-full mt-1.5 h-5 sm:h-6 rounded-t-lg bg-gradient-to-t from-[#1E1E1E] via-[#2A2A2A] to-[#252525] border-t-2 border-x border-[#FF80C5]/50 flex items-center justify-center shadow-xs">
                            <span className="text-[11px] sm:text-xs font-black text-[#FF80C5] font-display">
                              3º
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center opacity-40">
                          <div className="h-7 w-7 sm:h-8 sm:w-8 rounded-full bg-zinc-800 mb-1" />
                          <span className="text-[10px] text-zinc-500">Vago</span>
                          <div className="w-full mt-1.5 h-5 sm:h-6 rounded-t-lg bg-zinc-900 border-t border-zinc-800" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })()
          )}
        </section>

        {/* 4. Mais Lidos da Semana (Escala Compacta e Equilibrada) */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-6 w-6 sm:h-7 sm:w-7 items-center justify-center rounded-lg bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
                <Flame className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white font-display">
                Mais lidos da semana
              </h2>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => scrollCarousel('left')}
                className="rounded-xl border border-zinc-700 bg-zinc-850 p-1.5 text-zinc-300 hover:text-white hover:bg-zinc-800 hover:border-[#FF57B2]/60 transition shadow-2xs cursor-pointer"
                title="Anterior"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => scrollCarousel('right')}
                className="rounded-xl border border-zinc-700 bg-zinc-850 p-1.5 text-zinc-300 hover:text-white hover:bg-zinc-800 hover:border-[#FF57B2]/60 transition shadow-2xs cursor-pointer"
                title="Próximo"
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {popularBooks.length === 0 ? (
            <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-5 text-center text-xs text-zinc-400">
              Nenhuma leitura registrada nesta semana ainda. Comece a ler uma obra para inaugurar os rankings!
            </div>
          ) : (
            <div
              ref={carouselRef}
              className="flex gap-3 overflow-x-auto pb-2 pt-0.5 scroll-smooth snap-x snap-mandatory"
            >
              {popularBooks.map((book, idx) => (
                <div
                  key={book.id}
                  onClick={() => onSelectBook(book.id)}
                  className="w-32 sm:w-36 shrink-0 snap-start rounded-2xl bg-[#262626] p-2 sm:p-2.5 shadow-2xs border border-zinc-800 hover:border-[#FF57B2]/60 hover:shadow-[0_0_15px_rgba(255,87,178,0.2)] transition cursor-pointer group flex flex-col justify-between"
                >
                  <div>
                    <div className="relative aspect-[2/3] w-full overflow-hidden rounded-xl bg-zinc-900 mb-2 shadow-2xs border border-zinc-750">
                      {book.coverUrl ? (
                        <img
                          src={book.coverUrl}
                          alt={book.title}
                          className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                        />
                      ) : (
                        <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-b from-zinc-800 to-zinc-900 p-2 text-center text-white">
                          <BookOpen className="h-5 w-5 text-[#FF57B2] mb-1" />
                          <span className="font-literary text-[10px] font-bold line-clamp-2">
                            {book.title}
                          </span>
                        </div>
                      )}
                      <span className="absolute top-1.5 left-1.5 flex h-5 w-5 items-center justify-center rounded-md bg-black/75 text-[10px] font-black text-[#FF57B2] border border-[#FF57B2]/40 shadow-2xs backdrop-blur-xs">
                        #{idx + 1}
                      </span>
                    </div>

                    <h4 className="font-bold text-white text-xs font-literary line-clamp-1 group-hover:text-[#FF57B2] transition">
                      {book.title}
                    </h4>
                    <div className="flex items-center gap-1 text-[10px] text-zinc-400 truncate mt-0.5">
                      <UserDisplayName
                        userId={book.authorId}
                        fallback={book.authorName}
                        className="truncate"
                      />
                      <UserBadges userId={book.authorId} size="xs" />
                    </div>
                  </div>

                  <div className="mt-1.5 flex items-center justify-between pt-1.5 border-t border-zinc-800 text-[10px] text-zinc-400">
                    <span className="flex items-center gap-0.5 font-semibold text-zinc-300">
                      <Star className="h-3 w-3 fill-[#FF57B2] text-[#FF57B2]" />
                      {book.ratingCount > 0
                        ? (book.ratingSum / book.ratingCount).toFixed(1)
                        : 'Novo'}
                    </span>
                    <span>{book.viewsCount || 0} leitores</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* 5. Leituras Beta Exclusivas (Sem título redundante 'Primeiro Olhar' ou descrição, bem colado aos cards com auto-avanço) */}
        {betaBooks.length > 0 && (
          <section
            className="space-y-1.5"
            onMouseEnter={() => setIsBetaPaused(true)}
            onMouseLeave={() => setIsBetaPaused(false)}
            onTouchStart={() => setIsBetaPaused(true)}
            onTouchEnd={() => setTimeout(() => setIsBetaPaused(false), 3000)}
          >
            <div className="flex items-center justify-between pb-0.5">
              <div className="flex items-center gap-2">
                <div className="flex h-5 w-5 sm:h-6 sm:w-6 items-center justify-center rounded-lg bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
                  <Sparkles className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
                </div>
                <h2 className="text-xs sm:text-sm font-bold text-white font-display uppercase tracking-wider flex items-center gap-1.5">
                  <span>Leituras Beta Exclusivas</span>
                </h2>
              </div>

              {betaBooks.length > 1 && (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => scrollBetaCarousel('left')}
                    className="rounded-xl border border-zinc-700 bg-zinc-850 p-1 text-zinc-300 hover:text-white hover:bg-zinc-800 hover:border-[#FF57B2]/60 transition shadow-2xs cursor-pointer"
                    title="Anterior"
                  >
                    <ChevronLeft className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => scrollBetaCarousel('right')}
                    className="rounded-xl border border-zinc-700 bg-zinc-850 p-1 text-zinc-300 hover:text-white hover:bg-zinc-800 hover:border-[#FF57B2]/60 transition shadow-2xs cursor-pointer"
                    title="Próximo"
                  >
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Carrossel de Anúncios de Leitura Beta com Proporção Reduzida */}
            <div
              ref={betaCarouselRef}
              className="flex gap-3.5 overflow-x-auto pb-2 pt-0.5 scroll-smooth snap-x snap-mandatory"
            >
              {betaBooks.map((book) => {
                const isOwnBook = Boolean(currentUser && book.authorId === currentUser.uid);
                const hasApplied = Boolean(appliedBetaBooks[book.id]);

                return (
                  <div
                    key={book.id}
                    className="w-[310px] sm:w-[390px] md:w-[440px] shrink-0 snap-start rounded-2xl border border-zinc-800 bg-[#262626] p-3 sm:p-3.5 shadow-2xs hover:border-[#FF57B2]/60 transition relative flex flex-col justify-between gap-3 shadow-[0_0_15px_rgba(255,87,178,0.12)]"
                  >
                    {/* Top banner tag & Vagas */}
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-2 text-[10px] sm:text-[11px]">
                      <div className="flex items-center gap-1.5 text-[#FF57B2] font-bold uppercase tracking-wider text-[9px] sm:text-[10px]">
                        <Feather className="h-3 w-3 text-[#FF57B2]" />
                        <span>Convite de Leitura Crítica</span>
                      </div>
                      <div className="flex items-center gap-1 font-semibold text-zinc-400 text-[10px]">
                        <span>Vagas:</span>
                        <span className="font-bold text-[#FF57B2]">
                          {book.betaAcceptedCount || 0} de {book.betaSpots || 5}
                        </span>
                      </div>
                    </div>

                    {/* Middle Content */}
                    <div className="flex gap-3 items-start">
                      {/* Cover */}
                      <div
                        onClick={() => onSelectBook(book.id)}
                        className="relative h-28 w-20 sm:h-32 sm:w-22 shrink-0 cursor-pointer overflow-hidden rounded-xl bg-zinc-900 border border-zinc-750 shadow-2xs hover:shadow-xs transition"
                        title={`Ver detalhes de ${book.title}`}
                      >
                        {book.coverUrl ? (
                          <img
                            src={book.coverUrl}
                            alt={book.title}
                            className="h-full w-full object-cover transition duration-300 hover:scale-105"
                          />
                        ) : (
                          <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-b from-zinc-800 to-zinc-900 p-2 text-center text-white">
                            <BookOpen className="h-4 w-4 text-[#FF57B2] mb-1" />
                            <span className="font-literary text-[10px] font-bold line-clamp-2">
                              {book.title}
                            </span>
                          </div>
                        )}
                        <span className="absolute top-1 left-1 rounded-md bg-black/80 text-[#FF57B2] border border-[#FF57B2]/40 px-1 py-0.5 text-[8px] font-black shadow-2xs">
                          BETA
                        </span>
                      </div>

                      {/* Info & Author Announcement */}
                      <div className="flex-1 min-w-0 space-y-1.5">
                        <div>
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              if (book.authorId) openUserProfile(book.authorId);
                            }}
                            className="flex items-center gap-1.5 text-[10px] text-zinc-400 mb-0.5 cursor-pointer group/betaauthor"
                            title={`Ver perfil de ${book.authorName}`}
                          >
                            <UserAvatar
                              userId={book.authorId}
                              userName={book.authorName}
                              photoURL={book.authorPhoto}
                              sizeClass="h-4.5 w-4.5"
                            />
                            <span>por</span>
                            <UserDisplayName
                              userId={book.authorId}
                              fallback={book.authorName}
                              className="font-bold text-white group-hover/betaauthor:text-[#FF57B2] transition truncate"
                            />
                            <UserBadges userId={book.authorId} onlyVerified={true} size="xs" />
                          </div>
                          <h3
                            onClick={() => onSelectBook(book.id)}
                            className="text-xs sm:text-sm font-black text-white font-display hover:text-[#FF57B2] transition cursor-pointer line-clamp-1"
                          >
                            {book.title}
                          </h3>
                        </div>

                        {/* Descrição da Obra / Convite do Autor */}
                        <div className="rounded-lg bg-zinc-900 border border-zinc-800 p-2 text-[10px] sm:text-[11px] text-zinc-300 leading-relaxed font-literary">
                          <p className="line-clamp-2" title={book.synopsis}>
                            {getSynopsisPreview(book.synopsis || 'Busco leitores atentos e dedicados para avaliar os primeiros capítulos desta narrativa e enviar apontamentos críticos...', 95)}
                          </p>
                        </div>

                        {/* Gêneros e Prazo */}
                        <div className="flex items-center gap-1.5 flex-wrap text-[9px] sm:text-[10px] text-zinc-400">
                          {book.genres?.slice(0, 2).map((g) => (
                            <span
                              key={g}
                              className="rounded-md bg-zinc-800 px-1.5 py-0.5 font-medium text-zinc-300 border border-zinc-700"
                            >
                              {g}
                            </span>
                          ))}
                          {book.betaDeadline && (
                            <span className="text-[#FF57B2] font-medium truncate">
                              Prazo: {book.betaDeadline}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Footer Actions / Application Button */}
                    <div className="pt-2 border-t border-zinc-800 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => onSelectBook(book.id)}
                        className="rounded-xl border border-zinc-700 bg-zinc-800 px-2.5 py-1.5 text-[11px] font-semibold text-zinc-300 hover:text-white hover:border-[#FF57B2]/50 transition text-center cursor-pointer shrink-0"
                      >
                        Ver Ficha
                      </button>

                      <div className="flex-1 max-w-[240px] flex flex-col items-end">
                        {isOwnBook ? (
                          <div className="flex items-center gap-1 rounded-xl bg-zinc-800 border border-zinc-700 px-2.5 py-1.5 text-[11px] font-bold text-zinc-300">
                            <span>Sua Obra Beta</span>
                          </div>
                        ) : hasApplied ? (
                          <div className="flex items-center gap-1 rounded-xl bg-[#FF57B2]/15 border border-[#FF57B2]/40 px-2.5 py-1.5 text-[11px] font-bold text-[#FF80C5]">
                            <CheckCircle2 className="h-3.5 w-3.5 text-[#FF57B2]" />
                            <span>
                              {appliedBetaBooks[book.id] === 'approved' ? 'Aprovado' : 'Inscrito'}
                            </span>
                          </div>
                        ) : canApplyBeta ? (
                          <button
                            type="button"
                            onClick={() => handleOpenBetaModal(book)}
                            className="flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] active:scale-95 px-3 py-1.5 text-[11px] sm:text-xs font-bold text-white shadow-sm shadow-[#FF57B2]/25 hover:shadow-[0_0_12px_rgba(255,87,178,0.5)] border border-[#FF57B2]/50 transition cursor-pointer"
                            title="Inscrever-se para ler esta obra em primeira mão"
                          >
                            <Sparkles className="h-3.5 w-3.5 text-white" />
                            <span>Candidatar-se</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOpenBetaModal(book)}
                            className="inline-flex items-center gap-1.5 rounded-xl border border-[#FF57B2]/40 bg-zinc-900 hover:bg-zinc-800 px-2.5 py-1.5 text-[10px] sm:text-[11px] font-bold text-[#FF57B2] transition cursor-pointer shadow-2xs"
                            title="Requer Assinatura Leitor ou selo Leitor Experiente"
                          >
                            <Crown className="h-3 w-3 text-[#FF57B2]" />
                            <span>{currentUser ? 'Assinar p/ Candidatar' : 'Entrar p/ Candidatar'}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Indicações de Comunidades Literárias (Carrossel no Sentido Anti-Horário) */}
        <CommunityHomeCarousel
          onSelectCommunity={(commId) => {
            if (onSelectCommunity) {
              onSelectCommunity(commId);
            } else if (onNavigateTab) {
              onNavigateTab('communities');
            }
          }}
          onExploreCommunities={() => onNavigateTab && onNavigateTab('communities')}
        />

        {/* 4. Lançamentos (Obras e Capítulos Recentes, 2 Colunas, Últimos 3 Capítulos) */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
                <Clock className="h-4 w-4" />
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white font-display">
                Lançamentos
              </h2>
            </div>
            <div className="flex items-center gap-2">
              {recentBooks.length > 8 && (
                <button
                  type="button"
                  onClick={() => setShowAllRecent(!showAllRecent)}
                  className="text-xs font-bold text-[#FF57B2] hover:text-[#FF40A4] hover:underline flex items-center gap-1 transition cursor-pointer"
                >
                  <span>{showAllRecent ? 'Mostrar menos' : `Ver tudo (${recentBooks.length})`}</span>
                  {showAllRecent ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                </button>
              )}
              <button
                type="button"
                onClick={() => navigate('explore')}
                className="text-xs font-semibold text-zinc-400 hover:text-white hover:underline flex items-center gap-1 transition cursor-pointer"
                title="Ir para o catálogo completo de obras"
              >
                <span>Catálogo</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {recentBooks.length === 0 ? (
            <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-6 text-center text-xs text-zinc-400">
              Nenhum lançamento recente cadastrado.
            </div>
          ) : (
            <>
              {/* Grid em duas colunas na vertical: 2 obras lado a lado, 4 em cada lado (8 no total) */}
              <div className="grid grid-cols-2 gap-3 sm:gap-4 md:gap-5">
                {(showAllRecent ? recentBooks : recentBooks.slice(0, 8)).map((book) => (
                  <div
                    key={book.id}
                    onClick={() => onSelectBook(book.id)}
                    className="flex flex-col justify-between rounded-2xl bg-[#262626] p-2.5 sm:p-3 shadow-xs border border-zinc-800 hover:border-[#FF57B2]/60 hover:shadow-[0_0_15px_rgba(255,87,178,0.2)] transition cursor-pointer group"
                  >
                    {/* 1. Capa da Obra no Topo ocupando a largura do card sem sobras laterais */}
                    <div className="relative aspect-[3/4] w-full overflow-hidden rounded-xl bg-zinc-900 shadow-2xs border border-zinc-750">
                      {book.coverUrl ? (
                        <img
                          src={book.coverUrl}
                          alt={book.title}
                          className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
                        />
                      ) : (
                        <div className="flex h-full w-full flex-col items-center justify-center bg-zinc-850 p-4 text-center text-white">
                          <BookOpen className="h-7 w-7 text-[#FF57B2] mb-1.5" />
                          <span className="font-literary text-xs font-bold line-clamp-3">
                            {book.title}
                          </span>
                        </div>
                      )}
                      {book.isBeta && (
                        <span className="absolute top-2 right-2 rounded-md bg-black/85 text-[#FF57B2] border border-[#FF57B2]/40 font-black px-1.5 py-0.5 text-[9px] uppercase tracking-wider shadow-sm backdrop-blur-xs">
                          Beta
                        </span>
                      )}
                    </div>

                    {/* 2. Título da Obra embaixo da capa e acima dos capítulos */}
                    <div className="mt-2.5 mb-2 min-h-[2.4rem] sm:min-h-[2.75rem] flex items-center">
                      <h4
                        className="font-bold text-white text-xs sm:text-sm font-literary line-clamp-2 leading-snug group-hover:text-[#FF57B2] transition"
                        title={book.title}
                      >
                        {book.title}
                      </h4>
                    </div>

                    {/* 3. Abaixo do Título: Últimos 3 Capítulos Lançados */}
                    <div className="pt-2 border-t border-zinc-800">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 mb-1.5 flex items-center justify-between">
                        <span>Últimos Capítulos</span>
                        <span className="text-[9px] font-semibold text-[#FF57B2]">Recentes</span>
                      </div>

                      <div className="space-y-1">
                        {(() => {
                          const chaps = bookRecentChapters[book.id];
                          if (chaps && chaps.length > 0) {
                            return chaps.slice(0, 3).map((chap) => (
                              <button
                                key={chap.id}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onReadBook(book.id, chap.chapterNumber);
                                }}
                                className="w-full flex items-center justify-between gap-1.5 px-2 py-1 rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-[#FF57B2]/50 transition text-left group/chap cursor-pointer"
                                title={`Ler Capítulo ${chap.chapterNumber}: ${chap.title || 'Sem título'}`}
                              >
                                <div className="flex items-center gap-1.5 min-w-0">
                                  <span className="shrink-0 text-[9.5px] font-bold text-[#FF57B2] bg-[#FF57B2]/15 px-1 py-0.2 rounded border border-[#FF57B2]/30">
                                    Cap. {chap.chapterNumber}
                                  </span>
                                  <span className="truncate text-[10.5px] sm:text-[11px] font-medium text-zinc-200 group-hover/chap:text-white transition">
                                    {chap.title || `Capítulo ${chap.chapterNumber}`}
                                  </span>
                                </div>
                                <ChevronRight className="h-3 w-3 shrink-0 text-[#FF57B2] group-hover/chap:translate-x-0.5 transition-transform" />
                              </button>
                            ));
                          }

                          const count = book.chaptersCount && book.chaptersCount > 0 ? book.chaptersCount : 1;
                          const fallbackNums: number[] = [];
                          for (let i = 0; i < Math.min(3, count); i++) {
                            fallbackNums.push(count - i);
                          }
                          return fallbackNums.map((cNum) => (
                            <button
                              key={cNum}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onReadBook(book.id, cNum);
                              }}
                              className="w-full flex items-center justify-between gap-1.5 px-2 py-1 rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-[#FF57B2]/50 transition text-left group/chap cursor-pointer"
                              title={`Ler Capítulo ${cNum}`}
                            >
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span className="shrink-0 text-[9.5px] font-bold text-[#FF57B2] bg-[#FF57B2]/15 px-1 py-0.2 rounded border border-[#FF57B2]/30">
                                  Cap. {cNum}
                                </span>
                                <span className="truncate text-[10.5px] sm:text-[11px] font-medium text-zinc-200 group-hover/chap:text-white transition">
                                  Capítulo {cNum}
                                </span>
                              </div>
                              <ChevronRight className="h-3 w-3 shrink-0 text-[#FF57B2] group-hover/chap:translate-x-0.5 transition-transform" />
                            </button>
                          ));
                        })()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Botão Ver Tudo e Explorar Acervo */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                {recentBooks.length > 8 && (
                  <button
                    type="button"
                    onClick={() => setShowAllRecent(!showAllRecent)}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-2xl bg-zinc-850 hover:bg-zinc-800 border border-zinc-700 px-5 py-2.5 text-xs font-bold text-white shadow-xs hover:shadow-sm transition cursor-pointer"
                  >
                    {showAllRecent ? (
                      <>
                        <ChevronUp className="h-4 w-4 text-[#FF57B2]" />
                        <span>Mostrar menos (ver 8 principais)</span>
                      </>
                    ) : (
                      <>
                        <ChevronDown className="h-4 w-4 text-[#FF57B2]" />
                        <span>Ver tudo (+{recentBooks.length - 8} outras obras existentes)</span>
                      </>
                    )}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => navigate('explore')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white px-5 py-2.5 text-xs font-bold shadow-xs hover:shadow-[0_0_15px_rgba(255,87,178,0.35)] border border-[#FF57B2]/50 transition cursor-pointer"
                >
                  <BookOpen className="h-4 w-4" />
                  <span>Explorar acervo completo</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </>
          )}
        </section>

        {/* 5. Literary Callout for Independent Authors (Dark Charcoal & Hot Pink) */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#262626] via-[#212121] to-[#1A1A1A] p-8 text-white shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 border border-zinc-800 hover:border-[#FF57B2]/40 transition">
          {/* Micro-reflexo de superfície no topo */}
          <div className="absolute inset-x-0 top-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#FF57B2]/50 to-transparent pointer-events-none z-10" />

          {/* Brilho Hot Pink sutil */}
          <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-[#FF57B2]/10 blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-2 max-w-xl text-center md:text-left">
            <h3 className="text-xl sm:text-2xl font-black font-display tracking-tight text-white">
              Publique seus cordéis e romances no {branding.appName}
            </h3>
            <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
              Dê vida às suas obras, recrute Leitores Beta qualificados com o selo Leitor Experiente e receba o apoio dos seus leitores independentes.
            </p>
          </div>
          <button
            type="button"
            onClick={() => (currentUser ? navigate('studio') : onOpenAuth('login'))}
            className="relative z-10 shrink-0 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-6 py-3 text-sm font-bold text-white shadow-md shadow-[#FF57B2]/30 hover:shadow-[0_0_18px_rgba(255,87,178,0.5)] transition cursor-pointer border border-[#FF57B2]/50"
          >
            Acessar Estúdio do Autor
          </button>
        </section>
      </div>

      {/* Modal de Candidatura para Leitor Beta */}
      {betaModalBook && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg rounded-3xl border border-zinc-800 bg-[#202020] p-6 shadow-2xl space-y-4 text-white">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
                  <Award className="h-4.5 w-4.5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-display">
                    Candidatura — Primeiro Olhar
                  </h3>
                  <span className="text-[11px] text-[#FF57B2] font-semibold flex items-center gap-1">
                    <Sparkles className="h-3 w-3" />
                    <span>Acesso Exclusivo: Insígnia de Leitor Experiente</span>
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setBetaModalBook(null)}
                className="rounded-full p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                title="Fechar"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Resumo da Obra */}
            <div className="flex items-center gap-3 rounded-2xl bg-[#262626] border border-zinc-800 p-3">
              {betaModalBook.coverUrl ? (
                <img
                  src={betaModalBook.coverUrl}
                  alt={betaModalBook.title}
                  className="h-16 w-11 rounded-lg object-cover shadow-2xs border border-zinc-700"
                />
              ) : (
                <div className="flex h-16 w-11 items-center justify-center rounded-lg bg-zinc-800 text-[#FF57B2] font-bold text-xs border border-zinc-700">
                  {betaModalBook.title.charAt(0)}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-bold text-white truncate font-literary">
                  {betaModalBook.title}
                </h4>
                <div className="flex items-center gap-1.5 text-xs text-zinc-400 truncate">
                  <span>Autor(a): <UserDisplayName userId={betaModalBook.authorId} fallback={betaModalBook.authorName} /></span>
                  <UserBadges userId={betaModalBook.authorId} isLight={false} size="xs" />
                </div>
                <div className="mt-1 flex items-center gap-2 text-[10px] text-[#FF57B2] font-medium">
                  <span>
                    Vagas: {betaModalBook.betaAcceptedCount || 0} de {betaModalBook.betaSpots || 5}
                  </span>
                  <span>•</span>
                  <span>Prazo: {betaModalBook.betaDeadline || 'A combinar'}</span>
                </div>
              </div>
            </div>

            {/* Formulário de Motivação */}
            <form onSubmit={handleSubmitBeta} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-zinc-300">
                  Considerações do Leitor Crítico
                </label>
                <p className="text-[11px] text-zinc-400">
                  Apresente brevemente sua afinidade com o gênero, sua rotina de leitura e disponibilidade para envio de notas críticas.
                </p>
                <textarea
                  required
                  rows={4}
                  value={betaMotivation}
                  onChange={(e) => setBetaMotivation(e.target.value)}
                  placeholder="Ex: Acompanho com afinco obras do gênero e valorizo muito a consistência narrativa e ritmo de reviravoltas. Posso enviar notas estruturadas sobre cada capítulo..."
                  className="w-full rounded-2xl border border-zinc-700 bg-zinc-900 p-3 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none"
                  maxLength={1000}
                />
              </div>

              {betaError && (
                <div className="rounded-xl border border-[#FF57B2]/50 bg-[#262626] px-3 py-2 text-xs text-[#FF80C5] font-medium">
                  {betaError}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setBetaModalBook(null)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={submittingBeta || !betaMotivation.trim()}
                  className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-4 py-2 text-xs font-bold text-white shadow-sm shadow-[#FF57B2]/30 hover:shadow-[0_0_12px_rgba(255,87,178,0.5)] border border-[#FF57B2]/40 transition cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                >
                  <Sparkles className="h-3.5 w-3.5 text-white" />
                  <span>{submittingBeta ? 'Enviando...' : 'Confirmar Candidatura'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Toast de Sucesso da Candidatura */}
      {betaSuccessToast && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 rounded-2xl bg-[#262626] text-white px-4 py-3 text-xs font-semibold shadow-2xl border border-[#FF57B2]/50 animate-in fade-in slide-in-from-bottom-2 duration-300 max-w-sm">
          <CheckCircle2 className="h-4 w-4 text-[#FF57B2] shrink-0" />
          <span>{betaSuccessToast}</span>
        </div>
      )}
    </div>
  );
};
