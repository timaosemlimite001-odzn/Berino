import {
  arrayRemove,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import {
  AlertCircle,
  AlertTriangle,
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  BadgeCheck,
  BookOpen,
  Calendar,
  Camera,
  Check,
  CheckCircle2,
  ChevronUp,
  Coins,
  Crown,
  Edit2,
  EyeOff,
  FileText,
  Flame,
  Globe,
  Heart,
  Image as ImageIcon,
  Info,
  Loader2,
  Lock,
  LogOut,
  MessageCircle,
  MoreHorizontal,
  Plus,
  RefreshCw,
  Search,
  Send,
  Share2,
  Shield,
  SlidersHorizontal,
  Sparkles,
  TrendingUp,
  UserCheck,
  UserCog,
  UserPlus,
  Users,
  Vote,
  X,
} from 'lucide-react';
import React, { useEffect, useState, useMemo, useRef } from 'react';
import { CommunityFeedCard } from '../components/CommunityFeedCard';
import { CommunityHomeCarousel } from '../components/CommunityHomeCarousel';
import { CommunityMembersModal } from '../components/CommunityMembersModal';
import { CommunityModerationModal } from '../components/CommunityModerationModal';
import { ConfirmModal } from '../components/ConfirmModal';
import { EditCommunityModal } from '../components/EditCommunityModal';
import {
  AdjustedImageOutput,
  ImagePostAdjusterModal,
} from '../components/ImagePostAdjusterModal';
import { ReportModal } from '../components/ReportModal';
import { UserAvatar } from '../components/UserAvatar';
import { UserBadges } from '../components/UserBadges';
import { UserDisplayName } from '../components/UserDisplayName';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db, sanitizeFirestoreData } from '../services/firebase';
import { creditKards, KARD_COSTS, spendKards } from '../services/kardsService';
import { awardXp, checkAndUnlockAchievement, sendNotification } from '../services/progressionService';
import { uploadFileToStorage } from '../services/storageService';
import { isSubscriptionActive, isUserDeveloper } from '../services/subscriptionService';
import {
  Community,
  CommunityMember,
  CommunityPoll,
  CommunityPost,
  PollOption,
  PostImageFormat,
} from '../types';

interface CommunitiesViewProps {
  initialCommunityId?: string;
  onOpenAuth: () => void;
  onNavigateTab?: (tab: string) => void;
  onActiveCommunityChange?: (isInRoom: boolean) => void;
}

type PostTabType = 'text' | 'image' | 'poll';

export const CommunitiesView: React.FC<CommunitiesViewProps> = ({
  initialCommunityId,
  onOpenAuth,
  onNavigateTab,
  onActiveCommunityChange,
}) => {
  const { currentUser, userProfile, isDeveloper } = useAuth();
  const { openUserProfile } = usePublicProfile();
  const { addToast } = useNotifications();
  const [communities, setCommunities] = useState<Community[]>([]);
  const [activeCommunity, setActiveCommunity] = useState<Community | null>(null);
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todas');

  // Membership status for active community
  const [isMember, setIsMember] = useState(false);
  const [isPendingMember, setIsPendingMember] = useState(false);
  const [isCreator, setIsCreator] = useState(false);
  const [isModerator, setIsModerator] = useState(false);
  const [joiningGroup, setJoiningGroup] = useState(false);
  const [joinedCommunityIds, setJoinedCommunityIds] = useState<string[]>([]);
  const [pendingCommunityIds, setPendingCommunityIds] = useState<string[]>([]);
  const [copiedCommId, setCopiedCommId] = useState<string | null>(null);

  // Create community modal
  const [showCreateCommModal, setShowCreateCommModal] = useState(false);
  const [newCommName, setNewCommName] = useState('');
  const [newCommDesc, setNewCommDesc] = useState('');
  const [newCommRules, setNewCommRules] = useState('');
  const [newCommCategory, setNewCommCategory] = useState('Geral');
  const [newCommIsPrivate, setNewCommIsPrivate] = useState(false);
  const [newCommIsHidden, setNewCommIsHidden] = useState(false);
  const [newCommHidePosts, setNewCommHidePosts] = useState(false);
  const [newCommCoverFile, setNewCommCoverFile] = useState<File | null>(null);
  const [newCommCoverPreview, setNewCommCoverPreview] = useState('');
  const [newCommAvatarFile, setNewCommAvatarFile] = useState<File | null>(null);
  const [newCommAvatarPreview, setNewCommAvatarPreview] = useState('');
  const [creatingComm, setCreatingComm] = useState(false);
  const [commError, setCommError] = useState('');

  // Edit Community Modal (para criador editar ambas as fotos e dados)
  const [showEditCommunityModal, setShowEditCommunityModal] = useState(false);

  // Quick Privacy & Hiding Modal inside Community Room
  const [showQuickPrivacyModal, setShowQuickPrivacyModal] = useState(false);
  const [savingQuickPrivacy, setSavingQuickPrivacy] = useState(false);

  // Moderation Modal & Suspended Members List Modal
  const [showModerationModal, setShowModerationModal] = useState(false);
  const [showMembersModal, setShowMembersModal] = useState(false);
  const [staffReloadTick, setStaffReloadTick] = useState(0);

  // Leave Community confirmation state
  const [confirmLeaveOpen, setConfirmLeaveOpen] = useState(false);
  const [leavingCommunity, setLeavingCommunity] = useState(false);

  // 360-degree Pull-to-refresh no rodapé & Seta para rolar até a última publicação
  const [showScrollBottomBtn, setShowScrollBottomBtn] = useState(false);
  const [showCommentsScrollTopBtn, setShowCommentsScrollTopBtn] = useState(false);
  const [refreshProgress, setRefreshProgress] = useState(0); // 0 a 100%
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [refreshSuccess, setRefreshSuccess] = useState(false);
  const [selectedPostForComments, setSelectedPostForComments] = useState<CommunityPost | null>(null);
  const savedFeedScrollYRef = useRef<number>(0);
  const commentsTopRef = useRef<HTMLDivElement>(null);
  const [showCommunityDetailsPage, setShowCommunityDetailsPage] = useState(false);
  const [communityStaff, setCommunityStaff] = useState<CommunityMember[]>([]);
  const [loadingStaff, setLoadingStaff] = useState(false);
  const postsEndRef = useRef<HTMLDivElement>(null);
  const hasAutoScrolledRef = useRef(false);

  // New Post Form
  const [postType, setPostType] = useState<PostTabType>('text');
  const [postContent, setPostContent] = useState('');
  const [postImageFile, setPostImageFile] = useState<File | null>(null);
  const [postImageOriginalFile, setPostImageOriginalFile] = useState<File | null>(null);
  const [postImageOriginalUrl, setPostImageOriginalUrl] = useState('');
  const [postImagePreview, setPostImagePreview] = useState('');
  const [postImageFormat, setPostImageFormat] = useState<PostImageFormat>('default');
  const [postImageZoom, setPostImageZoom] = useState(1);
  const [postImagePanX, setPostImagePanX] = useState(0);
  const [postImagePanY, setPostImagePanY] = useState(0);
  const [showPostImageAdjuster, setShowPostImageAdjuster] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [postIsPrivate, setPostIsPrivate] = useState(false);
  const [postIsHiddenFromNonMembers, setPostIsHiddenFromNonMembers] = useState(false);
  const [submittingPost, setSubmittingPost] = useState(false);
  const [postError, setPostError] = useState('');

  const activePostForComments = useMemo(() => {
    if (!selectedPostForComments) return null;
    return (
      posts.find((p) => p.id === selectedPostForComments.id) ||
      selectedPostForComments
    );
  }, [posts, selectedPostForComments]);

  const handleOpenPostComments = (post: CommunityPost) => {
    savedFeedScrollYRef.current = window.scrollY || window.pageYOffset || 0;
    setSelectedPostForComments(post);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleClosePostComments = () => {
    const restoreY = savedFeedScrollYRef.current;
    setSelectedPostForComments(null);
    setShowCommentsScrollTopBtn(false);
    requestAnimationFrame(() => {
      window.scrollTo({ top: restoreY, behavior: 'auto' });
    });
  };

  const scrollCommentsToTop = () => {
    if (commentsTopRef.current) {
      commentsTopRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Anti-spam cooldown
  const [postCooldown, setPostCooldown] = useState<number>(() => {
    try {
      const last = localStorage.getItem('cordel_last_post_time');
      if (last) {
        const elapsed = (Date.now() - parseInt(last, 10)) / 1000;
        if (elapsed < 15) return Math.ceil(15 - elapsed);
      }
    } catch {
      // ignore
    }
    return 0;
  });

  useEffect(() => {
    if (postCooldown <= 0) return;
    const timer = setInterval(() => {
      setPostCooldown((p) => (p > 0 ? p - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [postCooldown]);

  // Reporting
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState<{ id: string; summary: string; type: 'community' | 'post' }>({
    id: '',
    summary: '',
    type: 'community',
  });

  // 1. Fetch communities list
  useEffect(() => {
    const q = query(collection(db, 'communities'), orderBy('membersCount', 'desc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: Community[] = [];
        snap.forEach((d) => list.push(d.data() as Community));
        setCommunities(list);

        if (initialCommunityId && !activeCommunity) {
          const found = list.find((c) => c.id === initialCommunityId);
          if (found) {
            setActiveCommunity(found);
          }
        }
        setLoading(false);
      },
      (err) => {
        console.error('Error fetching communities:', err);
        setLoading(false);
      }
    );
    return () => unsub();
  }, [initialCommunityId]);

  useEffect(() => {
    if (initialCommunityId && communities.length > 0) {
      const found = communities.find((c) => c.id === initialCommunityId);
      if (found && activeCommunity?.id !== found.id) {
        setActiveCommunity(found);
      }
    }
  }, [initialCommunityId, communities]);

  useEffect(() => {
    onActiveCommunityChange?.(Boolean(activeCommunity));
  }, [activeCommunity, onActiveCommunityChange]);

  // 2. Fetch user's joined & pending communities
  useEffect(() => {
    if (!currentUser) {
      setJoinedCommunityIds([]);
      setPendingCommunityIds([]);
      return;
    }

    const checkJoined = async () => {
      try {
        const joined: string[] = [];
        const pending: string[] = [];
        for (const comm of communities) {
          if (comm.creatorId === currentUser.uid) {
            joined.push(comm.id);
            continue;
          }
          const memRef = doc(db, 'communities', comm.id, 'members', currentUser.uid);
          const snap = await getDoc(memRef);
          if (snap.exists()) {
            const mData = snap.data() as Partial<CommunityMember>;
            if (mData.status === 'pending') {
              pending.push(comm.id);
            } else if (mData.status !== 'banned') {
              joined.push(comm.id);
            }
          }
        }
        setJoinedCommunityIds(joined);
        setPendingCommunityIds(pending);
      } catch (err) {
        console.error('Error checking joined communities:', err);
      }
    };

    if (communities.length > 0) {
      checkJoined();
    }
  }, [currentUser?.uid, communities.length]);

  // 3. Fetch posts when active community changes (mais recentes por último, de cima para baixo)
  useEffect(() => {
    if (!activeCommunity) {
      setPosts([]);
      return;
    }

    const q = query(
      collection(db, 'communities', activeCommunity.id, 'posts'),
      orderBy('createdAt', 'asc')
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: CommunityPost[] = [];
        snap.forEach((d) => list.push(d.data() as CommunityPost));
        setPosts(list);
      },
      (err) => {
        console.error('Error fetching posts:', err);
      }
    );

    return () => unsub();
  }, [activeCommunity?.id]);

  // Abre na atualização mais recente que está lá em baixo ao entrar na comunidade
  useEffect(() => {
    hasAutoScrolledRef.current = false;
    setShowCommunityDetailsPage(false);
    setCommunityStaff([]);
  }, [activeCommunity?.id]);

  // Carrega administradores e moderadores reais quando o usuário abre a página dedicada da comunidade
  useEffect(() => {
    if (!activeCommunity || !showCommunityDetailsPage) return;
    let cancelled = false;
    setLoadingStaff(true);

    const loadStaff = async () => {
      try {
        const snap = await getDocs(
          collection(db, 'communities', activeCommunity.id, 'members')
        );
        if (cancelled) return;

        const partialSet = new Set(activeCommunity.partialModeratorIds || []);
        const staffMap = new Map<string, CommunityMember>();

        snap.forEach((d) => {
          const m = d.data() as CommunityMember;
          const uid = m.userId || d.id;
          const isCreatorUid = uid === activeCommunity.creatorId;
          const isMod = m.role === 'creator' || m.role === 'moderator';
          const isPartial =
            m.role === 'partial_moderator' || partialSet.has(uid);

          if (isCreatorUid || isMod || isPartial) {
            staffMap.set(uid, {
              ...m,
              userId: uid,
              role: isCreatorUid
                ? 'creator'
                : m.role === 'moderator'
                ? 'moderator'
                : 'partial_moderator',
            });
          }
        });

        // Garante que o fundador esteja sempre presente na lista de administração
        if (activeCommunity.creatorId && !staffMap.has(activeCommunity.creatorId)) {
          staffMap.set(activeCommunity.creatorId, {
            id: activeCommunity.creatorId,
            communityId: activeCommunity.id,
            userId: activeCommunity.creatorId,
            userName: activeCommunity.creatorName || 'Fundador',
            role: 'creator',
            status: 'active',
            joinedAt: activeCommunity.createdAt || new Date().toISOString(),
          });
        }

        const ordered = Array.from(staffMap.values()).sort((a, b) => {
          const rank = (r: string) =>
            r === 'creator' ? 0 : r === 'moderator' ? 1 : 2;
          return rank(a.role) - rank(b.role);
        });

        setCommunityStaff(ordered);
      } catch (err) {
        console.warn('Could not load community administrators:', err);
      } finally {
        if (!cancelled) setLoadingStaff(false);
      }
    };

    loadStaff();
    return () => {
      cancelled = true;
    };
  }, [activeCommunity?.id, activeCommunity?.creatorId, activeCommunity?.partialModeratorIds, showCommunityDetailsPage, staffReloadTick]);

  useEffect(() => {
    if (
      activeCommunity &&
      !showCommunityDetailsPage &&
      posts.length > 0 &&
      !hasAutoScrolledRef.current
    ) {
      hasAutoScrolledRef.current = true;
      const t = setTimeout(() => {
        postsEndRef.current?.scrollIntoView({ behavior: 'auto' });
      }, 120);
      return () => clearTimeout(t);
    }
  }, [activeCommunity, showCommunityDetailsPage, posts.length]);

  // Função para atualizar as publicações ao completar o círculo de 360 graus
  const handleRefreshPosts = async () => {
    if (!activeCommunity || isRefreshing) return;
    setIsRefreshing(true);
    setRefreshSuccess(false);

    // Requisito do Usuário: fechar comentários abertos, processos de publicação não terminada e rascunhos
    setSelectedPostForComments(null);
    setPostContent('');
    setPostImageFile(null);
    setPostImagePreview('');
    setPollQuestion('');
    setPollOptions(['', '']);
    setPostError('');

    try {
      const q = query(
        collection(db, 'communities', activeCommunity.id, 'posts'),
        orderBy('createdAt', 'asc')
      );
      const snap = await getDocs(q);
      const list: CommunityPost[] = [];
      snap.forEach((d) => list.push(d.data() as CommunityPost));
      setPosts(list);
      setRefreshSuccess(true);
      setTimeout(() => {
        setRefreshSuccess(false);
        setRefreshProgress(0);
        setIsPulling(false);
      }, 1000);
    } catch (err) {
      console.error('Error refreshing posts:', err);
      setRefreshProgress(0);
      setIsPulling(false);
    } finally {
      setIsRefreshing(false);
    }
  };

  const scrollToBottom = () => {
    postsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Listener de rolagem para seta de ir ao final e gesto intencional de puxar para cima no rodapé (estilo WhatsApp modo temporário/atualização)
  useEffect(() => {
    if (!activeCommunity) return;

    let touchStartY = 0;
    let isTrackingBottomPull = false;

    const handleScroll = () => {
      const scrollY = window.scrollY || window.pageYOffset;
      const windowHeight = window.innerHeight;
      const docHeight = document.documentElement.scrollHeight;
      const distanceFromBottom = docHeight - (scrollY + windowHeight);

      // Seta para rolar até a última publicação: visível apenas no feed principal da comunidade
      setShowScrollBottomBtn(!selectedPostForComments && distanceFromBottom > 240);

      // Seta exclusiva quando os comentários de uma publicação estão abertos e o usuário desceu
      setShowCommentsScrollTopBtn(
        Boolean(selectedPostForComments) && !showCommunityDetailsPage && scrollY > 180
      );
    };

    const handleTouchStart = (e: TouchEvent) => {
      const scrollY = window.scrollY || window.pageYOffset;
      const windowHeight = window.innerHeight;
      const docHeight = document.documentElement.scrollHeight;
      // Inicia o rastreamento se o usuário estiver próximo ao rodapé (últimos 80px)
      if (scrollY + windowHeight >= docHeight - 80) {
        touchStartY = e.touches[0].clientY;
        isTrackingBottomPull = true;
      } else {
        isTrackingBottomPull = false;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isRefreshing || !isTrackingBottomPull) return;
      const currentY = e.touches[0].clientY;
      const diffY = touchStartY - currentY; // puxando para cima

      if (diffY > 5) {
        setIsPulling(true);
        // Escala elástica: 70px de puxada completa os 100%
        const progress = Math.min(100, Math.max(0, ((diffY - 5) / 65) * 100));
        setRefreshProgress(progress);
      } else if (diffY <= 0) {
        setRefreshProgress(0);
        setIsPulling(false);
      }
    };

    const handleTouchEnd = () => {
      if (isTrackingBottomPull && refreshProgress >= 75) {
        handleRefreshPosts();
      } else {
        setRefreshProgress(0);
        setIsPulling(false);
      }
      isTrackingBottomPull = false;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd, { passive: true });

    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [activeCommunity?.id, isRefreshing, posts.length, refreshProgress, selectedPostForComments, showCommunityDetailsPage]);

  // 4. Check membership & creator status in active community
  useEffect(() => {
    if (!activeCommunity || !currentUser) {
      setIsMember(false);
      setIsPendingMember(false);
      setIsCreator(false);
      setIsModerator(false);
      return;
    }

    if (activeCommunity.creatorId === currentUser.uid) {
      setIsCreator(true);
      setIsMember(true);
      setIsPendingMember(false);
      setIsModerator(true);
      return;
    }

    setIsCreator(false);

    const memberDocRef = doc(db, 'communities', activeCommunity.id, 'members', currentUser.uid);
    const unsub = onSnapshot(
      memberDocRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data() as Partial<CommunityMember>;
          if (data?.status === 'pending') {
            setIsMember(false);
            setIsPendingMember(true);
            setIsModerator(false);
          } else if (data?.status === 'banned') {
            setIsMember(false);
            setIsPendingMember(false);
            setIsModerator(false);
          } else {
            setIsMember(true);
            setIsPendingMember(false);
            const memberRole = data?.role;
            setIsModerator(memberRole === 'moderator' || memberRole === 'creator');
          }
        } else {
          setIsMember(false);
          setIsPendingMember(false);
          setIsModerator(false);
        }
      },
      (err) => {
        console.error('Error checking membership:', err);
      }
    );

    return () => unsub();
  }, [activeCommunity?.id, currentUser?.uid, activeCommunity?.creatorId]);

  // Self-heal creatorName on active community if current user is creator and has updated nickname
  useEffect(() => {
    if (
      currentUser &&
      userProfile?.displayName &&
      activeCommunity &&
      activeCommunity.creatorId === currentUser.uid &&
      activeCommunity.creatorName !== userProfile.displayName
    ) {
      updateDoc(doc(db, 'communities', activeCommunity.id), {
        creatorName: userProfile.displayName,
      }).catch(() => {});
    }
  }, [currentUser?.uid, userProfile?.displayName, activeCommunity?.id, activeCommunity?.creatorId, activeCommunity?.creatorName]);

  // Banned and Silenced state calculations
  const isBanned = Boolean(currentUser && activeCommunity?.bannedUserIds?.includes(currentUser.uid));
  const silencedUntil = currentUser && activeCommunity?.silencedUntilMap?.[currentUser.uid];
  const isSilenced = Boolean(
    currentUser &&
      activeCommunity?.silencedUserIds?.includes(currentUser.uid) &&
      silencedUntil &&
      new Date(silencedUntil).getTime() > Date.now()
  );

  // Authorizations: community administrator (creator or promoted moderator) or platform developer
  const isCommunityAdmin = Boolean(
    currentUser && (isCreator || isModerator || isDeveloper)
  );
  const isPartialModerator = Boolean(
    currentUser &&
      activeCommunity &&
      (activeCommunity.partialModeratorIds?.includes(currentUser.uid) || isModerator)
  );
  const canPublish = Boolean(
    currentUser && (isCreator || isDeveloper || isPartialModerator)
  );

  // Helper for activity badge (Dark-mode KORDEL palette)
  const getActivityBadge = (c: Community) => {
    const count = c.membersCount || 1;
    const pCount = c.postsCount || 0;

    if (pCount >= 10 || count >= 20 || c.activityLevel === 'intense') {
      return {
        label: 'Atividade Intensa',
        icon: <Flame className="h-3 w-3 text-[#FF57B2]" />,
        bg: 'bg-[#FF57B2]/15 text-[#FF80C5] border-[#FF57B2]/35',
      };
    }
    if (pCount >= 4 || count >= 8 || c.activityLevel === 'high') {
      return {
        label: 'Alta Atividade',
        icon: <TrendingUp className="h-3 w-3 text-[#FF80C5]" />,
        bg: 'bg-[#262626] text-white border-[#FF57B2]/45',
      };
    }
    if (pCount >= 1 || count >= 3 || c.activityLevel === 'moderate') {
      return {
        label: 'Atividade Moderada',
        icon: <Sparkles className="h-3 w-3 text-[#FF57B2]" />,
        bg: 'bg-[#262626] text-zinc-200 border-zinc-700',
      };
    }
    return {
      label: 'Em Crescimento',
      icon: <Users className="h-3 w-3 text-zinc-400" />,
      bg: 'bg-[#1A1A1A] text-zinc-300 border-zinc-800',
    };
  };

  // Validação: Criação de comunidade exclusiva para Plano Escritor (R$ 13,49/mês) ou Desenvolvedor
  const hasActiveEscritorPlan = Boolean(
    currentUser &&
      (isUserDeveloper(userProfile || {}) || isSubscriptionActive(userProfile, 'escritor'))
  );

  // Verificação de cota: Apenas 1 comunidade durante a assinatura ativa (renovável a cada ciclo)
  const communityCreatedThisCycle = useMemo(() => {
    if (!currentUser || isUserDeveloper(userProfile || {})) return false;
    if (!userProfile?.subscription) return false;

    // 1. Contador direto gravado na assinatura do usuário
    if ((userProfile.subscription.communitiesCreatedThisCycle || 0) >= 1) {
      return true;
    }

    // 2. Verificação com base na data de início do ciclo atual da assinatura
    const cycleStart = userProfile.subscription.startedAt
      ? new Date(userProfile.subscription.startedAt).getTime()
      : 0;

    if (cycleStart > 0 && communities.length > 0) {
      const alreadyCreated = communities.some((c) => {
        if (c.creatorId !== currentUser.uid) return false;
        const commCreatedTime = c.createdAt ? new Date(c.createdAt).getTime() : 0;
        return commCreatedTime >= cycleStart;
      });
      if (alreadyCreated) return true;
    }

    return false;
  }, [currentUser?.uid, userProfile?.subscription, communities]);

  const subscriptionRenewalDate = useMemo(() => {
    if (!userProfile?.subscription?.currentPeriodEnd) return null;
    return new Date(userProfile.subscription.currentPeriodEnd).toLocaleDateString('pt-BR');
  }, [userProfile?.subscription?.currentPeriodEnd]);

  // Create Community (Exclusivo Plano Escritor - R$ 13,49/mês • 1 por assinatura ativa)
  const handleCreateCommunity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    setCommError('');

    if (!hasActiveEscritorPlan) {
      setCommError(
        'A criação de comunidades é exclusiva para assinantes do Plano Escritor (R$ 13,49/mês). Assine o plano para fundar sua comunidade.'
      );
      return;
    }

    if (communityCreatedThisCycle) {
      setCommError(
        'Você já criou 1 comunidade durante esta assinatura ativa (limite de 1 comunidade por ciclo). Uma nova criação estará disponível assim que sua assinatura for renovada no próximo ciclo.'
      );
      return;
    }

    setCreatingComm(true);

    try {
      const commId = `comm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

      let coverUrl = '';
      if (newCommCoverFile) {
        coverUrl = await uploadFileToStorage(newCommCoverFile, 'covers', commId);
      }
      let iconUrl = '';
      if (newCommAvatarFile) {
        iconUrl = await uploadFileToStorage(newCommAvatarFile, 'avatars', `${commId}_icon`);
      }

      const newComm: Community = {
        id: commId,
        name: newCommName.trim(),
        description: newCommDesc.trim(),
        rules: newCommRules.trim(),
        category: newCommCategory,
        coverUrl,
        ...(iconUrl ? { iconUrl, avatarUrl: iconUrl } : {}),
        isPrivate: newCommIsPrivate,
        isHiddenFromNonMembers: newCommIsHidden,
        hidePostsFromNonMembers: newCommHidePosts,
        creatorId: currentUser.uid,
        creatorName: userProfile?.displayName || 'Fundador Literário',
        membersCount: 1,
        postsCount: 0,
        userPostsCount: 0,
        activityLevel: 'growing',
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'communities', commId), sanitizeFirestoreData(newComm));

      const memberData: CommunityMember = {
        id: currentUser.uid,
        communityId: commId,
        userId: currentUser.uid,
        userName: userProfile?.displayName || 'Fundador',
        userPhoto: userProfile?.photoURL || '',
        role: 'creator',
        status: 'active',
        joinedAt: new Date().toISOString(),
      };

      await setDoc(
        doc(db, 'communities', commId, 'members', currentUser.uid),
        sanitizeFirestoreData(memberData)
      );

      // Registra a cota de 1 comunidade consumida no ciclo atual da assinatura no Firestore
      try {
        await updateDoc(doc(db, 'users', currentUser.uid), {
          'subscription.communitiesCreatedThisCycle':
            (userProfile?.subscription?.communitiesCreatedThisCycle || 0) + 1,
          'subscription.createdCommunityId': commId,
          'subscription.createdCommunityAt': new Date().toISOString(),
        });
      } catch (subErr) {
        console.warn('Could not update subscription community counter:', subErr);
      }

      await awardXp(
        currentUser.uid,
        100,
        `create_comm_${commId}`,
        `Fundação do grupo: ${newComm.name}`
      );

      setShowCreateCommModal(false);
      setActiveCommunity(newComm);
      setNewCommName('');
      setNewCommDesc('');
      setNewCommRules('');
      setNewCommIsPrivate(false);
      setNewCommIsHidden(false);
      setNewCommHidePosts(false);
      setNewCommCoverFile(null);
      setNewCommCoverPreview('');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      setCommError(err.message || 'Falha ao criar comunidade.');
    } finally {
      setCreatingComm(false);
    }
  };

  // Quick toggle community privacy field directly from the room
  const handleToggleCommunityPrivacyField = async (
    field: 'isPrivate' | 'isHiddenFromNonMembers' | 'hidePostsFromNonMembers'
  ) => {
    if (!activeCommunity || (!isCreator && !isDeveloper) || savingQuickPrivacy) return;
    const nextValue = !Boolean(activeCommunity[field]);
    setSavingQuickPrivacy(true);
    try {
      await updateDoc(doc(db, 'communities', activeCommunity.id), {
        [field]: nextValue,
        updatedAt: new Date().toISOString(),
      });
      setActiveCommunity((prev) => (prev ? { ...prev, [field]: nextValue } : null));
      setCommunities((prev) =>
        prev.map((c) => (c.id === activeCommunity.id ? { ...c, [field]: nextValue } : c))
      );
    } catch (err) {
      console.error('Error toggling community privacy setting:', err);
    } finally {
      setSavingQuickPrivacy(false);
    }
  };

  // Join Community (Supports both open communities and private communities requiring approval)
  const handleJoinCommunity = async () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!activeCommunity || isBanned || isPendingMember) return;
    setJoiningGroup(true);

    try {
      const requiresApproval = Boolean(
        activeCommunity.isPrivate && activeCommunity.creatorId !== currentUser.uid
      );
      const memberRef = doc(db, 'communities', activeCommunity.id, 'members', currentUser.uid);
      const memberData: CommunityMember = {
        id: currentUser.uid,
        communityId: activeCommunity.id,
        userId: currentUser.uid,
        userName: userProfile?.displayName || 'Leitor',
        userPhoto: userProfile?.photoURL || '',
        role: 'member',
        status: requiresApproval ? 'pending' : 'active',
        joinedAt: new Date().toISOString(),
      };

      await setDoc(memberRef, sanitizeFirestoreData(memberData));

      if (requiresApproval) {
        setIsPendingMember(true);
        setPendingCommunityIds((prev) => Array.from(new Set([...prev, activeCommunity.id])));
        if (activeCommunity.creatorId !== currentUser.uid) {
          sendNotification(
            activeCommunity.creatorId,
            'community_join',
            'Solicitação para entrar na comunidade',
            `${userProfile?.displayName || 'Um leitor'} solicitou entrada na comunidade privada "${activeCommunity.name}".`,
            `/comunidade/${activeCommunity.id}`
          );
        }
        addToast({
          id: `pend_comm_${activeCommunity.id}_${Date.now()}`,
          type: 'system',
          title: 'Solicitação enviada',
          message: 'Esta comunidade é privada. Aguarde a aprovação da administração.',
        });
      } else {
        const updatedCount = (activeCommunity.membersCount || 0) + 1;
        await updateDoc(doc(db, 'communities', activeCommunity.id), {
          membersCount: updatedCount,
        });

        setIsMember(true);
        setJoinedCommunityIds((prev) => Array.from(new Set([...prev, activeCommunity.id])));
        setActiveCommunity((prev) => (prev ? { ...prev, membersCount: updatedCount } : null));

        await awardXp(
          currentUser.uid,
          15,
          `join_comm_${activeCommunity.id}`,
          `Entrou no grupo: ${activeCommunity.name}`
        );
      }
    } catch (err: any) {
      console.error('Error joining group:', err);
    } finally {
      setJoiningGroup(false);
    }
  };

  // Leave Community (or cancel pending join request)
  const handleLeaveCommunity = async () => {
    if (!currentUser || !activeCommunity || isCreator || leavingCommunity) return;
    setLeavingCommunity(true);

    try {
      const commId = activeCommunity.id;
      const wasActiveMember = isMember;
      const wasPartialMod = Boolean(
        activeCommunity.partialModeratorIds?.includes(currentUser.uid)
      );

      await deleteDoc(doc(db, 'communities', commId, 'members', currentUser.uid));

      if (wasActiveMember) {
        const updatedCount = Math.max(1, (activeCommunity.membersCount || 1) - 1);
        const updatePayload: Record<string, any> = {
          membersCount: updatedCount,
        };
        if (wasPartialMod) {
          updatePayload.partialModeratorIds = arrayRemove(currentUser.uid);
        }

        await updateDoc(doc(db, 'communities', commId), updatePayload);

        const nextPartialIds = (activeCommunity.partialModeratorIds || []).filter(
          (uid) => uid !== currentUser.uid
        );

        setIsMember(false);
        setIsModerator(false);
        setIsPendingMember(false);
        setJoinedCommunityIds((prev) => prev.filter((id) => id !== commId));
        setCommunities((prev) =>
          prev.map((c) =>
            c.id === commId
              ? {
                  ...c,
                  membersCount: updatedCount,
                  partialModeratorIds: nextPartialIds,
                }
              : c
          )
        );
        setConfirmLeaveOpen(false);

        addToast({
          id: `leave_comm_${commId}_${Date.now()}`,
          type: 'system',
          title: 'Você saiu da comunidade',
          message: `Sua participação em "${activeCommunity.name}" foi encerrada.`,
        });

        if (
          (activeCommunity.isPrivate || activeCommunity.isHiddenFromNonMembers) &&
          !isDeveloper
        ) {
          setShowCommunityDetailsPage(false);
          setActiveCommunity(null);
        } else {
          setActiveCommunity((prev) =>
            prev
              ? {
                  ...prev,
                  membersCount: updatedCount,
                  partialModeratorIds: nextPartialIds,
                }
              : null
          );
          setStaffReloadTick((t) => t + 1);
        }
      } else if (isPendingMember) {
        setIsPendingMember(false);
        setPendingCommunityIds((prev) => prev.filter((id) => id !== commId));
        setConfirmLeaveOpen(false);
        addToast({
          id: `cancel_pend_${commId}_${Date.now()}`,
          type: 'system',
          title: 'Solicitação cancelada',
          message: `Sua solicitação de entrada em "${activeCommunity.name}" foi removida.`,
        });
      }
    } catch (err: any) {
      console.error('Error leaving community:', err);
      addToast({
        id: `leave_err_${Date.now()}`,
        type: 'system',
        title: 'Erro ao sair da comunidade',
        message: err?.message || 'Não foi possível concluir a saída agora.',
      });
    } finally {
      setLeavingCommunity(false);
    }
  };

  // Quick Join from Community Card
  const handleQuickJoin = async (comm: Community, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (joinedCommunityIds.includes(comm.id)) {
      setActiveCommunity(comm);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    if (pendingCommunityIds.includes(comm.id)) {
      addToast({
        id: `already_pend_${comm.id}_${Date.now()}`,
        type: 'system',
        title: 'Solicitação em análise',
        message: 'Sua solicitação de entrada aguarda aprovação do fundador.',
      });
      return;
    }
    if (comm.bannedUserIds?.includes(currentUser.uid)) {
      addToast({
        id: `banned_comm_${comm.id}_${Date.now()}`,
        type: 'system',
        title: 'Acesso restrito',
        message: 'Você não possui permissão para entrar nesta comunidade.',
      });
      return;
    }

    try {
      const requiresApproval = Boolean(comm.isPrivate && comm.creatorId !== currentUser.uid);
      const memberRef = doc(db, 'communities', comm.id, 'members', currentUser.uid);
      const memberData: CommunityMember = {
        id: currentUser.uid,
        communityId: comm.id,
        userId: currentUser.uid,
        userName: userProfile?.displayName || 'Leitor',
        userPhoto: userProfile?.photoURL || '',
        role: 'member',
        status: requiresApproval ? 'pending' : 'active',
        joinedAt: new Date().toISOString(),
      };

      await setDoc(memberRef, sanitizeFirestoreData(memberData));

      if (requiresApproval) {
        setPendingCommunityIds((prev) => Array.from(new Set([...prev, comm.id])));
        if (comm.creatorId !== currentUser.uid) {
          sendNotification(
            comm.creatorId,
            'community_join',
            'Solicitação para entrar na comunidade',
            `${userProfile?.displayName || 'Um usuário'} solicitou entrada em "${comm.name}".`,
            `/comunidade/${comm.id}`
          );
        }
        addToast({
          id: `req_sent_${comm.id}_${Date.now()}`,
          type: 'system',
          title: 'Solicitação enviada',
          message: `Aguarde aprovação da administração para entrar em "${comm.name}".`,
        });
        return;
      }

      const updatedCount = (comm.membersCount || 0) + 1;
      await updateDoc(doc(db, 'communities', comm.id), {
        membersCount: updatedCount,
      });

      setJoinedCommunityIds((prev) => [...prev, comm.id]);
      setCommunities((prev) =>
        prev.map((c) => (c.id === comm.id ? { ...c, membersCount: updatedCount } : c))
      );

      if (comm.creatorId !== currentUser.uid) {
        sendNotification(
          comm.creatorId,
          'community_join',
          'Novo membro na comunidade',
          `${userProfile?.displayName || 'Um usuário'} entrou na sua comunidade "${comm.name}".`,
          `/comunidade/${comm.id}`
        );
      }

      await awardXp(currentUser.uid, 15, `join_comm_${comm.id}`, `Entrou no grupo: ${comm.name}`);
    } catch (err: any) {
      console.error('Error quick joining group:', err);
    }
  };

  // Copy community link
  const handleCopyCommunityLink = (commId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const url = `${window.location.origin}?community=${commId}`;
    navigator.clipboard.writeText(url);
    setCopiedCommId(commId);
    setTimeout(() => setCopiedCommId(null), 2000);
  };

  // Submit New Post in Feed (15 Kards for members, Free for creator)
  const handleSubmitPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!activeCommunity) return;

    if (isBanned) {
      setPostError('Você foi banido desta comunidade e não pode publicar.');
      return;
    }
    if (isSilenced) {
      setPostError('Você está silenciado temporariamente e não pode publicar.');
      return;
    }
    if (!canPublish) {
      setPostError('Apenas o criador da comunidade, o desenvolvedor e moderadores parciais autorizados podem publicar nesta comunidade.');
      return;
    }

    if (postCooldown > 0) {
      setPostError(`Aguarde mais ${postCooldown}s antes de publicar novamente.`);
      return;
    }

    if (postType === 'text' && !postContent.trim()) {
      setPostError('Escreva algo para a sua publicação.');
      return;
    }
    if (postType === 'image' && !postImageFile && !postContent.trim()) {
      setPostError('Selecione uma imagem ou escreva um texto para publicar.');
      return;
    }
    if (postType === 'poll') {
      if (!pollQuestion.trim()) {
        setPostError('Informe a pergunta da enquete.');
        return;
      }
      const validOpts = pollOptions.filter((o) => o.trim().length > 0);
      if (validOpts.length < 2) {
        setPostError('A enquete precisa de pelo menos 2 opções.');
        return;
      }
    }

    setPostError('');
    setSubmittingPost(true);

    try {
      const postCost = 0; // Publicação exclusiva e gratuita para criador, desenvolvedor e moderadores parciais

      const postId = `post_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      let mediaUrl = '';

      if (postType === 'image' && postImageFile) {
        mediaUrl = await uploadFileToStorage(postImageFile, 'posts', postId);
      }

      let pollData: CommunityPoll | undefined = undefined;
      if (postType === 'poll') {
        const validOptions = pollOptions.filter((opt) => opt.trim().length > 0);
        pollData = {
          question: pollQuestion.trim(),
          options: validOptions.map((opt, idx) => ({
            id: `opt_${Date.now()}_${idx}`,
            text: opt.trim(),
            votesCount: 0,
            voterIds: [],
          })),
          totalVotes: 0,
          voterIds: [],
        };
      }

      const postData: CommunityPost = {
        id: postId,
        communityId: activeCommunity.id,
        authorId: currentUser.uid,
        authorName: userProfile?.displayName || 'Membro do Grupo',
        authorPhoto: userProfile?.photoURL || '',
        authorTitle: isCreator ? 'Fundador' : (userProfile?.activeTitle || 'Membro'),
        content: postType === 'poll' ? (postContent.trim() || pollQuestion.trim()) : postContent.trim(),
        type: postType,
        ...(postType === 'image' && mediaUrl ? { imageFormat: postImageFormat } : {}),
        ...(postIsPrivate ? { isPrivate: true } : {}),
        ...(postIsHiddenFromNonMembers ? { isHiddenFromNonMembers: true } : {}),
        mediaUrl: mediaUrl || '',
        poll: pollData,
        likesCount: 0,
        commentsCount: 0,
        kardsSpent: postCost,
        createdAt: new Date().toISOString(),
      };

      await setDoc(
        doc(db, 'communities', activeCommunity.id, 'posts', postId),
        sanitizeFirestoreData(postData)
      );

      const newPostsCount = (activeCommunity.postsCount || posts.length) + 1;
      const commUpdates: Record<string, any> = {
        postsCount: newPostsCount,
      };

      // Milestone check: every 10 user posts award 5 kards to community creator
      if (!isCreator) {
        const currentUserPosts = (activeCommunity.userPostsCount || 0) + 1;
        commUpdates.userPostsCount = currentUserPosts;

        if (currentUserPosts % 10 === 0) {
          const ownerId = activeCommunity.creatorId;
          if (ownerId) {
            await creditKards(
              ownerId,
              5,
              'reward',
              `Recompensa de Comunidade Ativa: 10 publicações alcançadas em "${activeCommunity.name}"`
            );
            await sendNotification(
              ownerId,
              'kards_received',
              'Comunidade em Alta: +5 Kards Recebidos!',
              `Sua comunidade "${activeCommunity.name}" atingiu o marco de ${currentUserPosts} publicações feitas por membros! 5 Kards foram depositados em sua carteira.`,
              '/comunidades'
            );
          }
        }
      }

      await updateDoc(doc(db, 'communities', activeCommunity.id), commUpdates);

      await awardXp(
        currentUser.uid,
        25,
        `post_${postId}`,
        `Publicação na comunidade: ${activeCommunity.name}`
      );
      await checkAndUnlockAchievement(currentUser.uid, 'first_post');

      try {
        localStorage.setItem('cordel_last_post_time', Date.now().toString());
      } catch {
        // ignore
      }
      setPostCooldown(15);

      setPostContent('');
      setPostImageFile(null);
      setPostImageOriginalFile(null);
      setPostImageOriginalUrl('');
      setPostImagePreview('');
      setPostImageFormat('default');
      setPostImageZoom(1);
      setPostImagePanX(0);
      setPostImagePanY(0);
      setPollQuestion('');
      setPollOptions(['', '']);
      setPostIsPrivate(false);
      setPostIsHiddenFromNonMembers(false);
      setPostType('text');
    } catch (err: any) {
      setPostError(err.message || 'Falha ao publicar no grupo.');
    } finally {
      setSubmittingPost(false);
    }
  };

  const categories = [
    'Todas',
    'Geral',
    'Cordel & Verso',
    'Romance & Drama',
    'Ficção & Fantasia',
    'Poesia & Métricas',
    'Leitores Beta',
  ];

  const filteredCommunities = communities.filter((c) => {
    // Ocultar comunidades marcadas como isHiddenFromNonMembers para quem não faz parte
    if (c.isHiddenFromNonMembers && !isDeveloper) {
      const canSeeHidden =
        currentUser &&
        (c.creatorId === currentUser.uid || joinedCommunityIds.includes(c.id));
      if (!canSeeHidden) return false;
    }

    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.category.toLowerCase().includes(search.toLowerCase()) ||
      c.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory =
      selectedCategory === 'Todas' || c.category.toLowerCase() === selectedCategory.toLowerCase();
    return matchesSearch && matchesCategory;
  });

  const handleOpenCommunityFromCarousel = async (commId: string) => {
    const found = communities.find((c) => c.id === commId);
    if (found) {
      setActiveCommunity(found);
      setShowCommunityDetailsPage(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    try {
      const cSnap = await getDoc(doc(db, 'communities', commId));
      if (cSnap.exists()) {
        setActiveCommunity(cSnap.data() as Community);
        setShowCommunityDetailsPage(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (err) {
      console.warn('Error opening community from carousel:', err);
    }
  };

  // =========================================================================
  // VIEW MODE 1: ACTIVE COMMUNITY ROOM + DEDICATED COMMUNITY DETAILS PAGE
  // =========================================================================
  if (activeCommunity) {
    const badge = getActivityBadge(activeCommunity);
    const totalPostsCount = Math.max(activeCommunity.postsCount || 0, posts.length);
    const commIconSrc =
      activeCommunity.iconUrl ||
      activeCommunity.avatarUrl ||
      activeCommunity.coverUrl ||
      activeCommunity.bannerUrl ||
      '';
    const commBannerSrc =
      activeCommunity.bannerUrl || activeCommunity.coverUrl || '';

    return (
      <div className="relative min-h-screen">
        {/* CABEÇALHO SUSPENSO E FIXADO (NÃO RECOLHÍVEL) — Sempre visível lá em cima dentro da comunidade */}
        <header className="fixed top-2 inset-x-3 sm:inset-x-6 z-50 mx-auto max-w-4xl rounded-2xl border border-zinc-800/90 bg-[#1A1A1A]/95 backdrop-blur-md shadow-2xl">
          <div className="px-3 sm:px-5 py-2.5 flex items-center justify-between gap-2.5">
            {/* Botão Voltar (Recolhe detalhes -> recolhe comentários abertos mantendo na comunidade -> sai da comunidade) */}
            <button
              type="button"
              onClick={() => {
                if (showCommunityDetailsPage) {
                  setShowCommunityDetailsPage(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                } else if (selectedPostForComments) {
                  handleClosePostComments();
                } else {
                  setActiveCommunity(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
              title={
                showCommunityDetailsPage
                  ? 'Voltar para as publicações da comunidade'
                  : selectedPostForComments
                  ? 'Recolher comentários e continuar na comunidade'
                  : 'Voltar para todas as comunidades'
              }
              aria-label={
                showCommunityDetailsPage
                  ? 'Voltar para as publicações da comunidade'
                  : selectedPostForComments
                  ? 'Recolher comentários e continuar na comunidade'
                  : 'Voltar para todas as comunidades'
              }
            >
              <ArrowLeft className="h-5 w-5 text-[#FF57B2]" />
            </button>

            {/* Identidade da Comunidade: Clicar em cima do nome direciona para a página dedicada de informações */}
            <div className="flex-1 flex items-center gap-3 min-w-0">
              {commIconSrc ? (
                <img
                  src={commIconSrc}
                  alt={activeCommunity.name}
                  referrerPolicy="no-referrer"
                  onClick={() => {
                    if (!showCommunityDetailsPage) {
                      setShowCommunityDetailsPage(true);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }
                  }}
                  className="h-9 w-9 sm:h-10 sm:w-10 shrink-0 rounded-xl object-cover bg-zinc-900 border border-zinc-700 cursor-pointer"
                />
              ) : (
                <div
                  onClick={() => {
                    if (!showCommunityDetailsPage) {
                      setShowCommunityDetailsPage(true);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }
                  }}
                  className="flex h-9 w-9 sm:h-10 sm:w-10 shrink-0 items-center justify-center rounded-xl bg-zinc-800 text-[#FF57B2] font-black text-sm border border-zinc-700 cursor-pointer"
                >
                  {activeCommunity.name.charAt(0).toUpperCase()}
                </div>
              )}

              <div className="min-w-0 flex-1">
                <button
                  type="button"
                  onClick={() => {
                    setShowCommunityDetailsPage(true);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="block max-w-full text-left font-display font-bold text-sm sm:text-base text-white hover:text-[#FF57B2] truncate transition cursor-pointer"
                  title="Clique no nome da comunidade para abrir todas as informações"
                >
                  {activeCommunity.name}
                </button>
                <p className="text-[11px] text-zinc-400 truncate tabular-nums">
                  {showCommunityDetailsPage
                    ? 'Informações da comunidade'
                    : selectedPostForComments
                    ? 'Comentários da publicação abertos'
                    : `${activeCommunity.membersCount || 1} ${
                        activeCommunity.membersCount === 1 ? 'membro' : 'membros'
                      } · ${activeCommunity.category}${
                        activeCommunity.isPrivate ? ' · Privada' : ''
                      }${
                        activeCommunity.isHiddenFromNonMembers ? ' · Oculta' : ''
                      }`}
                </p>
              </div>
            </div>

            {/* Ações Rápidas no Topo (inclui botão sempre visível para recolher comentários sem sair da comunidade) */}
            <div className="flex items-center gap-1.5 shrink-0">
              {selectedPostForComments && !showCommunityDetailsPage && (
                <button
                  type="button"
                  onClick={handleClosePostComments}
                  className="inline-flex items-center gap-1 rounded-xl bg-[#262626] hover:bg-zinc-800 border border-[#FF57B2]/50 px-2.5 py-1.5 text-xs font-bold text-white transition cursor-pointer"
                  title="Recolher comentários e continuar na comunidade"
                >
                  <ChevronUp className="h-4 w-4 text-[#FF57B2]" />
                  <span>Recolher</span>
                </button>
              )}

              <button
                type="button"
                onClick={(e) => handleCopyCommunityLink(activeCommunity.id, e)}
                className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
                title="Copiar link da comunidade"
              >
                {copiedCommId === activeCommunity.id ? (
                  <Check className="h-4 w-4 text-[#FF57B2]" />
                ) : (
                  <Share2 className="h-4 w-4" />
                )}
              </button>
              <button
                type="button"
                onClick={() => {
                  setReportTarget({
                    id: activeCommunity.id,
                    summary: `Comunidade: ${activeCommunity.name}`,
                    type: 'community',
                  });
                  setReportModalOpen(true);
                }}
                className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-400 hover:text-[#FF57B2] hover:bg-zinc-800 transition cursor-pointer"
                title="Denunciar Comunidade"
              >
                <AlertTriangle className="h-4 w-4" />
              </button>
              {isMember && !isCreator && (
                <button
                  type="button"
                  onClick={() => setConfirmLeaveOpen(true)}
                  className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-400 hover:text-[#FF57B2] hover:bg-zinc-800 transition cursor-pointer"
                  title="Sair da Comunidade"
                  aria-label="Sair da Comunidade"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              )}
              {isCommunityAdmin && (
                <>
                  <button
                    type="button"
                    onClick={() => setShowMembersModal(true)}
                    className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-400 hover:text-[#FF57B2] hover:bg-zinc-800 transition cursor-pointer"
                    title="Lista e Controle de Membros"
                    aria-label="Abrir lista de membros"
                  >
                    <UserCog className="h-4 w-4 text-[#FF57B2]" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowQuickPrivacyModal(true)}
                    className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-400 hover:text-[#FF57B2] hover:bg-zinc-800 transition cursor-pointer"
                    title="Privacidade & Ocultação da Comunidade"
                  >
                    <Lock className="h-4 w-4 text-[#FF57B2]" />
                  </button>
                  {(isCreator || isDeveloper) && (
                    <button
                      type="button"
                      onClick={() => setShowModerationModal(true)}
                      className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-400 hover:text-[#FF57B2] hover:bg-zinc-800 transition cursor-pointer"
                      title="Gestão & Moderação"
                    >
                      <Shield className="h-4 w-4 text-[#FF57B2]" />
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        </header>

        {/* Conteúdo da Comunidade com padding-top para o cabeçalho suspenso fixo */}
        <div className="mx-auto max-w-4xl px-4 sm:px-6 pt-20 sm:pt-22 pb-12 space-y-5">
          {showCommunityDetailsPage ? (
            /* =====================================================================
               PÁGINA DEDICADA DE INFORMAÇÕES DA COMUNIDADE
               (Exibida SOMENTE ao clicar no nome da comunidade no cabeçalho)
               ===================================================================== */
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowCommunityDetailsPage(false);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 rounded-xl border border-zinc-800 bg-[#242424] hover:border-[#FF57B2]/50 px-3.5 py-2 text-xs font-bold text-white transition cursor-pointer"
                >
                  <ArrowLeft className="h-4 w-4 text-[#FF57B2]" />
                  <span>Voltar para as publicações</span>
                </button>

                {isCommunityAdmin && (
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowMembersModal(true)}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-[#FF57B2]/50 bg-[#242424] hover:bg-[#FF57B2]/15 px-3.5 py-2 text-xs font-bold text-white transition cursor-pointer"
                    >
                      <Users className="h-3.5 w-3.5 text-[#FF57B2]" />
                      <span>Membros</span>
                    </button>
                    {(isCreator || isDeveloper) && (
                      <>
                        <button
                          type="button"
                          onClick={() => setShowEditCommunityModal(true)}
                          className="inline-flex items-center gap-1.5 rounded-xl border border-zinc-700 bg-[#242424] hover:border-[#FF57B2] px-3 py-2 text-xs font-bold text-white transition cursor-pointer"
                        >
                          <Edit2 className="h-3.5 w-3.5 text-[#FF57B2]" />
                          <span>Editar Comunidade</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowModerationModal(true)}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-3.5 py-2 text-xs font-bold text-white transition cursor-pointer"
                        >
                          <Shield className="h-3.5 w-3.5" />
                          <span>Moderação</span>
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Card Principal da Comunidade */}
              <div className="overflow-hidden rounded-3xl bg-[#202020] border border-zinc-800 shadow-lg">
                {/* Capa Horizontal */}
                <div className="relative h-44 sm:h-56 w-full overflow-hidden bg-gradient-to-r from-[#262626] via-[#202020] to-[#1A1A1A]">
                  {commBannerSrc ? (
                    <img
                      src={commBannerSrc}
                      alt={activeCommunity.name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center bg-[#191919]">
                      <Users className="h-12 w-12 text-zinc-700" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent pointer-events-none" />
                </div>

                {/* Identidade, Participação e Métricas */}
                <div className="px-5 sm:px-8 pb-6 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-10 sm:-mt-12 relative z-10">
                    <div className="flex items-end gap-4">
                      <div className="h-20 w-20 sm:h-24 sm:w-24 rounded-3xl border-4 border-[#202020] shadow-xl overflow-hidden bg-[#2A2A2A] flex items-center justify-center text-white font-display text-3xl font-black shrink-0">
                        {commIconSrc ? (
                          <img
                            src={commIconSrc}
                            alt={activeCommunity.name}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <span>{activeCommunity.name.charAt(0).toUpperCase()}</span>
                        )}
                      </div>

                      <div className="pb-1">
                        <h2 className="text-xl sm:text-2xl font-black text-white font-display leading-tight">
                          {activeCommunity.name}
                        </h2>
                        <p className="text-xs text-zinc-400 mt-0.5">
                          {activeCommunity.category}
                          {activeCommunity.createdAt && (
                            <>
                              {' · '}Desde{' '}
                              {new Date(activeCommunity.createdAt).toLocaleDateString(
                                'pt-BR',
                                { month: 'long', year: 'numeric' }
                              )}
                            </>
                          )}
                        </p>
                      </div>
                    </div>

                    {/* Ação de Participação e Opção de Sair */}
                    <div className="self-start sm:self-end flex flex-wrap items-center gap-2">
                      {isCreator ? (
                        <div className="inline-flex items-center gap-2 rounded-2xl bg-[#262626] text-[#FF57B2] border border-[#FF57B2]/50 px-4 py-2 text-xs font-bold">
                          <Crown className="h-4 w-4 text-[#FF57B2]" />
                          <span>Você é o Fundador</span>
                        </div>
                      ) : isMember ? (
                        <>
                          <div className="inline-flex items-center gap-2 rounded-2xl bg-[#262626] text-white border border-[#FF57B2]/60 px-4 py-2 text-xs font-bold">
                            <UserCheck className="h-4 w-4 text-[#FF57B2]" />
                            <span>
                              {isModerator
                                ? 'Administrador'
                                : isPartialModerator
                                ? 'Moderador Parcial'
                                : 'Membro Ativo'}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setConfirmLeaveOpen(true)}
                            disabled={leavingCommunity}
                            className="inline-flex items-center gap-1.5 rounded-2xl bg-[#1A1A1A] hover:bg-[#2A2A2A] border border-zinc-700 hover:border-[#FF57B2]/60 px-3.5 py-2 text-xs font-bold text-zinc-200 hover:text-white transition cursor-pointer disabled:opacity-50"
                            title="Sair desta comunidade"
                          >
                            <LogOut className="h-3.5 w-3.5 text-[#FF57B2]" />
                            <span>Sair da Comunidade</span>
                          </button>
                        </>
                      ) : isPendingMember ? (
                        <>
                          <div className="inline-flex items-center gap-2 rounded-2xl bg-[#262626] text-zinc-200 border border-[#FF57B2]/45 px-4 py-2 text-xs font-bold">
                            <Lock className="h-4 w-4 text-[#FF57B2]" />
                            <span>Solicitação Pendente</span>
                          </div>
                          <button
                            type="button"
                            onClick={handleLeaveCommunity}
                            disabled={leavingCommunity}
                            className="inline-flex items-center gap-1.5 rounded-2xl bg-[#1A1A1A] hover:bg-[#2A2A2A] border border-zinc-700 px-3.5 py-2 text-xs font-bold text-zinc-300 hover:text-white transition cursor-pointer disabled:opacity-50"
                          >
                            <X className="h-3.5 w-3.5 text-[#FF57B2]" />
                            <span>Cancelar Solicitação</span>
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={handleJoinCommunity}
                          disabled={joiningGroup || isBanned}
                          className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2.5 text-xs sm:text-sm font-bold text-white shadow-md hover:from-[#FF40A4] hover:to-[#D02685] transition active:scale-95 disabled:opacity-50 cursor-pointer"
                        >
                          {joiningGroup ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : activeCommunity.isPrivate ? (
                            <Lock className="h-4 w-4" />
                          ) : (
                            <UserPlus className="h-4 w-4" />
                          )}
                          <span>
                            {isBanned
                              ? 'Acesso Restrito'
                              : activeCommunity.isPrivate
                              ? 'Solicitar Entrada'
                              : 'Participar da Comunidade'}
                          </span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Painel de Indicadores Reais: Membros, Publicações e Atividade */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-zinc-800/80">
                    {isCommunityAdmin ? (
                      <button
                        type="button"
                        onClick={() => setShowMembersModal(true)}
                        className="rounded-2xl bg-[#191919] hover:bg-[#232323] border border-zinc-800/80 hover:border-[#FF57B2]/50 p-4 text-left transition cursor-pointer group"
                        title="Abrir janela suspensa com todos os membros"
                      >
                        <div className="flex items-center justify-between gap-2 text-zinc-400 text-xs">
                          <span className="inline-flex items-center gap-2">
                            <Users className="h-4 w-4 text-[#FF57B2]" />
                            <span>Quantidade de membros</span>
                          </span>
                          <span className="text-[11px] font-bold text-[#FF57B2] group-hover:underline">
                            Ver lista
                          </span>
                        </div>
                        <p className="mt-1.5 text-xl font-black text-white tabular-nums">
                          {activeCommunity.membersCount || 1}
                        </p>
                      </button>
                    ) : (
                      <div className="rounded-2xl bg-[#191919] border border-zinc-800/80 p-4">
                        <div className="flex items-center gap-2 text-zinc-400 text-xs">
                          <Users className="h-4 w-4 text-[#FF57B2]" />
                          <span>Quantidade de membros</span>
                        </div>
                        <p className="mt-1.5 text-xl font-black text-white tabular-nums">
                          {activeCommunity.membersCount || 1}
                        </p>
                      </div>
                    )}

                    <div className="rounded-2xl bg-[#191919] border border-zinc-800/80 p-4">
                      <div className="flex items-center gap-2 text-zinc-400 text-xs">
                        <FileText className="h-4 w-4 text-[#FF57B2]" />
                        <span>Quantidade de publicações</span>
                      </div>
                      <p className="mt-1.5 text-xl font-black text-white tabular-nums">
                        {totalPostsCount}
                      </p>
                    </div>

                    <div className="rounded-2xl bg-[#191919] border border-zinc-800/80 p-4">
                      <div className="flex items-center gap-2 text-zinc-400 text-xs">
                        {badge.icon}
                        <span>Atividade da comunidade</span>
                      </div>
                      <p className="mt-1.5 text-sm font-bold text-white">
                        {badge.label}
                      </p>
                    </div>
                  </div>

                  {/* Acesso Exclusivo de Administrador e Desenvolvedor à Janela Suspensa de Membros */}
                  {isCommunityAdmin && (
                    <div className="rounded-2xl bg-[#191919] border border-[#FF57B2]/30 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 text-xs font-bold text-[#FF57B2]">
                          <UserCog className="h-4 w-4 shrink-0" />
                          <span>Gestão e Lista de Membros da Comunidade</span>
                        </div>
                        <p className="text-xs text-zinc-300 leading-relaxed">
                          Consulte todos os membros em uma janela suspensa dedicada, veja o status real de atividade na plataforma e gerencie cargos, promoções ou banimentos.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowMembersModal(true)}
                        className="shrink-0 inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-4 py-2.5 text-xs font-bold text-white shadow-md transition active:scale-95 cursor-pointer"
                      >
                        <Users className="h-4 w-4" />
                        <span>Abrir Lista de Membros</span>
                      </button>
                    </div>
                  )}

                  {/* Descrição Completa */}
                  <div className="space-y-2 border-t border-zinc-800/80 pt-5">
                    <h3 className="text-sm font-bold text-white font-display">
                      Descrição da Comunidade
                    </h3>
                    <p className="text-xs sm:text-sm text-zinc-300 font-literary leading-relaxed whitespace-pre-line">
                      {activeCommunity.description ||
                        'Comunidade literária dedicada à troca de ideias, versos e leituras.'}
                    </p>
                  </div>

                  {/* Criador e Administradores / Moderadores */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-zinc-800/80 pt-5">
                    {/* Criador */}
                    <div className="rounded-2xl bg-[#191919] border border-zinc-800/80 p-4 space-y-3">
                      <div className="flex items-center gap-2 text-xs font-bold text-[#FF57B2]">
                        <Crown className="h-4 w-4" />
                        <span>Criador da Comunidade</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <UserAvatar
                          userId={activeCommunity.creatorId}
                          userName={activeCommunity.creatorName}
                          sizeClass="h-11 w-11 shrink-0"
                          onClick={() => openUserProfile(activeCommunity.creatorId)}
                        />
                        <div className="min-w-0">
                          <button
                            type="button"
                            onClick={() => openUserProfile(activeCommunity.creatorId)}
                            className="font-bold text-sm text-white hover:text-[#FF57B2] hover:underline transition cursor-pointer truncate block"
                          >
                            <UserDisplayName
                              userId={activeCommunity.creatorId}
                              fallback={activeCommunity.creatorName || 'Fundador'}
                            />
                          </button>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <UserBadges
                              userId={activeCommunity.creatorId}
                              isLight={false}
                              size="xs"
                            />
                            <span className="text-[11px] text-zinc-400">
                              Fundador
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Administradores & Moderadores */}
                    <div className="rounded-2xl bg-[#191919] border border-zinc-800/80 p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs font-bold text-[#FF57B2]">
                          <Shield className="h-4 w-4" />
                          <span>Administradores e Moderadores</span>
                        </div>
                        <span className="text-[11px] text-zinc-400 tabular-nums">
                          {communityStaff.length}
                        </span>
                      </div>

                      {loadingStaff ? (
                        <p className="text-xs text-zinc-400 py-2">
                          Carregando equipe de administração...
                        </p>
                      ) : communityStaff.length === 0 ? (
                        <p className="text-xs text-zinc-400 py-2">
                          Administrada pelo fundador da comunidade.
                        </p>
                      ) : (
                        <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                          {communityStaff.map((member) => (
                            <div
                              key={member.userId}
                              className="flex items-center justify-between gap-2.5"
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <UserAvatar
                                  userId={member.userId}
                                  userName={member.userName}
                                  photoURL={member.userPhoto}
                                  sizeClass="h-8 w-8 shrink-0"
                                  onClick={() => openUserProfile(member.userId)}
                                />
                                <div className="min-w-0">
                                  <button
                                    type="button"
                                    onClick={() => openUserProfile(member.userId)}
                                    className="font-bold text-xs text-white hover:text-[#FF57B2] hover:underline transition cursor-pointer truncate block"
                                  >
                                    <UserDisplayName
                                      userId={member.userId}
                                      fallback={member.userName || 'Administrador'}
                                    />
                                  </button>
                                  <span className="text-[10px] text-zinc-400 block">
                                    {member.role === 'creator'
                                      ? 'Fundador & Administrador'
                                      : member.role === 'moderator'
                                      ? 'Administrador / Moderador'
                                      : 'Moderador Parcial'}
                                  </span>
                                </div>
                              </div>
                              <UserBadges
                                userId={member.userId}
                                isLight={false}
                                size="xs"
                              />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Regras de Convivência */}
                  <div className="space-y-3 border-t border-zinc-800/80 pt-5">
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-[#FF57B2]" />
                      <h3 className="text-sm font-bold text-white font-display">
                        Regras da Comunidade
                      </h3>
                    </div>

                    {activeCommunity.rules ? (
                      <div className="rounded-2xl bg-[#191919] border border-zinc-800/80 p-4 text-xs sm:text-sm text-zinc-200 font-literary leading-relaxed whitespace-pre-line">
                        {activeCommunity.rules}
                      </div>
                    ) : (
                      <p className="text-xs text-zinc-400 italic">
                        Nenhuma regra específica foi adicionada pelo criador desta comunidade até o momento.
                      </p>
                    )}

                    <div className="rounded-2xl bg-[#191919]/70 border border-zinc-800/60 p-4 space-y-2">
                      <h4 className="text-xs font-bold text-zinc-300">
                        Diretrizes Gerais do KORDEL
                      </h4>
                      <ul className="space-y-1.5 text-xs text-zinc-400 font-literary">
                        <li>1. Respeito mútuo entre todos os autores, leitores e participantes.</li>
                        <li>2. Proibido spam, conteúdo ofensivo ou divulgação fora de contexto.</li>
                        <li>3. Proteção rigorosa aos direitos autorais das obras compartilhadas.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : activePostForComments ? (
          <div ref={commentsTopRef} className="scroll-mt-24 space-y-4 animate-in fade-in duration-200">
            {/* Barra de retorno rápido para recolher os comentários e continuar exatamente na comunidade */}
            <div className="flex items-center justify-between gap-3 border-b border-zinc-800 pb-3.5">
              <button
                type="button"
                onClick={handleClosePostComments}
                className="inline-flex items-center gap-2 rounded-2xl border border-[#FF57B2]/45 bg-[#262626] px-4 py-2 text-xs font-bold text-white hover:bg-[#FF57B2]/15 transition cursor-pointer shadow-xs group"
              >
                <ChevronUp className="h-4 w-4 text-[#FF57B2]" />
                <span>Recolher comentários e continuar na comunidade</span>
              </button>

              <button
                type="button"
                onClick={handleClosePostComments}
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#262626] border border-zinc-700 text-zinc-300 hover:text-white hover:border-[#FF57B2] transition cursor-pointer"
                title="Fechar comentários"
                aria-label="Fechar comentários"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* A Publicação Ocupando Toda a Tela com Exclusividade com Seus Comentários */}
            <div className="w-full">
              <CommunityFeedCard
                key={activePostForComments.id}
                post={activePostForComments}
                community={activeCommunity}
                isCreator={isCreator}
                isMember={isMember}
                isModerator={isModerator}
                isBanned={isBanned}
                isSilenced={isSilenced}
                onOpenAuth={onOpenAuth}
                isExclusiveFullView={true}
                onCollapseComments={handleClosePostComments}
                onReportPost={(p) => {
                  setReportTarget({
                    id: p.id,
                    summary: `Publicação de ${p.authorName}: "${p.content.substring(0, 60)}..."`,
                    type: 'post',
                  });
                  setReportModalOpen(true);
                }}
                onPostDeleted={(deletedId) => {
                  setPosts((prev) => prev.filter((p) => p.id !== deletedId));
                  handleClosePostComments();
                }}
              />
            </div>
          </div>
        ) : (
          <>
            {/* Warning Banners for Banned or Silenced Users */}
            {isBanned && (
              <div className="rounded-3xl bg-[#202020] border-2 border-[#FF57B2]/60 p-6 text-center space-y-2">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#262626] text-[#FF57B2]">
                  <AlertCircle className="h-6 w-6" />
                </div>
                <h3 className="font-bold text-base text-white font-display">
                  Acesso Restrito: Você foi banido desta comunidade
                </h3>
                <p className="text-xs text-zinc-300 max-w-md mx-auto">
                  O moderador e fundador desta comunidade baniu seu acesso. Você não pode publicar mensagens ou interagir neste grupo.
                </p>
              </div>
            )}

            {isSilenced && !isBanned && (
              <div className="rounded-3xl bg-[#202020] border border-[#FF57B2]/45 p-5 flex items-center gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[#262626] text-[#FF80C5]">
                  <AlertCircle className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-white">
                    Você foi temporariamente silenciado nesta comunidade
                  </h4>
                  <p className="text-xs text-zinc-300 mt-0.5">
                    O moderador aplicou uma restrição temporária até{' '}
                    <strong className="text-[#FF80C5]">
                      {new Date(silencedUntil!).toLocaleString('pt-BR', {
                        day: '2-digit',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </strong>
                    . Durante esse período, você pode ler as discussões, mas não poderá publicar ou comentar.
                  </p>
                </div>
              </div>
            )}

            {/* Bloqueio de Conteúdo: usuário precisa aplicar para entrar para poder acessar as publicações */}
            {!isMember && !isCreator && !isDeveloper ? (
              <div className="rounded-3xl border border-[#FF57B2]/50 bg-[#262626] p-8 sm:p-14 text-center shadow-xs space-y-4 max-w-xl mx-auto my-6">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-[#202020] text-[#FF57B2] border border-[#FF57B2]/60 shadow-2xs">
                  {activeCommunity.isPrivate ? (
                    <Lock className="h-8 w-8" />
                  ) : (
                    <Shield className="h-8 w-8" />
                  )}
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl sm:text-2xl font-black font-display text-white">
                    {activeCommunity.isPrivate
                      ? 'Comunidade Privada'
                      : 'Comunidade Exclusiva para Membros'}
                  </h3>
                  <p className="text-xs sm:text-sm text-zinc-300 font-literary leading-relaxed max-w-md mx-auto">
                    {isPendingMember
                      ? 'Sua solicitação de participação já foi enviada e aguarda aprovação do fundador ou moderador para liberar as publicações.'
                      : activeCommunity.isPrivate
                      ? 'Esta comunidade é privada e suas publicações ficam ocultas para não-membros. Solicite participação para aguardar aprovação.'
                      : 'Para visualizar as publicações, conversas e participar desta comunidade, entre gratuitamente abaixo.'}
                  </p>
                </div>
                <div className="pt-3">
                  <button
                    type="button"
                    onClick={handleJoinCommunity}
                    disabled={joiningGroup || isBanned || isPendingMember}
                    className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-7 py-3 text-xs sm:text-sm font-bold text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] active:scale-95 transition disabled:opacity-55 cursor-pointer border border-[#FF57B2]"
                  >
                    {joiningGroup ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : isPendingMember || activeCommunity.isPrivate ? (
                      <Lock className="h-4 w-4" />
                    ) : (
                      <UserPlus className="h-4 w-4" />
                    )}
                    <span>
                      {isBanned
                        ? 'Você foi banido desta comunidade'
                        : isPendingMember
                        ? 'Solicitação Pendente de Aprovação'
                        : activeCommunity.isPrivate
                        ? 'Solicitar Entrada na Comunidade'
                        : 'Entrar na Comunidade'}
                    </span>
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* 1. Community Posts Feed (Threads/Chat style, de cima para baixo, atualizações mais recentes no fim) */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between px-1">
                    <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-2">
                      <MessageCircle className="h-4 w-4 text-[#FF57B2]" />
                      <span>Mensagens & Publicações ({posts.length})</span>
                    </h2>

                    {/* Botão de atualização manual rápida para desktop e mobile */}
                    <button
                      type="button"
                      onClick={handleRefreshPosts}
                      disabled={isRefreshing}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-850 hover:bg-zinc-800 text-zinc-300 hover:text-white text-xs font-bold transition border border-zinc-700/80 cursor-pointer shadow-2xs"
                      title="Atualizar publicações agora"
                    >
                      <RefreshCw className={`h-3 w-3 text-[#FF57B2] ${isRefreshing ? 'animate-spin' : ''}`} />
                      <span>{isRefreshing ? 'Atualizando...' : 'Atualizar'}</span>
                    </button>
                  </div>

                  {posts.length === 0 ? (
                    <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-10 text-center space-y-3">
                      <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#262626] text-[#FF57B2] border border-zinc-700">
                        <FileText className="h-6 w-6" />
                      </div>
                      <h3 className="font-bold text-sm text-white font-display">
                        Nenhuma publicação ainda
                      </h3>
                      <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                        Ainda não há postagens neste grupo. Seja o primeiro a publicar abaixo!
                      </p>
                    </div>
                  ) : (
                    posts.map((post) => (
                      <CommunityFeedCard
                        key={post.id}
                        post={post}
                        community={activeCommunity}
                        isCreator={isCreator}
                        isMember={isMember}
                        isModerator={isModerator}
                        isBanned={isBanned}
                        isSilenced={isSilenced}
                        onOpenAuth={onOpenAuth}
                        onOpenComments={() => handleOpenPostComments(post)}
                        onReportPost={(p) => {
                          setReportTarget({
                            id: p.id,
                            summary: `Publicação de ${p.authorName}: "${p.content.substring(0, 60)}..."`,
                            type: 'post',
                          });
                          setReportModalOpen(true);
                        }}
                        onPostDeleted={(deletedId) => {
                          setPosts((prev) => prev.filter((p) => p.id !== deletedId));
                          setSelectedPostForComments((curr) => (curr?.id === deletedId ? null : curr));
                        }}
                      />
                    ))
                  )}

                  {/* Fim do Feed & Ref para Rolar até a Última Publicação */}
                  <div ref={postsEndRef} className="h-2 w-full" />
                </div>

                {/* 2. Opção de Fazer Publicações no FIM DA PÁGINA, depois da última publicação (WhatsApp Chat Style) */}
                {canPublish && !isBanned && !isSilenced ? (
                  <div className="rounded-3xl bg-[#202020] p-4 sm:p-5 shadow-xl border border-zinc-800 space-y-3.5 mt-4">
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5">
                      <div className="flex items-center gap-2">
                        <Send className="h-4 w-4 text-[#FF57B2]" />
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-display">
                          Enviar Publicação no Grupo
                        </h3>
                      </div>

                      {isCreator ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-[#262626] text-white border border-[#FF57B2]/55 px-2.5 py-0.5 text-[10px] font-bold">
                          <Crown className="h-3 w-3 text-[#FF57B2]" />
                          Fundador
                        </span>
                      ) : isDeveloper ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-zinc-900 text-white border border-[#FF57B2] px-2.5 py-0.5 text-[10px] font-bold">
                          Desenvolvedor
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-full bg-[#262626] text-[#FF80C5] border border-zinc-700 px-2.5 py-0.5 text-[10px] font-bold">
                          <Shield className="h-3 w-3 text-[#FF57B2]" />
                          Membro Autorizado
                        </span>
                      )}
                    </div>

                    {postError && (
                      <div className="rounded-2xl bg-[#262626] p-3 text-xs text-white font-medium border border-[#FF57B2]/60">
                        {postError}
                      </div>
                    )}

                    {/* Identificação do Autor */}
                    {currentUser && (
                      <div className="flex items-center gap-2.5 py-0.5">
                        <UserAvatar
                          userId={currentUser.uid}
                          userName={userProfile?.displayName}
                          photoURL={userProfile?.photoURL}
                          sizeClass="h-8 w-8"
                        />
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-xs text-white">
                            {userProfile?.displayName || 'Você'}
                          </span>
                          <UserBadges userId={currentUser.uid} isLight={false} size="xs" />
                        </div>
                      </div>
                    )}

                    {/* Post Tabs: Text, Image, Poll */}
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setPostType('text')}
                        className={`rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer ${
                          postType === 'text'
                            ? 'bg-[#FF57B2] text-white shadow-xs'
                            : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-750 hover:text-white'
                        }`}
                      >
                        Texto
                      </button>
                      <button
                        type="button"
                        onClick={() => setPostType('image')}
                        className={`rounded-xl px-3 py-1.5 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                          postType === 'image'
                            ? 'bg-[#FF57B2] text-white shadow-xs'
                            : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-750 hover:text-white'
                        }`}
                      >
                        <ImageIcon className="h-3.5 w-3.5" />
                        <span>Foto</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPostType('poll')}
                        className={`rounded-xl px-3 py-1.5 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                          postType === 'poll'
                            ? 'bg-[#FF57B2] text-white shadow-xs'
                            : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-750 hover:text-white'
                        }`}
                      >
                        <Vote className="h-3.5 w-3.5" />
                        <span>Enquete</span>
                      </button>
                    </div>

                    <form onSubmit={handleSubmitPost} className="space-y-3">
                      <textarea
                        rows={3}
                        value={postContent}
                        onChange={(e) => setPostContent(e.target.value)}
                        placeholder={
                          postType === 'poll'
                            ? 'Contextualize sua enquete literária...'
                            : 'Escreva sua mensagem ou publicação para o grupo...'
                        }
                        className="w-full rounded-2xl border border-zinc-700 bg-zinc-900/90 p-3 text-xs sm:text-sm text-white focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none font-literary placeholder-zinc-500 shadow-inner"
                      />

                      {/* Image Upload Tab Content (with 2-Format Selector & Pre-Publish Adjuster) */}
                      {postType === 'image' && (
                        <div className="space-y-2.5">
                          {postImagePreview ? (
                            <div className="space-y-2.5">
                              <div className="flex items-center justify-between gap-2 flex-wrap">
                                <div className="inline-flex items-center rounded-xl bg-zinc-900 p-0.5 border border-zinc-800">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setPostImageFormat('default');
                                      setShowPostImageAdjuster(true);
                                    }}
                                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                                      postImageFormat === 'default'
                                        ? 'bg-[#FF57B2] text-white'
                                        : 'text-zinc-400 hover:text-white'
                                    }`}
                                  >
                                    Padrão
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setPostImageFormat('instagram');
                                      setShowPostImageAdjuster(true);
                                    }}
                                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                                      postImageFormat === 'instagram'
                                        ? 'bg-[#FF57B2] text-white'
                                        : 'text-zinc-400 hover:text-white'
                                    }`}
                                  >
                                    Instagram (4:5)
                                  </button>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => setShowPostImageAdjuster(true)}
                                  className="inline-flex items-center gap-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 px-3 py-1 text-xs font-bold text-[#FF57B2] transition cursor-pointer"
                                >
                                  <SlidersHorizontal className="h-3.5 w-3.5" />
                                  <span>Ajustar imagem</span>
                                </button>
                              </div>

                              <div className="relative inline-block">
                                <img
                                  src={postImagePreview}
                                  alt="Preview"
                                  onClick={() => setShowPostImageAdjuster(true)}
                                  className={`rounded-2xl object-cover border border-[#FF57B2]/40 shadow-xs cursor-pointer ${
                                    postImageFormat === 'instagram'
                                      ? 'h-48 aspect-[4/5]'
                                      : 'h-36 aspect-[16/10]'
                                  }`}
                                  title="Clique para ajustar imagem"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    setPostImageFile(null);
                                    setPostImageOriginalFile(null);
                                    setPostImageOriginalUrl('');
                                    setPostImagePreview('');
                                    setPostImageZoom(1);
                                    setPostImagePanX(0);
                                    setPostImagePanY(0);
                                  }}
                                  className="absolute -top-2 -right-2 rounded-full bg-zinc-800 text-white p-1 hover:bg-zinc-900 shadow cursor-pointer"
                                >
                                  <X className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </div>
                          ) : (
                            <label className="flex items-center gap-2 rounded-2xl border border-dashed border-[#FF57B2]/60 p-4 hover:border-[#FF57B2] bg-zinc-900/50 cursor-pointer transition">
                              <Camera className="h-5 w-5 text-[#FF57B2]" />
                              <span className="text-xs font-semibold text-zinc-300">
                                Selecionar e ajustar foto da publicação
                              </span>
                              <input
                                type="file"
                                accept="image/jpeg,image/png,image/webp"
                                className="hidden"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const objUrl = URL.createObjectURL(file);
                                    setPostImageOriginalFile(file);
                                    setPostImageOriginalUrl(objUrl);
                                    setPostImageFile(file);
                                    setPostImagePreview(objUrl);
                                    setPostImageZoom(1);
                                    setPostImagePanX(0);
                                    setPostImagePanY(0);
                                    setShowPostImageAdjuster(true);
                                  }
                                  e.target.value = '';
                                }}
                              />
                            </label>
                          )}
                        </div>
                      )}

                      {/* Poll Tab Content */}
                      {postType === 'poll' && (
                        <div className="space-y-2 rounded-2xl bg-zinc-900/60 p-4 border border-zinc-800">
                          <div>
                            <label className="block text-[11px] font-bold text-zinc-300 mb-1">
                              Pergunta da Enquete
                            </label>
                            <input
                              type="text"
                              value={pollQuestion}
                              onChange={(e) => setPollQuestion(e.target.value)}
                              placeholder="Ex: Qual o melhor cordel de Ariano Suassuna?"
                              className="w-full rounded-xl border border-zinc-700 bg-zinc-900 p-2 text-xs text-white focus:border-[#FF57B2] focus:outline-none"
                            />
                          </div>

                          <div className="space-y-2 pt-1">
                            <label className="block text-[11px] font-bold text-zinc-300">Opções</label>
                            {pollOptions.map((opt, idx) => (
                              <input
                                key={idx}
                                type="text"
                                value={opt}
                                onChange={(e) => {
                                  const copy = [...pollOptions];
                                  copy[idx] = e.target.value;
                                  setPollOptions(copy);
                                }}
                                placeholder={`Opção ${idx + 1}`}
                                className="w-full rounded-xl border border-zinc-700 bg-zinc-900 p-2 text-xs text-white focus:border-[#FF57B2] focus:outline-none"
                              />
                            ))}

                            {pollOptions.length < 5 && (
                              <button
                                type="button"
                                onClick={() => setPollOptions([...pollOptions, ''])}
                                className="text-xs font-bold text-[#FF57B2] hover:underline flex items-center gap-1 pt-1"
                              >
                                <Plus className="h-3.5 w-3.5" />
                                <span>Adicionar outra opção</span>
                              </button>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Post-level Privacy & Non-Member Hiding Controls */}
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setPostIsPrivate((prev) => !prev)}
                          className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-[11px] font-bold border transition cursor-pointer ${
                            postIsPrivate
                              ? 'bg-[#FF57B2]/20 border-[#FF57B2] text-white'
                              : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                          }`}
                        >
                          <Lock className="h-3.5 w-3.5 text-[#FF57B2]" />
                          <span>Privar post (só membros)</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setPostIsHiddenFromNonMembers((prev) => !prev)}
                          className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-[11px] font-bold border transition cursor-pointer ${
                            postIsHiddenFromNonMembers
                              ? 'bg-[#FF57B2]/20 border-[#FF57B2] text-white'
                              : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                          }`}
                        >
                          <EyeOff className="h-3.5 w-3.5 text-[#FF57B2]" />
                          <span>Ocultar p/ não-membros</span>
                        </button>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                        <span className="text-[11px] text-zinc-400">
                          {postCooldown > 0 && `Aguarde ${postCooldown}s`}
                        </span>

                        <button
                          type="submit"
                          disabled={submittingPost || postCooldown > 0}
                          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer border border-[#FF57B2]"
                        >
                          {submittingPost ? (
                            <>
                              <Loader2 className="h-4 w-4 animate-spin" />
                              <span>Publicando...</span>
                            </>
                          ) : (
                            <>
                              <Send className="h-4 w-4" />
                              <span>Publicar</span>
                            </>
                          )}
                        </button>
                      </div>
                    </form>
                  </div>
                ) : !canPublish && !isBanned && !isSilenced ? (
                  <div className="rounded-2xl border border-zinc-800 bg-[#202020] p-4 text-xs text-zinc-400 shadow-2xs flex items-center gap-3 mt-4">
                    <Shield className="h-5 w-5 text-[#FF57B2] shrink-0" />
                    <span>
                      Apenas administradores e moderadores podem publicar novas postagens neste grupo. Como participante, você pode ler, curtir e comentar livremente.
                    </span>
                  </div>
                ) : null}

        {/* Barra Didática de Rodapé WhatsApp: Puxe para Cima ou Toque para Atualizar */}
        <div className="pt-2 pb-6 flex flex-col items-center justify-center text-center">
          <button
            type="button"
            onClick={handleRefreshPosts}
            disabled={isRefreshing}
            className="group inline-flex items-center gap-2 rounded-full px-4 py-1.5 bg-[#202020] hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white text-xs font-semibold transition cursor-pointer shadow-xs active:scale-95"
            title="Puxe a tela para cima ou clique aqui para buscar atualizações recentes"
          >
            <div className={`relative flex items-center justify-center h-5 w-5 rounded-full bg-zinc-900 border border-zinc-700 ${isRefreshing ? 'border-[#FF57B2]' : ''}`}>
              {isRefreshing ? (
                <Loader2 className="h-3 w-3 animate-spin text-[#FF57B2]" />
              ) : refreshSuccess ? (
                <Check className="h-3 w-3 text-[#FF57B2]" />
              ) : (
                <RefreshCw className="h-2.5 w-2.5 text-[#FF57B2] group-hover:rotate-180 transition-transform duration-300" />
              )}
            </div>
            <span>
              {isRefreshing
                ? 'Sincronizando feed...'
                : refreshSuccess
                ? 'Feed atualizado com sucesso!'
                : 'Puxe para cima ou toque para atualizar o feed'}
            </span>
          </button>
        </div>

        {/* Indicador Dinâmico Circular WhatsApp */}
        {((isPulling && refreshProgress > 0) || isRefreshing || refreshSuccess) && (
          <div className="fixed bottom-20 inset-x-0 z-50 flex items-center justify-center pointer-events-none animate-in fade-in zoom-in duration-200">
            <div
              className={`flex items-center gap-3 rounded-full px-4 py-2.5 backdrop-blur-xl transition-all duration-200 shadow-2xl border ${
                refreshSuccess
                  ? 'bg-[#202020]/95 border-[#FF57B2] text-white shadow-[0_10px_35px_rgba(255,87,178,0.45)] scale-105'
                  : refreshProgress >= 75
                  ? 'bg-[#1C1C1C]/95 border-[#FF57B2] text-white shadow-[0_10px_35px_rgba(255,87,178,0.5)] scale-110'
                  : 'bg-[#1C1C1C]/90 border-zinc-700/90 text-zinc-200 shadow-lg scale-100'
              }`}
            >
              <div className="relative flex items-center justify-center h-9 w-9">
                <svg className="w-9 h-9 transform -rotate-90">
                  <circle
                    cx="18"
                    cy="18"
                    r="15"
                    stroke="currentColor"
                    strokeWidth="3.5"
                    className="text-zinc-800 fill-transparent"
                  />
                  <circle
                    cx="18"
                    cy="18"
                    r="15"
                    stroke="currentColor"
                    strokeWidth="3.5"
                    strokeDasharray={2 * Math.PI * 15}
                    strokeDashoffset={
                      isRefreshing
                        ? 0
                        : refreshSuccess
                        ? 0
                        : 2 * Math.PI * 15 * (1 - refreshProgress / 100)
                    }
                    strokeLinecap="round"
                    className={`fill-transparent transition-all duration-150 text-[#FF57B2] ${
                      isRefreshing ? 'animate-spin origin-center' : ''
                    }`}
                  />
                </svg>

                <div className="absolute inset-0 flex items-center justify-center">
                  {isRefreshing ? (
                    <Loader2 className="h-4 w-4 animate-spin text-[#FF57B2]" />
                  ) : refreshSuccess ? (
                    <Check className="h-4 w-4 text-[#FF57B2] animate-in zoom-in" />
                  ) : (
                    <RefreshCw
                      className={`h-3.5 w-3.5 transition-transform duration-150 ${
                        refreshProgress >= 75 ? 'text-[#FF57B2] scale-110' : 'text-zinc-300'
                      }`}
                      style={{ transform: `rotate(${(refreshProgress / 100) * 360}deg)` }}
                    />
                  )}
                </div>
              </div>

              <div className="flex flex-col text-left pr-1">
                <span className="text-xs font-bold leading-tight">
                  {isRefreshing
                    ? 'Atualizando publicações...'
                    : refreshSuccess
                    ? 'Feed atualizado!'
                    : refreshProgress >= 75
                    ? 'Solte para atualizar'
                    : 'Puxe para cima para atualizar'}
                </span>
                <span className="text-[10px] text-zinc-400 leading-tight">
                  {refreshProgress >= 75 ? 'Pronto para sincronizar' : `${Math.round(refreshProgress)}% concluído`}
                </span>
              </div>
            </div>
          </div>
        )}
      </>
    )}
  </>
)}

        {/* Seta Exclusiva quando os Comentários de uma Publicação estão abertos: leva ao início da publicação / primeiro comentário onde fica a seta de recolher */}
        {activePostForComments && !showCommunityDetailsPage && showCommentsScrollTopBtn && (
          <button
            type="button"
            onClick={scrollCommentsToTop}
            className="fixed bottom-24 right-5 sm:right-8 z-40 flex h-11 w-11 sm:w-auto sm:px-3.5 items-center justify-center gap-1.5 rounded-full bg-[#262626]/95 text-white shadow-2xl border border-[#FF57B2]/65 backdrop-blur-md hover:bg-[#FF57B2] hover:border-[#FF57B2] hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer group"
            title="Subir para o começo da publicação e recolher comentários"
            aria-label="Subir para o começo da publicação e primeiro comentário"
          >
            <ArrowUp className="h-4 w-4 sm:h-5 sm:w-5 text-[#FF57B2] group-hover:text-white group-hover:-translate-y-0.5 transition-transform" />
            <span className="hidden sm:inline text-xs font-bold text-white whitespace-nowrap">
              Topo da publicação
            </span>
          </button>
        )}

        {/* Botão Flutuante com Seta para Rolar até a Última Publicação (apenas no feed geral) */}
        {showScrollBottomBtn && !activePostForComments && !showCommunityDetailsPage && (
          <button
            type="button"
            onClick={scrollToBottom}
            className="fixed bottom-20 right-5 sm:right-8 z-40 flex items-center gap-2 rounded-full bg-[#262626] text-white p-3 sm:px-4 sm:py-2.5 shadow-2xl border border-[#A1A1AA]/30 backdrop-blur-md hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer group"
            title="Rolar tudo para baixo até a última publicação recente"
          >
            <ArrowDown className="h-4 w-4 sm:h-5 sm:w-5 text-[#FF57B2] group-hover:translate-y-0.5 transition-transform" />
            <span className="hidden sm:inline text-xs font-bold text-white tracking-wide">
              Mais Recentes
            </span>
          </button>
        )}

        {/* Modal: Editar Fotos & Comunidade (Criador/Dev) */}
        {activeCommunity && (
          <EditCommunityModal
            isOpen={showEditCommunityModal}
            onClose={() => setShowEditCommunityModal(false)}
            community={activeCommunity}
            onCommunityUpdated={(updated: Community) => {
              setActiveCommunity(updated);
              setCommunities((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
            }}
          />
        )}

        {/* Quick Privacy & Hiding Modal inside Community Room */}
        {showQuickPrivacyModal && activeCommunity && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
            <div className="w-full max-w-md rounded-3xl bg-[#202020] border border-zinc-800 p-5 sm:p-6 shadow-2xl space-y-4 text-white">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-[#FF57B2]" />
                  <h3 className="font-bold text-sm sm:text-base text-white font-display">
                    Privacidade & Ocultação
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowQuickPrivacyModal(false)}
                  className="rounded-xl p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-2.5 text-xs">
                <label className="flex items-start justify-between gap-3 rounded-2xl bg-[#262626] border border-zinc-800 p-3.5 cursor-pointer hover:border-[#FF57B2]/45 transition">
                  <div className="space-y-0.5">
                    <span className="font-bold text-white block">
                      Privar comunidade (entrada mediante aprovação)
                    </span>
                    <span className="text-[11px] text-zinc-400 block">
                      Quem não faz parte precisa enviar solicitação e ser aprovado na Moderação.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    disabled={savingQuickPrivacy}
                    checked={Boolean(activeCommunity.isPrivate)}
                    onChange={() => handleToggleCommunityPrivacyField('isPrivate')}
                    className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                  />
                </label>

                <label className="flex items-start justify-between gap-3 rounded-2xl bg-[#262626] border border-zinc-800 p-3.5 cursor-pointer hover:border-[#FF57B2]/45 transition">
                  <div className="space-y-0.5">
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <EyeOff className="h-3.5 w-3.5 text-[#FF57B2]" />
                      <span>Ocultar comunidade para quem não faz parte</span>
                    </span>
                    <span className="text-[11px] text-zinc-400 block">
                      Esconde esta comunidade das listagens públicas, carrosséis e buscas para não-membros.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    disabled={savingQuickPrivacy}
                    checked={Boolean(activeCommunity.isHiddenFromNonMembers)}
                    onChange={() =>
                      handleToggleCommunityPrivacyField('isHiddenFromNonMembers')
                    }
                    className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                  />
                </label>

                <label className="flex items-start justify-between gap-3 rounded-2xl bg-[#262626] border border-zinc-800 p-3.5 cursor-pointer hover:border-[#FF57B2]/45 transition">
                  <div className="space-y-0.5">
                    <span className="font-bold text-white block">
                      Ocultar publicações para quem não faz parte
                    </span>
                    <span className="text-[11px] text-zinc-400 block">
                      Impede que os posts desta comunidade apareçam no Flux ou fora da sala para não-membros.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    disabled={savingQuickPrivacy}
                    checked={Boolean(activeCommunity.hidePostsFromNonMembers)}
                    onChange={() =>
                      handleToggleCommunityPrivacyField('hidePostsFromNonMembers')
                    }
                    className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                  />
                </label>
              </div>

              <div className="flex justify-end pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setShowQuickPrivacyModal(false)}
                  className="rounded-xl bg-[#FF57B2] hover:bg-[#E03595] px-5 py-2 text-xs font-bold text-white transition cursor-pointer"
                >
                  Concluir
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Suspended Members List & Control Modal (Admin & Developer) */}
        <CommunityMembersModal
          isOpen={showMembersModal}
          onClose={() => {
            setShowMembersModal(false);
            setStaffReloadTick((t) => t + 1);
          }}
          community={activeCommunity}
          canPromote={Boolean(isCreator || isModerator || isDeveloper)}
          onUpdateCommunity={(updated) => {
            setActiveCommunity((prev) => (prev ? { ...prev, ...updated } : null));
            setCommunities((prev) =>
              prev.map((c) => (c.id === activeCommunity.id ? { ...c, ...updated } : c))
            );
            setStaffReloadTick((t) => t + 1);
          }}
        />

        {/* Leave Community Confirmation Modal */}
        <ConfirmModal
          isOpen={confirmLeaveOpen}
          onClose={() => setConfirmLeaveOpen(false)}
          onConfirm={handleLeaveCommunity}
          title="Sair da comunidade?"
          message={`Tem certeza que deseja sair de "${activeCommunity.name}"?${
            activeCommunity.isPrivate
              ? ' Como esta comunidade é privada, você precisará solicitar nova aprovação caso queira voltar no futuro.'
              : ' Você poderá voltar a participar quando quiser.'
          }`}
          confirmText="Sair da Comunidade"
          cancelText="Continuar no Grupo"
          variant="warning"
          isLoading={leavingCommunity}
        />

        {/* Moderation Modal */}
        <CommunityModerationModal
          isOpen={showModerationModal}
          onClose={() => setShowModerationModal(false)}
          community={activeCommunity}
          onUpdateCommunity={(updated) => {
            setActiveCommunity((prev) => (prev ? { ...prev, ...updated } : null));
            setCommunities((prev) =>
              prev.map((c) => (c.id === activeCommunity.id ? { ...c, ...updated } : c))
            );
            setStaffReloadTick((t) => t + 1);
          }}
          onCommunityDeleted={() => {
            const deletedId = activeCommunity.id;
            setShowModerationModal(false);
            setActiveCommunity(null);
            setCommunities((prev) => prev.filter((c) => c.id !== deletedId));
          }}
        />

        {/* Report Modal */}
        <ReportModal
          isOpen={reportModalOpen}
          onClose={() => setReportModalOpen(false)}
          targetId={reportTarget.id}
          targetSummary={reportTarget.summary}
          targetType={reportTarget.type}
        />

        {/* Pre-Publish Image Adjuster Modal for Community Image Posts */}
        {postImageOriginalFile && postImageOriginalUrl && (
          <ImagePostAdjusterModal
            isOpen={showPostImageAdjuster}
            initialFormat={postImageFormat}
            images={[
              {
                id: 'comm_post_img',
                originalFile: postImageOriginalFile,
                originalUrl: postImageOriginalUrl,
                zoom: postImageZoom,
                panX: postImagePanX,
                panY: postImagePanY,
              },
            ]}
            onClose={() => setShowPostImageAdjuster(false)}
            onConfirm={(res: {
              format: PostImageFormat;
              adjustedImages: AdjustedImageOutput[];
            }) => {
              setPostImageFormat(res.format);
              const first = res.adjustedImages[0];
              if (first) {
                setPostImageFile(first.adjustedFile);
                setPostImagePreview(first.adjustedPreviewUrl);
                setPostImageZoom(first.zoom);
                setPostImagePanX(first.panX);
                setPostImagePanY(first.panY);
              }
              setShowPostImageAdjuster(false);
            }}
          />
        )}
        </div>
      </div>
    );
  }

  // =========================================================================
  // VIEW MODE 2: ALL COMMUNITIES LISTING (Top Recommended Carousel + Compact Presentation Cards)
  // =========================================================================
  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 py-4 sm:py-6 space-y-6">
      {/* 1. CARROSSEL COM AS COMUNIDADES RECOMENDADAS BEM NO TOPO (Idêntico à Página Inicial) */}
      <CommunityHomeCarousel
        onSelectCommunity={handleOpenCommunityFromCarousel}
      />

      {/* 2. Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-display">
            Comunidades Literárias
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Participe de discussões, compartilhe versos e conecte-se com leitores e autores de todo o Brasil.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            if (!currentUser) {
              onOpenAuth();
              return;
            }
            setShowCreateCommModal(true);
          }}
          className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer self-start sm:self-auto border border-[#FF57B2] shrink-0"
        >
          <Crown className="h-3.5 w-3.5 text-white" />
          <span>Criar Comunidade (Plano Escritor)</span>
        </button>
      </div>

      {/* 3. Search & Category Filter */}
      <div className="flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#FF57B2]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Pesquisar por nome ou assunto da comunidade..."
            className="w-full rounded-2xl border border-zinc-800 bg-[#202020] py-2.5 pl-10 pr-4 text-xs text-white placeholder:text-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none shadow-xs"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto w-full md:w-auto pb-1 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold whitespace-nowrap transition cursor-pointer shrink-0 ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs border border-[#FF57B2]'
                  : 'bg-[#202020] border border-zinc-800 text-[#A1A1AA] hover:bg-[#262626]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 4. Compact Communities Presentation Grid */}
      {loading ? (
        <div className="py-16 text-center text-xs text-zinc-400">
          Carregando comunidades literárias...
        </div>
      ) : filteredCommunities.length === 0 ? (
        <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-10 text-center space-y-3">
          <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-2xl bg-[#262626] text-[#FF57B2] border border-[#FF57B2]/50">
            <Users className="h-5 w-5" />
          </div>
          <h3 className="font-bold text-sm text-white font-display">
            Nenhuma comunidade encontrada
          </h3>
          <p className="text-xs text-[#A1A1AA]">
            Tente buscar com outros termos ou seja o fundador de uma nova comunidade!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5">
          {filteredCommunities.map((comm) => {
            const badge = getActivityBadge(comm);
            const isUserJoined = joinedCommunityIds.includes(comm.id);

            return (
              <div
                key={comm.id}
                onClick={() => {
                  setActiveCommunity(comm);
                  setShowCommunityDetailsPage(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="group relative flex flex-col justify-between overflow-hidden rounded-2xl liquid-card cursor-pointer"
              >
                <div>
                  {/* Compact Top Cover Banner */}
                  <div className="relative h-20 sm:h-24 w-full overflow-hidden bg-gradient-to-r from-[#262626] via-[#202020] to-[#1A1A1A]">
                    <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-white/25 to-transparent pointer-events-none z-10" />
                    {comm.bannerUrl || comm.coverUrl ? (
                      <img
                        src={comm.bannerUrl || comm.coverUrl}
                        alt={comm.name}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover group-hover:scale-105 transition duration-500"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center bg-[#1B1B1B]">
                        <Users className="h-6 w-6 text-zinc-700" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent pointer-events-none" />

                    {/* Top Right Compact Category / Joined */}
                    <div className="absolute top-2 right-2 flex items-center gap-1 z-10">
                      <span className="rounded-md bg-black/55 backdrop-blur-md text-zinc-200 text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 border border-white/15">
                        {comm.category}
                      </span>
                      {isUserJoined && (
                        <span className="rounded-md bg-[#FF57B2]/90 backdrop-blur-md text-white px-1.5 py-0.5 text-[9px] font-bold flex items-center gap-0.5">
                          <Check className="h-2.5 w-2.5" />
                          <span>Membro</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Compact Overlapping Avatar & Activity Label */}
                  <div className="px-3.5 relative z-20">
                    <div className="flex items-end justify-between -mt-5 mb-2 relative z-20 gap-2">
                      <div className="relative z-30 h-10 w-10 sm:h-11 sm:w-11 rounded-xl border-2 border-[#202020] shadow-md overflow-hidden bg-gradient-to-br from-[#FF57B2] to-[#E03595] flex items-center justify-center text-white font-display text-sm font-black group-hover:scale-105 transition-transform duration-300 shrink-0">
                        {comm.iconUrl || comm.avatarUrl ? (
                          <img
                            src={comm.iconUrl || comm.avatarUrl}
                            alt={comm.name}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-cover"
                          />
                        ) : comm.bannerUrl || comm.coverUrl ? (
                          <img
                            src={comm.bannerUrl || comm.coverUrl}
                            alt={comm.name}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <span>{comm.name.charAt(0).toUpperCase()}</span>
                        )}
                      </div>

                      <div className="inline-flex items-center gap-1 text-[10px] text-zinc-400 truncate pb-0.5">
                        {badge.icon}
                        <span className="truncate">{badge.label}</span>
                      </div>
                    </div>

                    {/* Compact Title, Founder & Description */}
                    <div className="space-y-0.5">
                      <h3 className="font-bold text-sm text-white font-display group-hover:text-[#FF57B2] transition line-clamp-1">
                        {comm.name}
                      </h3>

                      <p className="text-[10px] text-zinc-400 truncate">
                        por{' '}
                        <strong className="text-zinc-200">
                          {comm.creatorName || 'Autor'}
                        </strong>
                      </p>

                      <p className="text-[11px] text-zinc-400 line-clamp-2 font-literary leading-snug mt-1 min-h-[2rem]">
                        {comm.description ||
                          'Comunidade literária dedicada à troca de ideias, versos e contos.'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Compact Card Footer */}
                <div className="px-3.5 pb-3.5 pt-2.5">
                  <div className="flex items-center justify-between border-t border-zinc-800/80 pt-2.5 text-[11px] gap-2">
                    <div className="flex items-center gap-1.5 text-zinc-400 font-semibold tabular-nums min-w-0">
                      <span className="inline-flex items-center gap-0.5">
                        <Users className="h-3 w-3 text-[#FF57B2]" />
                        <span>{comm.membersCount || 1}</span>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate">{comm.postsCount || 0} posts</span>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => handleCopyCommunityLink(comm.id, e)}
                        className="rounded-lg border border-zinc-800 p-1.5 text-zinc-400 hover:text-white hover:bg-[#262626] transition cursor-pointer"
                        title="Compartilhar link da comunidade"
                      >
                        {copiedCommId === comm.id ? (
                          <Check className="h-3 w-3 text-[#FF57B2]" />
                        ) : (
                          <Share2 className="h-3 w-3" />
                        )}
                      </button>

                      {isUserJoined ? (
                        <span className="inline-flex items-center gap-1 rounded-lg bg-[#262626] px-2.5 py-1 text-[11px] font-bold text-[#FF57B2] border border-[#FF57B2]/40">
                          <Check className="h-3 w-3 text-[#FF57B2]" />
                          <span>Acessar</span>
                        </span>
                      ) : pendingCommunityIds.includes(comm.id) ? (
                        <span className="inline-flex items-center gap-1 rounded-lg bg-[#262626] px-2.5 py-1 text-[11px] font-bold text-zinc-300 border border-zinc-700">
                          <Lock className="h-3 w-3 text-[#FF57B2]" />
                          <span>Pendente</span>
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => handleQuickJoin(comm, e)}
                          className="inline-flex items-center gap-1 rounded-lg bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-2.5 py-1 text-[11px] font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
                        >
                          {comm.isPrivate ? (
                            <Lock className="h-3 w-3" />
                          ) : (
                            <UserPlus className="h-3 w-3" />
                          )}
                          <span>{comm.isPrivate ? 'Solicitar' : 'Participar'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Create Community (Exclusivo Plano Escritor - R$ 13,49/mês • 1 por assinatura ativa) */}
      {showCreateCommModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs animate-fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-[#202020] border border-zinc-800 p-6 sm:p-8 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-white">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div>
                <h3 className="font-bold text-base text-white font-display">
                  Fundar Nova Comunidade
                </h3>
                <p className="text-[11px] text-zinc-400">
                  Exclusivo para assinantes do Plano Escritor (R$ 13,49/mês) · Concede +100 XP
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateCommModal(false)}
                className="rounded-xl p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {commError && (
              <div className="rounded-2xl bg-[#262626] p-3 text-xs text-white font-medium border border-[#FF57B2]/60">
                {commError}
              </div>
            )}

            {!hasActiveEscritorPlan ? (
              /* CASO 1: Usuário NÃO possui o Plano Escritor ativo */
              <div className="py-4 text-center space-y-4">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-[#262626] text-[#FF57B2] border border-[#FF57B2]/50 shadow-inner">
                  <Crown className="h-8 w-8" />
                </div>

                <div className="space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-[#FF80C5]">
                    Benefício Exclusivo da Assinatura
                  </span>
                  <h3 className="text-xl font-black text-white font-display">
                    Plano Escritor (R$ 13,49/mês)
                  </h3>
                  <p className="text-xs text-zinc-400 font-literary max-w-sm mx-auto leading-relaxed">
                    A criação de comunidades literárias não utiliza mais Kards e é exclusiva para assinantes com o <strong className="text-white">Plano Escritor</strong> ativo.
                  </p>
                </div>

                <div className="rounded-2xl bg-[#262626] p-4 border border-zinc-700 text-left text-xs space-y-2">
                  <div className="font-bold text-white flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-[#FF57B2]" />
                    <span>Benefícios inclusos no plano:</span>
                  </div>
                  <ul className="space-y-1.5 text-zinc-300 text-[11px] list-disc list-inside">
                    <li><strong className="text-white">Fundação de 1 comunidade literária</strong> durante a assinatura ativa</li>
                    <li>Selo oficial de <strong className="text-white">Escritor Verificado</strong></li>
                    <li>2 impulsionamentos de obras por mês (7 dias cada)</li>
                    <li>Participação em divulgações e campanhas no Instagram oficial</li>
                  </ul>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowCreateCommModal(false)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-zinc-700 bg-[#181818] text-xs font-semibold text-zinc-300 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                  >
                    Voltar
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowCreateCommModal(false);
                      onNavigateTab?.('subscriptions');
                    }}
                    className="w-full flex-1 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white py-2.5 px-4 text-xs font-bold transition shadow-md border border-[#FF57B2] cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Crown className="h-3.5 w-3.5 text-white" />
                    <span>Conhecer Plano Escritor (R$ 13,49)</span>
                  </button>
                </div>
              </div>
            ) : communityCreatedThisCycle ? (
              /* CASO 2: Usuário já criou 1 comunidade durante esta assinatura ativa */
              <div className="py-4 text-center space-y-4">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-[#262626] text-[#FF57B2] border border-[#FF57B2]/50 shadow-inner">
                  <AlertTriangle className="h-8 w-8" />
                </div>

                <div className="space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-[#FF80C5]">
                    Limite Atingido neste Ciclo
                  </span>
                  <h3 className="text-xl font-black text-white font-display">
                    1 Comunidade por Assinatura Ativa
                  </h3>
                  <p className="text-xs text-zinc-400 font-literary max-w-sm mx-auto leading-relaxed">
                    Você já fundou 1 comunidade durante o período da sua assinatura ativa atual.
                  </p>
                </div>

                <div className="rounded-2xl bg-[#262626] p-4 border border-[#FF57B2]/40 text-left text-xs space-y-2">
                  <div className="font-bold text-white flex items-center gap-2">
                    <Shield className="h-4 w-4 text-[#FF57B2]" />
                    <span>Regra de Renovação da Plataforma:</span>
                  </div>
                  <p className="text-[11px] text-zinc-300 leading-relaxed">
                    Pelas regras do plano, é permitida a criação de <strong className="text-white">somente uma comunidade durante a assinatura ativa</strong>. Para fundar outra comunidade, você poderá criá-la no <strong className="text-white">próximo ciclo de assinatura</strong> caso renove{subscriptionRenewalDate ? ` em ${subscriptionRenewalDate}` : ''}.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setShowCreateCommModal(false)}
                  className="w-full rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white py-3 text-xs font-bold uppercase tracking-wider hover:opacity-95 transition cursor-pointer shadow-md"
                >
                  Entendido
                </button>
              </div>
            ) : (
              /* CASO 3: Usuário tem Plano Escritor ativo e NÃO criou comunidade neste ciclo */
              <form onSubmit={handleCreateCommunity} className="space-y-3.5 text-xs">
                {/* 1. Foto Menor no Quadrado (Avatar / Ícone) */}
                <div>
                  <label className="block font-semibold text-zinc-300 mb-1">
                    Foto Menor no Quadrado (Avatar / Ícone da Comunidade)
                  </label>
                  <div className="flex items-center gap-3">
                    {newCommAvatarPreview ? (
                      <div className="relative">
                        <img
                          src={newCommAvatarPreview}
                          alt="Avatar preview"
                          className="h-16 w-16 rounded-2xl object-cover border-2 border-[#FF57B2]/50 shadow-md"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setNewCommAvatarFile(null);
                            setNewCommAvatarPreview('');
                          }}
                          className="absolute -top-1.5 -right-1.5 rounded-full bg-[#262626] border border-[#FF57B2] text-white p-1 hover:bg-[#FF57B2] cursor-pointer"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ) : null}
                    <label className="flex items-center gap-2 rounded-xl border border-dashed border-zinc-700 px-3.5 py-2 hover:border-[#FF57B2] bg-[#181818] cursor-pointer transition">
                      <Camera className="h-4 w-4 text-[#FF57B2]" />
                      <span className="text-[11px] font-semibold text-zinc-300">
                        {newCommAvatarPreview ? 'Trocar Avatar' : 'Carregar Foto Quadrada'}
                      </span>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setNewCommAvatarFile(file);
                            setNewCommAvatarPreview(URL.createObjectURL(file));
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>

                {/* 2. Foto Maior na Horizontal (Capa / Banner) */}
                <div>
                  <label className="block font-semibold text-zinc-300 mb-1">
                    Foto Maior na Horizontal (Capa / Banner da Comunidade)
                  </label>
                  <div className="flex items-center gap-3">
                    {newCommCoverPreview ? (
                      <div className="relative">
                        <img
                          src={newCommCoverPreview}
                          alt="Cover preview"
                          className="h-16 w-28 rounded-xl object-cover border border-zinc-700 shadow-sm"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setNewCommCoverFile(null);
                            setNewCommCoverPreview('');
                          }}
                          className="absolute -top-1.5 -right-1.5 rounded-full bg-[#262626] border border-[#FF57B2] text-white p-1 hover:bg-[#FF57B2] cursor-pointer"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ) : null}
                    <label className="flex items-center gap-2 rounded-xl border border-dashed border-zinc-700 px-3.5 py-2 hover:border-[#FF57B2] bg-[#181818] cursor-pointer transition">
                      <Camera className="h-4 w-4 text-[#FF57B2]" />
                      <span className="text-[11px] font-semibold text-zinc-300">
                        {newCommCoverPreview ? 'Trocar Capa' : 'Carregar Capa Horizontal'}
                      </span>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setNewCommCoverFile(file);
                            setNewCommCoverPreview(URL.createObjectURL(file));
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-zinc-300 mb-1">
                    Nome da Comunidade
                  </label>
                  <input
                    type="text"
                    required
                    value={newCommName}
                    onChange={(e) => setNewCommName(e.target.value)}
                    placeholder="Ex: Roda de Cordel Nordestino"
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-zinc-300 mb-1">Categoria</label>
                  <select
                    value={newCommCategory}
                    onChange={(e) => setNewCommCategory(e.target.value)}
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-hidden"
                  >
                    {categories.filter((c) => c !== 'Todas').map((c) => (
                      <option key={c} value={c} className="bg-[#181818] text-white">
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-zinc-300 mb-1">
                    Descrição & Propósito
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={newCommDesc}
                    onChange={(e) => setNewCommDesc(e.target.value)}
                    placeholder="Descreva sobre o que será debatido nesta comunidade..."
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-hidden font-literary"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-zinc-300 mb-1">
                    Regras de Convivência (Opcional)
                  </label>
                  <textarea
                    rows={2}
                    value={newCommRules}
                    onChange={(e) => setNewCommRules(e.target.value)}
                    placeholder="Respeito mútuo, críticas construtivas e foco na literatura..."
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-hidden font-literary"
                  />
                </div>

                {/* Privacidade & Ocultação Inicial da Comunidade */}
                <div className="rounded-2xl bg-[#181818] border border-zinc-800 p-3.5 space-y-2.5">
                  <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                    <Lock className="h-3.5 w-3.5 text-[#FF57B2]" />
                    <span>Privacidade & Visibilidade</span>
                  </div>

                  <label className="flex items-center justify-between gap-2.5 cursor-pointer">
                    <span className="text-[11px] text-zinc-300">
                      Privar comunidade (entrada sujeita a aprovação)
                    </span>
                    <input
                      type="checkbox"
                      checked={newCommIsPrivate}
                      onChange={(e) => setNewCommIsPrivate(e.target.checked)}
                      className="h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                    />
                  </label>

                  <label className="flex items-center justify-between gap-2.5 cursor-pointer">
                    <span className="text-[11px] text-zinc-300">
                      Ocultar comunidade para quem não faz parte
                    </span>
                    <input
                      type="checkbox"
                      checked={newCommIsHidden}
                      onChange={(e) => setNewCommIsHidden(e.target.checked)}
                      className="h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                    />
                  </label>

                  <label className="flex items-center justify-between gap-2.5 cursor-pointer">
                    <span className="text-[11px] text-zinc-300">
                      Ocultar publicações para quem não faz parte
                    </span>
                    <input
                      type="checkbox"
                      checked={newCommHidePosts}
                      onChange={(e) => setNewCommHidePosts(e.target.checked)}
                      className="h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                    />
                  </label>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-zinc-800">
                  <div className="flex items-center gap-1.5 text-zinc-400 font-semibold text-[11px]">
                    <Crown className="h-3.5 w-3.5 text-[#FF57B2]" />
                    <span>Plano Escritor Ativo (1 criação inclusa neste ciclo)</span>
                  </div>

                  <button
                    type="submit"
                    disabled={creatingComm}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer border border-[#FF57B2]"
                  >
                    {creatingComm ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Fundando Comunidade...</span>
                      </>
                    ) : (
                      <>
                        <Crown className="h-4 w-4 text-white" />
                        <span>Confirmar Criação da Comunidade</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Report Modal */}
      <ReportModal
        isOpen={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
        targetId={reportTarget.id}
        targetSummary={reportTarget.summary}
        targetType={reportTarget.type}
      />
    </div>
  );
};
