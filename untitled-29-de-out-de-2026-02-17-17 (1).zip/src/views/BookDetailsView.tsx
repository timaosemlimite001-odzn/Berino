import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  setDoc,
  updateDoc,
  where
} from 'firebase/firestore';
import {
  AlertTriangle,
  Award,
  Bookmark,
  BookMarked,
  BookOpen,
  Calendar,
  CheckCircle,
  Crown,
  Eye,
  Heart,
  Lock,
  Send,
  Share2,
  ShieldCheck,
  Sparkles,
  Star,
  Users,
  Zap
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { ReportModal } from '../components/ReportModal';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db, handleFirestoreError, OperationType, sanitizeFirestoreData } from '../services/firebase';
import { awardXp, checkAndUnlockAchievement, sendNotification } from '../services/progressionService';
import { isSubscriptionActive } from '../services/subscriptionService';
import { BetaApplication, Book, BookReview, Chapter, LibraryStatus } from '../types';
import { UserAvatar } from '../components/UserAvatar';
import { UserBadges } from '../components/UserBadges';
import { UserDisplayName } from '../components/UserDisplayName';

interface BookDetailsViewProps {
  bookId: string;
  onReadChapter?: (bookId: string, chapterNumber: number) => void;
  onReadBook?: (bookId: string, chapterNumber?: number) => void;
  onBack: () => void;
  onOpenAuth: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const BookDetailsView: React.FC<BookDetailsViewProps> = ({
  bookId,
  onReadChapter,
  onReadBook,
  onBack,
  onOpenAuth,
  onNavigateTab,
}) => {
  const { currentUser, userProfile, isDeveloper } = useAuth();
  const { addToast } = useNotifications();
  const { openUserProfile } = usePublicProfile();

  const isLeitorSubscriber = isSubscriptionActive(userProfile, 'leitor');
  const canApplyBeta = Boolean(
    isLeitorSubscriber || userProfile?.hasExperiencedReaderBadge || isDeveloper
  );
  const [book, setBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [reviews, setReviews] = useState<BookReview[]>([]);
  const [loading, setLoading] = useState(true);

  // Early access lock modal
  const [earlyAccessBlockedModal, setEarlyAccessBlockedModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
  }>({ isOpen: false, title: '', message: '' });

  // User relations
  const [libraryStatus, setLibraryStatus] = useState<LibraryStatus | null>(null);
  const [hasLiked, setHasLiked] = useState(false);
  const [betaApplication, setBetaApplication] = useState<BetaApplication | null>(null);

  // Form states
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  // Beta application modal
  const [showBetaModal, setShowBetaModal] = useState(false);
  const [betaMotivation, setBetaMotivation] = useState('');
  const [submittingBeta, setSubmittingBeta] = useState(false);
  const [betaApplyError, setBetaApplyError] = useState<string | null>(null);

  const handleRead = (bId: string, chapNum: number = 1) => {
    const targetChap = chapters.find((c) => c.chapterNumber === chapNum);
    const isAuthor = Boolean(currentUser && book && currentUser.uid === book.authorId);
    const isApprovedBeta = betaApplication?.status === 'approved';

    if (book?.isBeta && !canApplyBeta && !isApprovedBeta && !isAuthor) {
      setEarlyAccessBlockedModal({
        isOpen: true,
        title: 'Obra em Versão Beta',
        message:
          'A leitura antecipada e teste de obras em versão beta é um benefício exclusivo para assinantes da Assinatura Leitor (R$ 4,90/mês) ou leitores beta aprovados.',
      });
      return;
    }

    if (targetChap?.isEarlyAccess && !canApplyBeta && !isApprovedBeta && !isAuthor) {
      setEarlyAccessBlockedModal({
        isOpen: true,
        title: 'Capítulo em Acesso Antecipado',
        message: `O autor disponibilizou o Capítulo ${chapNum} antecipadamente de forma exclusiva para assinantes da Assinatura Leitor (R$ 4,90/mês).`,
      });
      return;
    }

    try {
      const session = {
        bookId: bId,
        bookTitle: book?.title || '',
        bookCover: book?.coverUrl || '',
        authorName: book?.authorName || '',
        currentChapterNumber: chapNum,
        progressPercent: 5,
        openedAt: Date.now(),
        lastReadAt: new Date().toISOString(),
      };
      localStorage.setItem('kordel_last_opened_reading', JSON.stringify(session));
    } catch {}

    if (onReadChapter) {
      onReadChapter(bId, chapNum);
    } else if (onReadBook) {
      onReadBook(bId, chapNum);
    }
  };

  // Report modal
  const [reportModalOpen, setReportModalOpen] = useState(false);

  useEffect(() => {
    setLoading(true);

    // 1. Listen to book doc
    const bookRef = doc(db, 'books', bookId);
    const unsubBook = onSnapshot(bookRef, (snap) => {
      if (snap.exists()) {
        setBook(snap.data() as Book);
      }
      setLoading(false);
    });

    // 2. Fetch published chapters
    const chaptersQuery = query(
      collection(db, 'books', bookId, 'chapters'),
      orderBy('chapterNumber', 'asc')
    );
    const unsubChapters = onSnapshot(chaptersQuery, (snap) => {
      const list: Chapter[] = [];
      snap.forEach((d) => list.push(d.data() as Chapter));
      setChapters(list);
    });

    // 3. Fetch reviews
    const reviewsQuery = query(
      collection(db, 'books', bookId, 'reviews'),
      orderBy('createdAt', 'desc')
    );
    const unsubReviews = onSnapshot(reviewsQuery, (snap) => {
      const rList: BookReview[] = [];
      snap.forEach((d) => rList.push(d.data() as BookReview));
      setReviews(rList);
    });

    return () => {
      unsubBook();
      unsubChapters();
      unsubReviews();
    };
  }, [bookId]);

  // Self-heal authorName if current user is the author and has updated nickname
  useEffect(() => {
    if (
      currentUser &&
      userProfile?.displayName &&
      book &&
      book.authorId === currentUser.uid &&
      book.authorName !== userProfile.displayName
    ) {
      updateDoc(doc(db, 'books', book.id), {
        authorName: userProfile.displayName,
        author: userProfile.displayName,
      }).catch(() => {});
    }
  }, [currentUser?.uid, userProfile?.displayName, book?.id, book?.authorId, book?.authorName]);

  // Check user library and beta status
  useEffect(() => {
    if (!currentUser) {
      setLibraryStatus(null);
      setBetaApplication(null);
      return;
    }

    const checkUserData = async () => {
      try {
        // Library status
        const libDocRef = doc(db, 'libraries', currentUser.uid, 'items', bookId);
        const libSnap = await getDoc(libDocRef);
        if (libSnap.exists()) {
          setLibraryStatus(libSnap.data().status as LibraryStatus);
        } else {
          setLibraryStatus(null);
        }

        // Beta application: check deterministic ID first, then readerId query fallback
        const directBetaSnap = await getDoc(
          doc(db, 'betaApplications', `beta_${bookId}_${currentUser.uid}`)
        );
        if (directBetaSnap.exists()) {
          setBetaApplication(directBetaSnap.data() as BetaApplication);
        } else {
          const betaQuery = query(
            collection(db, 'betaApplications'),
            where('readerId', '==', currentUser.uid)
          );
          const betaSnap = await getDocs(betaQuery);
          const matched = betaSnap.docs
            .map((d) => d.data() as BetaApplication)
            .find((app) => app.bookId === bookId);
          setBetaApplication(matched || null);
        }
      } catch (err) {
        console.error('Error fetching user-book relations:', err);
      }
    };

    checkUserData();
  }, [bookId, currentUser]);

  const toggleLibraryStatus = async (status: LibraryStatus) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!book) return;

    const libDocRef = doc(db, 'libraries', currentUser.uid, 'items', bookId);
    try {
      if (libraryStatus === status) {
        await deleteDoc(libDocRef);
        setLibraryStatus(null);
        addToast({
          id: `lib_rem_${Date.now()}`,
          type: 'system',
          title: status === 'saved' ? 'Removido dos Salvos' : 'Removido dos Favoritos',
          message: `"${book.title}" foi removido desta categoria na sua biblioteca.`,
        });
      } else {
        await setDoc(
          libDocRef,
          sanitizeFirestoreData({
            id: bookId,
            userId: currentUser.uid,
            bookId,
            bookTitle: book.title,
            bookCover: book.coverUrl || '',
            authorName: book.authorName,
            status,
            currentChapterNumber: 1,
            progressPercent: 0,
            lastReadAt: new Date().toISOString(),
          }),
          { merge: true }
        );
        setLibraryStatus(status);
        addToast({
          id: `lib_add_${Date.now()}`,
          type: 'system',
          title: status === 'saved' ? 'Livro Salvo!' : 'Adicionado aos Favoritos!',
          message:
            status === 'saved'
              ? `"${book.title}" foi salvo em Minha Biblioteca -> Salvos.`
              : `"${book.title}" foi adicionado aos seus Favoritos.`,
        });
      }
    } catch (err) {
      console.error('Error updating library status:', err);
    }
  };

  const handleLike = async () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!book) return;

    try {
      const bookRef = doc(db, 'books', bookId);
      const newLikes = hasLiked ? Math.max(0, (book.likesCount || 0) - 1) : (book.likesCount || 0) + 1;
      await updateDoc(bookRef, { likesCount: newLikes });
      setHasLiked(!hasLiked);
    } catch (err) {
      console.error('Error updating likes:', err);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!reviewComment.trim()) return;

    setSubmittingReview(true);
    try {
      const reviewId = `rev_${currentUser.uid}_${Date.now()}`;
      const reviewRef = doc(db, 'books', bookId, 'reviews', reviewId);
      const newReview: BookReview = {
        id: reviewId,
        bookId,
        userId: currentUser.uid,
        userName: userProfile?.displayName || 'Leitor',
        userPhoto: userProfile?.photoURL || '',
        rating: reviewRating,
        comment: reviewComment.trim(),
        createdAt: new Date().toISOString(),
      };

      await setDoc(reviewRef, sanitizeFirestoreData(newReview));

      // Update book average rating in transaction
      const bookRef = doc(db, 'books', bookId);
      await runTransaction(db, async (t) => {
        const bDoc = await t.get(bookRef);
        if (bDoc.exists()) {
          const data = bDoc.data() as Book;
          const currentSum = data.ratingSum || 0;
          const currentCount = data.ratingCount || 0;
          t.update(bookRef, {
            ratingSum: currentSum + reviewRating,
            ratingCount: currentCount + 1,
          });
        }
      });

      // Award reviewer XP and check achievement
      await awardXp(currentUser.uid, 25, `review_${bookId}`, `Avaliação da obra: ${book?.title}`);
      await checkAndUnlockAchievement(currentUser.uid, 'first_review');

      // Notify author of review
      if (book && book.authorId !== currentUser.uid) {
        await sendNotification(
          book.authorId,
          'comment',
          `Nova Avaliação em "${book.title}"`,
          `${userProfile?.displayName || 'Um leitor'} avaliou sua obra com nota ${reviewRating}/5: "${reviewComment.slice(0, 60)}..."`,
          `/livro/${bookId}`
        );
      }

      setReviewComment('');
    } catch (err) {
      console.error('Error adding review:', err);
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleApplyBeta = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !book) return;

    setSubmittingBeta(true);
    setBetaApplyError(null);
    try {
      const appId = `beta_${bookId}_${currentUser.uid}`;
      const appRef = doc(db, 'betaApplications', appId);

      const appData: BetaApplication = {
        id: appId,
        bookId,
        bookTitle: book.title,
        authorId: book.authorId || '',
        readerId: currentUser.uid,
        readerName: userProfile?.displayName || currentUser.displayName || 'Leitor',
        readerEmail: currentUser.email || userProfile?.email || '',
        readerLevel: userProfile?.level || 1,
        hasExperiencedBadge: Boolean(userProfile?.hasExperiencedReaderBadge || canApplyBeta),
        motivation: betaMotivation.trim() || 'Candidatura de leitura crítica.',
        status: 'applied',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await setDoc(appRef, sanitizeFirestoreData(appData));
      setBetaApplication(appData);
      setShowBetaModal(false);
      setBetaMotivation('');

      addToast({
        id: `beta_apply_${Date.now()}`,
        type: 'achievement',
        title: 'Candidatura Enviada!',
        message: `Sua candidatura para leitura beta de "${book.title}" foi registrada com sucesso.`,
      });

      // Notify author safely
      if (book.authorId && book.authorId !== currentUser.uid) {
        try {
          await sendNotification(
            book.authorId,
            'beta_event',
            `Nova Candidatura de Leitor Beta: "${book.title}"`,
            `${appData.readerName} se candidatou para a vaga de leitura beta de sua obra.`,
            '/estudio'
          );
        } catch (notifErr) {
          console.warn('Notice sending beta author notification:', notifErr);
        }
      }
    } catch (err: any) {
      console.error('Error applying for beta:', err);
      setBetaApplyError(
        err?.message || 'Não foi possível enviar sua candidatura agora. Tente novamente.'
      );
    } finally {
      setSubmittingBeta(false);
    }
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-16 text-center text-sm text-zinc-400">
        Carregando detalhes do livro...
      </div>
    );
  }

  if (!book) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h2 className="text-xl font-bold text-white">Obra não encontrada</h2>
        <p className="text-xs text-zinc-400 mt-1">Este livro pode ter sido arquivado pelo autor.</p>
        <button
          onClick={onBack}
          className="mt-4 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] transition"
        >
          Voltar para Explorar
        </button>
      </div>
    );
  }

  const avgRating =
    book.ratingCount > 0 ? (book.ratingSum / book.ratingCount).toFixed(1) : 'Sem avaliações';

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-8 space-y-8 text-white">
      <button
        onClick={onBack}
        className="text-xs font-semibold text-zinc-400 hover:text-[#FF57B2] transition flex items-center gap-1 cursor-pointer"
      >
        ← Voltar
      </button>

      {/* Main Book Card */}
      <div className="rounded-3xl bg-[#202020] p-6 sm:p-8 shadow-sm border border-[#FF57B2]/40 flex flex-col md:flex-row gap-8">
        {/* Cover */}
        <div className="mx-auto md:mx-0 w-48 sm:w-56 shrink-0">
          <div className="relative aspect-[2/3] w-full overflow-hidden rounded-2xl bg-[#181818] shadow-xl border border-[#FF57B2]/40">
            {book.coverUrl ? (
              <img src={book.coverUrl} alt={book.title} className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full flex-col items-center justify-center bg-[#262626] p-6 text-center text-white">
                <BookOpen className="h-12 w-12 text-[#FF80C5] mb-3" />
                <span className="font-literary text-sm font-bold text-white">{book.title}</span>
              </div>
            )}
          </div>
        </div>

        {/* Info */}
        <div className="flex-1 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="rounded-lg bg-[#262626] px-2.5 py-0.5 text-xs font-semibold text-[#FF57B2] border border-[#FF57B2]/30">
                {book.classification}
              </span>
              {book.genres?.map((g) => (
                <span
                  key={g}
                  className="rounded-lg bg-[#262626] text-[#FF80C5] border border-[#FF57B2]/40 px-2.5 py-0.5 text-xs font-semibold"
                >
                  {g}
                </span>
              ))}
              {book.isBeta && (
                <span className="rounded-lg bg-[#FF57B2]/20 border border-[#FF57B2] text-white px-2.5 py-0.5 text-xs font-bold flex items-center gap-1">
                  ★ Beta Reader Ativo
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white font-display">
              {book.title}
            </h1>

            <div className="flex items-center gap-2 mt-1.5 text-sm text-zinc-300">
              <UserAvatar
                userId={book.authorId}
                userName={book.authorName}
                photoURL={book.authorPhoto}
                sizeClass="h-6 w-6"
                onClick={() => openUserProfile(book.authorId)}
                title={`Ver perfil de ${book.authorName}`}
              />
              <span>Por</span>
              <UserDisplayName
                userId={book.authorId}
                fallback={book.authorName}
                onClick={() => openUserProfile(book.authorId)}
                className="font-bold text-white hover:text-[#FF57B2] hover:underline cursor-pointer transition"
                title={`Ver perfil de ${book.authorName}`}
              />
              <UserBadges userId={book.authorId} isLight={false} size="xs" />
            </div>

            {/* Metrics */}
            <div className="flex flex-wrap items-center gap-4 pt-3 text-xs text-zinc-400 border-y border-zinc-800 py-2.5 my-3 tabular-nums">
              <span className="flex items-center gap-1 font-bold text-zinc-100">
                <Star className="h-4 w-4 fill-[#FF57B2] text-[#FF57B2]" />
                {avgRating} ({book.ratingCount || 0})
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Eye className="h-4 w-4" /> {book.viewsCount || 0} visualizações
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Users className="h-4 w-4" /> {book.readersCount || 0} leitores
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <BookOpen className="h-4 w-4" /> {chapters.length} capítulos
              </span>
            </div>

            {/* Synopsis */}
            <div className="text-sm leading-relaxed text-zinc-200 font-literary space-y-2 whitespace-pre-line">
              {book.synopsis}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-[#FF57B2]/30">
            <button
              onClick={() => handleRead(book.id, 1)}
              className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-6 py-3 text-sm font-bold text-white shadow-md shadow-[#FF57B2]/25 border border-[#FF57B2] transition cursor-pointer"
            >
              <BookOpen className="h-4 w-4" />
              <span>Ler Obra</span>
            </button>

            <button
              onClick={() => toggleLibraryStatus('saved')}
              className={`flex items-center gap-2 rounded-2xl border px-4 py-3 text-xs font-semibold transition cursor-pointer ${
                libraryStatus === 'saved'
                  ? 'border-[#FF57B2] bg-[#FF57B2]/15 text-[#FF57B2] font-bold'
                  : 'border-[#FF57B2]/50 bg-[#262626] text-zinc-200 hover:bg-zinc-800'
              }`}
              title="Salvar livro em Salvos na Biblioteca"
            >
              <Bookmark className={`h-4 w-4 ${libraryStatus === 'saved' ? 'fill-[#FF57B2] text-[#FF57B2]' : ''}`} />
              <span>{libraryStatus === 'saved' ? 'Salvo' : 'Salvar Livro'}</span>
            </button>

            <button
              onClick={() => toggleLibraryStatus('favorite')}
              className={`flex items-center gap-2 rounded-2xl border px-4 py-3 text-xs font-semibold transition cursor-pointer ${
                libraryStatus === 'favorite'
                  ? 'border-[#FF57B2] bg-[#FF57B2]/15 text-[#FF57B2] font-bold'
                  : 'border-[#FF57B2]/50 bg-[#262626] text-zinc-200 hover:bg-zinc-800'
              }`}
              title="Adicionar aos Favoritos"
            >
              <BookMarked className="h-4 w-4" />
              <span>{libraryStatus === 'favorite' ? 'Favoritado' : 'Favoritar'}</span>
            </button>

            <button
              onClick={handleLike}
              className={`flex items-center gap-1.5 rounded-2xl border p-3 text-xs font-semibold transition cursor-pointer ${
                hasLiked
                  ? 'border-[#FF57B2] bg-[#262626] text-[#FF57B2]'
                  : 'border-[#FF57B2]/50 bg-[#262626] text-zinc-300 hover:bg-zinc-800'
              }`}
              title="Curtir"
            >
              <Heart className={`h-4 w-4 ${hasLiked ? 'fill-[#FF57B2] text-[#FF57B2]' : ''}`} />
              <span>{book.likesCount || 0}</span>
            </button>

            <button
              onClick={() => setReportModalOpen(true)}
              className="rounded-2xl border border-[#FF57B2]/50 p-3 text-zinc-400 hover:text-[#FF57B2] hover:border-[#FF57B2] transition cursor-pointer"
              title="Denunciar Obra"
            >
              <AlertTriangle className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 2. Beta Reading Recruitment Card (if enabled) */}
      {book.isBeta && (
        <div className="rounded-3xl border border-[#FF57B2]/40 bg-[#202020] p-6 shadow-md">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-[#FF57B2] font-bold text-sm">
                <Award className="h-5 w-5 text-[#FF57B2]" />
                <span>Oportunidade de Leitor Beta</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed max-w-xl">
                O autor disponibilizou esta obra para leitura e revisão crítica antecipada. Vagas limitadas: <strong className="text-white">{book.betaAcceptedCount || 0} de {book.betaSpots || 5}</strong> preenchidas.
              </p>
              <p className="text-[11px] text-zinc-400">
                Prazo para candidaturas: <span className="text-[#FF57B2] font-semibold">{book.betaDeadline || 'Aberto até preenchimento das vagas'}</span>
              </p>
            </div>

            {currentUser?.uid === book.authorId ? (
              <div className="rounded-2xl bg-[#262626] border border-zinc-700 px-4 py-2.5 text-xs text-center text-zinc-300 font-semibold">
                Você é o autor desta obra beta
              </div>
            ) : betaApplication ? (
              <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/40 px-4 py-2.5 text-xs text-center">
                <span className="font-semibold text-zinc-400 block">Status da sua candidatura:</span>
                <span className="font-bold text-[#FF57B2] uppercase">
                  {betaApplication.status === 'applied' && 'Em análise pelo autor'}
                  {betaApplication.status === 'approved' && 'Aprovado! Acesso liberado'}
                  {betaApplication.status === 'rejected' && 'Vagas encerradas'}
                </span>
              </div>
            ) : canApplyBeta ? (
              <button
                onClick={() => {
                  if (!currentUser) {
                    onOpenAuth();
                    return;
                  }
                  setBetaApplyError(null);
                  setShowBetaModal(true);
                }}
                className="shrink-0 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] border border-[#FF57B2]/50 transition cursor-pointer"
              >
                Candidatar-me como Leitor Beta
              </button>
            ) : (
              <button
                onClick={() => {
                  if (!currentUser) {
                    onOpenAuth();
                    return;
                  }
                  if (onNavigateTab) {
                    onNavigateTab('subscriptions');
                  }
                }}
                className="shrink-0 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] transition flex items-center gap-1.5 cursor-pointer"
              >
                <Crown className="h-4 w-4" />
                <span>{currentUser ? 'Assinar Leitor para Candidatar' : 'Entrar para Candidatar'}</span>
              </button>
            )}
          </div>

          {!canApplyBeta && currentUser?.uid !== book.authorId && (
            <div className="mt-3 text-[11px] text-zinc-200 bg-[#262626] border border-[#FF57B2]/40 p-2.5 rounded-xl flex items-center justify-between gap-2">
              <span>
                <strong>Exclusivo Assinatura Leitor:</strong> A inscrição para teste beta de obras literárias é um benefício para assinantes do plano Leitor (R$ 4,90/mês) ou portadores do selo Leitor Experiente.
              </span>
              {onNavigateTab && (
                <button
                  type="button"
                  onClick={() => onNavigateTab('subscriptions')}
                  className="font-bold text-[#FF57B2] hover:underline shrink-0 cursor-pointer"
                >
                  Ver Planos →
                </button>
              )}
            </div>
          )}

          {!userProfile?.hasExperiencedReaderBadge && (
            <div className="mt-3 text-[11px] text-zinc-300 bg-[#262626]/80 border border-zinc-800 p-2.5 rounded-xl">
              <strong>Nota:</strong> O selo <em>Leitor Experiente</em> concede prioridade nas vagas de Beta Readers da plataforma.
            </div>
          )}
        </div>
      )}

      {/* 3. Chapters List */}
      <div className="rounded-3xl bg-[#202020] p-6 sm:p-8 shadow-xs border border-zinc-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-white font-display">
            Capítulos Publicados ({chapters.length})
          </h3>
          <span className="text-xs text-zinc-400">Leitura contínua com salvamento automático</span>
        </div>

        {chapters.length === 0 ? (
          <div className="py-8 text-center text-xs text-zinc-400">
            Nenhum capítulo disponível no momento.
          </div>
        ) : (
          <div className="divide-y divide-zinc-800">
            {chapters.map((chap) => (
              <div
                key={chap.id}
                onClick={() => handleRead(book.id, chap.chapterNumber)}
                className="flex items-center justify-between py-3.5 px-2 hover:bg-[#262626] rounded-xl transition cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#262626] font-bold text-xs text-[#FF57B2] border border-[#FF57B2]/40 tabular-nums group-hover:bg-gradient-to-r group-hover:from-[#FF57B2] group-hover:to-[#E03595] group-hover:text-white transition">
                    {chap.chapterNumber}
                  </span>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm font-semibold text-white font-literary group-hover:text-[#FF57B2] transition">
                        {chap.title}
                      </h4>
                      {chap.isEarlyAccess && (
                        <span className="rounded-md bg-[#262626] text-[#FF80C5] border border-[#FF57B2]/40 px-1.5 py-0.5 text-[9px] font-bold inline-flex items-center gap-0.5">
                          <Zap className="h-2.5 w-2.5 text-[#FF57B2]" />
                          Acesso Antecipado
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-zinc-400">
                      {new Date(chap.createdAt).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                </div>
                <span className="text-xs font-semibold text-[#FF57B2] opacity-0 group-hover:opacity-100 transition">
                  Ler →
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 4. Avaliações e Comentários dos Leitores */}
      <div className="rounded-3xl bg-[#202020] p-6 sm:p-8 shadow-xs border border-zinc-800 space-y-6">
        <h3 className="text-lg font-bold text-white font-display">
          Avaliações dos Leitores ({reviews.length})
        </h3>

        {/* Form to submit review */}
        {currentUser ? (
          <form onSubmit={handleSubmitReview} className="rounded-2xl bg-[#262626] p-4 border border-zinc-800 space-y-3">
            <div className="flex items-center gap-2.5 pb-2 border-b border-zinc-800">
              <UserAvatar
                userId={currentUser.uid}
                userName={userProfile?.displayName}
                photoURL={userProfile?.photoURL}
                sizeClass="h-8 w-8"
              />
              <div>
                <span className="font-bold text-xs text-white block">
                  {userProfile?.displayName || 'Você'}
                </span>
                <span className="text-[10px] text-zinc-400">Escrevendo avaliação</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-200">Sua nota para esta obra:</span>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setReviewRating(star)}
                    className="p-1 text-[#FF57B2] hover:scale-110 transition cursor-pointer"
                  >
                    <Star
                      className={`h-5 w-5 ${
                        star <= reviewRating ? 'fill-[#FF57B2] text-[#FF57B2]' : 'text-zinc-600'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <textarea
              value={reviewComment}
              onChange={(e) => setReviewComment(e.target.value)}
              rows={3}
              placeholder="O que você achou dos personagens, do enredo e da escrita? Compartilhe sua impressão literária..."
              className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-3 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
              maxLength={1500}
            />

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submittingReview || !reviewComment.trim()}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2 text-xs font-bold text-white shadow-xs hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
                <span>{submittingReview ? 'Publicando...' : 'Publicar Avaliação (+25 XP)'}</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="rounded-2xl bg-[#262626] p-4 text-center text-xs text-zinc-200 border border-zinc-800">
            Deseja avaliar este livro?{' '}
            <button onClick={onOpenAuth} className="font-bold text-[#FF80C5] hover:underline cursor-pointer">
              Entre em sua conta
            </button>
          </div>
        )}

        {/* Reviews List */}
        <div className="space-y-4 pt-2">
          {reviews.length === 0 ? (
            <p className="text-xs text-zinc-400 text-center py-4">
              Nenhuma avaliação cadastrada ainda. Seja o primeiro a opinar!
            </p>
          ) : (
            reviews.map((rev) => (
              <div key={rev.id} className="rounded-2xl border border-zinc-800 bg-[#262626] p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <UserAvatar
                      userId={rev.userId}
                      userName={rev.userName}
                      photoURL={rev.userPhoto}
                      sizeClass="h-7 w-7"
                      onClick={() => openUserProfile(rev.userId)}
                      title={`Ver perfil de ${rev.userName}`}
                    />
                    <span
                      onClick={() => openUserProfile(rev.userId)}
                      className="font-bold text-xs text-white hover:text-[#FF80C5] hover:underline cursor-pointer transition"
                      title={`Ver perfil de ${rev.userName}`}
                    >
                      {rev.userName}
                    </span>
                    <UserBadges userId={rev.userId} isLight={false} size="xs" />
                  </div>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`h-3.5 w-3.5 ${
                          s <= rev.rating ? 'fill-[#FF57B2] text-[#FF57B2]' : 'text-zinc-700'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-xs text-zinc-200 font-literary leading-relaxed">
                  {rev.comment}
                </p>
                <span className="block text-[10px] text-zinc-400">
                  {new Date(rev.createdAt).toLocaleDateString('pt-BR')}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Beta Application Modal */}
      {showBetaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-[#202020] p-6 shadow-2xl border border-zinc-800 text-white">
            <h3 className="text-lg font-bold text-white font-display">
              Candidatura de Leitor Beta
            </h3>
            <p className="text-xs text-zinc-300 mt-1">
              Candidate-se para ler os capítulos inéditos de <strong>{book.title}</strong> e colaborar com sugestões diretamente com o escritor.
            </p>

            <form onSubmit={handleApplyBeta} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-200 mb-1">
                  Por que você quer ser Leitor Beta desta obra?
                </label>
                <textarea
                  required
                  rows={4}
                  value={betaMotivation}
                  onChange={(e) => setBetaMotivation(e.target.value)}
                  placeholder="Fale sobre seu interesse pelo tema, seus hábitos de leitura ou experiência prévia..."
                  className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-3 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
                  maxLength={1000}
                />
              </div>

              {betaApplyError && (
                <div className="rounded-xl border border-[#FF57B2]/50 bg-[#262626] px-3 py-2 text-xs text-[#FF80C5] font-medium">
                  {betaApplyError}
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBetaModal(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={submittingBeta || !betaMotivation.trim()}
                  className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer disabled:opacity-50"
                >
                  {submittingBeta ? 'Enviando...' : 'Confirmar Candidatura'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Early Access / Beta Gating Alert Modal */}
      {earlyAccessBlockedModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl bg-[#202020] p-6 shadow-2xl border border-zinc-800 space-y-4 text-center text-white">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-md border border-[#FF57B2]/40">
              <Lock className="h-7 w-7 text-white" />
            </div>

            <div>
              <h3 className="text-lg font-black text-white font-display">
                {earlyAccessBlockedModal.title}
              </h3>
              <p className="mt-2 text-xs text-zinc-300 leading-relaxed font-literary">
                {earlyAccessBlockedModal.message}
              </p>
            </div>

            <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/40 p-3 text-[11px] text-[#FF80C5] leading-tight">
              <strong>Assinatura Leitor (R$ 4,90/mês):</strong> Garante capítulos antecipados, acesso a obras beta, sistema de XP, missões, ranking semanal e o selo oficial <em>Leitor Experiente</em> no perfil.
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEarlyAccessBlockedModal({ isOpen: false, title: '', message: '' })}
                className="flex-1 rounded-xl py-2.5 text-xs font-semibold text-zinc-300 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
              >
                Voltar
              </button>
              <button
                type="button"
                onClick={() => {
                  setEarlyAccessBlockedModal({ isOpen: false, title: '', message: '' });
                  if (!currentUser) {
                    onOpenAuth();
                  } else if (onNavigateTab) {
                    onNavigateTab('subscriptions');
                  }
                }}
                className="flex-1 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] py-2.5 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition shadow-md shadow-[#FF57B2]/20 cursor-pointer"
              >
                Conhecer Assinatura Leitor
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Report Modal */}
      <ReportModal
        isOpen={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
        targetType="book"
        targetId={book.id}
        targetSummary={`Livro: ${book.title} (Autor: ${book.authorName})`}
      />
    </div>
  );
};
