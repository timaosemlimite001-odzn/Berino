import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  AlertTriangle,
  Award,
  Ban,
  BookOpen,
  CheckCircle,
  Clock,
  Coins,
  Crown,
  Eye,
  Feather,
  FileText,
  Filter,
  Flame,
  Heart,
  HelpCircle,
  Link as LinkIcon,
  Loader2,
  RefreshCw,
  RotateCcw,
  ScrollText,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Star,
  ThumbsDown,
  Trash2,
  Upload,
  UserCheck,
  Users,
  VolumeX,
  Volume2,
  X,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useBranding, AppLogoIcon } from '../context/BrandingContext';
import { uploadFileToStorage } from '../services/storageService';
import { db, sanitizeFirestoreData } from '../services/firebase';
import { creditKards, spendKards } from '../services/kardsService';
import { approvePixOrder, fetchAllPixOrders, rejectPixOrder } from '../services/pixService';
import { sendNotification } from '../services/progressionService';
import { calculateRealUserMetrics, UserAdminMetrics } from '../services/userService';
import { UserSearchBar } from '../components/UserSearchBar';
import {
  Book,
  Community,
  KardTransaction,
  PixOrder,
  SafetyReport,
  UserProfile,
  UserRole,
} from '../types';
import { ConfirmModal } from '../components/ConfirmModal';
import { UserAvatar } from '../components/UserAvatar';
import { deleteCommunityCascade } from '../services/communityService';
import {
  manuallyActivateUserSubscription,
  manuallyRevokeUserSubscription,
  SUBSCRIPTION_PLANS,
  isSubscriptionActive,
} from '../services/subscriptionService';

export const DeveloperAdminView: React.FC = () => {
  const { isDeveloper, currentUser } = useAuth();
  const { branding, updateBranding, resetToDefault } = useBranding();
  const [activeTab, setActiveTab] = useState<
    'branding' | 'users' | 'featured' | 'featuredCommunities' | 'pix' | 'reports' | 'content' | 'audit'
  >('branding');

  // Branding Customization State
  const [brandAppName, setBrandAppName] = useState(branding.appName);
  const [brandLogoType, setBrandLogoType] = useState(branding.logoType);
  const [brandLogoUrl, setBrandLogoUrl] = useState(branding.logoUrl || '');
  const [brandLogoIcon, setBrandLogoIcon] = useState(branding.logoIconName || 'BookOpen');
  const [brandTagline, setBrandTagline] = useState(branding.tagline);
  const [brandDescription, setBrandDescription] = useState(branding.shortDescription || '');
  const [brandSaving, setBrandSaving] = useState(false);
  const [brandUploading, setBrandUploading] = useState(false);
  const [brandFeedback, setBrandFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [confirmBrandReset, setConfirmBrandReset] = useState(false);
  const [contentFeedback, setContentFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  useEffect(() => {
    setBrandAppName(branding.appName);
    setBrandLogoType(branding.logoType);
    setBrandLogoUrl(branding.logoUrl || '');
    setBrandLogoIcon(branding.logoIconName || 'BookOpen');
    setBrandTagline(branding.tagline);
    setBrandDescription(branding.shortDescription || '');
  }, [branding]);

  // Reports
  const [reports, setReports] = useState<SafetyReport[]>([]);
  const [reportFilter, setReportFilter] = useState<'pending' | 'resolved' | 'all'>('pending');

  // Users
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [userMetrics, setUserMetrics] = useState<Record<string, UserAdminMetrics>>({});
  const [userSearch, setUserSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [kardsAdjustment, setKardsAdjustment] = useState<number>(0);
  const [kardsJustification, setKardsJustification] = useState('');
  const [savingUser, setSavingUser] = useState(false);
  const [userActionFeedback, setUserActionFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  // Manual Subscription Activation State
  const [manualSubPlan, setManualSubPlan] = useState<'leitor' | 'escritor'>('leitor');
  const [manualSubDurationDays, setManualSubDurationDays] = useState<number>(30);
  const [manualSubJustification, setManualSubJustification] = useState<string>('');
  const [savingManualSub, setSavingManualSub] = useState(false);

  // Content (Books)
  const [books, setBooks] = useState<Book[]>([]);

  // Communities
  const [communities, setCommunities] = useState<Community[]>([]);
  const [commSearch, setCommSearch] = useState('');

  // Destaques da Semana (Up to 3 Books)
  const [featuredBookIds, setFeaturedBookIds] = useState<string[]>([]);
  const [featuredSearch, setFeaturedSearch] = useState('');
  const [savingFeatured, setSavingFeatured] = useState(false);
  const [featuredFeedback, setFeaturedFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  // Comunidades Recomendadas para Home (Up to 5 Communities)
  const [featuredCommIds, setFeaturedCommIds] = useState<string[]>([]);
  const [savingFeaturedComms, setSavingFeaturedComms] = useState(false);
  const [featuredCommsFeedback, setFeaturedCommsFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  // Admin confirmation states
  const [bookToDeleteAdmin, setBookToDeleteAdmin] = useState<Book | null>(null);
  const [isDeletingBookAdmin, setIsDeletingBookAdmin] = useState(false);
  const [communityToDelete, setCommunityToDelete] = useState<Community | null>(null);
  const [isDeletingCommunity, setIsDeletingCommunity] = useState(false);
  const [pixToApprove, setPixToApprove] = useState<PixOrder | null>(null);

  // User Sorting Options
  const [userSortOption, setUserSortOption] = useState<
    | 'oldest_to_newest'
    | 'newest_to_oldest'
    | 'likes_desc'
    | 'likes_asc'
    | 'dislikes_desc'
    | 'dislikes_asc'
    | 'active_desc'
    | 'active_asc'
  >('oldest_to_newest');

  // Pix Orders & Manual Approval
  const [pixOrders, setPixOrders] = useState<PixOrder[]>([]);
  const [pixFilter, setPixFilter] = useState<'all' | 'under_review' | 'pending' | 'paid' | 'rejected'>('all');
  const [processingPixId, setProcessingPixId] = useState<string | null>(null);
  const [pixFeedback, setPixFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  // Audit (Kard Transactions & Paid Subscriptions)
  const [transactions, setTransactions] = useState<KardTransaction[]>([]);
  const [paidSubscriptions, setPaidSubscriptions] = useState<{
    receiptCode: string;
    userId: string;
    userEmail?: string;
    planId: 'leitor' | 'escritor' | string;
    amount: number;
    bankName?: string;
    type?: string;
    usedAt: string;
    activatedBy?: string;
    justification?: string;
  }[]>([]);
  const [auditFilter, setAuditFilter] = useState<'all' | 'subscriptions' | 'kards'>('all');
  const [auditSearch, setAuditSearch] = useState('');

  const [loading, setLoading] = useState(true);

  // 1. Fetch data & Realtime subscriptions
  useEffect(() => {
    if (!isDeveloper) return;

    setLoading(true);

    // Reports
    const repQuery = query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(50));
    const unsubRep = onSnapshot(repQuery, (snap) => {
      const list: SafetyReport[] = [];
      snap.forEach((d) => list.push(d.data() as SafetyReport));
      setReports(list);
    });

    // Users
    const userQuery = query(collection(db, 'users'), limit(150));
    const unsubUsers = onSnapshot(userQuery, (snap) => {
      const list: UserProfile[] = [];
      snap.forEach((d) => list.push(d.data() as UserProfile));
      setUsers(list);
    });

    // Books
    const booksQuery = query(collection(db, 'books'), limit(100));
    const unsubBooks = onSnapshot(booksQuery, (snap) => {
      const list: Book[] = [];
      snap.forEach((d) => list.push(d.data() as Book));
      setBooks(list);
    });

    // Communities
    const commQuery = query(collection(db, 'communities'), orderBy('membersCount', 'desc'), limit(100));
    const unsubComm = onSnapshot(commQuery, (snap) => {
      const list: Community[] = [];
      snap.forEach((d) => list.push(d.data() as Community));
      setCommunities(list);
    });

    // Pix Orders
    const pixQuery = query(collection(db, 'pixOrders'), orderBy('createdAt', 'desc'), limit(100));
    const unsubPix = onSnapshot(pixQuery, (snap) => {
      const list: PixOrder[] = [];
      snap.forEach((d) => list.push(d.data() as PixOrder));
      setPixOrders(list);
    });

    // Featured Books Setting (Up to 3)
    const unsubFeatBooks = onSnapshot(doc(db, 'settings', 'featuredBooks'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setFeaturedBookIds((data?.bookIds || []).slice(0, 3));
      } else {
        // Fallback: check single featuredBook
        getDoc(doc(db, 'settings', 'featuredBook')).then((singleSnap) => {
          if (singleSnap.exists() && singleSnap.data()?.bookId) {
            setFeaturedBookIds([singleSnap.data().bookId]);
          } else {
            setFeaturedBookIds([]);
          }
        });
      }
    });

    // Featured Communities Setting (Up to 5)
    const unsubFeatComms = onSnapshot(doc(db, 'settings', 'featuredCommunities'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setFeaturedCommIds((data?.communityIds || []).slice(0, 5));
      } else {
        setFeaturedCommIds([]);
      }
    });

    // Kard Transactions
    const txQuery = query(
      collection(db, 'transactions'),
      orderBy('createdAt', 'desc'),
      limit(100)
    );
    const unsubTx = onSnapshot(txQuery, (snap) => {
      const list: KardTransaction[] = [];
      snap.forEach((d) => list.push(d.data() as KardTransaction));
      setTransactions(list);
    });

    // Paid Subscriptions (usedPixReceipts)
    const subReceiptsQuery = query(
      collection(db, 'usedPixReceipts'),
      orderBy('usedAt', 'desc'),
      limit(100)
    );
    const unsubSubReceipts = onSnapshot(
      subReceiptsQuery,
      (snap) => {
        const list: any[] = [];
        snap.forEach((d) => list.push(d.data()));
        setPaidSubscriptions(list);
      },
      (err) => {
        console.warn('Could not listen to usedPixReceipts:', err);
      }
    );

    setLoading(false);

    return () => {
      unsubRep();
      unsubUsers();
      unsubBooks();
      unsubComm();
      unsubPix();
      unsubFeatBooks();
      unsubFeatComms();
      unsubTx();
      unsubSubReceipts();
    };
  }, [isDeveloper]);

  // Keep selected user fresh when users list updates
  useEffect(() => {
    if (selectedUser) {
      const fresh = users.find((u) => u.id === selectedUser.id);
      if (fresh) {
        setSelectedUser(fresh);
      }
    }
  }, [users]);

  // Calculate real metrics for users asynchronously
  useEffect(() => {
    if (users.length === 0) return;

    let isMounted = true;
    const computeAllMetrics = async () => {
      const metricsRecord: Record<string, UserAdminMetrics> = {};
      for (const u of users) {
        if (!isMounted) break;
        try {
          const m = await calculateRealUserMetrics(u);
          metricsRecord[u.id] = m;
        } catch (err) {
          console.warn('Error calculating metric for user', u.id, err);
        }
      }
      if (isMounted) {
        setUserMetrics(metricsRecord);
      }
    };

    computeAllMetrics();
    return () => {
      isMounted = false;
    };
  }, [users]);

  if (!isDeveloper) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <ShieldAlert className="mx-auto h-12 w-12 text-[#FF57B2] mb-3" />
        <h2 className="text-xl font-bold text-white">Acesso Restrito</h2>
        <p className="text-xs text-zinc-400 mt-1">
          Esta área é restrita aos desenvolvedores e gestores autorizados do KORDEL.
        </p>
      </div>
    );
  }

  // Handle Report Resolution
  const handleResolveReport = async (
    report: SafetyReport,
    status: 'resolved' | 'dismissed',
    actionTaken: string
  ) => {
    try {
      await updateDoc(doc(db, 'reports', report.id), {
        status,
        actionTaken,
        resolvedAt: new Date().toISOString(),
        resolvedBy: currentUser?.email || 'Desenvolvedor',
      });
    } catch (err) {
      console.error('Error resolving report:', err);
    }
  };

  // Toggle user badge / role / ban / silence
  const handleUpdateUser = async (
    userId: string,
    data: Partial<UserProfile> & { isSilenced?: boolean },
    actionLabel?: string
  ) => {
    setSavingUser(true);
    setUserActionFeedback(null);
    try {
      const sanitized = sanitizeFirestoreData({
        ...data,
        updatedAt: new Date().toISOString(),
      });
      await updateDoc(doc(db, 'users', userId), sanitized);

      // Record in audit logs
      await setDoc(
        doc(collection(db, 'auditLogs')),
        sanitizeFirestoreData({
          id: `audit_${Date.now()}`,
          adminId: currentUser?.uid || 'admin',
          adminEmail: currentUser?.email || 'desenvolvedor',
          action: actionLabel || 'user_profile_updated',
          targetUserId: userId,
          details: JSON.stringify(data),
          createdAt: new Date().toISOString(),
        })
      );

      // Real user notifications for badges, ban and silence
      if (data.hasExperiencedReaderBadge !== undefined) {
        await sendNotification(
          userId,
          'achievement',
          data.hasExperiencedReaderBadge
            ? 'Selo de Leitor Experiente Concedido!'
            : 'Selo de Leitor Experiente Atualizado',
          data.hasExperiencedReaderBadge
            ? 'A moderação concedeu a você a insígnia oficial de Leitor Experiente no KORDEL.'
            : 'Seu selo de Leitor Experiente foi desativado pela moderação.',
          '/profile'
        );
      }
      if (data.isVerifiedWriter !== undefined) {
        await sendNotification(
          userId,
          'achievement',
          data.isVerifiedWriter
            ? 'Selo de Escritor Verificado Concedido!'
            : 'Selo de Escritor Verificado Atualizado',
          data.isVerifiedWriter
            ? 'Parabéns! Sua conta agora possui o selo de Escritor Verificado no KORDEL.'
            : 'O selo de Escritor Verificado foi revogado pela administração.',
          '/profile'
        );
      }
      if (data.isBanned !== undefined) {
        await sendNotification(
          userId,
          'system',
          data.isBanned ? 'Aviso de Suspensão de Conta' : 'Conta Reativada',
          data.isBanned
            ? 'Sua conta foi suspensa por descumprimento das diretrizes da comunidade.'
            : 'Sua conta foi reativada e você já pode voltar a participar da plataforma.',
          '/'
        );
      }
      if (data.isSilenced !== undefined) {
        await sendNotification(
          userId,
          'system',
          data.isSilenced ? 'Aviso de Moderação: Conta Silenciada' : 'Silenciamento Revogado',
          data.isSilenced
            ? 'Sua conta foi silenciada temporariamente pela moderação e você não pode postar ou comentar.'
            : 'O silenciamento de sua conta foi revogado pela moderação.',
          '/'
        );
      }

      if (selectedUser?.id === userId) {
        setSelectedUser((prev) => (prev ? { ...prev, ...data } : null));
      }

      setUserActionFeedback({
        type: 'success',
        msg: `${actionLabel || 'Usuário atualizado com sucesso no Firebase'}.`,
      });
    } catch (err: any) {
      console.error('Error updating user:', err);
      setUserActionFeedback({
        type: 'error',
        msg: err.message || 'Falha ao atualizar usuário.',
      });
    } finally {
      setSavingUser(false);
    }
  };

  // Admin Kards grant/deduct
  const handleAdjustUserKards = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || kardsAdjustment === 0 || !kardsJustification.trim()) return;

    setSavingUser(true);
    setUserActionFeedback(null);
    try {
      if (kardsAdjustment > 0) {
        await creditKards(
          selectedUser.id,
          kardsAdjustment,
          'admin_grant',
          `Ajuste administrativo: ${kardsJustification.trim()}`
        );
      } else {
        await spendKards(
          selectedUser.id,
          Math.abs(kardsAdjustment),
          'admin_grant',
          `Estorno administrativo: ${kardsJustification.trim()}`
        );
      }

      // Record in audit log
      await setDoc(
        doc(collection(db, 'auditLogs')),
        sanitizeFirestoreData({
          id: `audit_${Date.now()}`,
          adminId: currentUser?.uid || 'admin',
          adminEmail: currentUser?.email || 'desenvolvedor',
          action: 'kards_adjusted',
          targetUserId: selectedUser.id,
          details: `${kardsAdjustment > 0 ? '+' : ''}${kardsAdjustment} Kards. Motivo: ${kardsJustification.trim()}`,
          createdAt: new Date().toISOString(),
        })
      );

      // Send real notification
      await sendNotification(
        selectedUser.id,
        'kards_received',
        kardsAdjustment > 0 ? 'Kards Creditados pela Moderação' : 'Ajuste de Saldo de Kards',
        kardsAdjustment > 0
          ? `Você recebeu ${kardsAdjustment} Kards em sua carteira. Motivo: ${kardsJustification.trim()}`
          : `Foram debitados ${Math.abs(kardsAdjustment)} Kards de sua conta. Motivo: ${kardsJustification.trim()}`,
        '/store'
      );

      setUserActionFeedback({
        type: 'success',
        msg: `Saldo de Kards atualizado com sucesso (${kardsAdjustment > 0 ? '+' : ''}${kardsAdjustment} Kards).`,
      });
      setKardsAdjustment(0);
      setKardsJustification('');
    } catch (err: any) {
      setUserActionFeedback({
        type: 'error',
        msg: err.message || 'Falha ao ajustar Kards.',
      });
    } finally {
      setSavingUser(false);
    }
  };

  // Ativação Manual de Assinatura pelo Desenvolvedor
  const handleManualActivateSub = async (targetUser: UserProfile) => {
    if (!targetUser) return;
    setSavingManualSub(true);
    setUserActionFeedback(null);
    try {
      const updated = await manuallyActivateUserSubscription(
        targetUser.id,
        manualSubPlan,
        manualSubDurationDays,
        manualSubJustification || 'Ativação manual autorizada por desenvolvedor',
        currentUser?.uid
      );
      setSelectedUser(updated);
      setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
      const planName = SUBSCRIPTION_PLANS[manualSubPlan].name;
      const durationLabel = manualSubDurationDays >= 3650 ? 'Vitalícia' : `${manualSubDurationDays} dias`;
      setUserActionFeedback({
        type: 'success',
        msg: `Assinatura ${planName} (${durationLabel}) ativada com sucesso para ${targetUser.displayName}!`,
      });
      setManualSubJustification('');
    } catch (err: any) {
      console.error('Error manually activating subscription:', err);
      setUserActionFeedback({
        type: 'error',
        msg: err.message || 'Erro ao ativar assinatura manual.',
      });
    } finally {
      setSavingManualSub(false);
    }
  };

  // Revogação Manual de Assinatura pelo Desenvolvedor
  const handleManualRevokeSub = async (targetUser: UserProfile) => {
    if (!targetUser) return;
    setSavingManualSub(true);
    setUserActionFeedback(null);
    try {
      await manuallyRevokeUserSubscription(targetUser.id, 'Revogada pelo desenvolvedor');
      const updated: UserProfile = {
        ...targetUser,
        subscription: targetUser.subscription
          ? { ...targetUser.subscription, status: 'canceled' as const, canceledAt: new Date().toISOString() }
          : undefined,
        hasExperiencedReaderBadge: false,
        hasKardelProBadge: false,
        isVerifiedWriter: false,
      };
      setSelectedUser(updated);
      setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
      setUserActionFeedback({
        type: 'success',
        msg: `Assinatura de ${targetUser.displayName} cancelada/revogada com sucesso.`,
      });
    } catch (err: any) {
      console.error('Error revoking subscription:', err);
      setUserActionFeedback({
        type: 'error',
        msg: err.message || 'Erro ao revogar assinatura.',
      });
    } finally {
      setSavingManualSub(false);
    }
  };

  // Toggle Featured Book for Home (Up to 3 Works)
  const handleToggleFeaturedBook = async (book: Book) => {
    setSavingFeatured(true);
    setFeaturedFeedback(null);
    try {
      const isCurrentlyFeatured = featuredBookIds.includes(book.id);
      let newIds: string[] = [];

      if (isCurrentlyFeatured) {
        newIds = featuredBookIds.filter((id) => id !== book.id);
      } else {
        if (featuredBookIds.length >= 3) {
          setFeaturedFeedback({
            type: 'error',
            msg: 'Você já selecionou o limite máximo de 3 obras para os Destaques da Semana. Remova uma obra antes de adicionar outra.',
          });
          setSavingFeatured(false);
          return;
        }
        newIds = [...featuredBookIds, book.id];
      }

      // Save to settings/featuredBooks
      const booksPayload = newIds.map((id) => {
        const found = books.find((b) => b.id === id);
        return {
          bookId: id,
          title: found?.title || '',
          authorName: found?.authorName || '',
          coverUrl: found?.coverUrl || '',
        };
      });

      await setDoc(
        doc(db, 'settings', 'featuredBooks'),
        sanitizeFirestoreData({
          id: 'featuredBooks',
          bookIds: newIds,
          books: booksPayload,
          updatedAt: new Date().toISOString(),
          setBy: currentUser?.email || 'Desenvolvedor',
        })
      );

      // Backwards compatibility with single featuredBook setting
      if (newIds.length > 0) {
        const firstBook = books.find((b) => b.id === newIds[0]);
        await setDoc(
          doc(db, 'settings', 'featuredBook'),
          sanitizeFirestoreData({
            id: 'featuredBook',
            bookId: newIds[0],
            title: firstBook?.title || '',
            authorName: firstBook?.authorName || '',
            coverUrl: firstBook?.coverUrl || '',
            updatedAt: new Date().toISOString(),
            setBy: currentUser?.email || 'Desenvolvedor',
          })
        );
      } else {
        await deleteDoc(doc(db, 'settings', 'featuredBook')).catch(() => {});
      }

      setFeaturedBookIds(newIds);
      setFeaturedFeedback({
        type: 'success',
        msg: isCurrentlyFeatured
          ? `Obra "${book.title}" removida dos destaques da semana.`
          : `Obra "${book.title}" adicionada aos Destaques da Semana (${newIds.length}/3)!`,
      });
    } catch (err: any) {
      console.error('Error saving featured books:', err);
      setFeaturedFeedback({
        type: 'error',
        msg: err.message || 'Erro ao atualizar destaques da semana no Firebase.',
      });
    } finally {
      setSavingFeatured(false);
    }
  };

  // Toggle Featured Community for Home (Up to 5 Communities)
  const handleToggleFeaturedCommunity = async (comm: Community) => {
    setSavingFeaturedComms(true);
    setFeaturedCommsFeedback(null);
    try {
      const isCurrentlyFeatured = featuredCommIds.includes(comm.id);
      let newIds: string[] = [];

      if (isCurrentlyFeatured) {
        newIds = featuredCommIds.filter((id) => id !== comm.id);
      } else {
        if (featuredCommIds.length >= 5) {
          setFeaturedCommsFeedback({
            type: 'error',
            msg: 'Você já selecionou o limite máximo de 5 comunidades para a Home. Remova uma antes de adicionar outra.',
          });
          setSavingFeaturedComms(false);
          return;
        }
        newIds = [...featuredCommIds, comm.id];
      }

      const commsPayload = newIds.map((id) => {
        const found = communities.find((c) => c.id === id);
        return {
          communityId: id,
          name: found?.name || '',
          category: found?.category || '',
          coverUrl: found?.coverUrl || '',
        };
      });

      await setDoc(
        doc(db, 'settings', 'featuredCommunities'),
        sanitizeFirestoreData({
          id: 'featuredCommunities',
          communityIds: newIds,
          communities: commsPayload,
          updatedAt: new Date().toISOString(),
          setBy: currentUser?.email || 'Desenvolvedor',
        })
      );

      setFeaturedCommIds(newIds);
      setFeaturedCommsFeedback({
        type: 'success',
        msg: isCurrentlyFeatured
          ? `Comunidade "${comm.name}" removida das recomendações da Home.`
          : `Comunidade "${comm.name}" adicionada às recomendações da Home (${newIds.length}/5)!`,
      });
    } catch (err: any) {
      console.error('Error saving featured communities:', err);
      setFeaturedCommsFeedback({
        type: 'error',
        msg: err.message || 'Erro ao salvar comunidades recomendadas no Firebase.',
      });
    } finally {
      setSavingFeaturedComms(false);
    }
  };

  // Manual Pix Approval
  const handleApprovePix = async (order: PixOrder) => {
    setProcessingPixId(order.id);
    setPixFeedback(null);
    try {
      await approvePixOrder(order.id, currentUser?.email || 'desenvolvedor');
      setPixFeedback({
        type: 'success',
        msg: `Pix de R$ ${order.amountBrl.toFixed(2)} aprovado com sucesso! ${order.kards} Kards foram creditados na conta do usuário.`,
      });
    } catch (err: any) {
      setPixFeedback({
        type: 'error',
        msg: err.message || 'Erro ao processar aprovação do Pix.',
      });
    } finally {
      setProcessingPixId(null);
      setPixToApprove(null);
    }
  };

  // Manual Pix Rejection
  const handleRejectPix = async (order: PixOrder) => {
    const reason = 'Comprovante ilegível ou valor não identificado na conta bancária';
    setProcessingPixId(order.id);
    setPixFeedback(null);
    try {
      await rejectPixOrder(order.id, currentUser?.email || 'desenvolvedor', reason);
      setPixFeedback({
        type: 'success',
        msg: `Pedido Pix #${order.id.slice(0, 8)} recusado com sucesso. O usuário foi notificado.`,
      });
    } catch (err: any) {
      setPixFeedback({
        type: 'error',
        msg: err.message || 'Erro ao recusar pedido Pix.',
      });
    } finally {
      setProcessingPixId(null);
    }
  };

  // Delete Content as Admin
  const handleConfirmDeleteBookAdmin = async () => {
    if (!bookToDeleteAdmin) return;
    setIsDeletingBookAdmin(true);
    try {
      const bookId = bookToDeleteAdmin.id;
      try {
        const chSnap = await getDocs(collection(db, 'books', bookId, 'chapters'));
        for (const d of chSnap.docs) {
          await deleteDoc(d.ref);
        }
      } catch (e) {
        console.warn('Err deleting chapters:', e);
      }
      try {
        const revSnap = await getDocs(collection(db, 'books', bookId, 'reviews'));
        for (const d of revSnap.docs) {
          await deleteDoc(d.ref);
        }
      } catch (e) {
        console.warn('Err deleting reviews:', e);
      }
      await deleteDoc(doc(db, 'books', bookId));
      setBooks((prev) => prev.filter((b) => b.id !== bookId));
      setContentFeedback({
        type: 'success',
        msg: `Obra "${bookToDeleteAdmin.title}" excluída permanentemente.`,
      });
      setBookToDeleteAdmin(null);
    } catch (err: any) {
      console.error('Error deleting book as admin:', err);
      setContentFeedback({
        type: 'error',
        msg: 'Erro ao excluir obra: ' + (err.message || 'Falha'),
      });
    } finally {
      setIsDeletingBookAdmin(false);
    }
  };

  // Delete Community as Admin
  const handleConfirmDeleteCommunity = async () => {
    if (!communityToDelete) return;
    setIsDeletingCommunity(true);
    try {
      await deleteCommunityCascade(communityToDelete.id);
      setCommunities((prev) => prev.filter((c) => c.id !== communityToDelete.id));
      setFeaturedCommIds((prev) => prev.filter((id) => id !== communityToDelete.id));
      setFeaturedCommsFeedback({
        type: 'success',
        msg: `Comunidade "${communityToDelete.name}" e todos os seus dados foram excluídos com sucesso.`,
      });
      setCommunityToDelete(null);
    } catch (err: any) {
      console.error('Error deleting community as admin:', err);
      setFeaturedCommsFeedback({
        type: 'error',
        msg: err.message || 'Erro ao excluir comunidade como desenvolvedor.',
      });
    } finally {
      setIsDeletingCommunity(false);
    }
  };

  const filteredReports = reports.filter((r) => {
    if (reportFilter === 'all') return true;
    return r.status === reportFilter;
  });

  // 3-day activity window (passou de 3 dias consecutivos sem entrar não é mais ativo)
  const THREE_DAYS_MS = 3 * 24 * 60 * 60 * 1000;

  const getUserActivityStatus = (u: UserProfile) => {
    const isBanned = Boolean(u.isBanned);
    const isSilenced = Boolean((u as any).isSilenced);

    // Prioritize lastActiveAt -> lastLoginAt -> updatedAt -> createdAt
    const lastAccessIso = u.lastActiveAt || u.lastLoginAt || u.updatedAt || u.createdAt;
    const lastAccessTime = lastAccessIso ? new Date(lastAccessIso).getTime() : 0;
    const now = Date.now();
    const timeSinceAccess = lastAccessTime > 0 ? now - lastAccessTime : Infinity;

    // Active if not banned and accessed within 3 consecutive days
    const isActive = !isBanned && lastAccessTime > 0 && timeSinceAccess <= THREE_DAYS_MS;

    // Registration time on platform
    const createdTime = u.createdAt ? new Date(u.createdAt).getTime() : now;
    const tenureMs = Math.max(0, now - createdTime);

    // Time inactive formatting
    let inactiveDurationLabel = '';
    if (!isActive && !isBanned) {
      const diffDays = Math.floor(timeSinceAccess / (24 * 60 * 60 * 1000));
      if (diffDays <= 0) {
        inactiveDurationLabel = 'Inativo há menos de 1 dia';
      } else if (diffDays < 30) {
        inactiveDurationLabel = `Inativo há ${diffDays} ${diffDays === 1 ? 'dia' : 'dias'}`;
      } else if (diffDays < 365) {
        const months = Math.floor(diffDays / 30);
        inactiveDurationLabel = `Inativo há ${months} ${months === 1 ? 'mês' : 'meses'}`;
      } else {
        const years = Math.floor(diffDays / 365);
        inactiveDurationLabel = `Inativo há ${years} ${years === 1 ? 'ano' : 'anos'}`;
      }
    }

    // Platform tenure formatting
    let tenureLabel = '';
    const tenureDays = Math.floor(tenureMs / (24 * 60 * 60 * 1000));
    if (tenureDays < 30) {
      tenureLabel = `${Math.max(1, tenureDays)} ${tenureDays === 1 ? 'dia' : 'dias'}`;
    } else if (tenureDays < 365) {
      const m = Math.floor(tenureDays / 30);
      tenureLabel = `${m} ${m === 1 ? 'mês' : 'meses'}`;
    } else {
      const y = Math.floor(tenureDays / 365);
      tenureLabel = `${y} ${y === 1 ? 'ano' : 'anos'}`;
    }

    return {
      isActive,
      isBanned,
      isSilenced,
      lastAccessTime,
      createdTime,
      inactiveDurationLabel,
      tenureLabel,
    };
  };

  const filteredUsers = users.filter((u) => {
    const term = userSearch.toLowerCase();
    const handle = (u.username || '').toLowerCase();
    const uId = (u.uniqueId || '').toLowerCase();
    return (
      u.displayName.toLowerCase().includes(term) ||
      u.email.toLowerCase().includes(term) ||
      handle.includes(term) ||
      uId.includes(term)
    );
  });

  // Sort users based on selected userSortOption
  const sortedUsers = [...filteredUsers].sort((a, b) => {
    const statA = getUserActivityStatus(a);
    const statB = getUserActivityStatus(b);
    const metricsA = userMetrics[a.id];
    const metricsB = userMetrics[b.id];

    switch (userSortOption) {
      case 'oldest_to_newest':
        // Mais antigos para mais novos (data de cadastro crescente)
        return statA.createdTime - statB.createdTime;

      case 'newest_to_oldest':
        // Mais novos para mais antigos (data de cadastro decrescente)
        return statB.createdTime - statA.createdTime;

      case 'likes_desc': {
        // Mais gostei para menos gostei
        const likesA = metricsA?.likesReceived ?? 0;
        const likesB = metricsB?.likesReceived ?? 0;
        if (likesA !== likesB) return likesB - likesA;
        return statA.createdTime - statB.createdTime;
      }

      case 'likes_asc': {
        // Menos gostei para mais gostei
        const likesA = metricsA?.likesReceived ?? 0;
        const likesB = metricsB?.likesReceived ?? 0;
        if (likesA !== likesB) return likesA - likesB;
        return statA.createdTime - statB.createdTime;
      }

      case 'dislikes_desc': {
        // Mais não gostei para menos não gostei
        const dislikesA = metricsA?.dislikesReceived ?? 0;
        const dislikesB = metricsB?.dislikesReceived ?? 0;
        if (dislikesA !== dislikesB) return dislikesB - dislikesA;
        return statA.createdTime - statB.createdTime;
      }

      case 'dislikes_asc': {
        // Menos não gostei para mais não gostei
        const dislikesA = metricsA?.dislikesReceived ?? 0;
        const dislikesB = metricsB?.dislikesReceived ?? 0;
        if (dislikesA !== dislikesB) return dislikesA - dislikesB;
        return statA.createdTime - statB.createdTime;
      }

      case 'active_desc': {
        // Mais ativos para menos ativos (acesso recente primeiro)
        return statB.lastAccessTime - statA.lastAccessTime;
      }

      case 'active_asc': {
        // Menos ativos para mais ativos (maior inatividade primeiro)
        return statA.lastAccessTime - statB.lastAccessTime;
      }

      default:
        return statA.createdTime - statB.createdTime;
    }
  });

  const totalActiveUsersCount = users.filter((u) => getUserActivityStatus(u).isActive).length;
  const totalInactiveUsersCount = users.filter((u) => !u.isBanned && !getUserActivityStatus(u).isActive).length;

  const filteredPixOrders = pixOrders.filter((order) => {
    if (pixFilter === 'all') return true;
    return order.status === pixFilter;
  });

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8 space-y-7 text-white">
      {/* Header */}
      <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="relative z-10 space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-[#FF57B2]/15 border border-[#FF57B2]/30 px-3 py-1 text-[11px] font-bold text-[#FF57B2] uppercase tracking-wider">
            <ShieldAlert className="h-3.5 w-3.5" />
            <span>Painel Master do Desenvolvedor</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black font-display tracking-tight text-white">
            Gestão & Moderação Global
          </h1>
          <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-literary">
            Controle de usuários, aprovação manual Pix, destaques da Home, gerenciamento de comunidades e auditoria.
          </p>
        </div>

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <div className="flex items-center gap-2.5 rounded-2xl bg-[#262626] px-4 py-2.5 text-xs font-bold border border-zinc-700 text-zinc-100 shadow-inner">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF57B2] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#FF57B2]"></span>
            </span>
            <span>Desenvolvedor Ativo</span>
          </div>
        </div>

        {/* Subtle decorative background glow */}
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-[#FF57B2]/10 blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 h-64 w-64 rounded-full bg-[#FF57B2]/5 blur-3xl pointer-events-none" />
      </div>

      {/* Executive Quick Stats Cards (KPI Strip) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <button
          type="button"
          onClick={() => setActiveTab('users')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer ${
            activeTab === 'users'
              ? 'bg-[#262626] text-white border-[#FF57B2] shadow-[0_0_15px_rgba(255,87,178,0.25)] ring-1 ring-[#FF57B2]'
              : 'bg-[#202020] text-zinc-300 border-zinc-800 hover:border-[#FF57B2]/50 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className={`text-[10px] uppercase font-bold tracking-wider ${activeTab === 'users' ? 'text-[#FF57B2]' : 'text-zinc-400'}`}>
              Usuários
            </span>
            <Users className={`h-4 w-4 ${activeTab === 'users' ? 'text-[#FF57B2]' : 'text-zinc-400'}`} />
          </div>
          <div className="text-xl font-black font-display text-white">{users.length}</div>
          <div className="text-[10px] mt-0.5 truncate text-zinc-400">
            {users.filter((u) => u.isBanned).length} banidos
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('featuredCommunities')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer ${
            activeTab === 'featuredCommunities'
              ? 'bg-[#262626] text-white border-[#FF57B2] shadow-[0_0_15px_rgba(255,87,178,0.25)] ring-1 ring-[#FF57B2]'
              : 'bg-[#202020] text-zinc-300 border-zinc-800 hover:border-[#FF57B2]/50 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className={`text-[10px] uppercase font-bold tracking-wider ${activeTab === 'featuredCommunities' ? 'text-[#FF57B2]' : 'text-zinc-400'}`}>
              Comunidades
            </span>
            <Sparkles className={`h-4 w-4 ${activeTab === 'featuredCommunities' ? 'text-[#FF57B2]' : 'text-zinc-400'}`} />
          </div>
          <div className="text-xl font-black font-display text-white">{communities.length}</div>
          <div className="text-[10px] mt-0.5 truncate text-zinc-400">
            {featuredCommIds.length}/5 na Home
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('content')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer ${
            activeTab === 'content'
              ? 'bg-[#262626] text-white border-[#FF57B2] shadow-[0_0_15px_rgba(255,87,178,0.25)] ring-1 ring-[#FF57B2]'
              : 'bg-[#202020] text-zinc-300 border-zinc-800 hover:border-[#FF57B2]/50 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className={`text-[10px] uppercase font-bold tracking-wider ${activeTab === 'content' ? 'text-[#FF57B2]' : 'text-zinc-400'}`}>
              Obras
            </span>
            <BookOpen className={`h-4 w-4 ${activeTab === 'content' ? 'text-[#FF57B2]' : 'text-zinc-400'}`} />
          </div>
          <div className="text-xl font-black font-display text-white">{books.length}</div>
          <div className="text-[10px] mt-0.5 truncate text-zinc-400">
            {featuredBookIds.length}/3 destaques
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('pix')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer relative ${
            activeTab === 'pix'
              ? 'bg-[#262626] text-white border-[#FF57B2] shadow-[0_0_15px_rgba(255,87,178,0.25)] ring-1 ring-[#FF57B2]'
              : 'bg-[#202020] text-zinc-300 border-zinc-800 hover:border-[#FF57B2]/50 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className={`text-[10px] uppercase font-bold tracking-wider ${activeTab === 'pix' ? 'text-[#FF57B2]' : 'text-zinc-400'}`}>
              Pix Análise
            </span>
            <Coins className={`h-4 w-4 ${activeTab === 'pix' ? 'text-[#FF57B2]' : 'text-[#FF57B2]'}`} />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xl font-black font-display text-white">
              {pixOrders.filter((o) => o.status === 'under_review').length}
            </span>
            {pixOrders.filter((o) => o.status === 'under_review').length > 0 && (
              <span className="h-2 w-2 rounded-full bg-[#FF57B2] animate-ping" />
            )}
          </div>
          <div className="text-[10px] mt-0.5 truncate text-zinc-400">
            {pixOrders.length} pedidos totais
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('reports')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer relative ${
            activeTab === 'reports'
              ? 'bg-[#262626] text-white border-[#FF57B2] shadow-[0_0_15px_rgba(255,87,178,0.25)] ring-1 ring-[#FF57B2]'
              : 'bg-[#202020] text-zinc-300 border-zinc-800 hover:border-[#FF57B2]/50 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className={`text-[10px] uppercase font-bold tracking-wider ${activeTab === 'reports' ? 'text-[#FF57B2]' : 'text-zinc-400'}`}>
              Denúncias
            </span>
            <ShieldAlert className={`h-4 w-4 ${activeTab === 'reports' ? 'text-[#FF57B2]' : 'text-zinc-400'}`} />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xl font-black font-display text-white">
              {reports.filter((r) => r.status === 'pending').length}
            </span>
            {reports.filter((r) => r.status === 'pending').length > 0 && (
              <span className="h-2 w-2 rounded-full bg-[#FF57B2] animate-ping" />
            )}
          </div>
          <div className="text-[10px] mt-0.5 truncate text-zinc-400">
            {reports.length} registradas
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('audit')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer ${
            activeTab === 'audit'
              ? 'bg-[#262626] text-white border-[#FF57B2] shadow-[0_0_15px_rgba(255,87,178,0.25)] ring-1 ring-[#FF57B2]'
              : 'bg-[#202020] text-zinc-300 border-zinc-800 hover:border-[#FF57B2]/50 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className={`text-[10px] uppercase font-bold tracking-wider ${activeTab === 'audit' ? 'text-[#FF57B2]' : 'text-zinc-400'}`}>
              Auditoria
            </span>
            <FileText className={`h-4 w-4 ${activeTab === 'audit' ? 'text-[#FF57B2]' : 'text-zinc-400'}`} />
          </div>
          <div className="text-xl font-black font-display text-white">{transactions.length + paidSubscriptions.length}</div>
          <div className="text-[10px] mt-0.5 truncate text-zinc-400">
            Livro contábil
          </div>
        </button>
      </div>

      {/* Tabs Navigation Bar */}
      <div className="overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-[#202020] border border-zinc-800 min-w-max">
          {[
            { id: 'branding', label: 'Marca & Identidade', count: 'Configurar', icon: Sparkles },
            { id: 'users', label: 'Usuários & Métricas', count: users.length, icon: Users },
            { id: 'featured', label: 'Obras em Destaque', count: `${featuredBookIds.length}/3`, icon: Sparkles },
            { id: 'featuredCommunities', label: 'Comunidades na Home', count: `${featuredCommIds.length}/5`, icon: Users },
            {
              id: 'pix',
              label: 'Pagamentos Pix',
              count: pixOrders.filter((o) => o.status === 'under_review').length > 0
                ? `${pixOrders.filter((o) => o.status === 'under_review').length} em análise`
                : pixOrders.length,
              badgeAlert: pixOrders.filter((o) => o.status === 'under_review').length > 0,
              icon: Coins,
            },
            {
              id: 'reports',
              label: 'Denúncias',
              count: reports.filter((r) => r.status === 'pending').length > 0
                ? `${reports.filter((r) => r.status === 'pending').length} pendente(s)`
                : reports.length,
              badgeAlert: reports.filter((r) => r.status === 'pending').length > 0,
              icon: ShieldAlert,
            },
            { id: 'content', label: 'Obras da Plataforma', count: books.length, icon: BookOpen },
            { id: 'audit', label: 'Auditoria (Kards & Assinaturas)', count: transactions.length + paidSubscriptions.length, icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#FF57B2] text-white shadow-xs'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-white' : 'text-zinc-400'}`} />
                <span>{tab.label}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                    tab.badgeAlert
                      ? 'bg-[#E03595] text-white animate-pulse font-extrabold'
                      : isActive
                      ? 'bg-black/30 text-white'
                      : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 0. BRANDING & IDENTITY (LOGO & NOME - EXCLUSIVO DESENVOLVEDOR) */}
      {activeTab === 'branding' && (
        <div className="space-y-6">
          <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-6 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-white font-display flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5 text-[#FF57B2]" />
                    <span>Personalização de Marca, Logo e Nome do Aplicativo</span>
                  </h2>
                  <span className="rounded-full bg-[#FF57B2]/15 border border-[#FF57B2]/40 px-2 py-0.5 text-[9px] font-black uppercase text-[#FF57B2]">
                    Apenas Desenvolvedor
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  Gerencie a identidade visual e o nome público da plataforma. As alterações têm efeito imediato no cabeçalho, rodapé, título de navegador e modais para todos os usuários.
                </p>
              </div>

              {confirmBrandReset ? (
                <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                  <button
                    type="button"
                    disabled={brandSaving}
                    onClick={async () => {
                      try {
                        setBrandSaving(true);
                        await resetToDefault();
                        setBrandFeedback({ type: 'success', msg: 'Padrão original KORDEL restaurado.' });
                      } catch (e: any) {
                        setBrandFeedback({ type: 'error', msg: e.message });
                      } finally {
                        setBrandSaving(false);
                        setConfirmBrandReset(false);
                      }
                    }}
                    className="rounded-xl bg-[#FF57B2] px-3 py-2 text-xs font-bold text-white hover:bg-[#E03595] transition cursor-pointer disabled:opacity-50"
                  >
                    Confirmar Restauração
                  </button>
                  <button
                    type="button"
                    disabled={brandSaving}
                    onClick={() => setConfirmBrandReset(false)}
                    className="rounded-xl border border-zinc-700 bg-[#262626] px-3 py-2 text-xs font-semibold text-zinc-300 hover:text-white transition cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmBrandReset(true)}
                  disabled={brandSaving}
                  className="flex items-center gap-1.5 rounded-xl border border-zinc-700 bg-[#262626] px-3.5 py-2 text-xs font-semibold text-zinc-300 hover:text-white hover:border-[#FF57B2] transition cursor-pointer self-start sm:self-auto shrink-0"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Restaurar Padrão</span>
                </button>
              )}
            </div>

            {/* Live Preview Bar */}
            <div className="rounded-2xl bg-[#181818] border border-zinc-800 p-4 space-y-3">
              <span className="text-xs font-bold text-[#FF57B2] flex items-center gap-1.5">
                <Eye className="h-4 w-4 text-[#FF57B2]" />
                <span>Pré-visualização ao Vivo na Interface</span>
              </span>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Navbar Preview */}
                <div className="rounded-xl bg-[#202020] border border-zinc-800 p-3 shadow-2xs space-y-1">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase">Visual no Cabeçalho (Navbar)</span>
                  <div className="flex items-center gap-3 pt-1">
                    {brandLogoType === 'image' && brandLogoUrl ? (
                      <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-xl border border-[#FF57B2]/40 bg-zinc-900 p-1 flex items-center justify-center shadow-[0_0_12px_rgba(255,87,178,0.25)]">
                        <img src={brandLogoUrl} alt={brandAppName} className="h-full w-full object-contain" />
                      </div>
                    ) : (
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-sm shadow-[#FF57B2]/35 border border-[#FF57B2]/40">
                        {brandLogoIcon === 'Feather' && <Feather className="h-5 w-5" />}
                        {brandLogoIcon === 'Flame' && <Flame className="h-5 w-5" />}
                        {brandLogoIcon === 'Sparkles' && <Sparkles className="h-5 w-5" />}
                        {brandLogoIcon === 'ScrollText' && <ScrollText className="h-5 w-5" />}
                        {brandLogoIcon === 'Crown' && <Crown className="h-5 w-5" />}
                        {(!brandLogoIcon || brandLogoIcon === 'BookOpen') && <BookOpen className="h-5 w-5" />}
                      </div>
                    )}
                    <div>
                      <span className="text-lg font-black tracking-wider text-white font-display">
                        {brandAppName || 'KORDEL'}
                      </span>
                      <p className="text-[10px] text-zinc-400">{brandTagline || 'Plataforma de leitura & publicação'}</p>
                    </div>
                  </div>
                </div>

                {/* Footer Preview */}
                <div className="rounded-xl bg-[#202020] border border-zinc-800 p-3 shadow-2xs space-y-1">
                  <span className="text-[10px] font-bold text-zinc-400 uppercase">Visual no Rodapé Institucional</span>
                  <div className="flex flex-col items-center text-center pt-1">
                    <div className="flex items-center gap-2">
                      <span className="text-base font-black tracking-wider text-white font-display">
                        {brandAppName || 'KORDEL'}
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-400 line-clamp-1 mt-0.5">
                      {brandDescription || 'Plataforma de leitura & publicação independente.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Feedback message */}
            {brandFeedback && (
              <div
                className={`p-3.5 rounded-2xl text-xs font-bold flex items-center gap-2 ${
                  brandFeedback.type === 'success'
                    ? 'bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40'
                    : 'bg-[#262626] text-zinc-200 border border-[#FF57B2]/40'
                }`}
              >
                {brandFeedback.type === 'success' ? (
                  <CheckCircle className="h-4 w-4 shrink-0 text-[#FF57B2]" />
                ) : (
                  <AlertTriangle className="h-4 w-4 shrink-0 text-[#FF57B2]" />
                )}
                <span>{brandFeedback.msg}</span>
              </div>
            )}

            {/* Customization Form */}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (!brandAppName.trim()) {
                  setBrandFeedback({ type: 'error', msg: 'O nome do aplicativo não pode ficar em branco.' });
                  return;
                }
                try {
                  setBrandSaving(true);
                  setBrandFeedback(null);
                  await updateBranding({
                    appName: brandAppName.trim(),
                    logoType: brandLogoType,
                    logoUrl: brandLogoType === 'image' ? brandLogoUrl.trim() : '',
                    logoIconName: brandLogoIcon as any,
                    tagline: brandTagline.trim(),
                    shortDescription: brandDescription.trim(),
                  });
                  setBrandFeedback({ type: 'success', msg: 'Identidade e marca atualizadas com sucesso para toda a plataforma!' });
                } catch (err: any) {
                  setBrandFeedback({ type: 'error', msg: err.message || 'Erro ao gravar alterações no Firebase.' });
                } finally {
                  setBrandSaving(false);
                }
              }}
              className="space-y-5"
            >
              {/* Nome do Aplicativo */}
              <div>
                <label className="block text-xs font-bold text-zinc-200 mb-1">
                  Nome Público da Plataforma / App
                </label>
                <input
                  type="text"
                  value={brandAppName}
                  onChange={(e) => setBrandAppName(e.target.value)}
                  placeholder="Ex: KORDEL"
                  maxLength={30}
                  required
                  className="w-full max-w-md rounded-xl border border-zinc-700 bg-[#181818] px-3.5 py-2.5 text-sm font-bold text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none transition"
                />
              </div>

              {/* Formato do Logo */}
              <div>
                <label className="block text-xs font-bold text-zinc-200 mb-2">
                  Tipo de Logo
                </label>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setBrandLogoType('icon')}
                    className={`flex items-center gap-2 rounded-xl py-2 px-4 text-xs font-bold border transition cursor-pointer ${
                      brandLogoType === 'icon'
                        ? 'border-[#FF57B2] bg-[#262626] text-[#FF80C5] shadow-2xs'
                        : 'border-zinc-700 bg-[#181818] text-zinc-300 hover:bg-[#262626] hover:text-white'
                    }`}
                  >
                    <BookOpen className="h-4 w-4" />
                    <span>Ícone Estilizado</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setBrandLogoType('image')}
                    className={`flex items-center gap-2 rounded-xl py-2 px-4 text-xs font-bold border transition cursor-pointer ${
                      brandLogoType === 'image'
                        ? 'border-[#FF57B2] bg-[#262626] text-[#FF80C5] shadow-2xs'
                        : 'border-zinc-700 bg-[#181818] text-zinc-300 hover:bg-[#262626] hover:text-white'
                    }`}
                  >
                    <Upload className="h-4 w-4" />
                    <span>Imagem / Arte Personalizada</span>
                  </button>
                </div>
              </div>

              {/* Opções de Ícone */}
              {brandLogoType === 'icon' ? (
                <div>
                  <label className="block text-xs font-bold text-zinc-200 mb-2">
                    Símbolo do Logo
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 max-w-lg">
                    {[
                      { id: 'BookOpen', label: 'Livro', icon: BookOpen },
                      { id: 'Feather', label: 'Pena', icon: Feather },
                      { id: 'Flame', label: 'Chama', icon: Flame },
                      { id: 'Sparkles', label: 'Brilho', icon: Sparkles },
                      { id: 'ScrollText', label: 'Pergaminho', icon: ScrollText },
                      { id: 'Crown', label: 'Coroa', icon: Crown },
                    ].map((item) => {
                      const Icon = item.icon;
                      const isSelected = brandLogoIcon === item.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setBrandLogoIcon(item.id as any)}
                          className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition cursor-pointer ${
                            isSelected
                              ? 'border-[#FF57B2] bg-[#262626] text-[#FF80C5] ring-2 ring-[#FF57B2]/40'
                              : 'border-zinc-700 bg-[#181818] text-zinc-400 hover:text-white hover:border-zinc-600'
                          }`}
                        >
                          <Icon className="h-5 w-5 mb-1" />
                          <span className="text-[10px] font-semibold">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : (
                /* Opções de Imagem */
                <div className="space-y-3 max-w-xl">
                  <label className="block text-xs font-bold text-zinc-200">
                    Arquivo de Imagem ou URL do Logo
                  </label>
                  <div className="flex flex-col sm:flex-row items-center gap-2">
                    <label className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl border border-dashed border-[#FF57B2] bg-[#262626] py-2.5 px-4 text-xs font-bold text-[#FF80C5] hover:bg-[#2B2B2B] cursor-pointer transition">
                      <Upload className="h-4 w-4" />
                      <span>{brandUploading ? 'Enviando...' : 'Carregar Imagem do Dispositivo'}</span>
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp,image/svg+xml"
                        disabled={brandUploading}
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            setBrandUploading(true);
                            setBrandFeedback(null);
                            const url = await uploadFileToStorage(file, 'banners', 'app_logo');
                            setBrandLogoUrl(url);
                            setBrandFeedback({ type: 'success', msg: 'Imagem carregada com sucesso!' });
                          } catch (err: any) {
                            setBrandFeedback({ type: 'error', msg: err.message });
                          } finally {
                            setBrandUploading(false);
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                      <LinkIcon className="h-3.5 w-3.5" />
                    </span>
                    <input
                      type="url"
                      value={brandLogoUrl}
                      onChange={(e) => setBrandLogoUrl(e.target.value)}
                      placeholder="Ou cole a URL direta (ex: https://...)"
                      className="w-full rounded-xl border border-zinc-700 bg-[#181818] pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none transition"
                    />
                  </div>
                </div>
              )}

              {/* Tagline e Descrição */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl pt-2">
                <div>
                  <label className="block text-xs font-bold text-zinc-200 mb-1">
                    Slogan / Subtítulo Curto
                  </label>
                  <input
                    type="text"
                    value={brandTagline}
                    onChange={(e) => setBrandTagline(e.target.value)}
                    placeholder="Ex: Plataforma soberana de leitura"
                    maxLength={80}
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] px-3 py-2 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-200 mb-1">
                    Descrição do Rodapé ("Quem Somos")
                  </label>
                  <textarea
                    rows={2}
                    value={brandDescription}
                    onChange={(e) => setBrandDescription(e.target.value)}
                    placeholder="Descrição institucional exibida no rodapé..."
                    maxLength={200}
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] px-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none transition"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={brandSaving || brandUploading}
                  className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF66C4] hover:to-[#D02685] px-6 py-2.5 text-xs font-black text-white shadow-md shadow-[#FF57B2]/30 transition cursor-pointer disabled:opacity-50"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>{brandSaving ? 'Salvando Alterações...' : 'Salvar Alterações da Marca'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 1. USERS & REAL METRICS TABLE */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          {/* Search & Sort Header */}
          <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-5 shadow-xs space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-bold text-white font-display flex items-center gap-2">
                  <Users className="h-5 w-5 text-[#FF57B2]" />
                  <span>Tabela de Usuários Cadastrados</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Gerenciamento, métricas de engajamento, status e ordenação customizada de membros.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
                {/* Filtro de Ordenamento Didático */}
                <div className="flex items-center gap-2 rounded-2xl bg-[#181818] border border-zinc-700 px-3 py-2 text-xs">
                  <Filter className="h-4 w-4 text-[#FF57B2] shrink-0" />
                  <span className="font-bold text-zinc-400 shrink-0">Ordenar:</span>
                  <select
                    value={userSortOption}
                    onChange={(e) => setUserSortOption(e.target.value as any)}
                    className="bg-[#181818] font-bold text-white focus:outline-none cursor-pointer text-xs pr-1 [color-scheme:dark]"
                  >
                    <option value="oldest_to_newest">Mais antigos → mais novos</option>
                    <option value="newest_to_oldest">Mais novos → mais antigos</option>
                    <option value="likes_desc">Mais gostei (curtidas) → menos</option>
                    <option value="likes_asc">Menos gostei → mais gostei</option>
                    <option value="dislikes_desc">Mais não gostei → menos</option>
                    <option value="dislikes_asc">Menos não gostei → mais não gostei</option>
                    <option value="active_desc">Mais ativos no site → menos ativos</option>
                    <option value="active_asc">Menos ativos no site → mais ativos</option>
                  </select>
                </div>

                {/* Pesquisa de Usuário */}
                <div className="w-full sm:w-72">
                  <UserSearchBar
                    placeholder="Pesquisar por nome, @username ou ID..."
                    onSelectUser={(u) => {
                      const match = users.find((usr) => usr.id === u.id);
                      if (match) setSelectedUser(match);
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-zinc-800">
              <div className="rounded-2xl bg-[#181818] border border-zinc-800 p-2.5">
                <span className="text-[10px] uppercase font-bold text-zinc-400 block">Total de Usuários</span>
                <span className="text-lg font-black text-white font-display tabular-nums">{users.length}</span>
              </div>
              <div className="rounded-2xl bg-[#FF57B2]/10 border border-[#FF57B2]/35 p-2.5">
                <span className="text-[10px] uppercase font-bold text-[#FF80C5] block">Ativos (&le; 3 dias)</span>
                <span className="text-lg font-black text-white font-display tabular-nums">{totalActiveUsersCount}</span>
              </div>
              <div className="rounded-2xl bg-[#181818] border border-zinc-700 p-2.5">
                <span className="text-[10px] uppercase font-bold text-zinc-300 block">Inativos (&gt; 3 dias)</span>
                <span className="text-lg font-black text-zinc-200 font-display tabular-nums">{totalInactiveUsersCount}</span>
              </div>
              <div className="rounded-2xl bg-[#262626] border border-zinc-700 p-2.5">
                <span className="text-[10px] uppercase font-bold text-zinc-400 block">Banidos</span>
                <span className="text-lg font-black text-white font-display tabular-nums">{users.filter((u) => u.isBanned).length}</span>
              </div>
            </div>

            {userActionFeedback && (
              <div
                className={`rounded-2xl p-3 text-xs font-semibold flex items-center justify-between ${
                  userActionFeedback.type === 'success'
                    ? 'bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40'
                    : 'bg-[#262626] text-zinc-200 border border-[#FF57B2]/40'
                }`}
              >
                <span>{userActionFeedback.msg}</span>
                <button
                  onClick={() => setUserActionFeedback(null)}
                  className="text-zinc-400 hover:text-white font-bold ml-2"
                >
                  ✕
                </button>
              </div>
            )}
          </div>

          {/* Real User Table */}
          <div className="overflow-hidden rounded-3xl border border-zinc-800 bg-[#202020] shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#181818] border-b border-zinc-800 text-zinc-400 uppercase text-[10px] tracking-wider font-bold">
                    <th className="py-3.5 px-4">Nome / Username & ID</th>
                    <th className="py-3.5 px-3 text-center">Tempo na Plataforma</th>
                    <th className="py-3.5 px-3 text-center">Curtidas</th>
                    <th className="py-3.5 px-3 text-center">Não Gostei</th>
                    <th className="py-3.5 px-3 text-center">Leituras</th>
                    <th className="py-3.5 px-3 text-center">Denúncias</th>
                    <th className="py-3.5 px-3 text-center">Status & Acesso</th>
                    <th className="py-3.5 px-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800">
                  {sortedUsers.map((u) => {
                    const m = userMetrics[u.id];
                    const stat = getUserActivityStatus(u);
                    const isSilenced = stat.isSilenced;
                    const isBanned = stat.isBanned;
                    const isSelected = selectedUser?.id === u.id;

                    return (
                      <tr
                        key={u.id}
                        className={`transition ${
                          isSelected ? 'bg-[#FF57B2]/10' : 'hover:bg-[#262626]/70'
                        }`}
                      >
                        {/* 1. Nome / Username & ID */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#181818] border border-zinc-700 text-white font-bold text-xs overflow-hidden">
                              {u.photoURL ? (
                                <img src={u.photoURL} alt={u.displayName} className="h-full w-full object-cover" />
                              ) : (
                                u.displayName?.charAt(0) || 'U'
                              )}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-white truncate max-w-[150px]">
                                  {u.displayName || 'Sem nome'}
                                </span>
                                {u.uniqueId && (
                                  <span className="rounded bg-[#181818] border border-zinc-700 text-zinc-300 px-1.5 py-0.2 text-[9px] font-mono font-bold">
                                    {u.uniqueId}
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-zinc-400 font-medium truncate">
                                {u.username || `@usuario_${u.id.slice(0, 5)}`} • {u.email}
                              </p>
                            </div>
                          </div>
                        </td>

                        {/* 2. Tempo na Plataforma */}
                        <td className="py-3.5 px-3 text-center">
                          <div className="flex flex-col items-center">
                            <span className="font-bold text-zinc-200 text-xs tabular-nums">
                              {stat.tenureLabel}
                            </span>
                            <span className="text-[9px] text-zinc-400 tabular-nums">
                              desde {new Date(stat.createdTime).toLocaleDateString('pt-BR')}
                            </span>
                          </div>
                        </td>

                        {/* 3. Curtidas (Cálculo real) */}
                        <td className="py-3.5 px-3 text-center">
                          <span className="inline-flex items-center gap-1 rounded-full bg-[#FF57B2]/15 text-[#FF80C5] px-2 py-0.5 text-xs font-bold border border-[#FF57B2]/35 tabular-nums">
                            <Heart className="h-3 w-3 fill-[#FF57B2] text-[#FF57B2]" />
                            <span>{m ? m.likesReceived : (u.totalLikesReceived || 0)}</span>
                          </span>
                        </td>

                        {/* 4. Não Gostei (Cálculo real) */}
                        <td className="py-3.5 px-3 text-center">
                          <span className="inline-flex items-center gap-1 rounded-full bg-[#181818] text-zinc-300 px-2 py-0.5 text-xs font-bold border border-zinc-700 tabular-nums">
                            <ThumbsDown className="h-3 w-3 text-zinc-400" />
                            <span>{m ? m.dislikesReceived : (u.totalDislikesReceived || 0)}</span>
                          </span>
                        </td>

                        {/* 5. Leituras (Histórico real da biblioteca) */}
                        <td className="py-3.5 px-3 text-center">
                          <span className="inline-flex items-center gap-1 rounded-full bg-[#FF57B2]/10 text-[#FF57B2] px-2 py-0.5 text-xs font-bold border border-[#FF57B2]/30 tabular-nums">
                            <BookOpen className="h-3 w-3 text-[#FF57B2]" />
                            <span>{m ? m.booksRead : (u.booksReadCount || 0)}</span>
                          </span>
                        </td>

                        {/* 6. Denúncias (Contagem real) */}
                        <td className="py-3.5 px-3 text-center">
                          <span
                            className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-bold border tabular-nums ${
                              (m ? m.reportsReceived : 0) > 0
                                ? 'bg-[#FF57B2]/15 text-[#FF80C5] border-[#FF57B2]/40'
                                : 'bg-[#181818] text-zinc-400 border-zinc-800'
                            }`}
                          >
                            <AlertTriangle className="h-3 w-3" />
                            <span>{m ? m.reportsReceived : 0}</span>
                          </span>
                        </td>

                        {/* 7. Status & Acesso (Ativo com tempo na plataforma vs Inativo há X tempo) */}
                        <td className="py-3.5 px-3 text-center">
                          {isBanned ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-[#262626] border border-[#FF57B2]/50 text-[#FF80C5] px-2.5 py-0.5 text-[10px] font-bold">
                              <Ban className="h-3 w-3" />
                              Banido
                            </span>
                          ) : isSilenced ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-[#262626] border border-zinc-600 text-zinc-200 px-2.5 py-0.5 text-[10px] font-bold">
                              <VolumeX className="h-3 w-3" />
                              Silenciado
                            </span>
                          ) : stat.isActive ? (
                            <div className="flex flex-col items-center gap-0.5">
                              <span className="inline-flex items-center gap-1.5 rounded-full bg-[#FF57B2]/15 text-[#FF80C5] px-2.5 py-0.5 text-[10px] font-bold border border-[#FF57B2]/40">
                                <span className="relative flex h-2 w-2">
                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[#FF57B2]"></span>
                                </span>
                                Ativo
                              </span>
                              <span className="text-[9px] text-zinc-400">Acesso recente</span>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center gap-0.5">
                              <span
                                className="inline-flex items-center gap-1 rounded-full bg-[#181818] text-zinc-300 px-2 py-0.5 text-[10px] font-medium border border-zinc-700"
                                title="Mais de 3 dias sem acessar a plataforma"
                              >
                                <Clock className="h-3 w-3 text-zinc-400" />
                                {stat.inactiveDurationLabel || 'Inativo'}
                              </span>
                              <span className="text-[9px] text-zinc-400 font-semibold">&gt; 3 dias sem acesso</span>
                            </div>
                          )}
                        </td>

                        {/* 7. Ações */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5 flex-wrap">
                            {/* Alterar Cargo */}
                            <select
                              value={u.role}
                              onChange={(e) =>
                                handleUpdateUser(
                                  u.id,
                                  { role: e.target.value as UserRole },
                                  `Cargo de ${u.displayName} alterado para ${e.target.value}`
                                )
                              }
                              disabled={savingUser}
                              className="rounded-lg border border-zinc-700 bg-[#181818] py-1 px-1.5 text-[11px] font-bold text-white focus:outline-none focus:border-[#FF57B2] [color-scheme:dark]"
                              title="Alterar Cargo"
                            >
                              <option value="leitor">Leitor</option>
                              <option value="escritor">Escritor</option>
                              <option value="desenvolvedor">Desenvolvedor</option>
                            </select>

                            {/* Silenciar / Des-silenciar */}
                            <button
                              onClick={() =>
                                handleUpdateUser(
                                  u.id,
                                  { isSilenced: !isSilenced },
                                  isSilenced ? `Silenciamento revogado de ${u.displayName}` : `${u.displayName} foi silenciado`
                                )
                              }
                              disabled={savingUser}
                              className={`rounded-lg p-1.5 text-xs font-bold transition ${
                                isSilenced
                                  ? 'bg-[#FF57B2]/20 text-[#FF80C5] border border-[#FF57B2]/40 hover:bg-[#FF57B2]/30'
                                  : 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:border-[#FF57B2]/50 hover:text-white'
                              }`}
                              title={isSilenced ? 'Des-silenciar usuário' : 'Silenciar usuário na plataforma'}
                            >
                              {isSilenced ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
                            </button>

                            {/* Banir / Desbanir */}
                            <button
                              onClick={() =>
                                handleUpdateUser(
                                  u.id,
                                  { isBanned: !isBanned },
                                  isBanned ? `Usuário ${u.displayName} desbanido` : `Usuário ${u.displayName} suspenso/banido`
                                )
                              }
                              disabled={savingUser}
                              className={`rounded-lg p-1.5 text-xs font-bold transition ${
                                isBanned
                                  ? 'bg-[#FF57B2] text-white hover:bg-[#E03595]'
                                  : 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:bg-[#E03595] hover:border-[#E03595] hover:text-white'
                              }`}
                              title={isBanned ? 'Desbanir usuário' : 'Banir usuário'}
                            >
                              <Ban className="h-3.5 w-3.5" />
                            </button>

                            {/* Inspecionar & Ajustar Kards */}
                            <button
                              onClick={() => {
                                setSelectedUser(u);
                                setUserActionFeedback(null);
                              }}
                              className={`rounded-lg px-2 py-1 text-[11px] font-bold transition tabular-nums ${
                                isSelected
                                  ? 'bg-[#FF57B2] text-white'
                                  : 'bg-[#181818] border border-zinc-700 text-white hover:border-[#FF57B2]'
                              }`}
                              title="Gerenciar Selos & Saldo de Kards"
                            >
                              <Coins className="h-3 w-3 inline mr-1 text-[#FF57B2]" />
                              {u.kards || 0}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* User Details & Kard Adjustment Drawer (when selected) */}
          {selectedUser && (
            <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-6 shadow-md space-y-4">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <div>
                  <h3 className="font-bold text-base text-white font-display">
                    Gerenciar Detalhes: {selectedUser.displayName} ({selectedUser.uniqueId})
                  </h3>
                  <p className="text-xs text-zinc-400">
                    {selectedUser.email} • Saldo Atual: <strong className="text-[#FF80C5] tabular-nums">{selectedUser.kards || 0} Kards</strong>
                  </p>
                </div>
                <button
                  onClick={() => setSelectedUser(null)}
                  className="rounded-xl p-1.5 text-zinc-400 hover:bg-[#262626] hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Badges and privileges */}
                <div className="space-y-3">
                  <h4 className="font-bold text-xs uppercase text-zinc-400 tracking-wider">
                    Distintivos & Reconhecimento
                  </h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-2xl bg-[#181818] border border-zinc-800">
                      <div>
                        <span className="font-bold text-xs text-white block">Selo de Leitor Experiente</span>
                        <span className="text-[10px] text-zinc-400">Insígnia especial para leitores fiéis</span>
                      </div>
                      <button
                        onClick={() =>
                          handleUpdateUser(
                            selectedUser.id,
                            { hasExperiencedReaderBadge: !selectedUser.hasExperiencedReaderBadge },
                            selectedUser.hasExperiencedReaderBadge
                              ? 'Selo de Leitor Experiente removido'
                              : 'Selo de Leitor Experiente concedido'
                          )
                        }
                        disabled={savingUser}
                        className={`px-3 py-1 rounded-xl text-xs font-bold transition ${
                          selectedUser.hasExperiencedReaderBadge
                            ? 'bg-[#FF57B2]/20 text-[#FF80C5] border border-[#FF57B2]/50'
                            : 'bg-[#262626] border border-zinc-700 text-zinc-200 hover:border-[#FF57B2]/50 hover:text-white'
                        }`}
                      >
                        {selectedUser.hasExperiencedReaderBadge ? '★ Concedido' : '+ Conceder'}
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-3 rounded-2xl bg-[#181818] border border-zinc-800">
                      <div>
                        <span className="font-bold text-xs text-white block">Selo de Escritor Verificado</span>
                        <span className="text-[10px] text-zinc-400">Selo oficial de autenticidade autoral</span>
                      </div>
                      <button
                        onClick={() =>
                          handleUpdateUser(
                            selectedUser.id,
                            { isVerifiedWriter: !selectedUser.isVerifiedWriter },
                            selectedUser.isVerifiedWriter
                              ? 'Selo de Escritor Verificado revogado'
                              : 'Selo de Escritor Verificado concedido'
                          )
                        }
                        disabled={savingUser}
                        className={`px-3 py-1 rounded-xl text-xs font-bold transition ${
                          selectedUser.isVerifiedWriter
                            ? 'bg-[#FF57B2] text-white'
                            : 'bg-[#262626] border border-zinc-700 text-zinc-200 hover:border-[#FF57B2]/50 hover:text-white'
                        }`}
                      >
                        {selectedUser.isVerifiedWriter ? '✓ Verificado' : '+ Conceder'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Kard Balance Adjustment Form */}
                <form onSubmit={handleAdjustUserKards} className="space-y-3">
                  <h4 className="font-bold text-xs uppercase text-zinc-400 tracking-wider">
                    Ajuste Contábil de Kards
                  </h4>
                  <div className="flex gap-1.5">
                    {[+20, +50, +100, -20, -50].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setKardsAdjustment(preset)}
                        className={`flex-1 rounded-xl py-1.5 text-xs font-bold border transition tabular-nums ${
                          kardsAdjustment === preset
                            ? 'bg-[#FF57B2] text-white border-[#FF57B2]'
                            : 'bg-[#181818] text-zinc-300 border-zinc-700 hover:bg-[#262626] hover:text-white'
                        }`}
                      >
                        {preset > 0 ? `+${preset}` : preset}
                      </button>
                    ))}
                  </div>

                  <input
                    type="number"
                    placeholder="Quantidade de Kards (+100 ou -50)"
                    value={kardsAdjustment || ''}
                    onChange={(e) => setKardsAdjustment(Number(e.target.value))}
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs font-bold text-white placeholder-zinc-500 tabular-nums [color-scheme:dark] focus:border-[#FF57B2] focus:outline-none"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Justificativa oficial (registrada na auditoria)..."
                    value={kardsJustification}
                    onChange={(e) => setKardsJustification(e.target.value)}
                    className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none"
                  />
                  <button
                    type="submit"
                    disabled={savingUser || kardsAdjustment === 0 || !kardsJustification.trim()}
                    className="w-full rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF66C4] hover:to-[#D02685] py-2.5 font-bold text-white disabled:opacity-50 transition shadow-xs text-xs cursor-pointer"
                  >
                    {savingUser ? 'Gravando no Firebase...' : 'Confirmar e Aplicar Ajuste'}
                  </button>
                </form>
              </div>

              {/* Ativação Manual de Assinatura para o Usuário Selecionado */}
              <div className="mt-4 rounded-3xl border border-[#FF57B2]/30 bg-[#181818] p-5 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
                      <Crown className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white font-display">
                        Ativação Manual de Assinatura
                      </h4>
                      <p className="text-[11px] text-zinc-400">
                        Conceda acesso a qualquer plano oficial do KORDEL para {selectedUser.displayName} sem necessidade de pagamento via Pix.
                      </p>
                    </div>
                  </div>

                  {/* Status da Assinatura Atual do Usuário */}
                  <div>
                    {isSubscriptionActive(selectedUser) ? (
                      <div className="flex items-center gap-2">
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40 px-3 py-1 text-xs font-bold">
                          <CheckCircle className="h-3.5 w-3.5" />
                          <span>Ativa: {selectedUser.subscription?.planName || 'KORDEL'}</span>
                        </span>
                        <span className="text-[10px] text-zinc-400 tabular-nums">
                          Até {new Date(selectedUser.subscription!.currentPeriodEnd).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-full bg-[#262626] text-zinc-400 px-3 py-1 text-xs font-medium border border-zinc-700">
                        Sem assinatura ativa
                      </span>
                    )}
                  </div>
                </div>

                {/* Controles de Configuração da Assinatura */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* 1. Escolha do Plano */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-zinc-300 block">Modalidade do Plano:</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setManualSubPlan('leitor')}
                        className={`p-2.5 rounded-2xl border text-xs font-bold transition cursor-pointer text-left ${
                          manualSubPlan === 'leitor'
                            ? 'border-[#FF57B2] bg-[#FF57B2]/15 text-[#FF80C5] shadow-xs'
                            : 'border-zinc-700 bg-[#202020] text-zinc-300 hover:border-zinc-600'
                        }`}
                      >
                        <span className="block font-black">Leitor</span>
                        <span className="text-[10px] text-zinc-400 font-normal">R$ 4,90/mês</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setManualSubPlan('escritor')}
                        className={`p-2.5 rounded-2xl border text-xs font-bold transition cursor-pointer text-left ${
                          manualSubPlan === 'escritor'
                            ? 'border-[#FF57B2] bg-[#FF57B2]/15 text-[#FF80C5] shadow-xs'
                            : 'border-zinc-700 bg-[#202020] text-zinc-300 hover:border-zinc-600'
                        }`}
                      >
                        <span className="block font-black">Escritor</span>
                        <span className="text-[10px] text-zinc-400 font-normal">R$ 13,49/mês</span>
                      </button>
                    </div>
                  </div>

                  {/* 2. Duração da Assinatura */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-zinc-300 block">Duração Concedida:</label>
                    <select
                      value={manualSubDurationDays}
                      onChange={(e) => setManualSubDurationDays(Number(e.target.value))}
                      className="w-full rounded-2xl border border-zinc-700 bg-[#202020] p-2.5 text-xs text-white font-semibold focus:border-[#FF57B2] focus:outline-none [color-scheme:dark]"
                    >
                      <option value={30}>30 Dias (1 Mês)</option>
                      <option value={60}>60 Dias (2 Meses)</option>
                      <option value={90}>90 Dias (3 Meses)</option>
                      <option value={180}>180 Dias (6 Meses)</option>
                      <option value={365}>365 Dias (1 Ano)</option>
                      <option value={3650}>Acesso Vitalício (10 Anos)</option>
                    </select>
                  </div>

                  {/* 3. Justificativa / Observação */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-zinc-300 block">Justificativa / Motivo:</label>
                    <input
                      type="text"
                      placeholder="Ex: Cortesia, Autor Parceiro, Beta..."
                      value={manualSubJustification}
                      onChange={(e) => setManualSubJustification(e.target.value)}
                      className="w-full rounded-2xl border border-zinc-700 bg-[#202020] p-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Botões de Ação */}
                <div className="flex flex-wrap items-center justify-end gap-3 pt-2 border-t border-zinc-800/80">
                  {isSubscriptionActive(selectedUser) && (
                    <button
                      type="button"
                      disabled={savingManualSub}
                      onClick={() => handleManualRevokeSub(selectedUser)}
                      className="rounded-2xl border border-zinc-700 bg-[#262626] px-4 py-2.5 text-xs font-bold text-zinc-200 hover:border-[#FF57B2] hover:text-white transition cursor-pointer"
                    >
                      {savingManualSub ? 'Processando...' : 'Revogar Assinatura Atual'}
                    </button>
                  )}

                  <button
                    type="button"
                    disabled={savingManualSub}
                    onClick={() => handleManualActivateSub(selectedUser)}
                    className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-6 py-2.5 text-xs font-black uppercase tracking-wider text-white shadow-md shadow-[#FF57B2]/30 hover:from-[#FF66C4] hover:to-[#D02685] transition cursor-pointer disabled:opacity-50"
                  >
                    {savingManualSub ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Ativando no Firebase...</span>
                      </>
                    ) : (
                      <>
                        <Crown className="h-4 w-4" />
                        <span>
                          Ativar {SUBSCRIPTION_PLANS[manualSubPlan].name} para {selectedUser.displayName}
                        </span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. DESTAQUES DA SEMANA (UP TO 3 WORKS) */}
      {activeTab === 'featured' && (
        <div className="space-y-6">
          <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-[#FF57B2]">
                  <Sparkles className="h-5 w-5" />
                  <h2 className="text-base font-bold text-white font-display">
                    Destaques da Semana na Home
                  </h2>
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  Selecione até 3 obras para a área nobre de curadoria na página inicial. O sistema respeita estritamente esse limite e nunca exibirá mais de 3.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="rounded-full bg-[#262626] text-white border border-[#FF57B2]/60 px-3 py-1 text-xs font-bold tabular-nums">
                  {featuredBookIds.length} / 3 Selecionadas
                </span>
              </div>
            </div>

            {featuredFeedback && (
              <div
                className={`rounded-2xl p-3 text-xs font-semibold flex items-center justify-between ${
                  featuredFeedback.type === 'success'
                    ? 'bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40'
                    : 'bg-[#262626] text-zinc-200 border border-[#FF57B2]/40'
                }`}
              >
                <span>{featuredFeedback.msg}</span>
                <button
                  onClick={() => setFeaturedFeedback(null)}
                  className="text-zinc-400 hover:text-white font-bold ml-2"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Currently Selected Cards */}
            {featuredBookIds.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                {featuredBookIds.map((bId, idx) => {
                  const b = books.find((bk) => bk.id === bId);
                  return (
                    <div
                      key={bId}
                      className="flex items-center justify-between gap-3 rounded-2xl bg-[#181818] p-3.5 border border-zinc-800"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="h-14 w-10 overflow-hidden rounded-lg bg-[#262626] border border-zinc-700 shrink-0">
                          {b?.coverUrl ? (
                            <img src={b.coverUrl} alt={b.title} className="h-full w-full object-cover" />
                          ) : (
                            <div className="h-full w-full bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white flex items-center justify-center font-bold text-xs">
                              {b?.title?.charAt(0) || 'D'}
                            </div>
                          )}
                        </div>
                        <div className="min-w-0">
                          <span className="text-[10px] font-bold text-[#FF80C5] uppercase">
                            Destaque #{idx + 1}
                          </span>
                          <h4 className="font-bold text-xs text-white truncate font-literary">
                            {b?.title || `Obra ID ${bId.slice(0, 6)}`}
                          </h4>
                          <p className="text-[10px] text-zinc-400 truncate">{b?.authorName}</p>
                        </div>
                      </div>

                      <button
                        onClick={() => b && handleToggleFeaturedBook(b)}
                        disabled={savingFeatured}
                        className="rounded-lg p-1.5 text-zinc-400 hover:text-[#FF57B2] hover:bg-[#262626] transition"
                        title="Remover dos Destaques"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-zinc-700 bg-[#181818] p-6 text-center text-xs text-zinc-400">
                Nenhum destaque manual definido. A Home está exibindo as obras mais populares por padrão. Selecione até 3 obras abaixo!
              </div>
            )}
          </div>

          {/* Book Catalog Selector */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-white font-display">
                  Catálogo de Obras Publicadas
                </h3>
                <p className="text-xs text-zinc-400">
                  Clique no botão para adicionar ou remover obras dos Destaques da Semana da Home.
                </p>
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                <input
                  type="text"
                  value={featuredSearch}
                  onChange={(e) => setFeaturedSearch(e.target.value)}
                  placeholder="Buscar por título ou autor..."
                  className="w-full rounded-2xl border border-zinc-700 bg-[#181818] pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {books
                .filter((b) => b.status === 'published')
                .filter((b) => {
                  const q = featuredSearch.toLowerCase();
                  return (
                    b.title.toLowerCase().includes(q) ||
                    b.authorName.toLowerCase().includes(q) ||
                    (b.genres && b.genres.some((g) => g.toLowerCase().includes(q)))
                  );
                })
                .map((b) => {
                  const isFeatured = featuredBookIds.includes(b.id);
                  return (
                    <div
                      key={b.id}
                      className={`relative flex flex-col justify-between rounded-2xl border p-4 bg-[#202020] shadow-xs transition ${
                        isFeatured
                          ? 'border-[#FF57B2] ring-2 ring-[#FF57B2]/20 bg-[#262626]'
                          : 'border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex gap-3">
                        <div className="h-24 w-16 overflow-hidden rounded-xl bg-[#181818] border border-zinc-700 shrink-0">
                          {b.coverUrl ? (
                            <img src={b.coverUrl} alt={b.title} className="h-full w-full object-cover" />
                          ) : (
                            <div className="h-full w-full bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white flex items-center justify-center font-bold text-sm">
                              {b.title.charAt(0)}
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0 space-y-1">
                          {isFeatured && (
                            <span className="inline-flex items-center gap-1 rounded-md bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40 px-1.5 py-0.5 text-[9px] font-bold uppercase">
                              <Sparkles className="h-2.5 w-2.5" />
                              Destaque Ativo
                            </span>
                          )}
                          <h4 className="font-bold text-sm text-white font-literary truncate">
                            {b.title}
                          </h4>
                          <p className="text-xs text-zinc-400 truncate">Por {b.authorName}</p>
                          <p className="text-[11px] text-zinc-500 tabular-nums">
                            {b.classification} • {b.viewsCount || 0} leituras
                          </p>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-end">
                        <button
                          onClick={() => handleToggleFeaturedBook(b)}
                          disabled={savingFeatured}
                          className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition ${
                            isFeatured
                              ? 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:text-white hover:border-[#FF57B2]'
                              : 'bg-[#FF57B2] text-white hover:bg-[#E03595] shadow-xs'
                          }`}
                        >
                          <Sparkles className="h-3.5 w-3.5" />
                          <span>{isFeatured ? 'Remover dos Destaques' : '+ Adicionar aos Destaques'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      {/* 3. COMUNIDADES RECOMENDADAS PARA A HOME (UP TO 5) */}
      {activeTab === 'featuredCommunities' && (
        <div className="space-y-6">
          <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-[#FF57B2]">
                  <Users className="h-5 w-5" />
                  <h2 className="text-base font-bold text-white font-display">
                    Comunidades Recomendadas na Home
                  </h2>
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  Selecione até 5 comunidades para serem exibidas no carrossel da Home. O carrossel respeitará essa quantidade sem quebrar o layout.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="rounded-full bg-[#262626] text-white border border-[#FF57B2]/60 px-3 py-1 text-xs font-bold tabular-nums">
                  {featuredCommIds.length} / 5 Selecionadas
                </span>
              </div>
            </div>

            {featuredCommsFeedback && (
              <div
                className={`rounded-2xl p-3 text-xs font-semibold flex items-center justify-between ${
                  featuredCommsFeedback.type === 'success'
                    ? 'bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40'
                    : 'bg-[#262626] text-zinc-200 border border-[#FF57B2]/40'
                }`}
              >
                <span>{featuredCommsFeedback.msg}</span>
                <button
                  onClick={() => setFeaturedCommsFeedback(null)}
                  className="text-zinc-400 hover:text-white font-bold ml-2"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Currently Selected Communities */}
            {featuredCommIds.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
                {featuredCommIds.map((cId, idx) => {
                  const c = communities.find((cm) => cm.id === cId);
                  return (
                    <div
                      key={cId}
                      className="flex items-center justify-between gap-3 rounded-2xl bg-[#181818] p-3.5 border border-zinc-800"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white flex items-center justify-center font-bold text-sm shrink-0">
                          {c?.name?.charAt(0).toUpperCase() || 'C'}
                        </div>
                        <div className="min-w-0">
                          <span className="text-[10px] font-bold text-[#FF80C5] uppercase">
                            Recomendação #{idx + 1}
                          </span>
                          <h4 className="font-bold text-xs text-white truncate">
                            {c?.name || `Comunidade ${cId.slice(0, 6)}`}
                          </h4>
                          <p className="text-[10px] text-zinc-400 truncate tabular-nums">
                            {c?.membersCount || 1} membros • {c?.category || 'Geral'}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => c && handleToggleFeaturedCommunity(c)}
                        disabled={savingFeaturedComms}
                        className="rounded-lg p-1.5 text-zinc-400 hover:text-[#FF57B2] hover:bg-[#262626] transition"
                        title="Remover das Recomendações"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-zinc-700 bg-[#181818] p-6 text-center text-xs text-zinc-400">
                Nenhuma comunidade foi fixada manualmente. A Home exibirá as 5 com maior número de membros por padrão.
              </div>
            )}
          </div>

          {/* Communities Catalog */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-white font-display">
                  Todas as Comunidades Cadastradas ({communities.length})
                </h3>
                <p className="text-xs text-zinc-400">
                  Clique para adicionar ou remover comunidades do carrossel da Home.
                </p>
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                <input
                  type="text"
                  value={commSearch}
                  onChange={(e) => setCommSearch(e.target.value)}
                  placeholder="Buscar comunidade por nome..."
                  className="w-full rounded-2xl border border-zinc-700 bg-[#181818] pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {communities
                .filter((c) => {
                  const q = commSearch.toLowerCase();
                  return (
                    c.name.toLowerCase().includes(q) ||
                    (c.description && c.description.toLowerCase().includes(q)) ||
                    (c.category && c.category.toLowerCase().includes(q))
                  );
                })
                .map((c) => {
                  const isFeatured = featuredCommIds.includes(c.id);
                  return (
                    <div
                      key={c.id}
                      className={`relative flex flex-col justify-between rounded-2xl border bg-[#202020] shadow-xs overflow-hidden transition ${
                        isFeatured
                          ? 'border-[#FF57B2] ring-2 ring-[#FF57B2]/20'
                          : 'border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {/* Optional cover thumbnail */}
                      {c.coverUrl && (
                        <div className="h-20 w-full overflow-hidden bg-[#181818] border-b border-zinc-800 relative">
                          <img
                            src={c.coverUrl}
                            alt=""
                            className="h-full w-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                        </div>
                      )}

                      <div className="p-4 flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs">
                                {c.name.charAt(0).toUpperCase()}
                              </div>
                              <div className="min-w-0">
                                <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider block">
                                  {c.category || 'Geral'}
                                </span>
                                <h4 className="font-bold text-xs text-white truncate max-w-[180px]" title={c.name}>
                                  {c.name}
                                </h4>
                              </div>
                            </div>

                            {isFeatured && (
                              <span className="shrink-0 rounded-full bg-[#FF57B2]/15 border border-[#FF57B2]/40 text-[#FF80C5] px-2 py-0.5 text-[9px] font-bold">
                                Home
                              </span>
                            )}
                          </div>

                          <p className="text-[11px] text-zinc-300 line-clamp-2 mt-2.5 font-literary leading-relaxed">
                            {c.description || 'Roda literária aberta para debate de versos e contos.'}
                          </p>

                          {c.creatorName && (
                            <p className="text-[10px] text-zinc-400 mt-2 truncate">
                              Criador: <span className="text-zinc-200 font-semibold">{c.creatorName}</span>
                            </p>
                          )}
                        </div>

                        <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between gap-2 text-xs">
                          <span className="font-semibold text-zinc-400 text-[11px] truncate tabular-nums">
                            {c.membersCount || 1} membros • {c.postsCount || 0} posts
                          </span>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              onClick={() => handleToggleFeaturedCommunity(c)}
                              disabled={savingFeaturedComms}
                              className={`inline-flex items-center gap-1 rounded-xl px-2.5 py-1.5 text-xs font-bold transition cursor-pointer ${
                                isFeatured
                                  ? 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:text-white'
                                  : 'bg-[#FF57B2] text-white hover:bg-[#E03595] shadow-2xs'
                              }`}
                              title={isFeatured ? 'Remover das Recomendações' : 'Recomendar no Carrossel da Home'}
                            >
                              <Users className="h-3 w-3" />
                              <span>{isFeatured ? 'Remover Home' : '+ Home'}</span>
                            </button>

                            <button
                              onClick={() => setCommunityToDelete(c)}
                              className="inline-flex items-center gap-1 rounded-xl px-2.5 py-1.5 text-xs font-bold text-zinc-300 bg-[#181818] hover:bg-[#E03595] hover:text-white border border-zinc-700 hover:border-[#E03595] transition cursor-pointer"
                              title="Excluir Comunidade Definitivamente"
                            >
                              <Trash2 className="h-3 w-3" />
                              <span>Excluir</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      {/* 4. PIX PAYMENTS & MANUAL APPROVAL */}
      {activeTab === 'pix' && (
        <div className="space-y-6">
          <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-bold text-white font-display flex items-center gap-2">
                  <Coins className="h-5 w-5 text-[#FF57B2]" />
                  <span>Gestão & Liberação de Pagamentos Pix</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Audite os comprovantes enviados pelos usuários. O crédito de Kards só é liberado mediante confirmação do Desenvolvedor.
                </p>
              </div>

              {/* Status Filter */}
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: 'all', label: 'Todos' },
                  { id: 'under_review', label: 'Em Análise' },
                  { id: 'pending', label: 'Pendentes' },
                  { id: 'paid', label: 'Pagos' },
                  { id: 'rejected', label: 'Recusados' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setPixFilter(f.id as any)}
                    className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                      pixFilter === f.id
                        ? 'bg-[#FF57B2] text-white'
                        : 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:text-white hover:border-zinc-600'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {pixFeedback && (
              <div
                className={`rounded-2xl p-3 text-xs font-semibold flex items-center justify-between ${
                  pixFeedback.type === 'success'
                    ? 'bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40'
                    : 'bg-[#262626] text-zinc-200 border border-[#FF57B2]/40'
                }`}
              >
                <span>{pixFeedback.msg}</span>
                <button
                  onClick={() => setPixFeedback(null)}
                  className="text-zinc-400 hover:text-white font-bold ml-2"
                >
                  ✕
                </button>
              </div>
            )}
          </div>

          {/* Orders Table */}
          <div className="overflow-hidden rounded-3xl border border-zinc-800 bg-[#202020] shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#181818] border-b border-zinc-800 text-zinc-400 uppercase text-[10px] tracking-wider font-bold">
                    <th className="py-3.5 px-4">Pedido / ID</th>
                    <th className="py-3.5 px-4">Usuário</th>
                    <th className="py-3.5 px-3 text-center">Valor / Kards</th>
                    <th className="py-3.5 px-3">Comprovante</th>
                    <th className="py-3.5 px-3 text-center">Data</th>
                    <th className="py-3.5 px-3 text-center">Status</th>
                    <th className="py-3.5 px-4 text-right">Ação do Desenvolvedor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800">
                  {filteredPixOrders.map((order) => {
                    const isProcessing = processingPixId === order.id;

                    return (
                      <tr key={order.id} className="hover:bg-[#262626]/70 transition">
                        <td className="py-3.5 px-4">
                          <span className="font-mono font-bold text-white block text-[11px]">
                            {order.id.slice(0, 10)}...
                          </span>
                          <span className="text-[10px] text-zinc-400">
                            Tx: {order.txId.slice(0, 8)}
                          </span>
                        </td>

                        <td className="py-3.5 px-4">
                          <span className="font-bold text-white block truncate max-w-[160px]">
                            {order.userEmail || order.userId}
                          </span>
                          <span className="text-[10px] text-zinc-400">UID: {order.userId.slice(0, 8)}</span>
                        </td>

                        <td className="py-3.5 px-3 text-center">
                          <span className="font-bold text-white block text-xs tabular-nums">
                            R$ {order.amountBrl.toFixed(2)}
                          </span>
                          <span className="rounded-full bg-[#FF57B2]/15 text-[#FF80C5] px-2 py-0.2 text-[10px] font-bold border border-[#FF57B2]/35 tabular-nums">
                            +{order.kards} Kards
                          </span>
                        </td>

                        <td className="py-3.5 px-3">
                          {order.receiptCode ? (
                            <span className="font-mono bg-[#181818] border border-zinc-700 text-zinc-200 px-2 py-1 rounded text-[11px] font-semibold">
                              {order.receiptCode}
                            </span>
                          ) : (
                            <span className="text-zinc-500 text-[11px] italic">Não enviado</span>
                          )}
                        </td>

                        <td className="py-3.5 px-3 text-center text-zinc-400 text-[11px] tabular-nums">
                          {new Date(order.createdAt).toLocaleDateString('pt-BR')}
                        </td>

                        <td className="py-3.5 px-3 text-center">
                          {order.status === 'paid' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40 px-2.5 py-0.5 text-[10px] font-bold">
                              <CheckCircle className="h-3 w-3" />
                              Pago & Creditado
                            </span>
                          ) : order.status === 'under_review' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-[#262626] border border-[#FF57B2]/50 text-white px-2.5 py-0.5 text-[10px] font-bold animate-pulse">
                              <AlertTriangle className="h-3 w-3 text-[#FF57B2]" />
                              Comprovante em Análise
                            </span>
                          ) : order.status === 'rejected' ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-[#181818] border border-zinc-700 text-zinc-400 px-2.5 py-0.5 text-[10px] font-bold">
                              <X className="h-3 w-3" />
                              Recusado
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded-full bg-[#181818] border border-zinc-700 text-zinc-300 px-2.5 py-0.5 text-[10px] font-bold">
                              Pendente
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          {order.status === 'paid' ? (
                            <span className="text-[11px] text-zinc-400 font-semibold tabular-nums">
                              Finalizado em {order.verifiedAt ? new Date(order.verifiedAt).toLocaleDateString('pt-BR') : 'auto'}
                            </span>
                          ) : (
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => setPixToApprove(order)}
                                disabled={isProcessing}
                                className="rounded-xl bg-[#FF57B2] px-3 py-1.5 text-xs font-bold text-white hover:bg-[#E03595] disabled:opacity-50 transition shadow-2xs"
                              >
                                {isProcessing ? 'Gravando...' : 'Aprovar e Liberar Kards'}
                              </button>
                              <button
                                onClick={() => handleRejectPix(order)}
                                disabled={isProcessing}
                                className="rounded-xl bg-[#181818] border border-zinc-700 px-2.5 py-1.5 text-xs font-bold text-zinc-300 hover:border-[#FF57B2] hover:text-white disabled:opacity-50 transition"
                              >
                                Recusar
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {filteredPixOrders.length === 0 && (
              <div className="p-8 text-center text-xs text-zinc-400">
                Nenhum pedido Pix encontrado para o filtro selecionado.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 5. REPORTS */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <button
                onClick={() => setReportFilter('pending')}
                className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                  reportFilter === 'pending'
                    ? 'bg-[#FF57B2] text-white'
                    : 'bg-[#202020] border border-zinc-800 text-zinc-300 hover:text-white'
                }`}
              >
                Pendentes ({reports.filter((r) => r.status === 'pending').length})
              </button>
              <button
                onClick={() => setReportFilter('resolved')}
                className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                  reportFilter === 'resolved'
                    ? 'bg-[#FF57B2] text-white'
                    : 'bg-[#202020] border border-zinc-800 text-zinc-300 hover:text-white'
                }`}
              >
                Resolvidas ({reports.filter((r) => r.status === 'resolved').length})
              </button>
              <button
                onClick={() => setReportFilter('all')}
                className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition ${
                  reportFilter === 'all'
                    ? 'bg-[#FF57B2] text-white'
                    : 'bg-[#202020] border border-zinc-800 text-zinc-300 hover:text-white'
                }`}
              >
                Todas ({reports.length})
              </button>
            </div>
          </div>

          <div className="overflow-hidden rounded-3xl bg-[#202020] shadow-xs border border-zinc-800 divide-y divide-zinc-800">
            {filteredReports.map((r) => (
              <div key={r.id} className="p-4 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#FF80C5] uppercase tracking-wider text-[10px]">
                    Motivo: {r.reason}
                  </span>
                  <span className="text-[11px] text-zinc-400 tabular-nums">
                    {new Date(r.createdAt).toLocaleString('pt-BR')}
                  </span>
                </div>
                <p className="text-zinc-200 font-medium">{r.details || 'Sem detalhes fornecidos.'}</p>
                <div className="flex items-center justify-between pt-2 border-t border-zinc-800 text-[11px] text-zinc-400">
                  <span>Alvo: {r.targetType} (ID: {r.targetId})</span>
                  {r.status === 'pending' ? (
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleResolveReport(r, 'resolved', 'Denúncia acolhida e usuário advertido')}
                        className="rounded-lg bg-[#FF57B2] text-white px-2.5 py-1 font-bold hover:bg-[#E03595] transition"
                      >
                        Acolher & Penalizar
                      </button>
                      <button
                        onClick={() => handleResolveReport(r, 'dismissed', 'Denúncia improcedente')}
                        className="rounded-lg bg-[#181818] border border-zinc-700 text-zinc-300 px-2.5 py-1 font-bold hover:text-white transition"
                      >
                        Descartar
                      </button>
                    </div>
                  ) : (
                    <span className="font-bold text-[#FF80C5]">Resolvida</span>
                  )}
                </div>
              </div>
            ))}

            {filteredReports.length === 0 && (
              <div className="p-8 text-center text-xs text-zinc-400">
                Nenhuma denúncia nesta categoria.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 6. CONTENT MANAGEMENT */}
      {activeTab === 'content' && (
        <div className="space-y-4">
          {contentFeedback && (
            <div
              className={`rounded-2xl p-3 text-xs font-semibold flex items-center justify-between ${
                contentFeedback.type === 'success'
                  ? 'bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40'
                  : 'bg-[#262626] text-zinc-200 border border-[#FF57B2]/40'
              }`}
            >
              <span>{contentFeedback.msg}</span>
              <button
                onClick={() => setContentFeedback(null)}
                className="text-zinc-400 hover:text-white font-bold ml-2"
              >
                ✕
              </button>
            </div>
          )}

          <div className="overflow-hidden rounded-3xl bg-[#202020] shadow-xs border border-zinc-800 divide-y divide-zinc-800">
            {books.map((b) => (
              <div key={b.id} className="flex items-center justify-between p-4 text-xs hover:bg-[#262626]/60 transition">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-8 overflow-hidden rounded bg-[#181818] border border-zinc-700 shrink-0">
                    {b.coverUrl ? (
                      <img src={b.coverUrl} alt={b.title} className="h-full w-full object-cover" />
                    ) : (
                      <div className="h-full w-full bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white flex items-center justify-center font-bold">
                        {b.title.charAt(0)}
                      </div>
                    )}
                  </div>
                  <div>
                    <h4 className="font-bold text-white font-literary">{b.title}</h4>
                    <p className="text-[11px] text-zinc-400 tabular-nums">
                      Autor: {b.authorName} • {b.classification} • {b.viewsCount || 0} visualizações
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setBookToDeleteAdmin(b)}
                    className="rounded-xl p-2 text-zinc-400 hover:text-[#FF57B2] hover:bg-[#181818] cursor-pointer transition"
                    title="Excluir Conteúdo Definitivamente"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. AUDIT (KARDS & PAID SUBSCRIPTIONS) */}
      {activeTab === 'audit' && (
        <div className="space-y-5">
          {/* Executive Totals Strip */}
          <div className="rounded-3xl border border-zinc-800 bg-[#202020] p-5 shadow-xs space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-bold text-white font-display flex items-center gap-2">
                  <FileText className="h-5 w-5 text-[#FF57B2]" />
                  <span>Auditoria Financeira & Contábil</span>
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Registro em tempo real de assinaturas pagas (Pix/comprovantes) e movimentações contábeis de Kards.
                </p>
              </div>

              {/* Quick Search */}
              <div className="relative w-full md:w-72">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                <input
                  type="text"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  placeholder="Buscar por comprovante, ID ou usuário..."
                  className="w-full rounded-xl border border-zinc-700 bg-[#181818] pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none"
                />
              </div>
            </div>

            {/* Metrics KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-zinc-800">
              <div className="rounded-2xl bg-[#FF57B2]/10 border border-[#FF57B2]/35 p-3.5">
                <span className="text-[10px] uppercase font-bold text-[#FF80C5] block">Receita de Assinaturas</span>
                <span className="text-xl font-black text-white font-display tabular-nums">
                  R${' '}
                  {paidSubscriptions
                    .reduce(
                      (acc, s) =>
                        acc +
                        (typeof s.amount === 'number'
                          ? s.amount
                          : s.planId === 'escritor'
                          ? 13.49
                          : 4.90),
                      0
                    )
                    .toFixed(2)}
                </span>
                <span className="text-[10px] text-zinc-300 block mt-0.5 tabular-nums">
                  {paidSubscriptions.length} assinaturas confirmadas e pagas
                </span>
              </div>

              <div className="rounded-2xl bg-[#181818] border border-zinc-800 p-3.5">
                <span className="text-[10px] uppercase font-bold text-[#FF57B2] block">Assinaturas Registradas</span>
                <span className="text-xl font-black text-white font-display tabular-nums">{paidSubscriptions.length}</span>
                <span className="text-[10px] text-zinc-400 block mt-0.5 tabular-nums">
                  {paidSubscriptions.filter((s) => s.planId === 'escritor').length} Escritor •{' '}
                  {paidSubscriptions.filter((s) => s.planId === 'leitor').length} Leitor
                </span>
              </div>

              <div className="rounded-2xl bg-[#181818] border border-zinc-800 p-3.5">
                <span className="text-[10px] uppercase font-bold text-zinc-400 block">Movimentações de Kards</span>
                <span className="text-xl font-black text-white font-display tabular-nums">{transactions.length}</span>
                <span className="text-[10px] text-zinc-400 block mt-0.5">Transações computadas no livro</span>
              </div>
            </div>

            {/* Filter Tabs */}
            <div className="flex gap-2 pt-1 border-t border-zinc-800 overflow-x-auto no-scrollbar">
              <button
                type="button"
                onClick={() => setAuditFilter('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  auditFilter === 'all'
                    ? 'bg-[#FF57B2] text-white'
                    : 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:text-white'
                }`}
              >
                Todas as Entradas ({paidSubscriptions.length + transactions.length})
              </button>
              <button
                type="button"
                onClick={() => setAuditFilter('subscriptions')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                  auditFilter === 'subscriptions'
                    ? 'bg-[#FF57B2] text-white shadow-xs'
                    : 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:text-white'
                }`}
              >
                <CheckCircle className="h-3.5 w-3.5" />
                <span>Assinaturas Pagas ({paidSubscriptions.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setAuditFilter('kards')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                  auditFilter === 'kards'
                    ? 'bg-[#FF57B2] text-white shadow-xs'
                    : 'bg-[#181818] border border-zinc-700 text-zinc-300 hover:text-white'
                }`}
              >
                <Coins className="h-3.5 w-3.5" />
                <span>Movimentações de Kards ({transactions.length})</span>
              </button>
            </div>
          </div>

          {/* Unified Ledger Feed */}
          <div className="overflow-hidden rounded-3xl bg-[#202020] shadow-xs border border-zinc-800 divide-y divide-zinc-800 text-xs">
            {/* 1. SEÇÃO DE ASSINATURAS PAGAS */}
            {(auditFilter === 'all' || auditFilter === 'subscriptions') &&
              paidSubscriptions
                .filter((sub) => {
                  if (!auditSearch.trim()) return true;
                  const term = auditSearch.toLowerCase();
                  return (
                    (sub.receiptCode || '').toLowerCase().includes(term) ||
                    (sub.userEmail || '').toLowerCase().includes(term) ||
                    (sub.userId || '').toLowerCase().includes(term) ||
                    (sub.bankName || '').toLowerCase().includes(term) ||
                    (sub.planId || '').toLowerCase().includes(term)
                  );
                })
                .map((sub, idx) => {
                  const isEscritor = sub.planId === 'escritor';
                  const planPrice =
                    typeof sub.amount === 'number'
                      ? sub.amount
                      : isEscritor
                      ? 13.49
                      : 4.90;

                  return (
                    <div
                      key={`sub_${sub.receiptCode}_${idx}`}
                      className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#262626]/60 transition"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                              isEscritor
                                ? 'bg-[#FF57B2]/15 text-[#FF80C5] border-[#FF57B2]/40'
                                : 'bg-[#181818] text-zinc-200 border-zinc-700'
                            }`}
                          >
                            <Crown className="h-3 w-3 text-[#FF57B2]" />
                            <span>{isEscritor ? 'Assinatura Escritor' : 'Assinatura Leitor'}</span>
                          </span>

                          <span className="inline-flex items-center gap-1 rounded-full bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/35 px-2 py-0.2 text-[9px] font-bold">
                            <CheckCircle className="h-3 w-3" />
                            <span>Paga & Ativa</span>
                          </span>

                          <span className="text-[11px] text-zinc-400 tabular-nums">
                            {sub.usedAt
                              ? new Date(sub.usedAt).toLocaleString('pt-BR')
                              : 'Data não informada'}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 flex-wrap pt-0.5">
                          <span className="font-bold text-white text-xs">
                            Comprovante:{' '}
                            <span className="font-mono text-zinc-300 select-all font-semibold">
                              {sub.receiptCode}
                            </span>
                          </span>
                          {sub.bankName && (
                            <span className="text-[11px] text-zinc-400">
                              • Instituição: <strong className="text-zinc-200">{sub.bankName}</strong>
                            </span>
                          )}
                          {sub.type && (
                            <span className="text-[10px] text-zinc-400 uppercase font-mono">
                              ({sub.type})
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-zinc-400">
                          Usuário Beneficiado: <strong className="text-zinc-200">{sub.userEmail || sub.userId}</strong>
                          {sub.activatedBy && (
                            <span className="text-zinc-400"> • Liberado por: {sub.activatedBy}</span>
                          )}
                          {sub.justification && (
                            <span className="text-zinc-400 italic"> • Obs: {sub.justification}</span>
                          )}
                        </p>
                      </div>

                      <div className="text-left sm:text-right shrink-0">
                        <span className="font-black text-sm text-[#FF80C5] font-display block tabular-nums">
                          + R$ {planPrice.toFixed(2)}
                        </span>
                        <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider">
                          Pix Bacen
                        </span>
                      </div>
                    </div>
                  );
                })}

            {/* 2. SEÇÃO DE TRANSAÇÕES DE KARDS */}
            {(auditFilter === 'all' || auditFilter === 'kards') &&
              transactions
                .filter((t) => {
                  if (!auditSearch.trim()) return true;
                  const term = auditSearch.toLowerCase();
                  return (
                    (t.description || '').toLowerCase().includes(term) ||
                    (t.id || '').toLowerCase().includes(term) ||
                    (t.userId || '').toLowerCase().includes(term)
                  );
                })
                .map((t) => (
                  <div
                    key={t.id}
                    className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#262626]/60 transition"
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="inline-flex items-center gap-1 rounded-full bg-[#181818] text-zinc-300 border border-zinc-700 px-2.5 py-0.5 text-[10px] font-bold">
                          <Coins className="h-3 w-3 text-[#FF57B2]" />
                          <span>Movimentação Kard</span>
                        </span>
                        <span className="text-[11px] text-zinc-400 tabular-nums">
                          {t.createdAt
                            ? new Date(t.createdAt).toLocaleString('pt-BR')
                            : 'Data recente'}
                        </span>
                      </div>

                      <p className="font-bold text-white text-xs">{t.description}</p>
                      <p className="text-[10px] text-zinc-400">
                        ID: <span className="font-mono">{t.id}</span> • Usuário: <span className="font-mono">{t.userId}</span>
                        {t.paymentMethod && <span> • Método: {t.paymentMethod}</span>}
                      </p>
                    </div>

                    <div className="text-left sm:text-right shrink-0">
                      <span
                        className={`font-black text-sm font-display block tabular-nums ${
                          t.amount > 0 ? 'text-[#FF80C5]' : 'text-zinc-300'
                        }`}
                      >
                        {t.amount > 0 ? `+${t.amount}` : t.amount} Kards
                      </span>
                      <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider">
                        Saldo Kard
                      </span>
                    </div>
                  </div>
                ))}

            {paidSubscriptions.length === 0 && transactions.length === 0 && (
              <div className="p-12 text-center text-xs text-zinc-400">
                Nenhum registro contábil ou assinatura encontrada.
              </div>
            )}
          </div>
        </div>
      )}
      {/* Confirmation Modals for Developer / Admin actions */}
      <ConfirmModal
        isOpen={Boolean(pixToApprove)}
        onClose={() => setPixToApprove(null)}
        onConfirm={() => {
          if (pixToApprove) handleApprovePix(pixToApprove);
        }}
        title="Aprovar Pedido Pix"
        message={`Confirma a aprovação manual do Pix de R$ ${pixToApprove?.amountBrl.toFixed(2)} para liberar ${pixToApprove?.kards} Kards ao usuário ${pixToApprove?.userEmail || pixToApprove?.userId}?`}
        confirmText="Aprovar e Creditar"
        cancelText="Cancelar"
        variant="info"
        isLoading={Boolean(processingPixId)}
      />

      <ConfirmModal
        isOpen={Boolean(bookToDeleteAdmin)}
        onClose={() => {
          if (!isDeletingBookAdmin) setBookToDeleteAdmin(null);
        }}
        onConfirm={handleConfirmDeleteBookAdmin}
        title={`Excluir "${bookToDeleteAdmin?.title}" (Admin)?`}
        message="Tem certeza que deseja excluir permanentemente esta obra e todos os seus capítulos? Esta ação não pode ser desfeita."
        confirmText="Excluir Obra"
        cancelText="Cancelar"
        variant="danger"
        isLoading={isDeletingBookAdmin}
      />

      <ConfirmModal
        isOpen={Boolean(communityToDelete)}
        onClose={() => {
          if (!isDeletingCommunity) setCommunityToDelete(null);
        }}
        onConfirm={handleConfirmDeleteCommunity}
        title={`Excluir Comunidade "${communityToDelete?.name}"?`}
        message={`Atenção: Você está prestes a excluir permanentemente a comunidade "${communityToDelete?.name}". Todas as postagens, comentários, reações e a lista de membros vinculados serão removidos do KORDEL. Esta ação é irreversível.`}
        confirmText="Excluir Comunidade"
        cancelText="Cancelar"
        variant="danger"
        isLoading={isDeletingCommunity}
      />
    </div>
  );
};
