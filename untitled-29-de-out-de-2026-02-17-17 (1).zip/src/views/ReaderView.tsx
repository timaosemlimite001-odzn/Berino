import {
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  setDoc,
  updateDoc
} from 'firebase/firestore';
import {
  ArrowLeft,
  BookOpen,
  Check,
  CheckCircle,
  ChevronLeft,
  ChevronRight,
  CornerDownRight,
  Crown,
  Edit2,
  Heart,
  List,
  Loader2,
  Lock,
  MessageSquare,
  Send,
  Settings,
  Trash2,
  Type,
  X,
  Zap
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { ConfirmModal } from '../components/ConfirmModal';
import { ReportModal } from '../components/ReportModal';
import { UserAvatar } from '../components/UserAvatar';
import { UserBadges } from '../components/UserBadges';
import { UserDisplayName } from '../components/UserDisplayName';
import { useAuth } from '../context/AuthContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db, sanitizeFirestoreData } from '../services/firebase';
import { awardXp, checkAndUnlockAchievement, sendNotification } from '../services/progressionService';
import { isSubscriptionActive } from '../services/subscriptionService';
import { Book, Chapter, ChapterComment } from '../types';

interface ReaderViewProps {
  bookId: string;
  initialChapterNumber?: number;
  onBack?: () => void;
  onBackToBook?: () => void;
  onOpenAuth: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  bookId,
  initialChapterNumber = 1,
  onBack,
  onBackToBook,
  onOpenAuth,
  onNavigateTab,
}) => {
  const handleBack = onBackToBook || onBack || (() => {});
  const { currentUser, userProfile, isDeveloper } = useAuth();
  const { openUserProfile } = usePublicProfile();
  const [book, setBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isApprovedBetaReader, setIsApprovedBetaReader] = useState(false);

  // Reading preferences (Sempre tema escuro com rosa)
  const [fontSize, setFontSize] = useState<number>(18);
  const [fontFamily, setFontFamily] = useState<'font-literary' | 'font-sans' | 'font-serif'>('font-literary');
  const [showSettings, setShowSettings] = useState(false);
  const [showChapterList, setShowChapterList] = useState(false);

  // Chapter comments (Embedded directly at the end of the chapter)
  const [comments, setComments] = useState<ChapterComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editCommentText, setEditCommentText] = useState('');
  const [savingCommentEdit, setSavingCommentEdit] = useState(false);
  const [replyTarget, setReplyTarget] = useState<{
    id: string;
    authorName: string;
    authorId?: string;
  } | null>(null);
  const [commentToDelete, setCommentToDelete] = useState<ChapterComment | null>(null);
  const [isDeletingComment, setIsDeletingComment] = useState(false);
  const commentInputRef = useRef<HTMLInputElement>(null);

  // Report modal
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState<{ id: string; summary: string }>({
    id: '',
    summary: '',
  });

  // Track progress
  const contentRef = useRef<HTMLDivElement>(null);
  const [hasAwardedChapterXp, setHasAwardedChapterXp] = useState(false);

  // 1. Fetch book and all chapters
  useEffect(() => {
    const loadBookData = async () => {
      setLoading(true);
      try {
        const bSnap = await getDoc(doc(db, 'books', bookId));
        if (bSnap.exists()) {
          const bData = bSnap.data() as Book;
          setBook(bData);

          try {
            const activeSession = {
              bookId,
              bookTitle: bData.title,
              bookCover: bData.coverUrl || '',
              authorName: bData.authorName,
              currentChapterNumber: initialChapterNumber || 1,
              progressPercent: 5,
              openedAt: Date.now(),
              lastReadAt: new Date().toISOString(),
            };
            localStorage.setItem('kordel_last_opened_reading', JSON.stringify(activeSession));
          } catch {}

          // Increment view count in transaction
          try {
            await updateDoc(doc(db, 'books', bookId), {
              viewsCount: (bSnap.data().viewsCount || 0) + 1,
            });
          } catch (e) {
            console.error('Error updating views count:', e);
          }
        }

        const chQuery = query(
          collection(db, 'books', bookId, 'chapters'),
          orderBy('chapterNumber', 'asc')
        );
        const chSnap = await getDocs(chQuery);
        const list: Chapter[] = [];
        chSnap.forEach((d) => list.push(d.data() as Chapter));
        setChapters(list);

        // Find initial index
        const idx = list.findIndex((c) => c.chapterNumber === initialChapterNumber);
        setCurrentChapterIndex(idx >= 0 ? idx : 0);
      } catch (err) {
        console.error('Error loading reader:', err);
      } finally {
        setLoading(false);
      }
    };

    loadBookData();
  }, [bookId, initialChapterNumber]);

  const activeChapter = chapters[currentChapterIndex] || null;

  useEffect(() => {
    if (!currentUser || !book?.isBeta) {
      setIsApprovedBetaReader(false);
      return;
    }
    getDoc(doc(db, 'betaApplications', `beta_${bookId}_${currentUser.uid}`))
      .then((snap) => {
        if (snap.exists() && snap.data()?.status === 'approved') {
          setIsApprovedBetaReader(true);
        }
      })
      .catch(() => {});
  }, [bookId, currentUser?.uid, book?.isBeta]);

  // Subscription gating for early access chapters & beta works
  const isLeitorActive = Boolean(
    isSubscriptionActive(userProfile, 'leitor') ||
      userProfile?.hasExperiencedReaderBadge ||
      isApprovedBetaReader ||
      isDeveloper
  );
  const isAuthor = Boolean(currentUser && book && currentUser.uid === book.authorId);
  const isEarlyAccessBlocked = Boolean(activeChapter?.isEarlyAccess && !isLeitorActive && !isAuthor);
  const isBetaBlocked = Boolean(book?.isBeta && !isLeitorActive && !isAuthor);
  const isAccessBlocked = isEarlyAccessBlocked || isBetaBlocked;

  // 2. Fetch comments for active chapter
  useEffect(() => {
    if (!activeChapter) return;

    const commQuery = query(
      collection(db, 'books', bookId, 'chapters', activeChapter.id, 'comments'),
      orderBy('createdAt', 'desc')
    );
    const unsubscribe = onSnapshot(commQuery, (snap) => {
      const cList: ChapterComment[] = [];
      snap.forEach((d) => cList.push(d.data() as ChapterComment));
      setComments(cList);
    });

    // Reset XP state for new chapter
    setHasAwardedChapterXp(false);

    return () => unsubscribe();
  }, [bookId, activeChapter]);

  // 3. Save progress automatically & award chapter reading XP on completion
  useEffect(() => {
    if (!currentUser || !book || !activeChapter) return;

    const saveProgress = async () => {
      try {
        const totalChaps = Math.max(chapters.length, 1);
        const pct = Math.round(((currentChapterIndex + 1) / totalChaps) * 100);

        const progressData = {
          userId: currentUser.uid,
          bookId,
          bookTitle: book.title,
          bookCover: book.coverUrl || '',
          authorName: book.authorName,
          status: pct >= 100 ? ('completed' as const) : ('reading' as const),
          currentChapterId: activeChapter.id,
          currentChapterNumber: activeChapter.chapterNumber,
          progressPercent: pct,
          lastReadAt: new Date().toISOString(),
        };

        const libDocRef = doc(db, 'libraries', currentUser.uid, 'items', bookId);
        await setDoc(libDocRef, sanitizeFirestoreData(progressData), { merge: true });

        // Save local backup and remove any dismiss flag for active reading
        try {
          const sessionPayload = {
            ...progressData,
            openedAt: Date.now(),
          };
          localStorage.setItem('kordel_last_opened_reading', JSON.stringify(sessionPayload));
          localStorage.setItem(`kordel_last_reading_${currentUser.uid}`, JSON.stringify(progressData));
          localStorage.removeItem(`kordel_dismissed_reading_${currentUser.uid}`);
          localStorage.removeItem(`kordel_dismissed_reading_info_${currentUser.uid}`);
        } catch {}
      } catch (err) {
        console.error('Error saving reading progress:', err);
      }
    };

    saveProgress();
  }, [currentUser, book, activeChapter, currentChapterIndex, chapters.length]);

  // Guest reading backup
  useEffect(() => {
    if (currentUser || !book || !activeChapter) return;
    try {
      const totalChaps = Math.max(chapters.length, 1);
      const pct = Math.round(((currentChapterIndex + 1) / totalChaps) * 100);
      const guestData = {
        userId: 'guest',
        bookId,
        bookTitle: book.title,
        bookCover: book.coverUrl || '',
        authorName: book.authorName,
        status: pct >= 100 ? ('completed' as const) : ('reading' as const),
        currentChapterId: activeChapter.id,
        currentChapterNumber: activeChapter.chapterNumber,
        progressPercent: pct,
        lastReadAt: new Date().toISOString(),
      };
      localStorage.setItem('kordel_guest_reading', JSON.stringify(guestData));
      localStorage.removeItem('kordel_dismissed_reading_guest');
      localStorage.removeItem('kordel_dismissed_reading_info_guest');
    } catch {}
  }, [currentUser, book, activeChapter, currentChapterIndex, chapters.length]);

  // Scroll handler to award XP when reaching end of chapter
  const handleScroll = () => {
    if (
      !contentRef.current ||
      hasAwardedChapterXp ||
      !currentUser ||
      !activeChapter ||
      !book ||
      isAccessBlocked
    )
      return;

    const { scrollTop, scrollHeight, clientHeight } = contentRef.current;
    if (scrollTop + clientHeight >= scrollHeight - 60) {
      setHasAwardedChapterXp(true);
      // Award XP
      const sourceKey = `read_${bookId}_chap_${activeChapter.chapterNumber}`;
      awardXp(
        currentUser.uid,
        30,
        sourceKey,
        `Leitura do Capítulo ${activeChapter.chapterNumber}: "${activeChapter.title}" (${book.title})`
      );
      // Check reading achievements
      checkAndUnlockAchievement(currentUser.uid, 'first_read');
    }
  };

  const handleNextChapter = () => {
    if (currentChapterIndex < chapters.length - 1) {
      setCurrentChapterIndex(currentChapterIndex + 1);
      if (contentRef.current) contentRef.current.scrollTop = 0;
    }
  };

  const handlePrevChapter = () => {
    if (currentChapterIndex > 0) {
      setCurrentChapterIndex(currentChapterIndex - 1);
      if (contentRef.current) contentRef.current.scrollTop = 0;
    }
  };

  // Scroll directly to chapter comments section
  const scrollToComments = () => {
    const el = document.getElementById('chapter-comments');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => {
        commentInputRef.current?.focus();
      }, 250);
    }
  };

  // Toggle Like on Chapter Comment or Reply
  const handleToggleChapterCommentLike = async (comment: ChapterComment) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!activeChapter) return;
    const commRef = doc(db, 'books', bookId, 'chapters', activeChapter.id, 'comments', comment.id);
    const hasLiked = Boolean(currentUser && comment.likedUserIds?.includes(currentUser.uid));
    try {
      if (hasLiked) {
        await updateDoc(commRef, {
          likedUserIds: arrayRemove(currentUser.uid),
          likesCount: Math.max(0, (comment.likesCount || 1) - 1),
        });
      } else {
        await updateDoc(commRef, {
          likedUserIds: arrayUnion(currentUser.uid),
          likesCount: (comment.likesCount || 0) + 1,
        });
      }
    } catch (err) {
      console.error('Error toggling chapter comment like:', err);
    }
  };

  // Initiate reply with @username auto-inserted
  const handleInitiateReply = (targetComment: ChapterComment) => {
    const rawAuthor = targetComment.userName || 'leitor';
    const cleanAuthor = rawAuthor.trim().replace(/\s+/g, '_');
    setReplyTarget({
      id: targetComment.parentId || targetComment.id,
      authorName: targetComment.userName || 'Leitor',
      authorId: targetComment.userId,
    });
    setNewComment(`@${cleanAuthor} `);
    scrollToComments();
    setTimeout(() => {
      commentInputRef.current?.focus();
    }, 200);
  };

  // Chapter comment editing handlers
  const handleStartEditComment = (comment: ChapterComment) => {
    setEditingCommentId(comment.id);
    setEditCommentText(comment.content);
  };

  const handleCancelEditComment = () => {
    setEditingCommentId(null);
    setEditCommentText('');
  };

  const handleSaveCommentEdit = async (commentId: string) => {
    if (!currentUser || !editCommentText.trim() || !activeChapter) return;
    setSavingCommentEdit(true);
    try {
      const commRef = doc(db, 'books', bookId, 'chapters', activeChapter.id, 'comments', commentId);
      await updateDoc(commRef, {
        content: editCommentText.trim(),
        editedAt: new Date().toISOString(),
      });
      setComments((prev) =>
        prev.map((c) =>
          c.id === commentId
            ? { ...c, content: editCommentText.trim(), editedAt: new Date().toISOString() }
            : c
        )
      );
      setEditingCommentId(null);
      setEditCommentText('');
    } catch (err) {
      console.error('Error saving chapter comment edit:', err);
    } finally {
      setSavingCommentEdit(false);
    }
  };

  // Self-heal and sync current user chapter comments in real-time when loaded
  useEffect(() => {
    if (!currentUser || !userProfile?.displayName || comments.length === 0 || !activeChapter) return;
    comments.forEach((c) => {
      if (
        c.userId === currentUser.uid &&
        (c.userName !== userProfile.displayName || (userProfile.photoURL && c.userPhoto !== userProfile.photoURL))
      ) {
        updateDoc(doc(db, 'books', bookId, 'chapters', activeChapter.id, 'comments', c.id), {
          userName: userProfile.displayName,
          ...(userProfile.photoURL ? { userPhoto: userProfile.photoURL } : {}),
        }).catch(() => {});
      }
    });
  }, [comments, currentUser?.uid, userProfile?.displayName, userProfile?.photoURL, bookId, activeChapter?.id]);

  // Render text with highlighted @mentions
  const renderFormattedText = (text: string) => {
    const parts = text.split(/(@[a-zA-Z0-9_À-ÿ.-]+)/g);
    return (
      <span>
        {parts.map((part, index) => {
          if (part.startsWith('@')) {
            const rawName = part.substring(1).replace(/_/g, ' ');
            return (
              <span
                key={index}
                className="inline-flex items-center gap-0.5 rounded-md bg-[#262626] dark:bg-[#202020] text-[#FF57B2] dark:text-[#FF57B2] font-bold px-1.5 py-0.2 text-[11px] border border-[#FF57B2]/50 mr-1"
              >
                @{rawName}
              </span>
            );
          }
          return <span key={index}>{part}</span>;
        })}
      </span>
    );
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!newComment.trim() || !activeChapter) return;

    setSubmittingComment(true);
    try {
      const commId = `comm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const commRef = doc(db, 'books', bookId, 'chapters', activeChapter.id, 'comments', commId);

      // Detect mentions
      const detectedMentions: string[] = [];
      const mentionRegex = /@([a-zA-Z0-9_À-ÿ.-]+)/g;
      let match;
      while ((match = mentionRegex.exec(newComment)) !== null) {
        detectedMentions.push(match[1]);
      }

      const commData: Partial<ChapterComment> & Record<string, any> = {
        id: commId,
        bookId,
        chapterId: activeChapter.id,
        userId: currentUser.uid,
        userName: userProfile?.displayName || 'Leitor',
        userPhoto: userProfile?.photoURL || '',
        content: newComment.trim(),
        likesCount: 0,
        likedUserIds: [],
        createdAt: new Date().toISOString(),
      };

      if (replyTarget?.id) {
        commData.parentId = replyTarget.id;
      }
      if (replyTarget?.authorName) {
        commData.replyToAuthorName = replyTarget.authorName;
      }
      if (replyTarget?.authorId) {
        commData.replyToUserId = replyTarget.authorId;
      }

      await setDoc(commRef, sanitizeFirestoreData(commData));

      // Increment chapter comments count
      await updateDoc(doc(db, 'books', bookId, 'chapters', activeChapter.id), {
        commentsCount: (activeChapter.commentsCount || 0) + 1,
      });

      // Award XP
      await awardXp(
        currentUser.uid,
        15,
        `comment_${commId}`,
        `Comentário no capítulo: ${activeChapter.title}`
      );

      // Notify mentioned user if this is a reply to another user
      if (replyTarget?.authorId && replyTarget.authorId !== currentUser.uid) {
        await sendNotification(
          replyTarget.authorId,
          'mention',
          `${userProfile?.displayName || 'Um participante'} respondeu você`,
          `${userProfile?.displayName || 'Um participante'} respondeu você no capítulo "${activeChapter.title}": "${newComment.trim().slice(0, 70)}"`,
          `/livro/${bookId}`
        );
      } else if (book && book.authorId !== currentUser.uid) {
        // Notify author of the book
        await sendNotification(
          book.authorId,
          'comment',
          `Novo comentário em "${activeChapter.title}"`,
          `${userProfile?.displayName}: "${newComment.slice(0, 50)}..."`,
          `/livro/${bookId}`
        );
      }

      setNewComment('');
      setReplyTarget(null);
    } catch (err) {
      console.error('Error posting comment:', err);
    } finally {
      setSubmittingComment(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#181818] text-sm text-zinc-400">
        Carregando leitor...
      </div>
    );
  }

  if (!book || chapters.length === 0) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <h3 className="font-bold text-white text-lg">Capítulo indisponível</h3>
        <p className="text-xs text-zinc-400 mt-1">
          Nenhum capítulo publicado foi encontrado nesta obra.
        </p>
        <button
          onClick={handleBack}
          className="mt-4 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
        >
          Voltar aos Detalhes
        </button>
      </div>
    );
  }

  // Group root comments and threaded replies for the chapter
  const rootComments = comments.filter((c) => !c.parentId);
  const repliesByParentId: { [key: string]: ChapterComment[] } = {};
  comments
    .filter((c) => c.parentId)
    .forEach((r) => {
      const pId = r.parentId!;
      if (!repliesByParentId[pId]) repliesByParentId[pId] = [];
      repliesByParentId[pId].push(r);
    });
  Object.keys(repliesByParentId).forEach((pId) => {
    repliesByParentId[pId].sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
  });

  // Theme styling (Sempre escuro com rosa)
  const themeClasses = 'bg-[#181818] text-white';
  const headerBorder = 'border-zinc-800 bg-[#202020]/95 text-white';

  return (
    <div className={`flex h-screen flex-col overflow-hidden transition-colors ${themeClasses}`}>
      {/* Top Reading Bar */}
      <header
        className={`sticky top-0 z-30 flex h-14 shrink-0 items-center justify-between border-b px-4 backdrop-blur-md ${headerBorder}`}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={handleBack}
            className="rounded-xl p-1.5 hover:bg-black/5 transition"
            title="Voltar aos detalhes"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="min-w-0">
            <h2 className="text-xs sm:text-sm font-bold truncate max-w-[200px] sm:max-w-xs font-literary">
              {book.title}
            </h2>
            <p className="text-[11px] opacity-70 truncate">
              Capítulo {activeChapter?.chapterNumber}: {activeChapter?.title}
            </p>
          </div>
        </div>

        {/* Action controls */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Chapter drawer trigger */}
          <button
            onClick={() => setShowChapterList(!showChapterList)}
            className="rounded-xl p-2 hover:bg-black/5 transition"
            title="Índice de Capítulos"
          >
            <List className="h-4 w-4" />
          </button>

          {/* Typography / Theme settings trigger */}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="rounded-xl p-2 hover:bg-black/5 transition"
            title="Preferências de Leitura"
          >
            <Settings className="h-4 w-4" />
          </button>

          {/* Comments trigger (Scroll to chapter comments at the end of the chapter) */}
          <button
            onClick={scrollToComments}
            className="relative rounded-xl p-2 hover:bg-black/5 transition cursor-pointer"
            title="Ir para os comentários do capítulo"
          >
            <MessageSquare className="h-4 w-4" />
            {comments.length > 0 && (
              <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#FF57B2] text-[9px] font-bold text-white shadow-2xs">
                {comments.length}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Settings Flyout */}
      {showSettings && (
        <div className="absolute right-4 top-16 z-40 w-72 rounded-2xl bg-[#202020] p-4 shadow-2xl border border-zinc-800 text-white text-xs space-y-4 animate-in fade-in zoom-in-95">
          <div>
            <span className="font-bold block mb-2 text-zinc-300">Tamanho do Texto ({fontSize}px)</span>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setFontSize(Math.max(14, fontSize - 2))}
                className="rounded-lg border border-zinc-700 bg-zinc-850 px-3 py-1 font-bold text-white hover:bg-zinc-750 transition cursor-pointer"
              >
                A-
              </button>
              <input
                type="range"
                min={14}
                max={26}
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="flex-1 accent-[#FF57B2]"
              />
              <button
                onClick={() => setFontSize(Math.min(26, fontSize + 2))}
                className="rounded-lg border border-zinc-700 bg-zinc-850 px-3 py-1 font-bold text-white hover:bg-zinc-750 transition cursor-pointer"
              >
                A+
              </button>
            </div>
          </div>

          <div>
            <span className="font-bold block mb-2 text-zinc-300">Tipografia Literária</span>
            <div className="grid grid-cols-3 gap-1.5 text-center">
              <button
                onClick={() => setFontFamily('font-literary')}
                className={`rounded-xl border p-2 font-literary transition cursor-pointer ${
                  fontFamily === 'font-literary'
                    ? 'border-[#FF57B2] bg-[#262626] text-[#FF57B2] font-bold shadow-xs'
                    : 'border-zinc-700 bg-zinc-900/60 text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                Literata
              </button>
              <button
                onClick={() => setFontFamily('font-serif')}
                className={`rounded-xl border p-2 font-serif transition cursor-pointer ${
                  fontFamily === 'font-serif'
                    ? 'border-[#FF57B2] bg-[#262626] text-[#FF57B2] font-bold shadow-xs'
                    : 'border-zinc-700 bg-zinc-900/60 text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                Cinzel
              </button>
              <button
                onClick={() => setFontFamily('font-sans')}
                className={`rounded-xl border p-2 font-sans transition cursor-pointer ${
                  fontFamily === 'font-sans'
                    ? 'border-[#FF57B2] bg-[#262626] text-[#FF57B2] font-bold shadow-xs'
                    : 'border-zinc-700 bg-zinc-900/60 text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                Moderna
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chapters Selector Drawer */}
      {showChapterList && (
        <div className="absolute left-4 top-16 z-40 w-80 max-h-[70vh] overflow-y-auto rounded-2xl bg-[#202020] p-4 shadow-2xl border border-zinc-800 text-zinc-100 text-xs space-y-2 animate-in fade-in zoom-in-95">
          <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
            <span className="font-bold text-sm text-[#FF57B2]">Sumário da Obra</span>
            <span className="text-[11px] text-zinc-400">{chapters.length} capítulos</span>
          </div>
          <div className="divide-y divide-zinc-800">
            {chapters.map((ch, idx) => (
              <button
                key={ch.id}
                onClick={() => {
                  setCurrentChapterIndex(idx);
                  setShowChapterList(false);
                }}
                className={`flex w-full items-center justify-between py-2.5 px-2 text-left rounded-lg transition cursor-pointer ${
                  idx === currentChapterIndex
                    ? 'bg-[#262626] font-bold text-[#FF57B2]'
                    : 'hover:bg-[#262626]/60 text-zinc-300'
                }`}
              >
                <span className="truncate">
                  {ch.chapterNumber}. {ch.title}
                </span>
                {idx === currentChapterIndex && (
                  <CheckCircle className="h-3.5 w-3.5 shrink-0 text-[#FF57B2]" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Reading Body */}
      <main
        ref={contentRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-4 sm:px-8 py-8 md:py-12"
      >
        <article className="mx-auto max-w-2xl space-y-6">
          {/* Chapter header */}
          <div className="text-center pb-6 border-b border-current/10">
            <span className="text-xs uppercase tracking-widest font-bold opacity-60">
              Capítulo {activeChapter?.chapterNumber}
            </span>
            <h1 className="mt-2 text-2xl sm:text-3xl font-black font-display tracking-tight">
              {activeChapter?.title}
            </h1>
          </div>

          {/* Chapter text or Gated Benefit Card */}
          {isAccessBlocked ? (
            <div className="rounded-3xl border border-[#FF57B2]/40 bg-[#202020] p-6 sm:p-8 text-center space-y-4 shadow-sm my-6">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-md">
                <Lock className="h-7 w-7" />
              </div>
              <div className="space-y-1">
                <span className="rounded-md bg-[#FF57B2]/15 border border-[#FF57B2]/40 px-2.5 py-0.5 text-[11px] font-bold text-[#FF80C5] uppercase tracking-wider">
                  {isEarlyAccessBlocked ? 'Capítulo em Acesso Antecipado' : 'Obra em Versão Beta'}
                </span>
                <h3 className="text-xl font-bold font-display text-white pt-2">
                  {isEarlyAccessBlocked
                    ? 'Conteúdo Exclusivo da Assinatura Leitor'
                    : 'Leitura Antecipada Exclusiva da Assinatura Leitor'}
                </h3>
                <p className="text-xs text-zinc-300 max-w-md mx-auto leading-relaxed font-literary">
                  {isEarlyAccessBlocked
                    ? 'O autor disponibilizou este capítulo com antecedência exclusiva para membros do plano KORDEL Leitor.'
                    : 'Esta obra está em fase de testes e leitura beta antecipada, benefício reservado exclusivamente para membros do plano KORDEL Leitor.'}
                </p>
              </div>

              <div className="rounded-2xl bg-[#262626] border border-zinc-800 p-4 text-xs text-left max-w-md mx-auto space-y-2">
                <p className="font-bold text-white flex items-center gap-1.5">
                  <Crown className="h-4 w-4 text-[#FF57B2]" />
                  Assinatura Leitor — R$ 4,90/mês
                </p>
                <ul className="text-[11px] text-zinc-300 space-y-1 list-disc list-inside font-literary">
                  <li>Acesso antecipado a capítulos e obras beta</li>
                  <li>Gamificação completa com XP, níveis e missões</li>
                  <li>Disputa no ranking semanal oficial de leitores</li>
                  <li>Selo oficial "Leitor Experiente" no perfil</li>
                </ul>
              </div>

              <div className="pt-2 flex justify-center">
                <button
                  type="button"
                  onClick={() => {
                    if (!currentUser) {
                      onOpenAuth();
                    } else if (onNavigateTab) {
                      onNavigateTab('subscriptions');
                    }
                  }}
                  className="rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-6 py-3 text-xs font-bold text-white shadow-lg shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer flex items-center gap-2"
                >
                  <Crown className="h-4 w-4" />
                  <span>Assinar Leitor por R$ 4,90/mês</span>
                </button>
              </div>
            </div>
          ) : (
            <div
              className={`${fontFamily} leading-relaxed whitespace-pre-line tracking-normal selection:bg-[#FF57B2]/40 selection:text-[#FFFFFF]`}
              style={{ fontSize: `${fontSize}px`, lineHeight: 1.75 }}
            >
              {activeChapter?.content}
            </div>
          )}

          {/* End of chapter notice & XP badge */}
          <div className="pt-10 pb-4 text-center border-t border-current/10 space-y-4">
            {!isAccessBlocked && (
              isLeitorActive ? (
                <div className="inline-flex items-center gap-2 rounded-full bg-[#262626] px-4 py-1.5 text-xs font-bold text-[#FF57B2] border border-[#FF57B2]/50">
                  <CheckCircle className="h-4 w-4 text-[#FF57B2]" />
                  <span>Capítulo Concluído (+30 XP Literário)</span>
                </div>
              ) : (
                <div className="inline-flex items-center gap-2 rounded-full bg-[#262626] border border-zinc-800 px-4 py-1.5 text-xs text-zinc-300">
                  <CheckCircle className="h-4 w-4 text-[#FF57B2]" />
                  <span>Capítulo Lido • Ganho de XP e ranking exclusivo para assinantes Leitor</span>
                </div>
              )
            )}

            {/* Next / Previous Navigation */}
            <div className="flex items-center justify-between gap-4 pt-4">
              <button
                onClick={handlePrevChapter}
                disabled={currentChapterIndex === 0}
                className="flex items-center gap-2 rounded-2xl border border-current/20 px-4 py-2.5 text-xs font-bold disabled:opacity-30 hover:bg-[#262626] transition cursor-pointer"
              >
                <ChevronLeft className="h-4 w-4" />
                <span>Capítulo Anterior</span>
              </button>

              <button
                onClick={handleNextChapter}
                disabled={currentChapterIndex >= chapters.length - 1}
                className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-5 py-2.5 text-xs font-bold text-white shadow-md hover:from-[#FF40A4] hover:to-[#D02685] disabled:opacity-30 transition cursor-pointer"
              >
                <span>Próximo Capítulo</span>
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            {/* SEÇÃO DE COMENTÁRIOS DO CAPÍTULO (Direto ao fim do capítulo, não em janela suspensa) */}
            <section
              id="chapter-comments"
              className="mt-12 pt-8 border-t border-current/15 text-left space-y-6"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-[#262626] dark:bg-[#202020] text-[#FF57B2] dark:text-[#FF57B2] border border-[#FF57B2]/40">
                    <MessageSquare className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-base sm:text-lg font-black font-display text-[#FFFFFF] dark:text-white">
                      Comentários do Capítulo ({comments.length})
                    </h3>
                    <p className="text-[11px] opacity-70">
                      Compartilhe suas reflexões, teorias e impressões literárias sobre este capítulo.
                    </p>
                  </div>
                </div>
              </div>

              {/* Formulário de Envio de Comentário */}
              <div className="rounded-3xl border border-[#FF57B2]/40 bg-[#262626]/30 dark:bg-[#202020]/30 p-4 sm:p-5 space-y-3 shadow-2xs">
                {replyTarget && (
                  <div className="flex items-center justify-between rounded-xl bg-[#262626] dark:bg-[#202020] border border-[#FF57B2]/50 px-3 py-1.5 text-xs text-[#FFFFFF] dark:text-[#FF57B2]">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <CornerDownRight className="h-3.5 w-3.5 shrink-0 text-[#FF57B2] dark:text-[#FF57B2]" />
                      <span className="font-semibold truncate">
                        Respondendo a <strong>{replyTarget.authorName}</strong>
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setReplyTarget(null);
                        setNewComment('');
                      }}
                      className="text-[#FF57B2] hover:text-[#FFFFFF] dark:hover:text-white font-bold ml-2 cursor-pointer p-0.5"
                      title="Cancelar resposta"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}

                <form onSubmit={handleAddComment} className="flex items-center gap-2.5">
                  {currentUser ? (
                    <UserAvatar
                      userId={currentUser.uid}
                      userName={userProfile?.displayName}
                      photoURL={userProfile?.photoURL}
                      sizeClass="h-9 w-9 shrink-0"
                    />
                  ) : (
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#262626] border border-zinc-700 text-zinc-300 text-xs font-bold">
                      ?
                    </div>
                  )}

                  <input
                    ref={commentInputRef}
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder={
                      currentUser
                        ? replyTarget
                          ? `Respondendo a ${replyTarget.authorName}...`
                          : 'Escreva sua reflexão ou teoria sobre o capítulo...'
                        : 'Faça login na plataforma para comentar...'
                    }
                    disabled={!currentUser}
                    className="flex-1 rounded-2xl border border-zinc-700 bg-[#181818] px-4 py-2.5 text-xs sm:text-sm text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none transition"
                  />

                  <button
                    type="submit"
                    disabled={submittingComment || !newComment.trim() || !currentUser}
                    className="flex items-center gap-1.5 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-2.5 text-xs font-bold text-white shadow-md hover:from-[#FF40A4] hover:to-[#D02685] disabled:opacity-40 transition cursor-pointer shrink-0"
                  >
                    <Send className="h-4 w-4" />
                    <span className="hidden sm:inline">Enviar</span>
                  </button>
                </form>
              </div>

              {/* Lista de Comentários do Capítulo */}
              <div className="space-y-4">
                {rootComments.length === 0 ? (
                  <div className="rounded-3xl border border-current/10 p-8 text-center opacity-70">
                    <p className="text-xs sm:text-sm font-literary">
                      Nenhum comentário neste capítulo ainda. Seja o primeiro a deixar suas impressões literárias!
                    </p>
                  </div>
                ) : (
                  rootComments.map((c) => {
                    const canDelete =
                      currentUser?.uid === c.userId ||
                      currentUser?.uid === book?.authorId ||
                      userProfile?.role === 'desenvolvedor';
                    const hasLikedComment = Boolean(
                      currentUser && c.likedUserIds?.includes(currentUser.uid)
                    );
                    const childReplies = repliesByParentId[c.id] || [];

                    return (
                      <div
                        key={c.id}
                        className="rounded-3xl border border-current/10 bg-[#202020]/70 p-4 sm:p-5 space-y-3"
                      >
                        {/* Autor e data */}
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <UserAvatar
                              userId={c.userId}
                              userName={c.userName}
                              photoURL={c.userPhoto}
                              sizeClass="h-8 w-8"
                              onClick={() => openUserProfile(c.userId)}
                              title={`Ver perfil de ${c.userName}`}
                            />
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <UserDisplayName
                                  userId={c.userId}
                                  fallback={c.userName}
                                  onClick={() => openUserProfile(c.userId)}
                                  className="font-bold text-xs sm:text-sm hover:underline cursor-pointer transition truncate"
                                  title={`Ver perfil de ${c.userName}`}
                                />
                                <UserBadges userId={c.userId} size="xs" />
                              </div>
                              <div className="flex items-center gap-1 text-[10px] opacity-60">
                                <span>
                                  {new Date(c.createdAt).toLocaleDateString('pt-BR', {
                                    day: '2-digit',
                                    month: 'short',
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                                </span>
                                {c.editedAt && (
                                  <>
                                    <span>•</span>
                                    <span className="italic">editado</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1">
                            {currentUser?.uid === c.userId && (
                              <button
                                type="button"
                                onClick={() => handleStartEditComment(c)}
                                className="opacity-50 hover:opacity-100 hover:text-current transition p-1.5 cursor-pointer"
                                title="Editar comentário"
                              >
                                <Edit2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                            {canDelete && (
                              <button
                                type="button"
                                onClick={() => setCommentToDelete(c)}
                                className="opacity-50 hover:opacity-100 hover:text-[#FF80C5] transition p-1.5 cursor-pointer"
                                title="Excluir comentário"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Conteúdo com menções formatadas ou formulário de edição */}
                        {editingCommentId === c.id ? (
                          <div className="space-y-2 pl-10 pt-1">
                            <textarea
                              rows={2}
                              value={editCommentText}
                              onChange={(e) => setEditCommentText(e.target.value)}
                              className="w-full rounded-2xl border border-zinc-700 bg-[#181818] p-2.5 text-xs sm:text-sm text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
                              placeholder="Editar seu comentário..."
                            />
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={handleCancelEditComment}
                                disabled={savingCommentEdit}
                                className="px-2.5 py-1 text-xs opacity-70 hover:opacity-100 transition cursor-pointer"
                              >
                                Cancelar
                              </button>
                              <button
                                type="button"
                                onClick={() => handleSaveCommentEdit(c.id)}
                                disabled={savingCommentEdit || !editCommentText.trim()}
                                className="flex items-center gap-1 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-3 py-1 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-40 cursor-pointer"
                              >
                                {savingCommentEdit ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                                <span>Salvar</span>
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="text-xs sm:text-sm leading-relaxed font-literary pl-10">
                            {renderFormattedText(c.content)}
                          </div>
                        )}

                        {/* Ações: Curtir e Responder */}
                        <div className="flex items-center gap-4 pl-10 pt-1 text-xs">
                          {/* Botão de Like no comentário */}
                          <button
                            type="button"
                            onClick={() => handleToggleChapterCommentLike(c)}
                            className={`flex items-center gap-1.5 transition cursor-pointer font-bold ${
                              hasLikedComment
                                ? 'text-[#FF57B2] dark:text-[#FF57B2]'
                                : 'opacity-70 hover:opacity-100 hover:text-[#FF57B2] dark:hover:text-[#FF57B2]'
                            }`}
                            title="Curtir comentário"
                          >
                            <Heart
                              className={`h-4 w-4 ${
                                hasLikedComment ? 'fill-[#FF57B2] text-[#FF57B2] dark:fill-[#FF57B2] dark:text-[#FF57B2]' : ''
                              }`}
                            />
                            <span>{c.likesCount || 0}</span>
                          </button>

                          {/* Botão de Responder */}
                          <button
                            type="button"
                            onClick={() => handleInitiateReply(c)}
                            className="flex items-center gap-1.5 opacity-70 hover:opacity-100 hover:text-[#FF57B2] dark:hover:text-[#FF57B2] transition cursor-pointer font-semibold"
                            title="Responder a este comentário"
                          >
                            <CornerDownRight className="h-3.5 w-3.5" />
                            <span>Responder</span>
                          </button>
                        </div>

                        {/* Respostas Aninhadas aos Comentários do Capítulo */}
                        {childReplies.length > 0 && (
                          <div className="mt-3 ml-6 sm:ml-10 space-y-2.5 border-l-2 border-[#FF57B2]/40 pl-3 sm:pl-4 pt-1">
                            {childReplies.map((reply) => {
                              const canDeleteReply =
                                currentUser?.uid === reply.userId ||
                                currentUser?.uid === book?.authorId ||
                                userProfile?.role === 'desenvolvedor';
                              const hasLikedReply = Boolean(
                                currentUser && reply.likedUserIds?.includes(currentUser.uid)
                              );

                              return (
                                <div
                                  key={reply.id}
                                  className="rounded-2xl border border-current/10 bg-[#181818]/80 p-3 space-y-2"
                                >
                                  <div className="flex items-center justify-between gap-2">
                                    <div className="flex items-center gap-2 min-w-0">
                                      <UserAvatar
                                        userId={reply.userId}
                                        userName={reply.userName}
                                        photoURL={reply.userPhoto}
                                        sizeClass="h-6 w-6"
                                        onClick={() => openUserProfile(reply.userId)}
                                        title={`Ver perfil de ${reply.userName}`}
                                      />
                                      <div className="min-w-0">
                                        <div className="flex items-center gap-1.5 flex-wrap">
                                          <UserDisplayName
                                            userId={reply.userId}
                                            fallback={reply.userName}
                                            onClick={() => openUserProfile(reply.userId)}
                                            className="font-bold text-xs hover:underline cursor-pointer transition truncate"
                                            title={`Ver perfil de ${reply.userName}`}
                                          />
                                          <UserBadges userId={reply.userId} size="xs" />
                                        </div>
                                        <div className="flex items-center gap-1 text-[9px] opacity-60">
                                          <span>
                                            {new Date(reply.createdAt).toLocaleDateString('pt-BR', {
                                              day: '2-digit',
                                              month: 'short',
                                              hour: '2-digit',
                                              minute: '2-digit',
                                            })}
                                          </span>
                                          {reply.editedAt && (
                                            <>
                                              <span>•</span>
                                              <span className="italic">editado</span>
                                            </>
                                          )}
                                        </div>
                                      </div>
                                    </div>

                                    <div className="flex items-center gap-1">
                                      {currentUser?.uid === reply.userId && (
                                        <button
                                          type="button"
                                          onClick={() => handleStartEditComment(reply)}
                                          className="opacity-50 hover:opacity-100 hover:text-current transition p-1 cursor-pointer"
                                          title="Editar resposta"
                                        >
                                          <Edit2 className="h-3 w-3" />
                                        </button>
                                      )}
                                      {canDeleteReply && (
                                        <button
                                          type="button"
                                          onClick={() => setCommentToDelete(reply)}
                                          className="opacity-50 hover:opacity-100 hover:text-[#FF80C5] transition p-1 cursor-pointer"
                                          title="Excluir resposta"
                                        >
                                          <Trash2 className="h-3 w-3" />
                                        </button>
                                      )}
                                    </div>
                                  </div>

                                  {/* Reply Content or Edit Form */}
                                  {editingCommentId === reply.id ? (
                                    <div className="space-y-2 pl-8 pt-1">
                                      <textarea
                                        rows={2}
                                        value={editCommentText}
                                        onChange={(e) => setEditCommentText(e.target.value)}
                                        className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
                                        placeholder="Editar sua resposta..."
                                      />
                                      <div className="flex items-center justify-end gap-2">
                                        <button
                                          type="button"
                                          onClick={handleCancelEditComment}
                                          disabled={savingCommentEdit}
                                          className="px-2 py-0.5 text-xs opacity-70 hover:opacity-100 transition cursor-pointer"
                                        >
                                          Cancelar
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => handleSaveCommentEdit(reply.id)}
                                          disabled={savingCommentEdit || !editCommentText.trim()}
                                          className="flex items-center gap-1 rounded-lg bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-2.5 py-1 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-40 cursor-pointer"
                                        >
                                          {savingCommentEdit ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                                          <span>Salvar</span>
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="text-xs leading-relaxed font-literary pl-8">
                                      {renderFormattedText(reply.content)}
                                    </div>
                                  )}

                                  {/* Ações da resposta: Curtir e Responder */}
                                  <div className="flex items-center gap-4 pl-8 pt-0.5 text-xs">
                                    <button
                                      type="button"
                                      onClick={() => handleToggleChapterCommentLike(reply)}
                                      className={`flex items-center gap-1 transition cursor-pointer font-bold ${
                                        hasLikedReply
                                          ? 'text-[#FF57B2] dark:text-[#FF57B2]'
                                          : 'opacity-70 hover:opacity-100 hover:text-[#FF57B2] dark:hover:text-[#FF57B2]'
                                      }`}
                                      title="Curtir resposta"
                                    >
                                      <Heart
                                        className={`h-3.5 w-3.5 ${
                                          hasLikedReply ? 'fill-[#FF57B2] text-[#FF57B2] dark:fill-[#FF57B2] dark:text-[#FF57B2]' : ''
                                        }`}
                                      />
                                      <span className="text-[11px]">{reply.likesCount || 0}</span>
                                    </button>

                                    <button
                                      type="button"
                                      onClick={() => handleInitiateReply(reply)}
                                      className="flex items-center gap-1 opacity-70 hover:opacity-100 hover:text-[#FF57B2] dark:hover:text-[#FF57B2] transition cursor-pointer font-semibold text-[11px]"
                                      title="Responder a este usuário"
                                    >
                                      <CornerDownRight className="h-3 w-3" />
                                      <span>Responder</span>
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </section>
          </div>
        </article>
      </main>

      {/* Report Modal */}
      <ReportModal
        isOpen={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
        targetType="chapter"
        targetId={reportTarget.id}
        targetSummary={reportTarget.summary}
      />

      {/* Confirm Delete Chapter Comment Modal */}
      <ConfirmModal
        isOpen={Boolean(commentToDelete)}
        onClose={() => {
          if (!isDeletingComment) setCommentToDelete(null);
        }}
        onConfirm={async () => {
          if (!commentToDelete || !activeChapter || !book) return;
          setIsDeletingComment(true);
          try {
            await deleteDoc(
              doc(db, 'books', book.id, 'chapters', activeChapter.id, 'comments', commentToDelete.id)
            );
            try {
              const updatedCount = Math.max(0, (activeChapter.commentsCount || 1) - 1);
              await updateDoc(doc(db, 'books', book.id, 'chapters', activeChapter.id), {
                commentsCount: updatedCount,
              });
            } catch {
              // ignore
            }
            setComments((prev) => prev.filter((c) => c.id !== commentToDelete.id));
            setCommentToDelete(null);
          } catch (err: any) {
            console.error('Error deleting chapter comment:', err);
          } finally {
            setIsDeletingComment(false);
          }
        }}
        title="Excluir Comentário?"
        message="Deseja excluir este comentário permanentemente do capítulo?"
        confirmText="Excluir Comentário"
        cancelText="Cancelar"
        variant="danger"
        isLoading={isDeletingComment}
      />
    </div>
  );
};
