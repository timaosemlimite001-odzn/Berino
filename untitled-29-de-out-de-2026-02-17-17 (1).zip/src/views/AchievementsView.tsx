import {
  Award,
  BookmarkCheck,
  BookOpen,
  CheckCircle,
  Coins,
  Crown,
  Feather,
  Glasses,
  GraduationCap,
  Lock,
  MessageSquare,
  Scroll,
  Sparkles,
  Star,
  Target
} from 'lucide-react';
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { creditKards } from '../services/kardsService';
import { awardXp, claimMissionReward } from '../services/progressionService';
import { isSubscriptionActive } from '../services/subscriptionService';
import { ALL_ACHIEVEMENTS, ALL_MISSIONS, calculateLevelFromXp, MAX_LEVEL } from '../services/xpLevels';

interface AchievementsViewProps {
  onOpenAuth: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const AchievementsView: React.FC<AchievementsViewProps> = ({ onOpenAuth, onNavigateTab }) => {
  const { currentUser, userProfile, updateUserProfileData } = useAuth();
  const [activeTab, setActiveTab] = useState<'achievements' | 'missions'>('achievements');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'general' | 'writers'>('all');
  const [claimingMissionId, setClaimingMissionId] = useState<string | null>(null);
  const [missionFeedback, setMissionFeedback] = useState<{ id: string; msg: string; type: 'success' | 'error' } | null>(null);

  const isLeitorActive = isSubscriptionActive(userProfile, 'leitor');
  const isEscritorActive = isSubscriptionActive(userProfile, 'escritor');

  const handleClaimMission = async (missionId: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    setMissionFeedback(null);
    setClaimingMissionId(missionId);
    try {
      const res = await claimMissionReward(currentUser.uid, missionId);
      setMissionFeedback({ id: missionId, msg: res.message, type: 'success' });
    } catch (err: any) {
      setMissionFeedback({ id: missionId, msg: err.message || 'Erro ao resgatar missão.', type: 'error' });
    } finally {
      setClaimingMissionId(null);
    }
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'BookOpen':
        return <BookOpen className="h-5 w-5" />;
      case 'BookmarkCheck':
        return <BookmarkCheck className="h-5 w-5" />;
      case 'GraduationCap':
        return <GraduationCap className="h-5 w-5" />;
      case 'Star':
        return <Star className="h-5 w-5" />;
      case 'MessageSquare':
        return <MessageSquare className="h-5 w-5" />;
      case 'Feather':
        return <Feather className="h-5 w-5" />;
      case 'Scroll':
        return <Scroll className="h-5 w-5" />;
      case 'Glasses':
        return <Glasses className="h-5 w-5" />;
      case 'Coins':
        return <Coins className="h-5 w-5" />;
      case 'Crown':
        return <Crown className="h-5 w-5" />;
      default:
        return <Award className="h-5 w-5" />;
    }
  };

  const unlockedIds = userProfile?.achievements || [];
  const titles = userProfile?.titles || ['Leitor Curioso'];

  const handleSelectTitle = async (title: string) => {
    try {
      await updateUserProfileData({ activeTitle: title });
    } catch (err) {
      console.error('Error selecting title:', err);
    }
  };

  const { progressPercent, nextLevelXp, currentLevelXp } = calculateLevelFromXp(
    userProfile?.xp || 0
  );

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-8 space-y-8 text-white">
      {/* Header */}
      <div className="border-b border-zinc-800 pb-6">
        <div className="flex items-center gap-2 text-[#FF57B2] text-xs font-bold uppercase tracking-wider mb-1">
          <Award className="h-4 w-4" />
          <span>Jornada Literária</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white font-display">
          Conquistas, Títulos & Missões
        </h1>
        <p className="text-xs sm:text-sm text-zinc-300 mt-1">
          Complete feitos no KORDEL, ganhe XP, suba pelos 33 níveis de maestria e ostente títulos exclusivos.
        </p>
      </div>

      {/* Progress Card */}
      {currentUser ? (
        <div className="rounded-3xl bg-[#202020] text-white p-6 shadow-xl border border-zinc-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`rounded-md px-2.5 py-0.5 text-xs font-bold text-white uppercase border ${
                  isLeitorActive
                    ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] border-[#FF57B2]'
                    : 'bg-[#262626] text-zinc-400 border-zinc-700'
                }`}>
                  {isLeitorActive ? `Nível ${userProfile?.level || 1} de ${MAX_LEVEL}` : 'Nível 0 (Plano Inativo)'}
                </span>
                {isLeitorActive && (userProfile?.progressionCycle || 0) > 0 && (
                  <span className="rounded-md bg-[#FF57B2]/20 border border-[#FF57B2] px-2.5 py-0.5 text-xs font-bold text-[#FF80C5]">
                    Ciclo {userProfile!.progressionCycle + 1}
                  </span>
                )}
                {!isLeitorActive && (
                  <span className="rounded-md bg-[#262626] border border-[#FF57B2]/40 px-2 py-0.5 text-[10px] font-bold text-[#FF80C5]">
                    Gamificação Bloqueada
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold font-display mt-2">
                {userProfile?.displayName} —{' '}
                <span className="text-[#FF80C5] font-literary">
                  {userProfile?.activeTitle || (isLeitorActive ? 'Leitor Experiente' : 'Leitor Visitante')}
                </span>
              </h2>
              {!isLeitorActive && (
                <p className="text-xs text-zinc-300 font-literary mt-1">
                  Seu nível e XP foram zerados pois a Assinatura Leitor (R$ 4,90/mês) não está ativa. Assine para reativar o progresso!
                </p>
              )}
            </div>

            <div className="text-right tabular-nums">
              <span className="text-2xl font-black font-display text-white">
                {isLeitorActive ? (userProfile?.xp || 0) : 0}{' '}
                <span className="text-xs font-normal text-[#FF80C5]">
                  / {isLeitorActive ? nextLevelXp : 0} XP
                </span>
              </span>
              <p className="text-[11px] text-zinc-400 mt-0.5">
                {isLeitorActive
                  ? `Próximo nível: ${Math.max(0, nextLevelXp - (userProfile?.xp || 0))} XP restantes`
                  : 'Requer Assinatura Leitor (R$ 4,90/mês)'}
              </p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="h-2 w-full overflow-hidden rounded-full bg-[#181818] border border-zinc-800">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isLeitorActive
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#FF80C5] shadow-[0_0_12px_rgba(255,87,178,0.6)]'
                  : 'bg-zinc-700'
              }`}
              style={{ width: isLeitorActive ? `${progressPercent}%` : '0%' }}
            ></div>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl border border-zinc-800 bg-[#202020] p-6 text-center text-xs text-zinc-300">
          Faça login para acompanhar sua progressão de XP e desbloquear conquistas.{' '}
          <button onClick={onOpenAuth} className="font-bold text-[#FF80C5] hover:underline cursor-pointer">
            Entrar
          </button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-zinc-800">
        <button
          onClick={() => setActiveTab('achievements')}
          className={`px-5 py-3 text-xs sm:text-sm font-bold border-b-2 transition cursor-pointer ${
            activeTab === 'achievements'
              ? 'border-[#FF57B2] text-[#FF57B2]'
              : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          Conquistas & Títulos ({unlockedIds.length}/{ALL_ACHIEVEMENTS.length})
        </button>
        <button
          onClick={() => setActiveTab('missions')}
          className={`px-5 py-3 text-xs sm:text-sm font-bold border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'missions'
              ? 'border-[#FF57B2] text-[#FF57B2]'
              : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <span>Missões de XP</span>
          {!isLeitorActive && (
            <span className="rounded bg-[#262626] border border-[#FF57B2]/40 text-[#FF80C5] text-[9px] px-1.5 py-0.5 font-extrabold uppercase">
              Assinante
            </span>
          )}
        </button>
      </div>

      {/* 1. Achievements Tab */}
      {activeTab === 'achievements' && (
        <div className="space-y-8">
          {/* Active Title Selector */}
          {currentUser && titles.length > 0 && (
            <div className="rounded-3xl bg-[#202020] p-5 shadow-xs border border-zinc-800 space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-xs">
                <Sparkles className="h-4 w-4 text-[#FF57B2]" />
                <span>Selecione seu Título Honorário Ativo</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {titles.map((t) => {
                  const isSelected = userProfile?.activeTitle === t;
                  return (
                    <button
                      key={t}
                      onClick={() => handleSelectTitle(t)}
                      className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition cursor-pointer ${
                        isSelected
                          ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs border border-[#FF57B2]'
                          : 'bg-[#262626] text-zinc-200 border border-zinc-700 hover:border-[#FF57B2]/50 hover:text-white'
                      }`}
                    >
                      {isSelected ? '✓ ' : ''}
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setCategoryFilter('all')}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer ${
                categoryFilter === 'all'
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs'
                  : 'bg-[#202020] border border-zinc-800 text-zinc-300 hover:border-[#FF57B2]/50 hover:text-white'
              }`}
            >
              Todas ({ALL_ACHIEVEMENTS.length})
            </button>
            <button
              type="button"
              onClick={() => setCategoryFilter('general')}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer ${
                categoryFilter === 'general'
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs'
                  : 'bg-[#202020] border border-zinc-800 text-zinc-300 hover:border-[#FF57B2]/50 hover:text-white'
              }`}
            >
              Leitores & Geral ({ALL_ACHIEVEMENTS.filter((a) => !a.isWriterExclusive).length})
            </button>
            <button
              type="button"
              onClick={() => setCategoryFilter('writers')}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                categoryFilter === 'writers'
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs'
                  : 'bg-[#202020] border border-[#FF57B2]/40 text-[#FF80C5] hover:border-[#FF57B2] hover:text-white'
              }`}
            >
              <Crown className="h-3.5 w-3.5" />
              <span>Escritores & Obras ({ALL_ACHIEVEMENTS.filter((a) => a.isWriterExclusive).length})</span>
            </button>
          </div>

          {/* Writers Banner if filtered by writers */}
          {categoryFilter === 'writers' && !isEscritorActive && (
            <div className="rounded-3xl border border-[#FF57B2]/40 bg-[#202020] p-5 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white font-black shadow-xs shrink-0">
                  <Crown className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-bold text-white text-sm font-display">
                    Sistema de Conquistas para Escritores, Obras & Comunidades
                  </p>
                  <p className="text-xs text-zinc-300">
                    Disponível na Assinatura Escritor (R$ 13,49/mês). Seus marcos de obras, visualizações, leitores e comunidades são reconhecidos automaticamente. Conquistas obtidas permanecem salvas para sempre.
                  </p>
                </div>
              </div>
              {onNavigateTab && (
                <button
                  onClick={() => onNavigateTab('subscriptions')}
                  className="shrink-0 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white px-4 py-2.5 text-xs font-black uppercase tracking-wider transition shadow-xs cursor-pointer"
                >
                  Assinar Escritor (R$ 13,49/mês)
                </button>
              )}
            </div>
          )}

          {/* Grid of All Achievements */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {ALL_ACHIEVEMENTS.filter((ach) => {
              if (categoryFilter === 'writers') return ach.isWriterExclusive;
              if (categoryFilter === 'general') return !ach.isWriterExclusive;
              return true;
            }).map((ach) => {
              const isUnlocked = unlockedIds.includes(ach.id);

              return (
                <div
                  key={ach.id}
                  className={`flex items-start gap-4 rounded-3xl p-5 border transition ${
                    isUnlocked
                      ? 'bg-[#202020] border-[#FF57B2]/50 shadow-xs'
                      : 'bg-[#181818] border-zinc-800 opacity-75'
                  }`}
                >
                  <div
                    className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${
                      isUnlocked
                        ? 'bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-sm shadow-[#FF57B2]/30'
                        : 'bg-[#262626] text-zinc-500 border border-zinc-800'
                    }`}
                  >
                    {isUnlocked ? getIcon(ach.icon) : <Lock className="h-5 w-5" />}
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between gap-1 flex-wrap">
                      <div className="flex items-center gap-1.5 truncate">
                        <h3 className="font-bold text-sm text-white truncate font-display">
                          {ach.title}
                        </h3>
                      </div>
                      <span className="rounded-md bg-[#262626] border border-zinc-700 px-2 py-0.5 text-[10px] font-bold text-[#FF80C5] shrink-0 tabular-nums">
                        +{ach.xpReward} XP
                      </span>
                    </div>

                    {ach.isWriterExclusive && (
                      <div className="pt-0.5">
                        <span className="inline-flex items-center gap-1 rounded-full bg-[#FF57B2]/15 border border-[#FF57B2]/40 text-[#FF80C5] text-[10px] font-black px-2 py-0.5 uppercase tracking-wider">
                          <Crown className="h-2.5 w-2.5" />
                          Plano Escritor & Obras
                        </span>
                      </div>
                    )}

                    <p className="text-xs text-zinc-300 leading-relaxed font-literary">
                      {ach.description}
                    </p>

                    {ach.titleReward && (
                      <span className="inline-block text-[11px] font-semibold text-[#FF57B2]">
                        Título: "{ach.titleReward}"
                      </span>
                    )}

                    <div className="pt-1 flex items-center justify-between">
                      {isUnlocked ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#FF80C5]">
                          <CheckCircle className="h-3 w-3 text-[#FF57B2]" /> Conquistado
                        </span>
                      ) : (
                        <span className="text-[10px] text-zinc-500">Bloqueado</span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. Missions Tab */}
      {activeTab === 'missions' && (
        <div className="space-y-6">
          {!isLeitorActive ? (
            <div className="rounded-3xl border border-[#FF57B2]/40 bg-[#202020] p-8 sm:p-12 text-center shadow-md max-w-2xl mx-auto space-y-4">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-md border border-[#FF57B2]/50">
                <Lock className="h-8 w-8 text-white" />
              </div>
              <div className="space-y-2">
                <span className="inline-block rounded-full bg-[#262626] px-3 py-1 text-[11px] font-black uppercase tracking-wider text-[#FF80C5] border border-[#FF57B2]/40">
                  Missões Ocultas • Requer Assinatura Leitor
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-white font-display">
                  As missões de XP sumiram da sua conta
                </h3>
                <p className="text-xs sm:text-sm text-zinc-300 font-literary leading-relaxed max-w-lg mx-auto">
                  O sistema de missões periódicas, ganho de XP e evolução de nível é exclusivo para membros com a <strong>Assinatura Leitor (R$ 4,90/mês)</strong> ativa. Sem a assinatura ativa, você perde acesso à gamificação, as missões somem, você não ganha mais XP e seu nível fica zerado.
                </p>
              </div>
              {onNavigateTab && (
                <div className="pt-2">
                  <button
                    onClick={() => onNavigateTab('subscriptions')}
                    className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white px-7 py-3 text-xs sm:text-sm font-black uppercase tracking-wider transition shadow-md cursor-pointer border border-[#FF57B2]"
                  >
                    <Crown className="h-4 w-4" />
                    <span>Assinar Leitor (R$ 4,90/mês) para Liberar Missões</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <div className="rounded-2xl bg-[#202020] p-4 border border-[#FF57B2]/40 text-xs text-zinc-200 leading-relaxed">
                <strong className="text-white">Missões Periódicas Ativas:</strong> Realize atividades de leitura e na comunidade para obter recompensas adicionais em XP e Kards. O sistema verifica no backend a ativação da assinatura antes de liberar as recompensas.
              </div>

              {missionFeedback && (
                <div className="rounded-2xl bg-[#262626] p-4 text-xs font-semibold text-white border border-[#FF57B2]/50">
                  {missionFeedback.msg}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {ALL_MISSIONS.map((m) => (
                  <div
                    key={m.id}
                    className="rounded-3xl bg-[#202020] p-5 border border-zinc-800 hover:border-[#FF57B2]/50 transition shadow-xs space-y-3 relative overflow-hidden"
                  >
                    <div className="flex items-center justify-between">
                      <span className="rounded-md bg-[#262626] px-2 py-0.5 text-[10px] font-bold uppercase text-[#FF80C5] border border-[#FF57B2]/30">
                        {m.period === 'daily' ? 'Diária' : 'Semanal'}
                      </span>
                      <div className="flex items-center gap-2 text-xs font-bold tabular-nums">
                        <span className="text-white">+{m.xpReward} XP</span>
                        <span className="text-[#FF80C5] flex items-center gap-0.5">
                          <Coins className="h-3.5 w-3.5 text-[#FF57B2]" /> +{m.kardReward}
                        </span>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-bold text-sm text-white font-display">{m.title}</h3>
                      <p className="text-xs text-zinc-300 mt-0.5 font-literary">{m.description}</p>
                    </div>

                    <div className="pt-2 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
                      <span>Meta: {m.targetCount} atividades</span>
                      <button
                        type="button"
                        onClick={() => handleClaimMission(m.id)}
                        disabled={claimingMissionId === m.id}
                        className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] disabled:opacity-50 text-white px-3.5 py-1.5 text-xs font-bold transition cursor-pointer shadow-xs border border-[#FF57B2]/40"
                      >
                        {claimingMissionId === m.id ? 'Resgatando...' : 'Reivindicar Recompensa'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};
