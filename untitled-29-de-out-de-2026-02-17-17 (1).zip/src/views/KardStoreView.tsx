import {
  ArrowDownLeft,
  ArrowUpRight,
  CheckCircle,
  Clock,
  Coins,
  CreditCard,
  ExternalLink,
  History,
  Loader2,
  QrCode,
  ShieldCheck,
  Sparkles,
  Zap,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { Browser } from '@capacitor/browser';
import { Capacitor } from '@capacitor/core';
import { PixCheckoutModal } from '../components/PixCheckoutModal';
import { PixOrdersTracker } from '../components/PixOrdersTracker';
import { useAuth } from '../context/AuthContext';
import { getApiBaseUrl } from '../services/apiConfig';
import { DEFAULT_KARD_PACKAGES, getUserTransactions } from '../services/kardsService';
import { subscribeUserPixOrders } from '../services/pixService';
import { KardPackage, KardTransaction, PixOrder } from '../types';

interface KardStoreViewProps {
  onOpenAuth: () => void;
}

export const KardStoreView: React.FC<KardStoreViewProps> = ({ onOpenAuth }) => {
  const { currentUser, userProfile } = useAuth();
  const [packages] = useState<KardPackage[]>(DEFAULT_KARD_PACKAGES);
  const [transactions, setTransactions] = useState<KardTransaction[]>([]);
  const [pixOrders, setPixOrders] = useState<PixOrder[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [purchasingPkgId, setPurchasingPkgId] = useState<string | null>(null);
  const [redirectingUrl, setRedirectingUrl] = useState<string | null>(null);
  const [redirectTimeoutWarning, setRedirectTimeoutWarning] = useState(false);
  const [pixModalOpen, setPixModalOpen] = useState(false);
  const [selectedPixPkg, setSelectedPixPkg] = useState<KardPackage | null>(null);
  const [selectedExistingOrder, setSelectedExistingOrder] = useState<PixOrder | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [activeTab, setActiveTab] = useState<'packages' | 'pix_orders' | 'history'>('packages');

  // Assina os pedidos Pix em tempo real para o usuário logado
  useEffect(() => {
    if (!currentUser) {
      setPixOrders([]);
      return;
    }
    const unsub = subscribeUserPixOrders(currentUser.uid, (orders) => {
      setPixOrders(orders);
    });
    return () => unsub();
  }, [currentUser]);

  // Filtra pedidos ativos não expirados
  const activePixOrders = pixOrders.filter((o) => {
    if (o.status === 'completed' || o.status === 'expired') return false;
    const expiresMs = new Date(o.expiresAt).getTime();
    return expiresMs > Date.now() || o.status === 'under_review' || o.status === 'paid';
  });

  const handleOpenPix = (pkg: KardPackage) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    setSelectedExistingOrder(null);
    setSelectedPixPkg(pkg);
    setPixModalOpen(true);
  };

  const handleOpenExistingPixOrder = (order: PixOrder) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    const foundPkg = packages.find((p) => p.id === order.packageId) || {
      id: order.packageId || 'custom',
      title: order.title,
      kards: order.kards,
      priceBrl: order.amountBrl,
    };
    setSelectedPixPkg(foundPkg);
    setSelectedExistingOrder(order);
    setPixModalOpen(true);
  };

  const handlePixSuccess = async () => {
    if (currentUser) {
      try {
        const list = await getUserTransactions(currentUser.uid);
        setTransactions(list);
      } catch (err) {
        console.warn('Erro ao atualizar extrato após Pix:', err);
      }
    }
  };

  useEffect(() => {
    if (!currentUser) return;

    const loadHistory = async () => {
      setLoadingHistory(true);
      try {
        const list = await getUserTransactions(currentUser.uid);
        setTransactions(list);
      } catch (err) {
        console.error('Error fetching transactions:', err);
      } finally {
        setLoadingHistory(false);
      }
    };

    loadHistory();
  }, [currentUser, activeTab]);

  const handleBuyPackage = async (pkg: KardPackage) => {
    const timestamp = new Date().toLocaleTimeString('pt-BR');
    const logPrefix = `[KardStoreView] [${pkg.title}]`;

    console.log(`${logPrefix} [1/6] 🛒 Clique no pacote detectado às ${timestamp}:`, {
      packageId: pkg.id,
      title: pkg.title,
      priceBrl: pkg.priceBrl,
      kardsBase: pkg.kards,
      bonus: pkg.bonus || 0,
      totalKards: pkg.kards + (pkg.bonus || 0),
      userId: currentUser?.uid || null,
      userEmail: currentUser?.email || null,
      clientContext: {
        isNative: Capacitor.isNativePlatform(),
        isInIframe: typeof window !== 'undefined' && window.self !== window.top,
        currentLocation: typeof window !== 'undefined' ? window.location.href : '',
        origin: typeof window !== 'undefined' ? window.location.origin : '',
      },
    });

    if (!currentUser) {
      console.warn(`${logPrefix} Usuário não autenticado. Abrindo modal de autenticação.`);
      onOpenAuth();
      return;
    }

    setPurchasingPkgId(pkg.id);
    setErrorMsg('');
    setRedirectingUrl(null);
    setRedirectTimeoutWarning(false);

    const startTime = performance.now();

    try {
      const apiBase = getApiBaseUrl();
      const endpoint = `${apiBase}/api/create-stripe-checkout`;
      const requestPayload = {
        packageId: pkg.id,
        kards: pkg.kards + (pkg.bonus || 0),
        amountBrl: pkg.priceBrl,
        title: pkg.title,
        userId: currentUser.uid,
        userEmail: currentUser.email,
      };

      console.log(`${logPrefix} [2/6] 🌐 Enviando requisição POST para ${endpoint}:`, requestPayload);

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestPayload),
      });

      const latencyMs = Math.round(performance.now() - startTime);
      console.log(`${logPrefix} [3/6] 📥 Resposta HTTP recebida em ${latencyMs}ms:`, {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok,
        contentType: response.headers.get('content-type'),
      });

      const contentType = response.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        const textFallback = await response.text().catch(() => '');
        console.error(`${logPrefix} Resposta não retornou JSON:`, textFallback.slice(0, 300));
        throw new Error(
          `O servidor de pagamentos retornou uma resposta inesperada (Status ${response.status}). Verifique se o servidor está ativo.`
        );
      }

      const data = await response.json();
      console.log(`${logPrefix} [4/6] 📦 Payload JSON retornado pelo servidor:`, data);

      if (!response.ok) {
        throw new Error(
          data.error || `Falha ao iniciar pagamento com Stripe (Código HTTP ${response.status}).`
        );
      }

      console.log(`${logPrefix} [5/6] 🔍 Validando URL recebida do Stripe Checkout:`, {
        url: data.url,
        sessionId: data.sessionId,
        type: typeof data.url,
      });

      if (!data.url || typeof data.url !== 'string' || !data.url.startsWith('http')) {
        console.error(`${logPrefix} URL inválida retornada pelo backend:`, data);
        throw new Error('URL de redirecionamento do Stripe Checkout inválida retornada pelo servidor.');
      }

      console.log(`${logPrefix} ✅ URL do Stripe Checkout validada com sucesso:`, data.url);

      // Persiste referência de checkout temporária no sessionStorage para sincronização pós-redirecionamento
      try {
        sessionStorage.setItem(
          'pending_stripe_checkout',
          JSON.stringify({
            sessionId: data.sessionId,
            packageId: pkg.id,
            kards: pkg.kards + (pkg.bonus || 0),
            amountBrl: pkg.priceBrl,
            timestamp: Date.now(),
          })
        );
      } catch (e) {
        console.warn(`${logPrefix} Não foi possível armazenar em sessionStorage:`, e);
      }

      // Ativa overlay de transição e feedback visual para evitar travamento em tela branca
      setRedirectingUrl(data.url);

      console.log(`${logPrefix} [6/6] 🚀 Iniciando transição para o Stripe Checkout...`);

      // Tratamento para ambiente móvel nativo (Capacitor)
      if (Capacitor.isNativePlatform()) {
        console.log(
          `${logPrefix} Plataforma Capacitor nativa detectada. Abrindo URL no navegador do sistema via @capacitor/browser.`
        );
        await Browser.open({ url: data.url, windowName: '_system' });
        setPurchasingPkgId(null);
        return;
      }

      // Tratamento para Web:
      const isInIframe = window.self !== window.top;
      console.log(`${logPrefix} Plataforma Web. Está dentro de iframe: ${isInIframe}.`);

      if (isInIframe) {
        console.log(
          `${logPrefix} ⚠️ Iframe detectado. O Stripe bloqueia iframe interno com cabeçalho X-Frame-Options: DENY (causa comum de tela branca).`
        );
        let topNavSucceeded = false;
        try {
          if (window.top) {
            console.log(`${logPrefix} Tentando redirecionar window.top.location.href para o Stripe...`);
            window.top.location.href = data.url;
            topNavSucceeded = true;
          }
        } catch (topErr) {
          console.warn(`${logPrefix} window.top.location bloqueado pela sandbox do iframe:`, topErr);
        }

        if (!topNavSucceeded) {
          window.location.href = data.url;
        }
      } else {
        console.log(`${logPrefix} Janela principal padrão. Atribuindo window.location.href = data.url:`, data.url);
        window.location.href = data.url;
      }

      // Temporizador para acionar aviso de escape caso o navegador demore a navegar
      setTimeout(() => {
        setRedirectTimeoutWarning(true);
      }, 3500);
    } catch (err: any) {
      console.error(`${logPrefix} ❌ Erro durante o fluxo de checkout:`, err);
      setErrorMsg(
        err.message ||
          'Chaves do Stripe não configuradas no servidor ou serviço indisponível.'
      );
      setPurchasingPkgId(null);
      setRedirectingUrl(null);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-8 space-y-8">
      {/* Header */}
      <div className="border-b border-zinc-800 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[#FF57B2] text-xs font-bold uppercase tracking-wider mb-1">
            <Coins className="h-4 w-4" />
            <span>Economia Literária</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-display">
            Loja Oficial de Kards
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Kards são a moeda oficial do KORDEL para publicação de livros, fundação de comunidades e apoio aos autores.
          </p>
        </div>

        {/* Current Balance Display */}
        {currentUser && (
          <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-4 shrink-0 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs">
              <Coins className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase tracking-wider font-bold text-[#FF57B2] block">
                Seu Saldo Atual
              </span>
              <span className="text-xl font-black text-white font-display">
                {userProfile?.kards ?? 0}{' '}
                <span className="text-xs font-semibold text-zinc-400">Kards</span>
              </span>
            </div>
          </div>
        )}
      </div>

      {errorMsg && (
        <div className="rounded-2xl bg-[#262626] p-4 text-xs text-[#FF80C5] border border-[#FF57B2]/50">
          <strong className="text-white">Aviso:</strong> {errorMsg}
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-zinc-800">
        <button
          onClick={() => setActiveTab('packages')}
          className={`px-5 py-3 text-xs sm:text-sm font-bold border-b-2 transition cursor-pointer ${
            activeTab === 'packages'
              ? 'border-[#FF57B2] text-[#FF57B2]'
              : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          Pacotes de Kards
        </button>
        <button
          onClick={() => setActiveTab('pix_orders')}
          className={`px-5 py-3 text-xs sm:text-sm font-bold border-b-2 transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'pix_orders'
              ? 'border-[#FF57B2] text-[#FF57B2]'
              : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          <span>Pedidos Pix em Andamento</span>
          {activePixOrders.length > 0 && (
            <span className="rounded-full bg-[#FF57B2] px-2 py-0.5 text-[10px] font-black text-white shadow-2xs tabular-nums">
              {activePixOrders.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-5 py-3 text-xs sm:text-sm font-bold border-b-2 transition cursor-pointer ${
            activeTab === 'history'
              ? 'border-[#FF57B2] text-[#FF57B2]'
              : 'border-transparent text-zinc-400 hover:text-white'
          }`}
        >
          Extrato de Transações
        </button>
      </div>

      {/* 1. Packages Tab */}
      {activeTab === 'packages' && (
        <div className="space-y-6">
          {/* Banner de Pedido Ativo se houver */}
          {activePixOrders.length > 0 && (
            <div className="rounded-3xl bg-[#202020] border border-[#FF57B2]/50 p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs shadow-xs animate-in fade-in duration-200">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shrink-0 shadow-xs">
                  <Clock className="h-6 w-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <strong className="text-white font-bold text-sm">
                      Você possui {activePixOrders.length} pedido Pix aberto
                    </strong>
                    <span className="rounded-full bg-[#FF57B2]/20 border border-[#FF57B2]/40 px-2 py-0.5 text-[10px] font-black text-[#FF80C5] uppercase">
                      Pendente
                    </span>
                  </div>
                  <p className="text-zinc-300 text-xs mt-0.5">
                    Pacote <strong className="text-white">{activePixOrders[0].title}</strong> (R$ {activePixOrders[0].amountBrl.toFixed(2).replace('.', ',')}) permanece salvo na sua conta aguardando conferência bancária.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => handleOpenExistingPixOrder(activePixOrders[0])}
                  className="flex-1 sm:flex-none rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white font-bold px-4 py-2.5 transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <QrCode className="h-4 w-4" />
                  <span>Ver QR Code / Pagar</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('pix_orders')}
                  className="flex-1 sm:flex-none rounded-xl bg-[#262626] border border-zinc-700 text-zinc-200 font-bold px-3.5 py-2.5 hover:border-[#FF57B2]/60 hover:text-white transition text-center cursor-pointer"
                >
                  Ver Andamento
                </button>
              </div>
            </div>
          )}
          {/* Banner de Destaque Pix Instantâneo */}
          <div className="rounded-3xl bg-[#202020] p-4 sm:p-5 border border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xs">
            <div className="flex items-center gap-3.5">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shrink-0 shadow-md shadow-[#FF57B2]/20">
                <Zap className="h-6 w-6 fill-white" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-black text-white uppercase tracking-wide">
                    Novo: Pix Instantâneo
                  </span>
                  <span className="rounded-full bg-[#FF57B2]/20 px-2 py-0.5 text-[10px] font-black text-[#FF80C5] border border-[#FF57B2]/40">
                    ⚡ Liberação em Segundos
                  </span>
                </div>
                <p className="text-xs text-zinc-300 mt-0.5 leading-relaxed">
                  Pague com QR Code ou Pix Copia e Cola pelo app do seu banco. Os Kards caem na hora na sua carteira!
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0 text-[11px] font-bold text-white bg-[#262626] px-3.5 py-2 rounded-2xl border border-zinc-700 shadow-2xs">
              <ShieldCheck className="h-4 w-4 text-[#FF57B2]" />
              <span>Sem tarifas extras</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {packages.map((pkg) => {
              const totalKards = pkg.kards + (pkg.bonus || 0);

              return (
                <div
                  key={pkg.id}
                  className={`relative flex flex-col justify-between rounded-3xl bg-[#202020] p-6 border transition shadow-xs hover:shadow-xl ${
                    pkg.popular
                      ? 'border-[#FF57B2] ring-2 ring-[#FF57B2]/30 shadow-[0_0_20px_rgba(255,87,178,0.2)]'
                      : 'border-zinc-800 hover:border-[#FF57B2]/50'
                  }`}
                >
                  {pkg.popular && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-3 py-0.5 text-[10px] font-black uppercase tracking-wider text-white shadow-xs whitespace-nowrap">
                      Mais Popular
                    </span>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#262626] text-[#FF57B2] border border-[#FF57B2]/30">
                        <Coins className="h-6 w-6" />
                      </div>
                      {pkg.bonus && (
                        <span className="rounded-lg bg-[#FF57B2]/15 px-2 py-0.5 text-[10px] font-bold text-[#FF80C5] border border-[#FF57B2]/40">
                          +{pkg.bonus} BÔNUS
                        </span>
                      )}
                    </div>

                    <h3 className="font-bold text-base text-white font-display">{pkg.title}</h3>

                    <div className="mt-3 flex items-baseline gap-1 tabular-nums">
                      <span className="text-3xl font-black text-white font-display">
                        {totalKards}
                      </span>
                      <span className="text-xs font-bold uppercase text-[#FF57B2]">Kards</span>
                    </div>

                    <p className="text-xs text-zinc-400 mt-1">
                      {pkg.bonus ? `${pkg.kards} Kards + ${pkg.bonus} de bônus` : 'Carga padrão'}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-zinc-800 space-y-2.5">
                    <div className="flex items-baseline justify-between mb-1 tabular-nums">
                      <span className="text-xs text-zinc-400">Preço único:</span>
                      <span className="text-xl font-black text-white font-display">
                        R$ {pkg.priceBrl.toFixed(2).replace('.', ',')}
                      </span>
                    </div>

                    {/* Botão Principal: Pix Instantâneo */}
                    <button
                      id={`buy-pix-btn-${pkg.id}`}
                      onClick={() => handleOpenPix(pkg)}
                      className="w-full flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] py-3 text-center text-xs font-bold text-white shadow-md shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] active:scale-[0.98] transition cursor-pointer"
                    >
                      <Zap className="h-4 w-4 fill-white text-white" />
                      <span>Pagar com Pix (Instantâneo)</span>
                    </button>

                    {/* Botão Secundário: Cartão via Stripe */}
                    <button
                      id={`buy-card-btn-${pkg.id}`}
                      onClick={() => handleBuyPackage(pkg)}
                      disabled={purchasingPkgId === pkg.id}
                      className="w-full flex items-center justify-center gap-2 rounded-2xl bg-[#262626] border border-zinc-700 py-2.5 text-center text-xs font-bold text-zinc-200 hover:border-[#FF57B2]/60 hover:text-white transition disabled:opacity-50 cursor-pointer"
                    >
                      <CreditCard className="h-3.5 w-3.5 text-[#FF57B2]" />
                      <span>{purchasingPkgId === pkg.id ? 'Iniciando Stripe...' : 'Pagar com Cartão'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Guarantee disclaimer */}
          <div className="rounded-2xl border border-zinc-800 bg-[#202020] p-4 flex items-center gap-3 text-xs text-zinc-300">
            <ShieldCheck className="h-5 w-5 shrink-0 text-[#FF57B2]" />
            <span>
              Pagamentos seguros processados com <strong className="text-white">Pix Instantâneo</strong> e <strong className="text-white">Stripe (Cartão)</strong>. Seus Kards são creditados e auditados em tempo real na sua conta do KORDEL. Sem cobranças recorrentes indesejadas.
            </span>
          </div>
        </div>
      )}

      {/* 2. Pix Orders Tab */}
      {activeTab === 'pix_orders' && (
        <PixOrdersTracker
          orders={pixOrders}
          packages={packages}
          currentUser={currentUser}
          userProfile={userProfile}
          onOpenOrder={handleOpenExistingPixOrder}
          onOrderUpdated={handlePixSuccess}
        />
      )}

      {/* 3. Transactions History Tab */}
      {activeTab === 'history' && (
        <div className="overflow-hidden rounded-3xl bg-[#202020] shadow-xs border border-zinc-800">
          <div className="border-b border-zinc-800 bg-[#262626] px-6 py-3 text-[11px] font-bold uppercase tracking-wider text-zinc-400">
            Extrato Contábil de Kards
          </div>

          {loadingHistory ? (
            <div className="py-16 text-center text-xs text-zinc-400">Carregando histórico...</div>
          ) : transactions.length === 0 ? (
            <div className="py-16 text-center text-xs text-zinc-400">
              Nenhuma movimentação de Kards registrada até o momento.
            </div>
          ) : (
            <div className="divide-y divide-zinc-800">
              {transactions.map((tx) => {
                const isPositive = tx.amount > 0;

                return (
                  <div key={tx.id} className="flex items-center justify-between p-4 text-xs">
                    <div className="flex items-center gap-3">
                      <div
                        className={`flex h-8 w-8 items-center justify-center rounded-xl border ${
                          isPositive
                            ? 'bg-[#FF57B2]/15 text-[#FF57B2] border-[#FF57B2]/40'
                            : 'bg-[#262626] text-zinc-300 border-zinc-700'
                        }`}
                      >
                        {isPositive ? (
                          <ArrowDownLeft className="h-4 w-4" />
                        ) : (
                          <ArrowUpRight className="h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-white">{tx.description}</p>
                        <span className="text-[10px] text-zinc-400">
                          {new Date(tx.createdAt).toLocaleDateString('pt-BR', {
                            day: '2-digit',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    </div>

                    <div
                      className={`text-sm font-black font-display tabular-nums ${
                        isPositive ? 'text-[#FF80C5]' : 'text-zinc-300'
                      }`}
                    >
                      {isPositive ? `+${tx.amount}` : tx.amount} Kards
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Transição Segura para o Stripe Checkout (Prevenção de tela branca) */}
      {redirectingUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-[#202020] p-6 sm:p-8 shadow-2xl border border-zinc-800 text-center space-y-4">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#262626] text-[#FF57B2] border border-[#FF57B2]/40">
              <Loader2 className="h-7 w-7 animate-spin" />
            </div>

            <div>
              <h3 className="text-lg font-black text-white font-display">
                Redirecionando para o Stripe Checkout...
              </h3>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                Você está sendo transferido para o ambiente seguro do Stripe para finalizar o seu pagamento.
              </p>
            </div>

            <div className="pt-2 space-y-2">
              <a
                href={redirectingUrl}
                target="_top"
                rel="noopener noreferrer"
                onClick={() => {
                  console.log(
                    '[KardStoreView] Usuário acionou o link direto para o Stripe Checkout:',
                    redirectingUrl
                  );
                }}
                className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] py-3 text-xs font-bold text-white shadow-md hover:from-[#FF40A4] hover:to-[#D02685] transition"
              >
                <span>Abrir Stripe Checkout Diretamente</span>
                <ExternalLink className="h-4 w-4" />
              </a>

              <button
                onClick={() => {
                  console.log('[KardStoreView] Usuário cancelou a tela de redirecionamento.');
                  setRedirectingUrl(null);
                  setPurchasingPkgId(null);
                }}
                className="w-full rounded-2xl py-2 text-xs font-semibold text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
              >
                Voltar para a Loja
              </button>
            </div>

            {redirectTimeoutWarning && (
              <div className="text-[11px] text-zinc-300 bg-[#262626] p-3 rounded-2xl border border-[#FF57B2]/40 text-left leading-relaxed">
                <strong className="text-[#FF80C5]">Atenção:</strong> Se o seu navegador ou visualizador bloqueou a navegação automática por políticas de quadro (iframe), clique no botão acima para abrir a página de pagamento sem risco de tela branca.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal de Pagamento Instantâneo via Pix */}
      <PixCheckoutModal
        isOpen={pixModalOpen}
        onClose={() => {
          setPixModalOpen(false);
          setSelectedPixPkg(null);
          setSelectedExistingOrder(null);
        }}
        pkg={selectedPixPkg}
        existingOrder={selectedExistingOrder}
        currentUser={currentUser}
        userProfile={userProfile}
        onSuccess={handlePixSuccess}
      />
    </div>
  );
};
