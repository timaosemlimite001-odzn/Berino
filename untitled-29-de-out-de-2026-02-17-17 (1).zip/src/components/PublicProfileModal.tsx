import {
  collection,
  getDocs,
  limit,
  query,
  where,
} from 'firebase/firestore';
import {
  Award,
  BookOpen,
  Calendar,
  Check,
  Crown,
  Eye,
  Hash,
  Loader2,
  Share2,
  ShieldCheck,
  Star,
  User as UserIcon,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { db } from '../services/firebase';
import {
  followUser,
  getFollowCounts,
  subscribeFollowStatus,
  unfollowUser,
} from '../services/followService';
import { PublicUserProfile } from '../services/userService';
import { Book } from '../types';
import { UserBadges } from './UserBadges';

interface PublicProfileModalProps {
  user: PublicUserProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectBook?: (bookId: string) => void;
  onOpenAuth?: () => void;
}

export const PublicProfileModal: React.FC<PublicProfileModalProps> = ({
  user,
  isOpen,
  onClose,
  onSelectBook,
  onOpenAuth,
}) => {
  const { currentUser, userProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<'about' | 'books'>('about');
  const [authorBooks, setAuthorBooks] = useState<Book[]>([]);
  const [loadingBooks, setLoadingBooks] = useState(false);

  // Follow State
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);
  const [followersCount, setFollowersCount] = useState<number>(0);
  const [followingCount, setFollowingCount] = useState<number>(0);
  const [copiedLink, setCopiedLink] = useState(false);

  const isMe = Boolean(currentUser && user && currentUser.uid === user.id);

  // 1. Sync counts & subscribe to real-time follow status
  useEffect(() => {
    if (!isOpen || !user) return;

    setFollowersCount(user.followersCount || 0);
    setFollowingCount(user.followingCount || 0);

    // Fetch accurate live counts
    getFollowCounts(user.id).then(({ followersCount: fCount, followingCount: fIngCount }) => {
      setFollowersCount(fCount);
      setFollowingCount(fIngCount);
    });

    if (!currentUser || currentUser.uid === user.id) {
      setIsFollowing(false);
      return;
    }

    const unsub = subscribeFollowStatus(currentUser.uid, user.id, (status) => {
      setIsFollowing(status);
    });

    return () => unsub();
  }, [isOpen, user?.id, currentUser?.uid]);

  // 2. Fetch author published books if applicable
  useEffect(() => {
    if (!isOpen || !user) {
      setAuthorBooks([]);
      return;
    }

    setLoadingBooks(true);
    const fetchBooks = async () => {
      try {
        const q = query(
          collection(db, 'books'),
          where('authorId', '==', user.id),
          limit(20)
        );
        const snap = await getDocs(q);
        const booksList: Book[] = [];
        snap.forEach((d) => {
          const b = d.data() as Book;
          if (b.status === 'published' || b.status === 'completed') {
            booksList.push(b);
          }
        });
        setAuthorBooks(booksList);
      } catch (err) {
        console.error('Error fetching author books:', err);
      } finally {
        setLoadingBooks(false);
      }
    };

    fetchBooks();
  }, [isOpen, user?.id]);

  if (!isOpen || !user) return null;

  // Toggle Follow
  const handleToggleFollow = async () => {
    if (!currentUser) {
      if (onOpenAuth) onOpenAuth();
      return;
    }
    if (isMe) return;

    setFollowLoading(true);
    try {
      if (isFollowing) {
        await unfollowUser(currentUser.uid, user.id);
        setIsFollowing(false);
        setFollowersCount((prev) => Math.max(0, prev - 1));
      } else {
        await followUser(
          {
            id: currentUser.uid,
            displayName: userProfile?.displayName || 'Leitor',
            photoURL: userProfile?.photoURL || '',
          },
          {
            id: user.id,
            displayName: user.displayName,
          }
        );
        setIsFollowing(true);
        setFollowersCount((prev) => prev + 1);
      }
    } catch (err: any) {
      console.error('Error toggling follow:', err);
    } finally {
      setFollowLoading(false);
    }
  };

  const handleCopyProfileLink = () => {
    const url = `${window.location.origin}/usuario/${user.id}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-lg rounded-3xl bg-[#202020] text-white shadow-2xl border border-zinc-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Top Cover Banner Decoration */}
        <div className="relative h-28 w-full bg-gradient-to-r from-[#262626] via-[#212121] to-[#1A1A1A] p-4 flex items-start justify-between border-b border-zinc-800">
          <div className="flex items-center gap-1.5 text-white text-[11px] font-bold uppercase tracking-wider">
            <UserIcon className="h-3.5 w-3.5 text-[#FF57B2]" />
            <span>Perfil Público Literário</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyProfileLink}
              className="rounded-full bg-zinc-800/90 p-2 text-white hover:bg-zinc-700 backdrop-blur-xs transition cursor-pointer border border-zinc-700 shadow-2xs"
              title="Copiar link do perfil"
            >
              {copiedLink ? <Check className="h-4 w-4 text-[#FF80C5]" /> : <Share2 className="h-4 w-4" />}
            </button>
            <button
              onClick={onClose}
              className="rounded-full bg-zinc-800/90 p-2 text-white hover:bg-zinc-700 backdrop-blur-xs transition cursor-pointer border border-zinc-700 shadow-2xs"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Profile Header & Main Info */}
        <div className="p-6 pt-0 relative space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-12">
            {/* Avatar */}
            <div className="relative">
              <div className="h-24 w-24 overflow-hidden rounded-full border-4 border-[#202020] shadow-xl bg-zinc-950 shrink-0">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-3xl font-black text-[#FF57B2] bg-zinc-900 border border-zinc-800">
                    {user.displayName?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}
              </div>
              {user.isVerifiedWriter && (
                <div
                  className="absolute bottom-1 right-1 rounded-full bg-zinc-900 p-1 shadow-md border border-[#FF57B2]/40"
                  title="Escritor Verificado"
                >
                  <ShieldCheck className="h-5 w-5 text-[#FF57B2]" />
                </div>
              )}
            </div>

            {/* Follow / Edit Button */}
            <div className="flex items-center gap-2">
              {isMe ? (
                <div className="rounded-2xl bg-zinc-800 border border-zinc-700 px-4 py-2 text-xs font-bold text-zinc-300">
                  Seu Perfil
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleToggleFollow}
                  disabled={followLoading}
                  className={`inline-flex items-center gap-2 rounded-2xl px-5 py-2.5 text-xs font-bold transition shadow-sm cursor-pointer ${
                    isFollowing
                      ? 'bg-zinc-800 hover:bg-zinc-750 text-white border border-zinc-700'
                      : 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white shadow-md shadow-[#FF57B2]/30 border border-[#FF57B2]/40'
                  }`}
                >
                  {followLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Processando...</span>
                    </>
                  ) : isFollowing ? (
                    <>
                      <UserCheck className="h-4 w-4 text-[#FF57B2]" />
                      <span>Seguindo</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="h-4 w-4" />
                      <span>Seguir</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Names, Handles, Unique ID */}
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="font-bold text-xl text-white font-display">
                {user.displayName}
              </h2>
              <UserBadges
                userId={user.id}
                isVerified={user.isVerifiedWriter}
                hasExperienced={user.hasExperiencedReaderBadge}
                role={user.role}
                size="sm"
                isLight={false}
              />
            </div>

            <div className="flex items-center gap-2 mt-1 text-xs text-zinc-400 flex-wrap">
              <span className="font-mono text-zinc-300 font-semibold">{user.username}</span>
              <span>•</span>
              <span className="inline-flex items-center gap-0.5 font-mono text-[11px] font-bold text-[#FF57B2] bg-[#FF57B2]/15 px-2 py-0.5 rounded-lg border border-[#FF57B2]/30">
                <Hash className="h-3 w-3" />
                {user.uniqueId}
              </span>
              <span>•</span>
              {(user.level || 0) > 0 ? (
                <span className="rounded-md bg-zinc-800 px-2 py-0.5 text-[10px] font-bold text-[#FF57B2] border border-[#FF57B2]/30 flex items-center gap-1">
                  <Star className="h-3 w-3 fill-[#FF57B2] text-[#FF57B2]" />
                  Nível {user.level} ({user.xp || 0} XP)
                </span>
              ) : (
                <span className="rounded-md bg-zinc-800 px-2 py-0.5 text-[10px] font-semibold text-zinc-400 border border-zinc-700 flex items-center gap-1">
                  Nível 0
                </span>
              )}
            </div>

            {/* Followers & Following Counters */}
            <div className="flex items-center gap-4 mt-3 pt-3 border-t border-zinc-800 text-xs">
              <div className="flex items-center gap-1.5 font-semibold text-zinc-300">
                <Users className="h-4 w-4 text-[#FF57B2]" />
                <strong className="text-white font-bold">{followersCount}</strong>
                <span className="text-zinc-400">seguidores</span>
              </div>
              <span>•</span>
              <div className="flex items-center gap-1.5 font-semibold text-zinc-300">
                <strong className="text-white font-bold">{followingCount}</strong>
                <span className="text-zinc-400">seguindo</span>
              </div>
              {authorBooks.length > 0 && (
                <>
                  <span>•</span>
                  <div className="flex items-center gap-1.5 font-semibold text-zinc-300">
                    <BookOpen className="h-4 w-4 text-[#FF57B2]" />
                    <strong className="text-white font-bold">{authorBooks.length}</strong>
                    <span className="text-zinc-400">obras publicadas</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Active Title Banner */}
          {user.activeTitle && (
            <div className="rounded-2xl bg-[#262626] p-3 text-xs border border-zinc-800 flex items-center gap-2">
              <Crown className="h-4 w-4 text-[#FF57B2] shrink-0" />
              <div>
                <span className="text-[10px] uppercase font-bold text-zinc-400 block">Título de Honra</span>
                <span className="font-bold text-[#FF57B2]">"{user.activeTitle}"</span>
              </div>
            </div>
          )}

          {/* Tab Selection */}
          <div className="flex border-b border-zinc-800 gap-6 pt-1">
            <button
              type="button"
              onClick={() => setActiveTab('about')}
              className={`pb-2.5 text-xs font-bold transition border-b-2 cursor-pointer ${
                activeTab === 'about'
                  ? 'border-[#FF57B2] text-[#FF57B2]'
                  : 'border-transparent text-zinc-400 hover:text-white'
              }`}
            >
              Sobre & Medalhas
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('books')}
              className={`pb-2.5 text-xs font-bold transition border-b-2 flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'books'
                  ? 'border-[#FF57B2] text-[#FF57B2]'
                  : 'border-transparent text-zinc-400 hover:text-white'
              }`}
            >
              <BookOpen className="h-3.5 w-3.5" />
              <span>Obras Publicadas ({authorBooks.length})</span>
            </button>
          </div>

          {/* Tab Content: About */}
          {activeTab === 'about' && (
            <div className="space-y-4 max-h-[36vh] overflow-y-auto pr-1">
              {/* Bio */}
              <div>
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 mb-1">
                  Biografia
                </h4>
                {user.bio ? (
                  <p className="text-xs text-zinc-300 font-literary leading-relaxed bg-[#262626] p-3 rounded-2xl border border-zinc-800">
                    {user.bio}
                  </p>
                ) : (
                  <p className="text-xs text-zinc-500 italic">
                    Nenhuma biografia informada por este membro.
                  </p>
                )}
              </div>

              {/* Badges & Titles */}
              <div className="space-y-2">
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">
                  Condecorações & Medalhas
                </h4>
                <div className="flex flex-wrap gap-2">
                  {user.hasExperiencedReaderBadge && (
                    <span className="inline-flex items-center gap-1 rounded-xl bg-[#262626] border border-[#FF57B2]/40 px-2.5 py-1 text-xs font-bold text-[#FF80C5] shadow-2xs">
                      <Award className="h-3.5 w-3.5 text-[#FF57B2]" />
                      Leitor Experiente
                    </span>
                  )}
                  {user.isVerifiedWriter && (
                    <span className="inline-flex items-center gap-1 rounded-xl bg-zinc-800 text-[#FF57B2] px-2.5 py-1 text-xs font-bold shadow-2xs border border-[#FF57B2]/40">
                      <ShieldCheck className="h-3.5 w-3.5 text-[#FF57B2]" />
                      Escritor Verificado
                    </span>
                  )}
                  {user.titles &&
                    user.titles.map((t, idx) => (
                      <span
                        key={idx}
                        className="rounded-xl bg-zinc-800 px-2.5 py-1 text-xs font-medium text-zinc-300 border border-zinc-700 shadow-2xs"
                      >
                        {t}
                      </span>
                    ))}
                </div>
              </div>

              {/* Member Since */}
              <div className="flex items-center gap-1.5 text-xs text-zinc-400 pt-2 border-t border-zinc-800">
                <Calendar className="h-3.5 w-3.5" />
                <span>
                  Membro do KORDEL desde{' '}
                  {new Date(user.createdAt).toLocaleDateString('pt-BR', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  })}
                </span>
              </div>
            </div>
          )}

          {/* Tab Content: Author Books */}
          {activeTab === 'books' && (
            <div className="space-y-3 max-h-[36vh] overflow-y-auto pr-1">
              {loadingBooks ? (
                <div className="py-8 text-center text-xs text-zinc-400">
                  Carregando publicações do autor...
                </div>
              ) : authorBooks.length === 0 ? (
                <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-6 text-center text-xs text-zinc-400">
                  Este autor ainda não publicou nenhuma obra no catálogo.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {authorBooks.map((b) => (
                    <div
                      key={b.id}
                      onClick={() => {
                        if (onSelectBook) {
                          onSelectBook(b.id);
                          onClose();
                        }
                      }}
                      className="group flex items-center justify-between gap-3 rounded-2xl border border-zinc-800 bg-[#262626] p-3 hover:border-[#FF57B2]/60 hover:shadow-[0_0_15px_rgba(255,87,178,0.2)] transition cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {b.coverUrl ? (
                          <img
                            src={b.coverUrl}
                            alt={b.title}
                            className="h-14 w-10 rounded-lg object-cover border border-zinc-700 shrink-0"
                          />
                        ) : (
                          <div className="flex h-14 w-10 shrink-0 items-center justify-center rounded-lg bg-zinc-800 text-[#FF57B2] font-bold text-xs border border-zinc-700">
                            K
                          </div>
                        )}
                        <div className="min-w-0">
                          <h4 className="font-bold text-xs sm:text-sm text-white group-hover:text-[#FF57B2] transition truncate">
                            {b.title}
                          </h4>
                          <div className="flex items-center gap-2 text-[10px] text-zinc-400 mt-0.5">
                            <span className="text-[#FF57B2] font-semibold">{b.genres?.[0] || 'Literatura'}</span>
                            <span>•</span>
                            <span className="flex items-center gap-0.5 tabular-nums">
                              <Star className="h-3 w-3 fill-[#FF57B2] text-[#FF57B2]" />
                              {b.ratingCount ? (b.ratingSum / b.ratingCount).toFixed(1) : '5.0'}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-0.5">
                              <Eye className="h-3 w-3" />
                              {b.viewsCount || 0}
                            </span>
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        className="rounded-xl bg-zinc-800 group-hover:bg-[#FF57B2] group-hover:text-white px-3 py-1.5 text-[11px] font-bold text-zinc-300 transition shrink-0 border border-zinc-700 group-hover:border-[#FF57B2]"
                      >
                        Acessar Obra
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
