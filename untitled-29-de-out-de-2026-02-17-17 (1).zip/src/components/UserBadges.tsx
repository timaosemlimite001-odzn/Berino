import React, { useEffect, useState } from 'react';
import { ShieldCheck, Sparkles, Star } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getUserCachedData, subscribeUserData, UserBadgeData } from '../services/userService';

export interface UserBadgesProps {
  userId?: string;
  isVerified?: boolean;
  hasExperienced?: boolean;
  role?: string;
  size?: 'xs' | 'sm' | 'md';
  isLight?: boolean; // true if placed on white/light background, false if on dark/colored background
  onlyVerified?: boolean; // if true, only renders writer verified badge if verified, never reader badge or roles
  className?: string;
}

export const UserBadges: React.FC<UserBadgesProps> = ({
  userId,
  isVerified: propVerified,
  hasExperienced: propExperienced,
  role: propRole,
  size = 'xs',
  isLight = false,
  onlyVerified = false,
  className = '',
}) => {
  const { currentUser, userProfile } = useAuth();
  const isSelf = Boolean(currentUser && userId && currentUser.uid === userId);

  const [userData, setUserData] = useState<UserBadgeData | null>(() => {
    if (isSelf && userProfile) {
      return {
        id: userProfile.id,
        displayName: userProfile.displayName || '',
        photoURL: userProfile.photoURL,
        hasExperiencedReaderBadge: Boolean(userProfile.hasExperiencedReaderBadge),
        isVerifiedWriter: Boolean(userProfile.isVerifiedWriter),
        role: userProfile.role || 'leitor',
      };
    }
    if (userId) {
      return getUserCachedData(userId) || null;
    }
    return null;
  });

  useEffect(() => {
    if (isSelf && userProfile) {
      setUserData({
        id: userProfile.id,
        displayName: userProfile.displayName || '',
        photoURL: userProfile.photoURL,
        hasExperiencedReaderBadge: Boolean(userProfile.hasExperiencedReaderBadge),
        isVerifiedWriter: Boolean(userProfile.isVerifiedWriter),
        role: userProfile.role || 'leitor',
      });
      return;
    }

    if (
      propVerified !== undefined &&
      propExperienced !== undefined &&
      propRole !== undefined
    ) {
      // All flags provided by parent props, no need to subscribe
      return;
    }

    if (userId) {
      const unsub = subscribeUserData(userId, (fresh) => {
        setUserData(fresh);
      });
      return unsub;
    }
  }, [isSelf, userProfile, userId, propVerified, propExperienced, propRole]);

  // Priority: explicit prop > resolved user data > fallback false
  const verified = propVerified !== undefined
    ? propVerified
    : Boolean(userData?.isVerifiedWriter && (isSelf ? !userProfile?.isVerifiedWriterSuspended : true));
  const experienced = onlyVerified
    ? false
    : (propExperienced !== undefined ? propExperienced : Boolean(userData?.hasExperiencedReaderBadge));
  const isKardelPro = onlyVerified
    ? false
    : Boolean(isSelf ? userProfile?.hasKardelProBadge : userData?.hasKardelProBadge);
  const userRole = onlyVerified ? '' : (propRole !== undefined ? propRole : (userData?.role || ''));

  const isDev = userRole === 'desenvolvedor';
  const isAdmin = userRole === 'admin';

  // Only Verified Writer and Experienced Reader remain beside the name (Pro is now the energy border around avatar; Dev does not occupy space)
  if (!verified && !experienced) {
    return null;
  }

  const iconSizeClass = size === 'xs' ? 'h-3.5 w-3.5' : size === 'sm' ? 'h-4 w-4' : 'h-4.5 w-4.5';
  const textBadgeClass = size === 'xs' ? 'text-[8.5px] px-1 py-0.2' : 'text-[9.5px] px-1.5 py-0.5';

  return (
    <span className={`inline-flex items-center gap-1 select-none align-middle ${className}`}>
      {/* 1. Selo Escritor Verificado (Aparece do lado do nome) */}
      {verified && (
        <span
          title="Escritor Verificado"
          className="inline-flex items-center text-[#FF57B2] shrink-0 drop-shadow-[0_0_6px_rgba(255,87,178,0.4)]"
        >
          <ShieldCheck className={`${iconSizeClass} fill-[#FF57B2]/20 text-[#FF57B2]`} />
        </span>
      )}

      {/* 2. Selo Leitor Experiente (Aparece do lado do nome) */}
      {experienced && (
        <span
          title="Leitor Experiente"
          className={`inline-flex items-center gap-0.5 rounded font-bold tracking-tight shrink-0 ${textBadgeClass} bg-zinc-800 text-zinc-200 border border-zinc-700 shadow-2xs`}
        >
          <Star className="h-2 w-2 fill-[#FF57B2] text-[#FF57B2]" />
          <span>Experiente</span>
        </span>
      )}
    </span>
  );
};
