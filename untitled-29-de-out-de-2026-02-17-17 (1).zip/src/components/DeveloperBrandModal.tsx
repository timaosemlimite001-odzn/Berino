import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Upload,
  Link,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  BookOpen,
  Feather,
  Flame,
  ScrollText,
  Crown,
  Eye,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useBranding, BrandingData } from '../context/BrandingContext';
import { uploadFileToStorage } from '../services/storageService';

interface DeveloperBrandModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeveloperBrandModal: React.FC<DeveloperBrandModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isDeveloper } = useAuth();
  const { branding, updateBranding, resetToDefault } = useBranding();

  const [appName, setAppName] = useState(branding.appName);
  const [logoType, setLogoType] = useState<'icon' | 'image'>(branding.logoType);
  const [logoUrl, setLogoUrl] = useState(branding.logoUrl || '');
  const [logoIconName, setLogoIconName] = useState<BrandingData['logoIconName']>(
    branding.logoIconName || 'BookOpen'
  );
  const [tagline, setTagline] = useState(branding.tagline);
  const [shortDescription, setShortDescription] = useState(
    branding.shortDescription || ''
  );

  const [uploadingImage, setUploadingImage] = useState(false);
  const [saving, setSaving] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  // Sync with current branding when modal opens
  useEffect(() => {
    if (isOpen) {
      setAppName(branding.appName);
      setLogoType(branding.logoType);
      setLogoUrl(branding.logoUrl || '');
      setLogoIconName(branding.logoIconName || 'BookOpen');
      setTagline(branding.tagline);
      setShortDescription(branding.shortDescription || '');
      setFeedback(null);
      setConfirmReset(false);
    }
  }, [isOpen, branding]);

  if (!isOpen) return null;

  // Security guard: If not developer, render nothing
  if (!isDeveloper) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
        <div className="w-full max-w-md rounded-2xl bg-[#202020] p-6 text-center shadow-2xl border border-[#FF57B2]/40">
          <AlertTriangle className="h-10 w-10 text-[#FF57B2] mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white">
            Acesso Restrito
          </h3>
          <p className="text-sm text-zinc-300 mt-2 mb-6">
            A personalização de marca e logo é de acesso exclusivo para a conta do desenvolvedor da plataforma.
          </p>
          <button
            onClick={onClose}
            className="rounded-xl bg-zinc-800 text-white px-5 py-2 text-sm font-semibold hover:bg-zinc-700 transition cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    );
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadingImage(true);
      setFeedback(null);
      const uploadedUrl = await uploadFileToStorage(file, 'banners', 'app_logo');
      setLogoUrl(uploadedUrl);
      setLogoType('image');
      setFeedback({
        type: 'success',
        message: 'Imagem do logo enviada e comprimida com sucesso!',
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err.message || 'Erro ao enviar arquivo do logo.',
      });
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!appName.trim()) {
      setFeedback({
        type: 'error',
        message: 'O nome do aplicativo não pode ficar vazio.',
      });
      return;
    }

    try {
      setSaving(true);
      setFeedback(null);
      await updateBranding({
        appName: appName.trim(),
        logoType,
        logoUrl: logoType === 'image' ? logoUrl.trim() : '',
        logoIconName,
        tagline: tagline.trim(),
        shortDescription: shortDescription.trim(),
      });
      setFeedback({
        type: 'success',
        message: 'Identidade e marca atualizadas com sucesso para toda a plataforma!',
      });
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err.message || 'Erro ao salvar alterações no Firebase.',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    if (!confirmReset) {
      setConfirmReset(true);
      return;
    }
    try {
      setSaving(true);
      setConfirmReset(false);
      await resetToDefault();
      setAppName('KORDEL');
      setLogoType('icon');
      setLogoUrl('');
      setLogoIconName('BookOpen');
      setTagline('Plataforma soberana de leitura & publicação independente');
      setShortDescription('Plataforma soberana de leitura & publicação independente. Valorizando a literatura autoral, a métrica dos versos e a voz livre dos escritores e leitores independentes.');
      setFeedback({
        type: 'success',
        message: 'Padrão original KORDEL restaurado com sucesso.',
      });
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err.message || 'Erro ao restaurar padrão.',
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl rounded-3xl bg-[#202020] p-5 sm:p-7 shadow-2xl border border-zinc-800 my-8 animate-in fade-in zoom-in-95 duration-200 text-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-[0_0_12px_rgba(255,87,178,0.4)] border border-[#FF57B2]/50">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black font-display text-white">
                  Identidade do Aplicativo
                </h2>
                <span className="rounded-full bg-[#FF57B2]/20 border border-[#FF57B2]/40 px-2 py-0.5 text-[9px] font-black uppercase text-[#FF57B2]">
                  Apenas Desenvolvedor
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Altere o nome e o logo exibidos em toda a interface do KORDEL.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Live Preview Bar */}
        <div className="mt-4 rounded-2xl bg-[#262626] border border-zinc-800 p-3.5 space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-zinc-400">
            <span className="flex items-center gap-1">
              <Eye className="h-3.5 w-3.5 text-[#FF57B2]" />
              <span>Pré-visualização em Tempo Real (Cabeçalho)</span>
            </span>
            <span className="text-[10px] text-zinc-400 font-normal">
              Como aparecerá na barra superior
            </span>
          </div>

          <div className="flex items-center gap-3 rounded-xl bg-[#202020] p-2.5 border border-zinc-800 shadow-2xs">
            {/* Logo Preview */}
            {logoType === 'image' && logoUrl ? (
              <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-xl border border-zinc-700 bg-zinc-900 p-1 flex items-center justify-center shadow-[0_0_12px_rgba(255,87,178,0.3)]">
                <img
                  src={logoUrl}
                  alt={appName}
                  className="h-full w-full object-contain"
                />
              </div>
            ) : (
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-sm shadow-[#FF57B2]/40 border border-[#FF57B2]/50">
                {logoIconName === 'Feather' && <Feather className="h-5 w-5" />}
                {logoIconName === 'Flame' && <Flame className="h-5 w-5" />}
                {logoIconName === 'Sparkles' && <Sparkles className="h-5 w-5" />}
                {logoIconName === 'ScrollText' && <ScrollText className="h-5 w-5" />}
                {logoIconName === 'Crown' && <Crown className="h-5 w-5" />}
                {(!logoIconName || logoIconName === 'BookOpen') && (
                  <BookOpen className="h-5 w-5" />
                )}
              </div>
            )}

            <div>
              <span className="text-lg font-black tracking-wider text-white font-display">
                {appName || 'KORDEL'}
              </span>
              <p className="text-[10px] text-zinc-400 truncate max-w-xs">
                {tagline || 'Plataforma soberana de leitura'}
              </p>
            </div>
          </div>
        </div>

        {/* Feedback alert */}
        {feedback && (
          <div
            className={`mt-4 flex items-center gap-2 rounded-xl p-3 text-xs font-semibold ${
              feedback.type === 'success'
                ? 'bg-[#262626] text-white border border-[#FF57B2]/40'
                : 'bg-[#262626] text-[#FF80C5] border border-[#FF57B2]/50'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 className="h-4 w-4 shrink-0 text-[#FF57B2]" />
            ) : (
              <AlertTriangle className="h-4 w-4 shrink-0 text-[#FF57B2]" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSave} className="mt-4 space-y-4">
          {/* Nome do Aplicativo */}
          <div>
            <label className="block text-xs font-bold text-zinc-200 mb-1">
              Nome da Plataforma / App
            </label>
            <input
              type="text"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              placeholder="Ex: KORDEL"
              maxLength={30}
              required
              className="w-full rounded-xl border border-zinc-700 bg-zinc-900 px-3.5 py-2.5 text-sm font-bold text-white focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] transition"
            />
            <p className="text-[10px] text-zinc-400 mt-1">
              Atualiza o nome na barra de navegação, rodapé, modais e título da aba.
            </p>
          </div>

          {/* Formato do Logo */}
          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5">
              Tipo de Logo
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setLogoType('icon')}
                className={`flex items-center justify-center gap-2 rounded-xl py-2 px-3 text-xs font-bold border transition cursor-pointer ${
                  logoType === 'icon'
                    ? 'border-[#FF57B2] bg-[#FF57B2]/20 text-[#FF57B2] shadow-2xs'
                    : 'border-zinc-750 bg-zinc-900 text-zinc-300 hover:bg-zinc-800'
                }`}
              >
                <BookOpen className="h-4 w-4" />
                <span>Ícone Estilizado</span>
              </button>
              <button
                type="button"
                onClick={() => setLogoType('image')}
                className={`flex items-center justify-center gap-2 rounded-xl py-2 px-3 text-xs font-bold border transition cursor-pointer ${
                  logoType === 'image'
                    ? 'border-[#FF57B2] bg-[#FF57B2]/20 text-[#FF57B2] shadow-2xs'
                    : 'border-zinc-750 bg-zinc-900 text-zinc-300 hover:bg-zinc-800'
                }`}
              >
                <Upload className="h-4 w-4" />
                <span>Imagem Personalizada</span>
              </button>
            </div>
          </div>

          {/* Opção Ícone */}
          {logoType === 'icon' ? (
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5">
                Escolha o Símbolo do Logo
              </label>
              <div className="grid grid-cols-6 gap-2">
                {[
                  { id: 'BookOpen', label: 'Livro', icon: BookOpen },
                  { id: 'Feather', label: 'Pena', icon: Feather },
                  { id: 'Flame', label: 'Chama', icon: Flame },
                  { id: 'Sparkles', label: 'Brilho', icon: Sparkles },
                  { id: 'ScrollText', label: 'Pergaminho', icon: ScrollText },
                  { id: 'Crown', label: 'Coroa', icon: Crown },
                ].map((item) => {
                  const Icon = item.icon;
                  const isSelected = logoIconName === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setLogoIconName(item.id as any)}
                      className={`flex flex-col items-center justify-center p-2 rounded-xl border transition cursor-pointer ${
                        isSelected
                          ? 'border-[#FF57B2] bg-[#FF57B2]/25 text-[#FF57B2] ring-2 ring-[#FF57B2]/30'
                          : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white'
                      }`}
                      title={item.label}
                    >
                      <Icon className="h-5 w-5 mb-0.5" />
                      <span className="text-[9px] font-semibold">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Opção Imagem */
            <div className="space-y-2.5">
              <label className="block text-xs font-bold text-zinc-300">
                Arquivo ou URL do Logo
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-2">
                <label className="flex-1 w-full flex items-center justify-center gap-2 rounded-xl border border-dashed border-[#FF57B2]/60 bg-[#FF57B2]/10 py-2.5 px-3 text-xs font-bold text-[#FF57B2] hover:bg-[#FF57B2]/20 cursor-pointer transition">
                  <Upload className="h-4 w-4" />
                  <span>{uploadingImage ? 'Enviando...' : 'Carregar Imagem do Dispositivo'}</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/svg+xml"
                    onChange={handleFileUpload}
                    disabled={uploadingImage}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                  <Link className="h-3.5 w-3.5" />
                </span>
                <input
                  type="url"
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  placeholder="Ou cole a URL direta da imagem (ex: https://...)"
                  className="w-full rounded-xl border border-zinc-700 bg-zinc-900 pl-9 pr-3 py-2 text-xs text-white focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] transition"
                />
              </div>
            </div>
          )}

          {/* Slogan / Descrição do Rodapé */}
          <div className="pt-1">
            <label className="block text-xs font-bold text-zinc-300 mb-1">
              Apresentação Curta do Rodapé ("Quem Somos")
            </label>
            <textarea
              rows={2}
              value={shortDescription}
              onChange={(e) => setShortDescription(e.target.value)}
              placeholder="Descrição exibida no rodapé institucional..."
              className="w-full rounded-xl border border-zinc-700 bg-zinc-900 px-3 py-2 text-xs text-white focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] transition"
            />
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-zinc-800">
            <button
              type="button"
              onClick={handleReset}
              disabled={saving}
              className={`flex items-center gap-1.5 text-xs font-semibold transition cursor-pointer self-start sm:self-auto ${
                confirmReset
                  ? 'text-[#FF80C5] bg-[#FF57B2]/15 border border-[#FF57B2]/40 px-2.5 py-1 rounded-lg'
                  : 'text-zinc-400 hover:text-[#FF57B2]'
              }`}
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>{confirmReset ? 'Confirmar Restauração KORDEL?' : 'Restaurar Padrão (KORDEL)'}</span>
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none rounded-xl border border-zinc-700 bg-zinc-850 px-4 py-2 text-xs font-bold text-zinc-300 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={saving || uploadingImage}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#FF57B2] via-[#F43F9A] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-5 py-2 text-xs font-black text-white shadow-md shadow-[#FF57B2]/30 hover:shadow-[0_0_15px_rgba(255,87,178,0.5)] border border-[#FF57B2]/50 transition cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>{saving ? 'Gravando...' : 'Salvar Alterações'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
