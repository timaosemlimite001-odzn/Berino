import {
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc
} from 'firebase/firestore';
import {
  AlertTriangle,
  AtSign,
  BarChart3,
  Bookmark,
  Check,
  ChevronUp,
  CornerDownRight,
  Crown,
  Edit2,
  Eye,
  EyeOff,
  Heart,
  Loader2,
  Lock,
  MessageSquare,
  MoreVertical,
  Send,
  Share2,
  ThumbsDown,
  Trash2,
  Unlock,
  X
} from 'lucide-react';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db, sanitizeFirestoreData } from '../services/firebase';
import {
  extractPostMediaItems,
  getFavoriteDocId,
  toggleFluxPostFavorite,
} from '../services/fluxService';
import { sendNotification } from '../services/progressionService';
import { Community, CommunityComment, CommunityPost, FluxFeedItem, PollOption } from '../types';
import { ConfirmModal } from './ConfirmModal';
import { FluxStoryStage } from './FluxStoryStage';
import { UserAvatar } from './UserAvatar';
import { UserBadges } from './UserBadges';
import { UserDisplayName } from './UserDisplayName';

interface CommunityFeedCardProps {
  post: CommunityPost;
  community: Community;
  isCreator: boolean;
  isMember: boolean;
  isModerator?: boolean;
  isBanned: boolean;
  isSilenced: boolean;
  onOpenAuth: () => void;
  onReportPost: (post: CommunityPost) => void;
  onPostDeleted?: (postId: string) => void;
  onOpenComments?: () => void;
  onCollapseComments?: () => void;
  isExclusiveFullView?: boolean;
}

export const CommunityFeedCard: React.FC<CommunityFeedCardProps> = ({
  post,
  community,
  isCreator,
  isMember,
  isModerator = false,
  isBanned,
  isSilenced,
  onOpenAuth,
  onReportPost,
  onPostDeleted,
  onOpenComments,
  onCollapseComments,
  isExclusiveFullView = false,
}) => {
  const { currentUser, userProfile } = useAuth();
  const { openUserProfile } = usePublicProfile();
  const { addToast } = useNotifications();

  // Post Actions State
  const [showMenu, setShowMenu] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(post.content);
  const [savingEdit, setSavingEdit] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [togglingSave, setTogglingSave] = useState(false);
  const [cardMediaIdx, setCardMediaIdx] = useState(0);
  const [togglingPostPrivacy, setTogglingPostPrivacy] = useState(false);

  const fluxCompatibleItem = useMemo<FluxFeedItem>(
    () => ({
      ...post,
      communityId: community.id,
      postSource: 'community',
      communityName: community.name,
      communityCoverUrl:
        community.iconUrl ||
        community.avatarUrl ||
        community.coverUrl ||
        community.bannerUrl ||
        '',
      communityCreatorId: community.creatorId,
    }),
    [post, community]
  );

  useEffect(() => {
    if (!currentUser || !post.id || !community.id) {
      setIsSaved(false);
      return;
    }
    let cancelled = false;
    const favId = getFavoriteDocId({
      postSource: 'community',
      communityId: community.id,
      id: post.id,
    });
    getDoc(doc(db, 'users', currentUser.uid, 'favoritePosts', favId))
      .then((snap) => {
        if (!cancelled) {
          setIsSaved(snap.exists());
        }
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [currentUser?.uid, post.id, community.id]);

  // Deletion Modal State
  const [deleteModalState, setDeleteModalState] = useState<{
    isOpen: boolean;
    type: 'post' | 'comment';
    comment?: CommunityComment;
    title: string;
    message: string;
  }>({
    isOpen: false,
    type: 'post',
    title: '',
    message: '',
  });
  const [isDeleting, setIsDeleting] = useState(false);

  // Poll voting
  const [votingPoll, setVotingPoll] = useState(false);

  // Thread comments state (in standalone exclusive view, always shown)
  const [showComments, setShowComments] = useState(isExclusiveFullView);
  const [comments, setComments] = useState<CommunityComment[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [newCommentText, setNewCommentText] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);
  const [replyTarget, setReplyTarget] = useState<{ id: string; authorName: string; authorId?: string } | null>(null);
  const [collapsedThreads, setCollapsedThreads] = useState<Record<string, boolean>>({});
  const commentInputRef = useRef<HTMLInputElement>(null);
  const fixedCommentInputRef = useRef<HTMLInputElement>(null);

  // Editing state for comments and replies
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editCommentText, setEditCommentText] = useState('');
  const [savingCommentEdit, setSavingCommentEdit] = useState(false);

  // Lightbox
  const [showImageLightbox, setShowImageLightbox] = useState(false);

  const isPostAuthor = currentUser?.uid === post.authorId;
  const isDev = userProfile?.role === 'desenvolvedor';
  const canDeletePost = isPostAuthor || isCreator || isModerator || isDev;
  const canManagePostPrivacy = isPostAuthor || isCreator || isModerator || isDev;
  const postMediaItems = useMemo(() => extractPostMediaItems(post), [post]);
  const hasStoryCanvasTexts = Boolean(
    post.storyCanvas?.texts?.some(
      (t) => typeof t.text === 'string' && t.text.trim().length > 0
    )
  );
  const useStoryStage =
    hasStoryCanvasTexts ||
    postMediaItems.length > 1 ||
    post.imageFormat === 'story' ||
    postMediaItems.some((m) => m.type === 'video');

  const handleTogglePostPrivacyField = async (
    field: 'isPrivate' | 'isHiddenFromNonMembers'
  ) => {
    if (!canManagePostPrivacy || togglingPostPrivacy) return;
    setShowMenu(false);
    setTogglingPostPrivacy(true);
    const nextVal = !Boolean(post[field]);
    try {
      await updateDoc(doc(db, 'communities', community.id, 'posts', post.id), {
        [field]: nextVal,
      });
      addToast({
        id: `post_priv_${post.id}_${Date.now()}`,
        type: 'system',
        title:
          field === 'isPrivate'
            ? nextVal
              ? 'Publicação privada'
              : 'Publicação aberta na comunidade'
            : nextVal
            ? 'Oculta para não-membros'
            : 'Visível conforme a comunidade',
        message:
          field === 'isPrivate'
            ? nextVal
              ? 'Apenas participantes ativos desta comunidade podem visualizar.'
              : 'Restrição privada individual removida desta publicação.'
            : nextVal
            ? 'Esta publicação não aparecerá para quem não faz parte da comunidade.'
            : 'Ocultação individual para não-membros desativada.',
      });
    } catch (err) {
      console.error('Error updating post privacy:', err);
    } finally {
      setTogglingPostPrivacy(false);
    }
  };

  const checkCanDeleteComment = (comment: CommunityComment) => {
    return (
      currentUser?.uid === comment.userId ||
      isPostAuthor ||
      isCreator ||
      isModerator ||
      isDev
    );
  };
  const hasLiked = Boolean(currentUser && post.likedUserIds?.includes(currentUser.uid));
  const hasDisliked = Boolean(currentUser && post.dislikedUserIds?.includes(currentUser.uid));

  // Load comments when comments section is opened
  useEffect(() => {
    if (!showComments || !community.id || !post.id) return;
    setLoadingComments(true);

    const q = query(
      collection(db, 'communities', community.id, 'posts', post.id, 'comments'),
      orderBy('createdAt', 'asc')
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: CommunityComment[] = [];
        snap.forEach((d) => list.push(d.data() as CommunityComment));
        setComments(list);
        setLoadingComments(false);
      },
      (err) => {
        console.error('Error loading comments:', err);
        setLoadingComments(false);
      }
    );

    return () => unsub();
  }, [showComments, community.id, post.id]);

  // Toggle Like (Atomically updates likedUserIds & likesCount)
  const handleToggleLike = async () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const postRef = doc(db, 'communities', community.id, 'posts', post.id);

    try {
      if (hasLiked) {
        // Unlike
        const newLikes = Math.max(0, (post.likesCount || 1) - 1);
        await updateDoc(postRef, {
          likedUserIds: arrayRemove(currentUser.uid),
          likesCount: newLikes,
        });
      } else {
        // Like (and remove dislike if present)
        const newLikes = (post.likesCount || 0) + 1;
        const updates: any = {
          likedUserIds: arrayUnion(currentUser.uid),
          likesCount: newLikes,
        };
        if (hasDisliked) {
          updates.dislikedUserIds = arrayRemove(currentUser.uid);
          updates.dislikesCount = Math.max(0, (post.dislikesCount || 1) - 1);
        }
        await updateDoc(postRef, updates);
      }
    } catch (err) {
      console.error('Error toggling like:', err);
    }
  };

  // Toggle Dislike (Atomically updates dislikedUserIds & dislikesCount)
  const handleToggleDislike = async () => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const postRef = doc(db, 'communities', community.id, 'posts', post.id);

    try {
      if (hasDisliked) {
        // Undislike
        const newDislikes = Math.max(0, (post.dislikesCount || 1) - 1);
        await updateDoc(postRef, {
          dislikedUserIds: arrayRemove(currentUser.uid),
          dislikesCount: newDislikes,
        });
      } else {
        // Dislike (and remove like if present)
        const newDislikes = (post.dislikesCount || 0) + 1;
        const updates: any = {
          dislikedUserIds: arrayUnion(currentUser.uid),
          dislikesCount: newDislikes,
        };
        if (hasLiked) {
          updates.likedUserIds = arrayRemove(currentUser.uid);
          updates.likesCount = Math.max(0, (post.likesCount || 1) - 1);
        }
        await updateDoc(postRef, updates);
      }
    } catch (err) {
      console.error('Error toggling dislike:', err);
    }
  };

  // Vote on Poll
  const handleVotePoll = async (optionId: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (!post.poll) return;

    const hasVoted =
      post.poll.voterIds?.includes(currentUser.uid) ||
      post.poll.options.some((opt) => opt.voterIds?.includes(currentUser.uid));

    if (hasVoted) return;

    setVotingPoll(true);
    try {
      const updatedOptions: PollOption[] = post.poll.options.map((opt) => {
        if (opt.id === optionId) {
          return {
            ...opt,
            votesCount: (opt.votesCount || 0) + 1,
            voterIds: [...(opt.voterIds || []), currentUser.uid],
          };
        }
        return opt;
      });

      await updateDoc(doc(db, 'communities', community.id, 'posts', post.id), {
        poll: {
          question: post.poll.question,
          options: updatedOptions,
          totalVotes: (post.poll.totalVotes || 0) + 1,
          voterIds: [...(post.poll.voterIds || []), currentUser.uid],
        },
      });
    } catch (err) {
      console.error('Error voting on poll:', err);
    } finally {
      setVotingPoll(false);
    }
  };

  // Self-heal and sync current user photo & nickname in real-time if post was authored by currentUser
  useEffect(() => {
    if (
      currentUser &&
      userProfile?.displayName &&
      post.authorId === currentUser.uid &&
      (post.authorName !== userProfile.displayName || (userProfile.photoURL && post.authorPhoto !== userProfile.photoURL))
    ) {
      updateDoc(doc(db, 'communities', community.id, 'posts', post.id), {
        authorName: userProfile.displayName,
        ...(userProfile.photoURL ? { authorPhoto: userProfile.photoURL } : {}),
      }).catch(() => {});
    }
  }, [currentUser?.uid, userProfile?.displayName, userProfile?.photoURL, post.id, post.authorId, post.authorName, post.authorPhoto, community.id]);

  // Self-heal and sync current user comments & replies in real-time when loaded
  useEffect(() => {
    if (!currentUser || !userProfile?.displayName || comments.length === 0) return;
    comments.forEach((c) => {
      if (
        c.userId === currentUser.uid &&
        (c.userName !== userProfile.displayName || (userProfile.photoURL && c.userPhoto !== userProfile.photoURL))
      ) {
        updateDoc(doc(db, 'communities', community.id, 'posts', post.id, 'comments', c.id), {
          userName: userProfile.displayName,
          ...(userProfile.photoURL ? { userPhoto: userProfile.photoURL } : {}),
        }).catch(() => {});
      }
    });
  }, [comments, currentUser?.uid, userProfile?.displayName, userProfile?.photoURL, community.id, post.id]);

  // Comment and reply editing handlers
  const handleStartEditComment = (comment: CommunityComment) => {
    setEditingCommentId(comment.id);
    setEditCommentText(comment.content);
  };

  const handleCancelEditComment = () => {
    setEditingCommentId(null);
    setEditCommentText('');
  };

  const handleSaveCommentEdit = async (commentId: string) => {
    if (!currentUser || !editCommentText.trim()) return;
    setSavingCommentEdit(true);
    try {
      await updateDoc(doc(db, 'communities', community.id, 'posts', post.id, 'comments', commentId), {
        content: editCommentText.trim(),
        editedAt: new Date().toISOString(),
      });
      setComments((prev) =>
        prev.map((c) =>
          c.id === commentId
            ? { ...c, content: editCommentText.trim(), editedAt: new Date().toISOString() }
            : c
        )
      );
      setEditingCommentId(null);
      setEditCommentText('');
    } catch (err) {
      console.error('Error saving comment edit:', err);
    } finally {
      setSavingCommentEdit(false);
    }
  };

  // Prompt delete post
  const promptDeletePost = () => {
    if (!canDeletePost) return;
    setShowMenu(false);
    setDeleteModalState({
      isOpen: true,
      type: 'post',
      title: isPostAuthor ? 'Excluir sua publicação?' : 'Remover publicação (Moderação)',
      message: isPostAuthor
        ? 'Tem certeza de que deseja excluir sua publicação? Esta ação é definitiva e removerá a publicação e suas respostas.'
        : 'Como moderador ou desenvolvedor, deseja remover esta publicação indesejada da comunidade?',
    });
  };

  // Prompt delete comment
  const promptDeleteComment = (comment: CommunityComment) => {
    if (!checkCanDeleteComment(comment)) return;
    const isAuthorOfComment = currentUser?.uid === comment.userId;
    setDeleteModalState({
      isOpen: true,
      type: 'comment',
      comment,
      title: isAuthorOfComment ? 'Excluir seu comentário?' : 'Remover comentário (Moderação)',
      message: isAuthorOfComment
        ? 'Deseja excluir seu comentário permanentemente?'
        : `Deseja remover o comentário de "${comment.userName}" desta publicação?`,
    });
  };

  // Execute deletion confirmed via modal
  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    try {
      if (deleteModalState.type === 'post') {
        await deleteDoc(doc(db, 'communities', community.id, 'posts', post.id));
        const updatedCount = Math.max(0, (community.postsCount || 1) - 1);
        try {
          await updateDoc(doc(db, 'communities', community.id), {
            postsCount: updatedCount,
          });
        } catch {
          // ignore
        }
        if (onPostDeleted) onPostDeleted(post.id);
      } else if (deleteModalState.type === 'comment' && deleteModalState.comment) {
        const targetComment = deleteModalState.comment;
        await deleteDoc(
          doc(db, 'communities', community.id, 'posts', post.id, 'comments', targetComment.id)
        );
        const updatedCount = Math.max(0, (post.commentsCount || 1) - 1);
        try {
          await updateDoc(doc(db, 'communities', community.id, 'posts', post.id), {
            commentsCount: updatedCount,
          });
        } catch {
          // ignore
        }
        setComments((prev) => prev.filter((c) => c.id !== targetComment.id));
      }
      setDeleteModalState((prev) => ({ ...prev, isOpen: false }));
    } catch (err: any) {
      console.error('Error deleting:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  // Save Edited Post
  const handleSaveEdit = async () => {
    if (!isPostAuthor || !editContent.trim()) return;
    setSavingEdit(true);
    try {
      await updateDoc(doc(db, 'communities', community.id, 'posts', post.id), {
        content: editContent.trim(),
        editedAt: new Date().toISOString(),
      });
      setIsEditing(false);
    } catch (err) {
      console.error('Error editing post:', err);
    } finally {
      setSavingEdit(false);
    }
  };

  // Add Comment (Threaded with parentId & replyToAuthorName)
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (isBanned || isSilenced || !newCommentText.trim()) return;

    setSubmittingComment(true);
    try {
      const commentId = `comment_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

      // Detect mentions
      const detectedMentions: string[] = [];
      const mentionRegex = /@([a-zA-Z0-9_À-ÿ.-]+)/g;
      let match;
      while ((match = mentionRegex.exec(newCommentText)) !== null) {
        detectedMentions.push(match[1]);
      }

      const newComment: Partial<CommunityComment> & Record<string, any> = {
        id: commentId,
        postId: post.id,
        communityId: community.id,
        userId: currentUser.uid,
        userName: userProfile?.displayName || 'Leitor',
        userPhoto: userProfile?.photoURL || '',
        content: newCommentText.trim(),
        mentions: detectedMentions,
        likesCount: 0,
        createdAt: new Date().toISOString(),
      };

      if (replyTarget?.id) {
        newComment.parentId = replyTarget.id;
      }
      if (replyTarget?.authorName) {
        newComment.replyToAuthorName = replyTarget.authorName;
      }

      await updateDoc(doc(db, 'communities', community.id, 'posts', post.id), {
        commentsCount: (post.commentsCount || 0) + 1,
      });

      const commentDocRef = doc(
        db,
        'communities',
        community.id,
        'posts',
        post.id,
        'comments',
        commentId
      );
      await setDoc(commentDocRef, sanitizeFirestoreData(newComment));

      // Notify mentioned user if this is a reply or contains mentions
      if (replyTarget?.authorId && replyTarget.authorId !== currentUser.uid) {
        await sendNotification(
          replyTarget.authorId,
          'mention',
          `${userProfile?.displayName || 'Um participante'} mencionou você`,
          `${userProfile?.displayName || 'Um participante'} mencionou você em uma resposta: "${newCommentText.trim().slice(0, 70)}"`,
          `/comunidades`
        );
      }

      setNewCommentText('');
      setReplyTarget(null);
    } catch (err) {
      console.error('Error posting comment:', err);
    } finally {
      setSubmittingComment(false);
    }
  };

  // Toggle Comment or Reply Like
  const handleToggleCommentLike = async (comment: CommunityComment) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    const commentRef = doc(
      db,
      'communities',
      community.id,
      'posts',
      post.id,
      'comments',
      comment.id
    );
    const hasLikedComment = Boolean(currentUser && comment.likedUserIds?.includes(currentUser.uid));
    try {
      if (hasLikedComment) {
        await updateDoc(commentRef, {
          likedUserIds: arrayRemove(currentUser.uid),
          likesCount: Math.max(0, (comment.likesCount || 1) - 1),
        });
      } else {
        await updateDoc(commentRef, {
          likedUserIds: arrayUnion(currentUser.uid),
          likesCount: (comment.likesCount || 0) + 1,
        });
      }
    } catch (err) {
      console.error('Error toggling comment like:', err);
    }
  };

  // Start reply with @username auto-inserted
  const handleInitiateReply = (targetComment: CommunityComment) => {
    const rawAuthor = targetComment.userName || 'leitor';
    const cleanAuthor = rawAuthor.trim().replace(/\s+/g, '_');
    setReplyTarget({
      id: targetComment.parentId || targetComment.id,
      authorName: targetComment.userName || 'Leitor',
      authorId: targetComment.userId || targetComment.authorId || '',
    });
    setNewCommentText(`@${cleanAuthor} `);
    setTimeout(() => {
      fixedCommentInputRef.current?.focus();
    }, 80);
  };

  // Share post link
  const handleShare = () => {
    const shareUrl = `${window.location.origin}/?comunidade=${community.id}&post=${post.id}`;
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Save / Unsave post to personal collection (Library -> Salvos -> Publicações Salvas)
  const handleToggleSavePost = async () => {
    setShowMenu(false);
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    if (togglingSave) return;

    const previousSaved = isSaved;
    setIsSaved(!previousSaved);
    setTogglingSave(true);

    try {
      const nextSaved = await toggleFluxPostFavorite(
        fluxCompatibleItem,
        currentUser.uid,
        previousSaved
      );
      setIsSaved(nextSaved);
      addToast({
        id: `save_comm_post_${post.id}_${Date.now()}`,
        type: 'system',
        title: nextSaved ? 'Publicação salva!' : 'Removida dos salvos',
        message: nextSaved
          ? 'Disponível em Biblioteca > Salvos > Publicações Salvas.'
          : 'A publicação foi removida da sua lista de salvos.',
      });
    } catch {
      setIsSaved(previousSaved);
      addToast({
        id: `save_comm_err_${Date.now()}`,
        type: 'system',
        title: 'Erro ao salvar',
        message: 'Não foi possível atualizar os salvos agora.',
      });
    } finally {
      setTogglingSave(false);
    }
  };

  // Render text with highlighted @mentions
  const renderFormattedText = (text: string) => {
    const parts = text.split(/(@[a-zA-Z0-9_À-ÿ.-]+)/g);
    return (
      <span>
        {parts.map((part, index) => {
          if (part.startsWith('@')) {
            const rawName = part.substring(1).replace(/_/g, ' ');
            return (
              <span
                key={index}
                className="inline-flex items-center gap-0.5 rounded-md bg-[#FF57B2]/15 text-[#FF57B2] font-bold px-1.5 py-0.5 text-[11px] border border-[#FF57B2]/40 mr-1"
              >
                <AtSign className="h-2.5 w-2.5 inline" />
                {rawName}
              </span>
            );
          }
          return <span key={index}>{part}</span>;
        })}
      </span>
    );
  };

  // Format date
  const formatDate = (iso: string) => {
    try {
      const d = new Date(iso);
      const now = Date.now();
      const diffMin = Math.floor((now - d.getTime()) / 60000);
      if (diffMin < 1) return 'Agora há pouco';
      if (diffMin < 60) return `há ${diffMin} min`;
      const diffHours = Math.floor(diffMin / 60);
      if (diffHours < 24) return `há ${diffHours} h`;
      return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
    } catch {
      return '';
    }
  };

  // Group comments into root comments and their child replies
  const rootComments = comments.filter((c) => !c.parentId);
  const getChildReplies = (parentId: string) => comments.filter((c) => c.parentId === parentId);

  return (
    <article className="rounded-3xl bg-[#202020] border border-zinc-800 shadow-xs hover:border-zinc-700 transition-all overflow-hidden">
      <div className="p-5 sm:p-6 space-y-3.5">
        {/* Post Header: Avatar, Name, Badges, Dropdown */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <UserAvatar
              userId={post.authorId}
              userName={post.authorName}
              photoURL={post.authorPhoto}
              sizeClass="h-11 w-11"
              onClick={() => openUserProfile(post.authorId)}
              title={`Ver perfil de ${post.authorName}`}
            />

            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <UserDisplayName
                  userId={post.authorId}
                  fallback={post.authorName}
                  onClick={() => openUserProfile(post.authorId)}
                  className="font-bold text-sm text-white hover:text-[#FF57B2] hover:underline cursor-pointer transition truncate"
                  title={`Ver perfil de ${post.authorName}`}
                />

                <UserBadges userId={post.authorId} isLight={false} size="xs" />

                {post.authorId === community.creatorId && (
                  <span className="inline-flex items-center gap-0.5 rounded-md bg-[#262626] text-[#FF80C5] border border-[#FF57B2]/45 px-1.5 py-0.2 text-[10px] font-bold">
                    <Crown className="h-3 w-3 text-[#FF57B2]" />
                    Fundador
                  </span>
                )}

                {post.authorTitle && post.authorId !== community.creatorId && (
                  <span className="rounded-md bg-zinc-800 text-zinc-300 border border-zinc-700 px-1.5 py-0.2 text-[10px] font-semibold">
                    {post.authorTitle}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-zinc-400 mt-0.5 flex-wrap">
                <span>{formatDate(post.createdAt)}</span>
                {post.editedAt && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="italic">editado</span>
                  </>
                )}
                {post.isPrivate && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="text-[#FF80C5]">Privado</span>
                  </>
                )}
                {post.isHiddenFromNonMembers && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="text-zinc-300">Oculto p/ não-membros</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* 3-dots Menu */}
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="rounded-xl p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
              title="Opções da publicação"
            >
              <MoreVertical className="h-4 w-4" />
            </button>

            {showMenu && (
              <div className="absolute right-0 top-8 z-20 w-60 rounded-2xl bg-[#262626] p-1.5 shadow-xl border border-zinc-800 text-xs">
                <button
                  type="button"
                  onClick={handleToggleSavePost}
                  className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-200 hover:bg-zinc-800 font-medium transition cursor-pointer"
                >
                  <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-[#FF57B2] text-[#FF57B2]' : 'text-[#FF57B2]'}`} />
                  <span>{isSaved ? 'Remover dos salvos' : 'Salvar publicação'}</span>
                </button>

                {canManagePostPrivacy && (
                  <>
                    <button
                      type="button"
                      disabled={togglingPostPrivacy}
                      onClick={() => handleTogglePostPrivacyField('isPrivate')}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-200 hover:bg-zinc-800 font-medium transition cursor-pointer"
                    >
                      {post.isPrivate ? (
                        <Unlock className="h-3.5 w-3.5 text-[#FF57B2]" />
                      ) : (
                        <Lock className="h-3.5 w-3.5 text-[#FF57B2]" />
                      )}
                      <span>
                        {post.isPrivate
                          ? 'Desativar modo privado do post'
                          : 'Privar publicação (só membros)'}
                      </span>
                    </button>

                    <button
                      type="button"
                      disabled={togglingPostPrivacy}
                      onClick={() =>
                        handleTogglePostPrivacyField('isHiddenFromNonMembers')
                      }
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-200 hover:bg-zinc-800 font-medium transition cursor-pointer"
                    >
                      {post.isHiddenFromNonMembers ? (
                        <Eye className="h-3.5 w-3.5 text-[#FF57B2]" />
                      ) : (
                        <EyeOff className="h-3.5 w-3.5 text-[#FF57B2]" />
                      )}
                      <span>
                        {post.isHiddenFromNonMembers
                          ? 'Mostrar p/ quem não é membro'
                          : 'Ocultar p/ quem não é membro'}
                      </span>
                    </button>
                  </>
                )}

                {isPostAuthor && (
                  <button
                    onClick={() => {
                      setIsEditing(true);
                      setShowMenu(false);
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-200 hover:bg-zinc-800 font-medium transition cursor-pointer"
                  >
                    <Edit2 className="h-3.5 w-3.5 text-zinc-400" />
                    <span>Editar publicação</span>
                  </button>
                )}

                {canDeletePost && (
                  <button
                    onClick={promptDeletePost}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-[#FF80C5] hover:bg-zinc-800 font-medium transition cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5 text-[#FF57B2]" />
                    <span>{isPostAuthor ? 'Excluir publicação' : 'Remover publicação (Moderação)'}</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    onReportPost(post);
                    setShowMenu(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-300 hover:bg-zinc-800 font-medium transition cursor-pointer"
                >
                  <AlertTriangle className="h-3.5 w-3.5 text-[#FF57B2]" />
                  <span>Denunciar publicação</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Post Content */}
        {isEditing ? (
          <div className="space-y-2 pt-1">
            <textarea
              rows={3}
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className="w-full rounded-2xl border border-zinc-700 p-3 text-xs sm:text-sm text-white bg-[#1A1A1A] focus:border-[#FF57B2] focus:outline-none"
            />
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="rounded-xl px-3 py-1.5 text-xs font-semibold text-zinc-400 hover:text-white transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                disabled={savingEdit}
                className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-4 py-1.5 text-xs font-bold text-white shadow-xs hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer"
              >
                {savingEdit ? 'Salvando...' : 'Salvar Alteração'}
              </button>
            </div>
          </div>
        ) : post.content ? (
          <div className="text-sm sm:text-base text-zinc-100 font-literary leading-relaxed whitespace-pre-wrap">
            {renderFormattedText(post.content)}
          </div>
        ) : null}

        {/* Post Media / Story Canvas */}
        {useStoryStage ? (
          <div className="aspect-[3/4] w-full max-w-sm mx-auto rounded-2xl overflow-hidden border border-zinc-800 bg-[#262626]">
            <FluxStoryStage
              mediaItems={postMediaItems}
              activeMediaIndex={cardMediaIdx}
              onChangeMediaIndex={setCardMediaIdx}
              storyCanvas={post.storyCanvas}
              className="h-full w-full"
            />
          </div>
        ) : (
          post.mediaUrl && (
            <div
              className={`relative overflow-hidden rounded-2xl border border-zinc-800 bg-[#181818] group ${
                post.imageFormat === 'instagram'
                  ? 'aspect-[4/5] max-w-md mx-auto'
                  : post.imageFormat === 'default'
                  ? 'aspect-[16/10]'
                  : 'max-h-96'
              }`}
            >
              <img
                src={post.mediaUrl}
                alt="Publicação da comunidade"
                onClick={() => setShowImageLightbox(true)}
                className={`w-full rounded-2xl cursor-pointer hover:opacity-95 transition ${
                  post.imageFormat
                    ? 'h-full object-cover'
                    : 'h-auto max-h-96 object-contain'
                }`}
              />
            </div>
          )
        )}

        {/* Post Poll */}
        {post.poll && (
          <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-white">
              <BarChart3 className="h-4 w-4 text-[#FF57B2]" />
              <span>{post.poll.question}</span>
            </div>

            <div className="space-y-2">
              {post.poll.options.map((opt) => {
                const total = post.poll?.totalVotes || 0;
                const percent = total > 0 ? Math.round(((opt.votesCount || 0) / total) * 100) : 0;
                const hasVotedThis = Boolean(currentUser && opt.voterIds?.includes(currentUser.uid));
                const userHasVotedPoll = Boolean(
                  currentUser &&
                    (post.poll?.voterIds?.includes(currentUser.uid) ||
                      post.poll?.options.some((o) => o.voterIds?.includes(currentUser.uid)))
                );

                return (
                  <button
                    key={opt.id}
                    type="button"
                    disabled={userHasVotedPoll || votingPoll}
                    onClick={() => handleVotePoll(opt.id)}
                    className={`relative w-full overflow-hidden rounded-xl border p-2.5 text-left text-xs transition cursor-pointer ${
                      hasVotedThis
                        ? 'border-[#FF57B2] bg-[#FF57B2]/15 font-bold text-[#FF57B2]'
                        : 'border-zinc-800 bg-[#1A1A1A] hover:border-[#FF57B2]/40'
                    }`}
                  >
                    {userHasVotedPoll && (
                      <div
                        className="absolute inset-y-0 left-0 bg-[#FF57B2]/20 transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    )}
                    <div className="relative z-10 flex items-center justify-between">
                      <span className="text-zinc-200">{opt.text}</span>
                      {userHasVotedPoll && (
                        <span className="font-bold text-[#FF57B2]">{percent}%</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="text-[11px] text-zinc-400">
              Total de {post.poll.totalVotes || 0} votos
            </div>
          </div>
        )}

        {/* Action Bar (Like, Dislike, Comment, Save, Share) */}
        <div className="flex items-center justify-between border-t border-zinc-800 pt-3 text-xs text-zinc-400 gap-2 flex-wrap">
          <div className="flex items-center gap-4">
            {/* Like */}
            <button
              type="button"
              onClick={handleToggleLike}
              className={`flex items-center gap-1.5 font-semibold transition cursor-pointer hover:text-[#FF57B2] ${
                hasLiked ? 'text-[#FF57B2] font-bold' : 'text-zinc-400'
              }`}
              title="Curtir publicação"
            >
              <Heart className={`h-4 w-4 ${hasLiked ? 'fill-[#FF57B2] text-[#FF57B2]' : ''}`} />
              <span>{post.likesCount || 0}</span>
            </button>

            {/* Dislike */}
            <button
              type="button"
              onClick={handleToggleDislike}
              className={`flex items-center gap-1.5 font-semibold transition cursor-pointer hover:text-zinc-200 ${
                hasDisliked ? 'text-white font-bold' : 'text-zinc-500'
              }`}
              title="Descurtir publicação"
            >
              <ThumbsDown className={`h-4 w-4 ${hasDisliked ? 'fill-zinc-200 text-zinc-200' : ''}`} />
              <span>{post.dislikesCount || 0}</span>
            </button>

            {/* Comments toggle / collapse */}
            <button
              type="button"
              onClick={() => {
                if (isExclusiveFullView && onCollapseComments) {
                  onCollapseComments();
                } else if (onOpenComments) {
                  onOpenComments();
                } else {
                  setShowComments(!showComments);
                }
              }}
              className={`flex items-center gap-1.5 font-semibold transition cursor-pointer hover:text-white ${
                showComments || isExclusiveFullView ? 'text-[#FF57B2] font-bold' : 'text-zinc-400'
              }`}
              title={
                isExclusiveFullView || showComments
                  ? 'Recolher comentários e continuar na comunidade'
                  : 'Ver e responder comentários'
              }
            >
              <MessageSquare className="h-4 w-4" />
              <span>
                {post.commentsCount || 0}{' '}
                {post.commentsCount === 1 ? 'comentário' : 'comentários'}
              </span>
              {(isExclusiveFullView || (!onOpenComments && showComments)) && (
                <span className="inline-flex items-center gap-0.5 ml-1 text-[11px] text-zinc-300 hover:text-white">
                  · Recolher
                  <ChevronUp className="h-3.5 w-3.5 text-[#FF57B2]" />
                </span>
              )}
            </button>
          </div>

          <div className="flex items-center gap-3.5">
            {/* Save Publication */}
            <button
              type="button"
              onClick={handleToggleSavePost}
              disabled={togglingSave}
              className={`flex items-center gap-1 font-semibold transition cursor-pointer ${
                isSaved ? 'text-[#FF57B2] font-bold' : 'text-zinc-400 hover:text-[#FF57B2]'
              }`}
              title={isSaved ? 'Remover dos salvos' : 'Salvar publicação'}
            >
              <Bookmark className={`h-4 w-4 ${isSaved ? 'fill-[#FF57B2] text-[#FF57B2]' : ''}`} />
              <span>{isSaved ? 'Salvo' : 'Salvar'}</span>
            </button>

            {/* Share */}
            <button
              type="button"
              onClick={handleShare}
              className="flex items-center gap-1 text-zinc-400 hover:text-zinc-200 transition cursor-pointer"
              title="Copiar link da publicação"
            >
              {copiedLink ? <Check className="h-3.5 w-3.5 text-[#FF57B2]" /> : <Share2 className="h-3.5 w-3.5" />}
              <span>{copiedLink ? 'Copiado!' : 'Compartilhar'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Expandable Threaded Comments Section */}
      {(isExclusiveFullView || (!onOpenComments && showComments)) && (
        <div className="border-t border-zinc-800 bg-[#1A1A1A] p-5 sm:p-6 space-y-4">
          {/* Comments Section Header with Immediate Collapse Action */}
          <div className="flex items-center justify-between gap-3 pb-2 border-b border-zinc-800/80">
            <span className="text-xs font-bold text-zinc-200">
              Comentários ({comments.length})
            </span>
            <button
              type="button"
              onClick={() => {
                if (onCollapseComments) {
                  onCollapseComments();
                } else {
                  setShowComments(false);
                }
              }}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#262626] hover:bg-zinc-800 border border-zinc-700/80 hover:border-[#FF57B2]/60 px-3 py-1.5 text-xs font-bold text-zinc-200 hover:text-white transition cursor-pointer"
              title="Recolher comentários e voltar para a comunidade"
            >
              <ChevronUp className="h-3.5 w-3.5 text-[#FF57B2]" />
              <span>Recolher comentários</span>
            </button>
          </div>

          {/* Notice if banned or silenced */}
          {isBanned && (
            <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/60 p-3 text-xs text-white font-medium">
              Você foi banido desta comunidade e não pode comentar.
            </div>
          )}
          {isSilenced && !isBanned && (
            <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/45 p-3 text-xs text-zinc-200 font-medium">
              Você está silenciado temporariamente e não pode comentar.
            </div>
          )}

          {/* Comments List with Nested Connector lines */}
          <div className="space-y-3 pt-1 pb-2">
            {loadingComments ? (
              <div className="py-4 text-center text-xs text-zinc-400">
                Carregando respostas...
              </div>
            ) : rootComments.length === 0 ? (
              <div className="py-4 text-center text-xs text-zinc-400">
                Nenhuma resposta ainda. Seja o primeiro a responder!
              </div>
            ) : (
              rootComments.map((root) => {
                const replies = getChildReplies(root.id);
                const isCollapsed = collapsedThreads[root.id];
                const canDeleteRoot = checkCanDeleteComment(root);

                return (
                  <div key={root.id} className="space-y-2">
                    {/* Root comment card */}
                    <div className="rounded-2xl bg-[#262626] p-3.5 border border-zinc-800 shadow-2xs space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <UserAvatar
                            userId={root.userId}
                            userName={root.userName}
                            photoURL={root.userPhoto}
                            sizeClass="h-7 w-7"
                            onClick={() => root.userId && openUserProfile(root.userId)}
                            title={`Ver perfil de ${root.userName}`}
                          />
                          <UserDisplayName
                            userId={root.userId || root.authorId}
                            fallback={root.userName}
                            onClick={() => root.userId && openUserProfile(root.userId)}
                            className="font-bold text-xs text-white hover:text-[#FF57B2] hover:underline cursor-pointer transition truncate"
                            title={`Ver perfil de ${root.userName}`}
                          />
                          <UserBadges userId={root.userId || root.authorId} isLight={false} size="xs" />
                          <div className="flex items-center gap-1 text-[10px] text-zinc-400">
                            <span>{formatDate(root.createdAt)}</span>
                            {root.editedAt && (
                              <>
                                <span>•</span>
                                <span className="italic">editado</span>
                              </>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          {currentUser?.uid === root.userId && (
                            <button
                              type="button"
                              onClick={() => handleStartEditComment(root)}
                              className="text-zinc-400 hover:text-white transition p-1 cursor-pointer"
                              title="Editar resposta"
                            >
                              <Edit2 className="h-3 w-3" />
                            </button>
                          )}
                          {canDeleteRoot && (
                            <button
                              type="button"
                              onClick={() => promptDeleteComment(root)}
                              className="text-zinc-400 hover:text-[#FF57B2] transition p-1 cursor-pointer"
                              title="Excluir resposta"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Content or Edit form */}
                      {editingCommentId === root.id ? (
                        <div className="space-y-2 pl-9 pt-1">
                          <textarea
                            rows={2}
                            value={editCommentText}
                            onChange={(e) => setEditCommentText(e.target.value)}
                            className="w-full rounded-xl border border-zinc-700 p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-none bg-[#1A1A1A]"
                            placeholder="Editar sua resposta..."
                          />
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={handleCancelEditComment}
                              disabled={savingCommentEdit}
                              className="px-2.5 py-1 text-xs text-zinc-400 hover:text-white transition cursor-pointer"
                            >
                              Cancelar
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveCommentEdit(root.id)}
                              disabled={savingCommentEdit || !editCommentText.trim()}
                              className="flex items-center gap-1 rounded-lg bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-3 py-1 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-40 cursor-pointer shadow-xs"
                            >
                              {savingCommentEdit ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                              <span>Salvar</span>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-zinc-200 font-literary leading-relaxed pl-9">
                          {renderFormattedText(root.content)}
                        </div>
                      )}

                      {/* Reply and Like actions */}
                      <div className="flex items-center gap-3 pl-9 pt-1 text-[11px]">
                        <button
                          type="button"
                          onClick={() => handleToggleCommentLike(root)}
                          className={`inline-flex items-center gap-1 hover:scale-105 transition cursor-pointer text-xs font-semibold ${
                            Boolean(currentUser && root.likedUserIds?.includes(currentUser.uid))
                              ? 'text-[#FF57B2]'
                              : 'text-zinc-400 hover:text-[#FF57B2]'
                          }`}
                          title="Curtir resposta"
                        >
                          <Heart
                            className={`h-3.5 w-3.5 ${
                              Boolean(currentUser && root.likedUserIds?.includes(currentUser.uid))
                                ? 'fill-[#FF57B2] text-[#FF57B2]'
                                : ''
                            }`}
                          />
                          <span>{root.likesCount || 0}</span>
                        </button>

                        {!isBanned && !isSilenced && (
                          <button
                            type="button"
                            onClick={() => handleInitiateReply(root)}
                            className="text-[#FF57B2] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                          >
                            <CornerDownRight className="h-3 w-3" />
                            <span>Responder</span>
                          </button>
                        )}

                        {replies.length > 0 && (
                          <button
                            type="button"
                            onClick={() =>
                              setCollapsedThreads((prev) => ({
                                ...prev,
                                [root.id]: !prev[root.id],
                              }))
                            }
                            className="text-zinc-400 font-medium hover:text-white cursor-pointer"
                          >
                            {isCollapsed
                              ? `Ver ${replies.length} ${replies.length === 1 ? 'resposta' : 'respostas'}`
                              : 'Recolher respostas'}
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Child replies (Nested Thread) */}
                    {!isCollapsed && replies.length > 0 && (
                      <div className="ml-6 pl-4 border-l-2 border-zinc-800 space-y-2">
                        {replies.map((reply) => {
                          const canDeleteReply = checkCanDeleteComment(reply);

                          return (
                            <div
                              key={reply.id}
                              className="rounded-xl bg-[#262626] p-3 border border-zinc-800 shadow-2xs space-y-1.5"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <UserAvatar
                                    userId={reply.userId}
                                    userName={reply.userName}
                                    photoURL={reply.userPhoto}
                                    sizeClass="h-6 w-6"
                                    onClick={() => reply.userId && openUserProfile(reply.userId)}
                                    title={`Ver perfil de ${reply.userName}`}
                                  />
                                  <UserDisplayName
                                    userId={reply.userId || reply.authorId}
                                    fallback={reply.userName}
                                    onClick={() => reply.userId && openUserProfile(reply.userId)}
                                    className="font-bold text-xs text-white hover:text-[#FF57B2] hover:underline cursor-pointer transition truncate"
                                    title={`Ver perfil de ${reply.userName}`}
                                  />
                                  <UserBadges userId={reply.userId || reply.authorId} isLight={false} size="xs" />
                                  <div className="flex items-center gap-1 text-[10px] text-zinc-400">
                                    <span>{formatDate(reply.createdAt)}</span>
                                    {reply.editedAt && (
                                      <>
                                        <span>•</span>
                                        <span className="italic">editado</span>
                                      </>
                                    )}
                                  </div>
                                </div>

                                <div className="flex items-center gap-1">
                                  {currentUser?.uid === reply.userId && (
                                    <button
                                      type="button"
                                      onClick={() => handleStartEditComment(reply)}
                                      className="text-zinc-400 hover:text-white transition p-1 cursor-pointer"
                                      title="Editar resposta"
                                    >
                                      <Edit2 className="h-3 w-3" />
                                    </button>
                                  )}
                                  {canDeleteReply && (
                                    <button
                                      type="button"
                                      onClick={() => promptDeleteComment(reply)}
                                      className="text-zinc-400 hover:text-[#FF57B2] transition p-1 cursor-pointer"
                                      title="Excluir resposta"
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </button>
                                  )}
                                </div>
                              </div>

                              {/* Reply Content or Edit form */}
                              {editingCommentId === reply.id ? (
                                <div className="space-y-2 pl-8 pt-1">
                                  <textarea
                                    rows={2}
                                    value={editCommentText}
                                    onChange={(e) => setEditCommentText(e.target.value)}
                                    className="w-full rounded-xl border border-zinc-700 p-2 text-xs text-white focus:border-[#FF57B2] focus:outline-none bg-[#1A1A1A]"
                                    placeholder="Editar sua resposta..."
                                  />
                                  <div className="flex items-center justify-end gap-2">
                                    <button
                                      type="button"
                                      onClick={handleCancelEditComment}
                                      disabled={savingCommentEdit}
                                      className="px-2 py-0.5 text-xs text-zinc-400 hover:text-white transition cursor-pointer"
                                    >
                                      Cancelar
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleSaveCommentEdit(reply.id)}
                                      disabled={savingCommentEdit || !editCommentText.trim()}
                                      className="flex items-center gap-1 rounded-lg bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-2.5 py-1 text-xs font-bold text-white hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-40 cursor-pointer shadow-xs"
                                    >
                                      {savingCommentEdit ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                                      <span>Salvar</span>
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="text-xs text-zinc-200 font-literary leading-relaxed pl-8">
                                  {renderFormattedText(reply.content)}
                                </div>
                              )}

                              <div className="flex items-center gap-3 pl-8 pt-0.5 text-[11px]">
                                <button
                                  type="button"
                                  onClick={() => handleToggleCommentLike(reply)}
                                  className={`inline-flex items-center gap-1 hover:scale-105 transition cursor-pointer text-xs font-semibold ${
                                    Boolean(currentUser && reply.likedUserIds?.includes(currentUser.uid))
                                      ? 'text-[#FF57B2]'
                                      : 'text-zinc-400 hover:text-[#FF57B2]'
                                  }`}
                                  title="Curtir resposta"
                                >
                                  <Heart
                                    className={`h-3 w-3 ${
                                      Boolean(currentUser && reply.likedUserIds?.includes(currentUser.uid))
                                        ? 'fill-[#FF57B2] text-[#FF57B2]'
                                        : ''
                                    }`}
                                  />
                                  <span>{reply.likesCount || 0}</span>
                                </button>

                                {!isBanned && !isSilenced && (
                                  <button
                                    type="button"
                                    onClick={() => handleInitiateReply(reply)}
                                    className="text-[#FF57B2] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                                  >
                                    <CornerDownRight className="h-3 w-3" />
                                    <span>Responder</span>
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* WhatsApp-Style Bottom Composer (Sempre no final da página/thread) + Botão Rápido de Recolher */}
          {!isBanned && !isSilenced ? (
            <div className="sticky bottom-0 z-30 -mx-5 -mb-5 sm:-mx-6 sm:-mb-6 pt-2">
              <form
                onSubmit={handleAddComment}
                className="rounded-b-2xl sm:rounded-b-3xl bg-[#1A1A1A]/95 backdrop-blur-md border-t border-zinc-800 p-3 sm:p-4 shadow-lg space-y-2"
              >
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (onCollapseComments) {
                        onCollapseComments();
                      } else {
                        setShowComments(false);
                      }
                    }}
                    className="flex h-9 px-2.5 shrink-0 items-center justify-center gap-1 rounded-full bg-[#262626] hover:bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-white text-[11px] font-bold transition cursor-pointer"
                    title="Recolher comentários e continuar na comunidade"
                  >
                    <ChevronUp className="h-3.5 w-3.5 text-[#FF57B2]" />
                    <span className="hidden sm:inline">Recolher</span>
                  </button>

                  {currentUser && (
                    <UserAvatar
                      userId={currentUser.uid}
                      userName={userProfile?.displayName}
                      photoURL={userProfile?.photoURL}
                      sizeClass="h-8 w-8 shrink-0"
                    />
                  )}
                  <input
                    ref={commentInputRef}
                    type="text"
                    value={newCommentText}
                    onChange={(e) => setNewCommentText(e.target.value)}
                    placeholder="Escreva um comentário nesta publicação..."
                    className="flex-1 rounded-full border border-zinc-700 bg-[#262626] px-4 py-2.5 text-xs text-white placeholder:text-zinc-500 focus:border-[#FF57B2] focus:outline-hidden transition"
                  />
                  <button
                    type="submit"
                    disabled={submittingComment || !newCommentText.trim()}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] hover:scale-105 active:scale-95 transition disabled:opacity-40 cursor-pointer"
                    title="Enviar comentário"
                  >
                    {submittingComment ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4 ml-0.5" />
                    )}
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="pt-2 flex justify-center">
              <button
                type="button"
                onClick={() => {
                  if (onCollapseComments) {
                    onCollapseComments();
                  } else {
                    setShowComments(false);
                  }
                }}
                className="inline-flex items-center gap-1.5 rounded-xl bg-[#262626] hover:bg-zinc-800 border border-zinc-700 px-4 py-2 text-xs font-bold text-white transition cursor-pointer"
              >
                <ChevronUp className="h-4 w-4 text-[#FF57B2]" />
                <span>Recolher comentários</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Barra de Resposta Fixada no Final da Página (Estilo WhatsApp) */}
      {replyTarget && (
        <div className="fixed bottom-0 inset-x-0 z-50 bg-[#1A1A1A]/95 backdrop-blur-xl border-t border-zinc-800 px-4 py-2.5 sm:py-3 shadow-2xl animate-in slide-in-from-bottom duration-200">
          <div className="mx-auto max-w-3xl space-y-2">
            {/* Faixa de Citação de Resposta Estilo WhatsApp */}
            <div className="flex items-center justify-between rounded-xl bg-[#262626] px-3.5 py-1.5 text-xs text-white border-l-4 border-l-[#FF57B2] border-y border-r border-zinc-800 shadow-xs">
              <div className="flex items-center gap-2 truncate">
                <CornerDownRight className="h-3.5 w-3.5 text-[#FF57B2] shrink-0" />
                <span className="truncate">
                  Respondendo a <strong className="font-bold text-[#FF57B2]">@{replyTarget.authorName}</strong>
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setReplyTarget(null);
                  setNewCommentText('');
                }}
                className="text-zinc-400 hover:text-white font-bold p-1 rounded-full hover:bg-white/10 cursor-pointer"
                title="Cancelar resposta"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Linha de Entrada Estilo WhatsApp */}
            <form onSubmit={handleAddComment} className="flex items-center gap-2">
              {currentUser && (
                <UserAvatar
                  userId={currentUser.uid}
                  userName={userProfile?.displayName}
                  photoURL={userProfile?.photoURL}
                  sizeClass="h-8 w-8 shrink-0"
                />
              )}
              <input
                ref={fixedCommentInputRef}
                type="text"
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder={`Responder a @${replyTarget.authorName}...`}
                className="flex-1 rounded-full border border-zinc-700 bg-[#262626] px-4 py-2.5 text-xs text-white placeholder:text-zinc-500 focus:border-[#FF57B2] focus:outline-hidden transition shadow-inner"
                autoFocus
              />
              <button
                type="submit"
                disabled={submittingComment || !newCommentText.trim()}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-md shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] hover:scale-105 active:scale-95 transition disabled:opacity-40 cursor-pointer"
                title="Enviar resposta"
              >
                {submittingComment ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4 ml-0.5" />
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Image Lightbox */}
      {showImageLightbox && post.mediaUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4"
          onClick={() => setShowImageLightbox(false)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img
              src={post.mediaUrl}
              alt="Ampliação"
              className="max-h-[85vh] max-w-full rounded-2xl object-contain shadow-2xl"
            />
            <button
              type="button"
              onClick={() => setShowImageLightbox(false)}
              className="absolute -top-3 -right-3 rounded-full bg-[#262626] border border-zinc-700 text-white p-2 shadow-lg hover:border-[#FF57B2] cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Post & Comments Deletion */}
      <ConfirmModal
        isOpen={deleteModalState.isOpen}
        onClose={() => {
          if (!isDeleting) {
            setDeleteModalState((prev) => ({ ...prev, isOpen: false }));
          }
        }}
        onConfirm={handleConfirmDelete}
        title={deleteModalState.title}
        message={deleteModalState.message}
        confirmText="Excluir Definitivamente"
        cancelText="Cancelar"
        variant="danger"
        isLoading={isDeleting}
      />
    </article>
  );
};
