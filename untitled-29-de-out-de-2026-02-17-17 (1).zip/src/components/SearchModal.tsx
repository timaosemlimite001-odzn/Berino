import { collection, doc, getDoc, getDocs, limit, query } from 'firebase/firestore';
import { BookOpen, Feather, Search, Sparkles, User, Users, X } from 'lucide-react';
import React, { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db } from '../services/firebase';
import { Book, Community, CommunityMember, UserProfile } from '../types';
import { UserAvatar } from './UserAvatar';
import { UserBadges } from './UserBadges';
import { getSynopsisPreview } from '../utils/textUtils';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectBook: (bookId: string) => void;
  onSelectCommunity: (communityId: string) => void;
}

export type SearchFilterType = 'books' | 'authors' | 'communities';

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectBook,
  onSelectCommunity,
}) => {
  const { currentUser, isDeveloper } = useAuth();
  const { openUserProfile } = usePublicProfile();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<SearchFilterType>('books');
  const [books, setBooks] = useState<Book[]>([]);
  const [communities, setCommunities] = useState<Community[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    // Reset to default 'books' filter whenever search modal is opened
    setActiveFilter('books');

    const loadAll = async () => {
      setLoading(true);
      try {
        const booksSnap = await getDocs(query(collection(db, 'books'), limit(100)));
        const loadedBooks: Book[] = [];
        booksSnap.forEach((d) => loadedBooks.push(d.data() as Book));
        setBooks(loadedBooks);

        const commSnap = await getDocs(query(collection(db, 'communities'), limit(50)));
        const rawComm: Community[] = [];
        commSnap.forEach((d) => rawComm.push(d.data() as Community));

        const visibleComm = isDeveloper
          ? rawComm
          : (
              await Promise.all(
                rawComm.map(async (c) => {
                  if (!c.isHiddenFromNonMembers) return c;
                  if (!currentUser) return null;
                  if (c.creatorId === currentUser.uid) return c;
                  try {
                    const mSnap = await getDoc(
                      doc(db, 'communities', c.id, 'members', currentUser.uid)
                    );
                    if (mSnap.exists()) {
                      const mData = mSnap.data() as Partial<CommunityMember>;
                      if (mData.status !== 'pending' && mData.status !== 'banned') {
                        return c;
                      }
                    }
                  } catch {
                    // ignore
                  }
                  return null;
                })
              )
            ).filter((c): c is Community => c !== null);

        setCommunities(visibleComm);

        const usersSnap = await getDocs(query(collection(db, 'users'), limit(100)));
        const loadedUsers: UserProfile[] = [];
        usersSnap.forEach((d) => loadedUsers.push(d.data() as UserProfile));
        setUsers(loadedUsers);
      } catch (err) {
        console.error('Error loading search index:', err);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [isOpen, currentUser?.uid, isDeveloper]);

  // Compute author book counts to strictly verify who is a writer of at least one work
  const authorWorkStats = useMemo(() => {
    const countByAuthorId = new Map<string, number>();
    const countByAuthorName = new Map<string, number>();

    books.forEach((b) => {
      if (b.authorId) {
        countByAuthorId.set(b.authorId, (countByAuthorId.get(b.authorId) || 0) + 1);
      }
      if (b.authorName) {
        const nameNorm = b.authorName.toLowerCase().trim();
        countByAuthorName.set(nameNorm, (countByAuthorName.get(nameNorm) || 0) + 1);
      }
    });

    return { countByAuthorId, countByAuthorName };
  }, [books]);

  const getWorksCount = (u: UserProfile): number => {
    const byId = authorWorkStats.countByAuthorId.get(u.id) || 0;
    const byName = u.displayName
      ? authorWorkStats.countByAuthorName.get(u.displayName.toLowerCase().trim()) || 0
      : 0;
    return Math.max(byId, byName);
  };

  // STRICT REQUIREMENT: Only include users who are actually writers of at least one work
  const eligibleAuthors = useMemo(() => {
    return users.filter((u) => getWorksCount(u) > 0);
  }, [users, authorWorkStats]);

  if (!isOpen) return null;

  const term = searchTerm.toLowerCase().trim();

  const filteredBooks = term
    ? books.filter(
        (b) =>
          b.title.toLowerCase().includes(term) ||
          b.authorName.toLowerCase().includes(term) ||
          b.synopsis?.toLowerCase().includes(term) ||
          b.genres?.some((g) => g.toLowerCase().includes(term))
      )
    : books.slice(0, 10);

  const filteredCommunities = term
    ? communities.filter(
        (c) =>
          c.name.toLowerCase().includes(term) ||
          c.description?.toLowerCase().includes(term) ||
          c.category?.toLowerCase().includes(term)
      )
    : communities.slice(0, 8);

  const filteredAuthors = term
    ? eligibleAuthors.filter(
        (u) =>
          u.displayName?.toLowerCase().includes(term) ||
          u.username?.toLowerCase().includes(term) ||
          u.uniqueId?.toLowerCase().includes(term) ||
          u.bio?.toLowerCase().includes(term)
      )
    : eligibleAuthors.slice(0, 10);

  const getPlaceholder = () => {
    if (activeFilter === 'authors') {
      return 'Buscar autores de obras por nome ou @usuário...';
    }
    if (activeFilter === 'communities') {
      return 'Buscar comunidades literárias...';
    }
    return 'Buscar obras por título, autor, gênero ou sinopse...';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/70 p-4 pt-16 sm:pt-24 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-2xl overflow-hidden rounded-3xl bg-[#202020] shadow-2xl border border-zinc-800 transition text-white">
        {/* Search input header */}
        <div className="flex items-center border-b border-zinc-800 px-4 py-3.5 gap-3 bg-[#202020]">
          <Search className="h-5 w-5 text-[#FF57B2] shrink-0" />
          <input
            type="text"
            autoFocus
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={getPlaceholder()}
            className="flex-1 bg-transparent text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-xs text-zinc-400 hover:text-white px-1 cursor-pointer"
            >
              Limpar
            </button>
          )}
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white cursor-pointer transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Filter Selection Bar: Obras (Default), Autores, Comunidades */}
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-zinc-800 bg-[#262626]">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 mr-1 hidden sm:inline">
              Filtrar:
            </span>

            {/* Filtro Obras (Padrão) */}
            <button
              type="button"
              onClick={() => setActiveFilter('books')}
              className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer ${
                activeFilter === 'books'
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs border border-[#FF57B2]/50'
                  : 'bg-zinc-800 text-zinc-300 border border-zinc-700 hover:bg-zinc-750 hover:text-white'
              }`}
            >
              <BookOpen className="h-3.5 w-3.5" />
              <span>Obras</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                  activeFilter === 'books'
                    ? 'bg-black/25 text-white'
                    : 'bg-zinc-700 text-zinc-300'
                }`}
              >
                {filteredBooks.length}
              </span>
            </button>

            {/* Filtro Autores (Apenas quem for escritor de alguma obra) */}
            <button
              type="button"
              onClick={() => setActiveFilter('authors')}
              className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer ${
                activeFilter === 'authors'
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs border border-[#FF57B2]/50'
                  : 'bg-zinc-800 text-zinc-300 border border-zinc-700 hover:bg-zinc-750 hover:text-white'
              }`}
            >
              <Feather className="h-3.5 w-3.5" />
              <span>Autores</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                  activeFilter === 'authors'
                    ? 'bg-black/25 text-white'
                    : 'bg-zinc-700 text-zinc-300'
                }`}
              >
                {filteredAuthors.length}
              </span>
            </button>

            {/* Filtro Comunidades */}
            <button
              type="button"
              onClick={() => setActiveFilter('communities')}
              className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition cursor-pointer ${
                activeFilter === 'communities'
                  ? 'bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-xs border border-[#FF57B2]/50'
                  : 'bg-zinc-800 text-zinc-300 border border-zinc-700 hover:bg-zinc-750 hover:text-white'
              }`}
            >
              <Users className="h-3.5 w-3.5" />
              <span>Comunidades</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                  activeFilter === 'communities'
                    ? 'bg-black/25 text-white'
                    : 'bg-zinc-700 text-zinc-300'
                }`}
              >
                {filteredCommunities.length}
              </span>
            </button>
          </div>

          <span className="text-[10px] text-zinc-400 hidden md:inline">
            {activeFilter === 'books'
              ? 'Exibindo obras literárias'
              : activeFilter === 'authors'
              ? 'Exibindo escritores com obras'
              : 'Exibindo comunidades'}
          </span>
        </div>

        {/* Results Area */}
        <div className="max-h-[62vh] overflow-y-auto p-4 space-y-3">
          {loading ? (
            <div className="py-12 text-center text-xs text-zinc-400">
              Carregando acervo literário...
            </div>
          ) : activeFilter === 'books' ? (
            /* SEÇÃO: APENAS OBRAS (PADRÃO) */
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                  <BookOpen className="h-3.5 w-3.5 text-[#FF57B2]" />
                  Obras Encontradas ({filteredBooks.length})
                </span>
                {filteredAuthors.length > 0 && term && (
                  <button
                    type="button"
                    onClick={() => setActiveFilter('authors')}
                    className="text-[11px] text-[#FF80C5] hover:underline font-semibold cursor-pointer"
                  >
                    Ver {filteredAuthors.length} autor(es) →
                  </button>
                )}
              </div>

              {filteredBooks.length === 0 ? (
                <div className="py-8 text-center text-xs text-zinc-400 space-y-1">
                  <p className="italic">Nenhuma obra literária encontrada para esta pesquisa.</p>
                  {(filteredAuthors.length > 0 || filteredCommunities.length > 0) && (
                    <p className="text-[11px] text-zinc-500">
                      Tente alternar para o filtro de <strong>Autores</strong> ou <strong>Comunidades</strong> acima.
                    </p>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredBooks.map((b) => (
                    <div
                      key={b.id}
                      onClick={() => {
                        onSelectBook(b.id);
                        onClose();
                      }}
                      className="flex items-center gap-3 rounded-2xl p-2.5 bg-[#262626]/60 hover:bg-[#262626] transition cursor-pointer border border-zinc-800 hover:border-[#FF57B2]/40"
                    >
                      <div className="h-16 w-11 shrink-0 overflow-hidden rounded-lg bg-[#181818] border border-zinc-800 shadow-2xs">
                        {b.coverUrl ? (
                          <img
                            src={b.coverUrl}
                            alt={b.title}
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white font-serif font-bold text-xs">
                            {b.title.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-white text-sm truncate font-literary">
                          {b.title}
                        </h4>
                        <p className="text-xs text-zinc-400 truncate">
                          Por <strong className="text-zinc-200">{b.authorName}</strong>
                        </p>
                        <p className="text-[11px] text-zinc-400 line-clamp-1 mt-0.5 font-literary">
                          {getSynopsisPreview(b.synopsis, 90)}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="rounded-md bg-zinc-800 px-1.5 py-0.5 text-[10px] text-zinc-300 font-medium">
                            {b.classification}
                          </span>
                          {b.genres?.slice(0, 2).map((g) => (
                            <span
                              key={g}
                              className="rounded-md bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30 px-1.5 py-0.5 text-[10px] font-medium"
                            >
                              {g}
                            </span>
                          ))}
                          {b.isBeta && (
                            <span className="rounded-md bg-zinc-800 text-[#FF57B2] border border-[#FF57B2]/50 px-1.5 py-0.5 text-[10px] font-bold shadow-2xs">
                              Beta Reader
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : activeFilter === 'authors' ? (
            /* SEÇÃO: APENAS AUTORES (QUEM É ESCRITOR DE ALGUMA OBRA) */
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                  <Feather className="h-3.5 w-3.5 text-[#FF57B2]" />
                  Autores com Obras ({filteredAuthors.length})
                </span>
                <span className="text-[10px] text-zinc-400">
                  (Somente escritores com obras cadastradas)
                </span>
              </div>

              {filteredAuthors.length === 0 ? (
                <div className="py-8 text-center text-xs text-zinc-400 space-y-1">
                  <p className="italic">Nenhum autor de obras encontrado para esta pesquisa.</p>
                  <p className="text-[11px] text-zinc-400">
                    Apenas usuários que já publicaram ou cadastraram ao menos uma obra aparecem aqui.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredAuthors.map((u) => {
                    const worksCount = getWorksCount(u);
                    return (
                      <div
                        key={u.id}
                        onClick={() => {
                          openUserProfile(u);
                          onClose();
                        }}
                        className="flex items-center gap-3 rounded-2xl p-2.5 bg-[#262626] hover:bg-zinc-800 transition cursor-pointer border border-zinc-800 hover:border-[#FF57B2]/40"
                      >
                        <UserAvatar
                          userId={u.id}
                          userName={u.displayName}
                          photoURL={u.photoURL}
                          sizeClass="h-11 w-11"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="font-bold text-white text-sm truncate">
                              {u.displayName}
                            </h4>
                            <UserBadges
                              userId={u.id}
                              isVerified={u.isVerifiedWriter}
                              hasExperienced={u.hasExperiencedReaderBadge}
                              role={u.role}
                              size="xs"
                              isLight={false}
                            />
                            {u.username && (
                              <span className="text-xs font-mono text-zinc-400">
                                @{u.username.replace(/^@/, '')}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-1 text-xs text-zinc-400">
                            <span className="inline-flex items-center gap-1 font-semibold text-[#FF57B2] bg-[#FF57B2]/15 border border-[#FF57B2]/30 px-2 py-0.5 rounded-md text-[11px]">
                              <Feather className="h-3 w-3 text-[#FF57B2]" />
                              {worksCount} {worksCount === 1 ? 'obra publicada' : 'obras publicadas'}
                            </span>
                            {u.activeTitle && <span>• {u.activeTitle}</span>}
                            {u.followersCount ? <span>• {u.followersCount} seguidores</span> : null}
                          </div>
                          {u.bio && (
                            <p className="text-[11px] text-zinc-400 truncate mt-0.5 font-literary">
                              {u.bio}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            /* SEÇÃO: APENAS COMUNIDADES */
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5 text-[#FF57B2]" />
                  Comunidades Literárias ({filteredCommunities.length})
                </span>
              </div>

              {filteredCommunities.length === 0 ? (
                <p className="text-xs text-zinc-400 py-8 text-center italic">
                  Nenhuma comunidade encontrada para esta pesquisa.
                </p>
              ) : (
                <div className="space-y-2">
                  {filteredCommunities.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => {
                        onSelectCommunity(c.id);
                        onClose();
                      }}
                      className="flex items-center gap-3 rounded-2xl p-2.5 bg-[#262626]/60 hover:bg-[#262626] transition cursor-pointer border border-zinc-800 hover:border-[#FF57B2]/40"
                    >
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#181818] border border-zinc-700 text-[#FF57B2] font-bold text-sm">
                        {c.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-white text-sm truncate">
                          {c.name}
                        </h4>
                        <p className="text-xs text-zinc-400 truncate">
                          {c.description}
                        </p>
                        <span className="text-[10px] text-zinc-400 mt-0.5 block">
                          {c.membersCount || 1} membros • {c.category}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

