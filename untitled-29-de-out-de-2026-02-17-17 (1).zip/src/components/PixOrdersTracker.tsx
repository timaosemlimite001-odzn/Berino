import React, { useState, useEffect } from 'react';
import {
  Clock,
  QrCode,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Zap,
  ShieldCheck,
  FileCheck,
  XCircle,
  Coins,
  Loader2,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { KardPackage, PixOrder, PixOrderStatus } from '../types';
import {
  verifyPixPayment,
  submitPixReceipt,
  approvePixOrder,
  claimAndCreditPixOrder,
  cancelPixOrder,
} from '../services/pixService';

interface PixOrdersTrackerProps {
  orders: PixOrder[];
  packages: KardPackage[];
  currentUser: any;
  userProfile: any;
  onOpenOrder: (order: PixOrder) => void;
  onOrderUpdated: () => void;
}

export const PixOrdersTracker: React.FC<PixOrdersTrackerProps> = ({
  orders,
  packages,
  currentUser,
  userProfile,
  onOpenOrder,
  onOrderUpdated,
}) => {
  const [now, setNow] = useState(Date.now());
  const [verifyingTxId, setVerifyingTxId] = useState<string | null>(null);
  const [approvingTxId, setApprovingTxId] = useState<string | null>(null);
  const [receiptTxId, setReceiptTxId] = useState<string | null>(null);
  const [receiptInput, setReceiptInput] = useState('');
  const [submittingReceipt, setSubmittingReceipt] = useState(false);
  const [cancellingTxId, setCancellingTxId] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<{
    txId?: string;
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  const isDeveloper =
    userProfile?.role === 'desenvolvedor' ||
    currentUser?.email === 'timaosemlimite001@gmail.com';

  // Atualiza relógio a cada 1s para o countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatRemainingTime = (expiresAtStr: string) => {
    const expiresMs = new Date(expiresAtStr).getTime();
    const diffSec = Math.max(0, Math.floor((expiresMs - now) / 1000));
    if (diffSec <= 0) return 'Expirado';
    const m = Math.floor(diffSec / 60)
      .toString()
      .padStart(2, '0');
    const s = (diffSec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const isOrderExpired = (order: PixOrder) => {
    if (order.status === 'expired') return true;
    if (order.status === 'completed' || order.status === 'paid') return false;
    const expiresMs = new Date(order.expiresAt).getTime();
    return expiresMs <= now;
  };

  // Verificar pagamento da ordem
  const handleCheckOrderPayment = async (order: PixOrder) => {
    if (!currentUser) return;
    setVerifyingTxId(order.txId);
    setActionMessage(null);

    try {
      const result = await verifyPixPayment(
        order.txId,
        currentUser.uid,
        order.receiptCode,
        order
      );

      if (result.paid) {
        // Credita Kards
        await claimAndCreditPixOrder(order, currentUser.uid);
        setActionMessage({
          txId: order.txId,
          type: 'success',
          text: `Pagamento de R$ ${order.amountBrl.toFixed(2).replace('.', ',')} identificado! +${order.kards} Kards liberados com sucesso na sua conta!`,
        });
        onOrderUpdated();
      } else {
        if (result.status === 'expired') {
          setActionMessage({
            txId: order.txId,
            type: 'error',
            text: 'Tempo limite expirado para este pedido. Você pode gerar uma nova cobrança.',
          });
        } else if (result.status === 'under_review') {
          setActionMessage({
            txId: order.txId,
            type: 'info',
            text: 'Comprovante em análise na conta bancária. Aguardando conciliação da compensação.',
          });
        } else {
          setActionMessage({
            txId: order.txId,
            type: 'info',
            text: `Pagamento ainda não identificado no extrato bancário da ${order.merchantName || 'GB Payment'}. Se você já transferiu, aguarde alguns instantes e tente novamente.`,
          });
        }
        onOrderUpdated();
      }
    } catch (err: any) {
      setActionMessage({
        txId: order.txId,
        type: 'error',
        text: err.message || 'Erro ao verificar pagamento bancário.',
      });
    } finally {
      setVerifyingTxId(null);
    }
  };

  // Enviar código de comprovante
  const handleSubmitReceiptCode = async (order: PixOrder) => {
    const cleanInput = receiptInput.trim();
    if (!cleanInput || cleanInput.length < 10 || !currentUser) {
      setActionMessage({
        txId: order.txId,
        type: 'error',
        text: 'O código do comprovante deve conter no mínimo 10 caracteres alfanuméricos.',
      });
      return;
    }
    setSubmittingReceipt(true);
    setActionMessage(null);

    try {
      const res = await submitPixReceipt(order.txId, cleanInput, currentUser.uid, order);
      setReceiptTxId(null);
      setReceiptInput('');

      if (res.paid) {
        // Conciliação bancária confirmada automaticamente!
        await claimAndCreditPixOrder(order, currentUser.uid);
        setActionMessage({
          txId: order.txId,
          type: 'success',
          text: `Comprovante validado e compensação confirmada! +${order.kards} Kards creditados imediatamente na sua conta!`,
        });
      } else {
        setActionMessage({
          txId: order.txId,
          type: 'info',
          text: res.message || 'Código do comprovante registrado com sucesso! O sistema está acompanhando a conciliação.',
        });
      }
      onOrderUpdated();
    } catch (err: any) {
      setActionMessage({
        txId: order.txId,
        type: 'error',
        text: err.message || 'Falha ao registrar comprovante.',
      });
    } finally {
      setSubmittingReceipt(false);
    }
  };

  // Cancelar pedido
  const handleCancelOrder = async (order: PixOrder) => {
    if (!currentUser) return;
    setCancellingTxId(order.txId);
    setActionMessage(null);

    try {
      await cancelPixOrder(order.txId, currentUser.uid);
      setActionMessage({
        txId: order.txId,
        type: 'info',
        text: 'Pedido descartado com sucesso.',
      });
      onOrderUpdated();
    } catch (err: any) {
      setActionMessage({
        txId: order.txId,
        type: 'error',
        text: err.message || 'Erro ao descartar pedido.',
      });
    } finally {
      setCancellingTxId(null);
    }
  };

  // Aprovação de desenvolvedor / admin
  const handleAdminApproveOrder = async (order: PixOrder) => {
    if (!currentUser || !isDeveloper) return;
    setApprovingTxId(order.txId);
    setActionMessage(null);

    try {
      await approvePixOrder(order.txId, currentUser.uid, order);
      await claimAndCreditPixOrder(order, currentUser.uid);
      setActionMessage({
        txId: order.txId,
        type: 'success',
        text: `Ordem Pix aprovada como titular da conta! +${order.kards} Kards creditados com sucesso na sua carteira.`,
      });
      onOrderUpdated();
    } catch (err: any) {
      setActionMessage({
        txId: order.txId,
        type: 'error',
        text: err.message || 'Erro ao aprovar ordem.',
      });
    } finally {
      setApprovingTxId(null);
    }
  };

  // Separa ordens ativas (pendentes, sob análise, pagas ou finalizadas recentemente)
  const activeOrders = orders.filter((o) => {
    if (o.status === 'completed') {
      // Exibe concluídos das últimas 2 horas
      const completedTime = new Date(o.createdAt).getTime();
      return now - completedTime < 2 * 60 * 60 * 1000;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Mensagem Geral de Ação */}
      {actionMessage && !actionMessage.txId && (
        <div
          className={`rounded-2xl p-4 text-xs font-medium border animate-in fade-in duration-200 ${
            actionMessage.type === 'error'
              ? 'bg-[#262626] border-[#FF57B2]/45 text-[#FF80C5]'
              : 'bg-[#262626] border-[#FF57B2]/35 text-white'
          }`}
        >
          {actionMessage.text}
        </div>
      )}

      {/* Lista de Pedidos Pix */}
      {activeOrders.length === 0 ? (
        <div className="rounded-3xl bg-[#202020] border border-zinc-800 p-8 sm:p-12 text-center space-y-3">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#262626] text-[#FF57B2] border border-zinc-700">
            <Clock className="h-7 w-7" />
          </div>
          <h3 className="text-base font-bold text-white">Nenhum Pedido Pix em Aberto</h3>
          <p className="text-xs text-zinc-400 max-w-md mx-auto leading-relaxed">
            Quando você gerar uma cobrança Pix na aba <strong className="text-white">Pacotes de Kards</strong>, o pedido permanecerá aberto aqui até que você efetue o pagamento no seu banco ou até o tempo expirar.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
              <Clock className="h-4 w-4 text-[#FF57B2]" />
              <span>Seus Pedidos Pix em Andamento ({activeOrders.length})</span>
            </h2>
            <span className="text-[11px] text-zinc-400 font-medium">
              Atualização automática em tempo real
            </span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {activeOrders.map((order) => {
              const expired = isOrderExpired(order);
              const isUnderReview = order.status === 'under_review';
              const isPaid = order.status === 'paid';
              const isCompleted = order.status === 'completed';

              return (
                <div
                  key={order.txId}
                  className={`relative rounded-3xl bg-[#202020] p-5 sm:p-6 border transition shadow-xs space-y-4 ${
                    isCompleted || isPaid
                      ? 'border-[#FF57B2]/50 ring-1 ring-[#FF57B2]/25'
                      : isUnderReview
                      ? 'border-[#FF57B2]/40 bg-[#222222]'
                      : expired
                      ? 'border-zinc-800 opacity-75'
                      : 'border-zinc-800 hover:border-[#FF57B2]/40'
                  }`}
                >
                  {/* Top Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3.5">
                    <div className="flex items-center gap-3">
                      <div
                        className={`flex h-11 w-11 items-center justify-center rounded-2xl shrink-0 border ${
                          expired
                            ? 'bg-[#262626] text-zinc-500 border-zinc-700'
                            : 'bg-[#FF57B2]/15 text-[#FF57B2] border-[#FF57B2]/35'
                        }`}
                      >
                        {isCompleted || isPaid ? (
                          <CheckCircle2 className="h-6 w-6" />
                        ) : isUnderReview ? (
                          <FileCheck className="h-6 w-6" />
                        ) : (
                          <Zap className="h-6 w-6" />
                        )}
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-bold text-white text-sm sm:text-base">
                            {order.title}
                          </h4>
                          <span className="text-xs font-black text-[#FF80C5] bg-[#FF57B2]/15 px-2 py-0.5 rounded-md border border-[#FF57B2]/30 tabular-nums">
                            +{order.kards} Kards
                          </span>
                        </div>
                        <span className="text-[11px] text-zinc-400 block mt-0.5">
                          Iniciado em {new Date(order.createdAt).toLocaleTimeString('pt-BR')} • TXID: {order.txId}
                        </span>
                      </div>
                    </div>

                    {/* Status Pill */}
                    <div className="flex items-center gap-2 shrink-0">
                      {isCompleted ? (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#FF57B2]/15 px-3 py-1 text-xs font-bold text-[#FF80C5] border border-[#FF57B2]/40">
                          <CheckCircle2 className="h-3.5 w-3.5 text-[#FF57B2]" />
                          <span>Kards Creditados</span>
                        </span>
                      ) : isPaid ? (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#FF57B2]/20 px-3 py-1 text-xs font-bold text-white border border-[#FF57B2]/50">
                          <CheckCircle2 className="h-3.5 w-3.5 text-[#FF57B2]" />
                          <span>Pagamento Recebido</span>
                        </span>
                      ) : isUnderReview ? (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#262626] px-3 py-1 text-xs font-bold text-[#FF80C5] border border-[#FF57B2]/35">
                          <FileCheck className="h-3.5 w-3.5 text-[#FF57B2]" />
                          <span>Comprovante em Análise</span>
                        </span>
                      ) : expired ? (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#262626] px-3 py-1 text-xs font-bold text-zinc-400 border border-zinc-700">
                          <XCircle className="h-3.5 w-3.5" />
                          <span>Tempo Expirado</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#262626] px-3 py-1 text-xs font-bold text-white border border-[#FF57B2]/35 tabular-nums">
                          <Clock className="h-3.5 w-3.5 text-[#FF57B2]" />
                          <span>Aguardando Pagamento ({formatRemainingTime(order.expiresAt)})</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Detalhes Financeiros */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#262626] p-3 rounded-2xl border border-zinc-800 text-xs">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-zinc-400 block">Valor</span>
                      <span className="font-black text-white text-sm tabular-nums">
                        R$ {order.amountBrl.toFixed(2).replace('.', ',')}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-zinc-400 block">Recebedor</span>
                      <span className="font-semibold text-zinc-200">
                        {order.merchantName || 'GB Payment'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-zinc-400 block">Chave Pix</span>
                      <span className="font-mono text-zinc-300 text-[11px]">
                        {order.pixKey || 'pix@kordel.com.br'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-zinc-400 block">Tempo Limite</span>
                      <span className={`font-mono text-[11px] font-bold tabular-nums ${expired ? 'text-zinc-500' : 'text-[#FF80C5]'}`}>
                        {expired ? 'Expirado' : `Válido por ${formatRemainingTime(order.expiresAt)}`}
                      </span>
                    </div>
                  </div>

                  {/* Feedback específico desta ordem */}
                  {actionMessage && actionMessage.txId === order.txId && (
                    <div
                      className={`rounded-2xl p-3 text-xs font-medium border animate-in fade-in duration-200 ${
                        actionMessage.type === 'error'
                          ? 'bg-[#262626] border-[#FF57B2]/45 text-[#FF80C5]'
                          : 'bg-[#262626] border-[#FF57B2]/35 text-white'
                      }`}
                    >
                      {actionMessage.text}
                    </div>
                  )}

                  {/* Formulário de Comprovante inline se aberto */}
                  {receiptTxId === order.txId && (
                    <div className="p-3.5 bg-[#262626] rounded-2xl border border-[#FF57B2]/35 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">
                          Informar Código de Autenticação do Comprovante:
                        </span>
                        <button
                          onClick={() => setReceiptTxId(null)}
                          className="text-[11px] text-[#FF57B2] hover:underline cursor-pointer"
                        >
                          Cancelar
                        </button>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Ex: E18236120202309..."
                          value={receiptInput}
                          onChange={(e) => setReceiptInput(e.target.value)}
                          className="flex-1 rounded-xl bg-[#181818] px-3 py-2 text-xs border border-zinc-700 text-white focus:border-[#FF57B2] focus:outline-hidden"
                        />
                        <button
                          onClick={() => handleSubmitReceiptCode(order)}
                          disabled={submittingReceipt || !receiptInput.trim()}
                          className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white px-4 py-2 text-xs font-bold hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer"
                        >
                          {submittingReceipt ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Enviar'}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Seção Exclusiva de Desenvolvedor / Admin */}
                  {isDeveloper && !isCompleted && (
                    <div className="p-3 bg-[#262626] rounded-2xl border border-[#FF57B2]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs text-zinc-200">
                      <div>
                        <strong className="flex items-center gap-1 text-white">
                          <Sparkles className="h-3.5 w-3.5 text-[#FF57B2]" />
                          Controle de Titular / Desenvolvedor (GB Payment)
                        </strong>
                        <p className="text-[11px] text-zinc-300">
                          Você realizou o teste deste pedido? Aprove e libere os Kards para sua conta com um clique.
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleAdminApproveOrder(order)}
                        disabled={approvingTxId === order.txId}
                        className="shrink-0 rounded-xl bg-[#181818] hover:bg-[#FF57B2] border border-[#FF57B2]/40 text-white font-bold text-xs px-4 py-2 transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        {approvingTxId === order.txId ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        )}
                        <span>Aprovar & Liberar Kards</span>
                      </button>
                    </div>
                  )}

                  {/* Ações do Comprador */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      {!isCompleted && !expired && (
                        <button
                          type="button"
                          onClick={() => onOpenOrder(order)}
                          className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] text-white px-4 py-2.5 text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-[#FF57B2]/20 cursor-pointer"
                        >
                          <QrCode className="h-3.5 w-3.5" />
                          <span>Ver QR Code / Pagar</span>
                        </button>
                      )}

                      {!isCompleted && (
                        <button
                          type="button"
                          onClick={() => handleCheckOrderPayment(order)}
                          disabled={verifyingTxId === order.txId}
                          className="rounded-xl bg-[#262626] hover:bg-zinc-800 border border-zinc-700 text-white px-3.5 py-2.5 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                        >
                          {verifyingTxId === order.txId ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin text-[#FF57B2]" />
                          ) : (
                            <RefreshCw className="h-3.5 w-3.5 text-[#FF57B2]" />
                          )}
                          <span>Verificar Pagamento</span>
                        </button>
                      )}

                      {!isCompleted && !isUnderReview && (
                        <button
                          type="button"
                          onClick={() => {
                            setReceiptTxId(order.txId);
                            setReceiptInput('');
                          }}
                          className="rounded-xl bg-[#181818] hover:bg-zinc-800 border border-zinc-700 text-zinc-200 px-3 py-2.5 text-xs font-medium transition flex items-center gap-1 cursor-pointer"
                        >
                          <FileCheck className="h-3.5 w-3.5 text-[#FF57B2]" />
                          <span>Informar Comprovante</span>
                        </button>
                      )}
                    </div>

                    {!isCompleted && (
                      <button
                        type="button"
                        onClick={() => handleCancelOrder(order)}
                        disabled={cancellingTxId === order.txId}
                        className="text-xs text-zinc-400 hover:text-[#FF80C5] underline transition cursor-pointer"
                      >
                        {cancellingTxId === order.txId ? 'Descartando...' : 'Descartar pedido'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
