import React, { useState, useEffect, useRef } from 'react';
import { Search, User, X, Hash, ShieldCheck, Loader2 } from 'lucide-react';
import { PublicUserProfile, searchPublicUsers } from '../services/userService';
import { usePublicProfile } from '../context/PublicProfileContext';
import { UserAvatar } from './UserAvatar';
import { UserBadges } from './UserBadges';

interface UserSearchBarProps {
  placeholder?: string;
  onSelectUser?: (user: PublicUserProfile) => void;
  className?: string;
}

export const UserSearchBar: React.FC<UserSearchBarProps> = ({
  placeholder = 'Buscar usuários por nome, @username ou ID (ex: KRD-10492)...',
  onSelectUser,
  className = '',
}) => {
  const { openUserProfile } = usePublicProfile();
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<PublicUserProfile[]>([]);
  const [searching, setSearching] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const timer = setTimeout(async () => {
      const trimmed = searchTerm.trim();
      if (!trimmed) {
        setResults([]);
        setSearching(false);
        return;
      }

      setSearching(true);
      try {
        const found = await searchPublicUsers(trimmed, 8);
        setResults(found);
      } catch (err) {
        console.error('Error in search:', err);
      } finally {
        setSearching(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (user: PublicUserProfile) => {
    if (onSelectUser) {
      onSelectUser(user);
    } else {
      openUserProfile(user);
    }
    setIsOpen(false);
  };

  return (
    <div ref={dropdownRef} className={`relative ${className}`}>
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[#FF57B2]" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder}
          className="w-full rounded-2xl border border-zinc-700 bg-[#181818] py-2.5 pl-10 pr-9 text-xs text-white placeholder:text-zinc-500 focus:border-[#FF57B2] focus:outline-none shadow-xs"
        />
        {searchTerm && (
          <button
            type="button"
            onClick={() => {
              setSearchTerm('');
              setResults([]);
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Results Dropdown */}
      {isOpen && searchTerm.trim() && (
        <div className="absolute left-0 right-0 top-full z-40 mt-1.5 rounded-2xl border border-zinc-800 bg-[#202020] p-2 shadow-2xl max-h-72 overflow-y-auto space-y-1">
          {searching ? (
            <div className="flex items-center justify-center gap-2 py-4 text-xs text-zinc-400">
              <Loader2 className="h-4 w-4 animate-spin text-[#FF57B2]" />
              <span>Pesquisando usuários...</span>
            </div>
          ) : results.length === 0 ? (
            <div className="py-4 text-center text-xs text-zinc-400">
              Nenhum usuário encontrado com "{searchTerm}".
            </div>
          ) : (
            results.map((u) => (
              <button
                key={u.id}
                type="button"
                onClick={() => handleSelect(u)}
                className="w-full text-left rounded-xl p-2 hover:bg-[#262626] transition flex items-center gap-3 cursor-pointer border border-transparent hover:border-[#FF57B2]/35"
              >
                <UserAvatar
                  userId={u.id}
                  userName={u.displayName}
                  photoURL={u.photoURL}
                  sizeClass="h-8 w-8"
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-bold text-white truncate font-display">
                      {u.displayName}
                    </span>
                    <UserBadges
                      userId={u.id}
                      isVerified={u.isVerifiedWriter}
                      hasExperienced={u.hasExperiencedReaderBadge}
                      role={u.role}
                      size="xs"
                      isLight={false}
                    />
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-zinc-400">
                    <span className="font-mono">{u.username}</span>
                    <span>•</span>
                    <span className="font-mono font-bold text-[#FF80C5] flex items-center gap-0.5">
                      <Hash className="h-2 w-2" />
                      {u.uniqueId}
                    </span>
                  </div>
                </div>

                <span className="rounded-md bg-[#262626] border border-zinc-700 px-2 py-0.5 text-[10px] font-semibold text-zinc-300 uppercase">
                  {u.role}
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
};
