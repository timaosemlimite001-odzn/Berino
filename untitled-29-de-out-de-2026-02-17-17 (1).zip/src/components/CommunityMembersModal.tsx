import {
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  updateDoc,
} from 'firebase/firestore';
import {
  Ban,
  Check,
  Clock,
  Crown,
  Filter,
  Loader2,
  Search,
  Shield,
  UserCheck,
  UserMinus,
  UserPlus,
  Users,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import React, { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { db } from '../services/firebase';
import { awardXp, sendNotification } from '../services/progressionService';
import {
  fetchUsersActivityMap,
  PlatformActivityStatus,
} from '../services/userService';
import { Community, CommunityMember, UserProfile } from '../types';
import { ConfirmModal } from './ConfirmModal';
import { UserAvatar } from './UserAvatar';
import { UserBadges } from './UserBadges';

interface CommunityMembersModalProps {
  isOpen: boolean;
  onClose: () => void;
  community: Community;
  canPromote?: boolean;
  onUpdateCommunity: (updated: Partial<Community>) => void;
}

type MemberFilterTab =
  | 'all'
  | 'active'
  | 'inactive'
  | 'staff'
  | 'pending'
  | 'banned';

type MemberSortMode =
  | 'role_priority'
  | 'active_desc'
  | 'active_asc'
  | 'joined_desc';

export const CommunityMembersModal: React.FC<CommunityMembersModalProps> = ({
  isOpen,
  onClose,
  community,
  onUpdateCommunity,
}) => {
  const { currentUser, isDeveloper } = useAuth();
  const { openUserProfile } = usePublicProfile();
  const { addToast } = useNotifications();

  const [members, setMembers] = useState<CommunityMember[]>([]);
  const [loadingMembers, setLoadingMembers] = useState(true);
  const [activityMap, setActivityMap] = useState<
    Record<
      string,
      { profile: Partial<UserProfile> | null; activity: PlatformActivityStatus }
    >
  >({});
  const [loadingActivity, setLoadingActivity] = useState(false);

  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<MemberFilterTab>('all');
  const [sortMode, setSortMode] = useState<MemberSortMode>('role_priority');

  const [actionLoadingUserId, setActionLoadingUserId] = useState<string | null>(
    null
  );
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    type: 'remove' | 'ban';
    member: CommunityMember | null;
  }>({
    isOpen: false,
    type: 'remove',
    member: null,
  });

  const isCreatorViewer = Boolean(
    currentUser && currentUser.uid === community.creatorId
  );
  const isTopAuthority = isCreatorViewer || Boolean(isDeveloper);

  // 1. Real-time subscription to community members
  useEffect(() => {
    if (!isOpen || !community.id) return;
    setLoadingMembers(true);

    const q = query(
      collection(db, 'communities', community.id, 'members'),
      orderBy('joinedAt', 'desc')
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const loaded: CommunityMember[] = [];
        snap.forEach((d) => {
          const raw = d.data() as CommunityMember;
          loaded.push({
            ...raw,
            id: raw.id || d.id,
            userId: raw.userId || d.id,
          });
        });

        // Guarantee founder appears in list even on older community documents
        if (
          community.creatorId &&
          !loaded.some((m) => m.userId === community.creatorId)
        ) {
          loaded.unshift({
            id: community.creatorId,
            communityId: community.id,
            userId: community.creatorId,
            userName: community.creatorName || 'Fundador',
            role: 'creator',
            status: 'active',
            joinedAt: community.createdAt || new Date().toISOString(),
          });
        }

        setMembers(loaded);
        setLoadingMembers(false);
      },
      (err) => {
        console.error('Error loading community members modal:', err);
        setLoadingMembers(false);
      }
    );

    return () => unsub();
  }, [isOpen, community.id, community.creatorId, community.creatorName]);

  // 2. Load real platform activity status (exact Developer Area criteria) for all members & banned users
  useEffect(() => {
    if (!isOpen) return;
    const allIds = Array.from(
      new Set([
        ...members.map((m) => m.userId),
        ...(community.bannedUserIds || []),
      ])
    ).filter(Boolean);

    if (allIds.length === 0) return;

    let cancelled = false;
    setLoadingActivity(true);
    fetchUsersActivityMap(allIds)
      .then((res) => {
        if (!cancelled) {
          setActivityMap(res);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setLoadingActivity(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [isOpen, members, community.bannedUserIds]);

  const activeCommunityMembers = useMemo(
    () =>
      members.filter(
        (m) =>
          m.status !== 'pending' &&
          m.status !== 'banned' &&
          !(community.bannedUserIds || []).includes(m.userId)
      ),
    [members, community.bannedUserIds]
  );

  const pendingRequests = useMemo(
    () => members.filter((m) => m.status === 'pending'),
    [members]
  );

  const bannedUserIds = community.bannedUserIds || [];

  const getEffectiveRole = (
    m: CommunityMember
  ): 'creator' | 'moderator' | 'partial_moderator' | 'member' => {
    if (m.userId === community.creatorId || m.role === 'creator') {
      return 'creator';
    }
    if (m.role === 'moderator') {
      return 'moderator';
    }
    if (
      m.role === 'partial_moderator' ||
      community.partialModeratorIds?.includes(m.userId)
    ) {
      return 'partial_moderator';
    }
    return 'member';
  };

  // KPI metrics using exact Developer Area activity criteria (<= 3 days vs > 3 days)
  const kpiStats = useMemo(() => {
    let activeCount = 0;
    let inactiveCount = 0;
    for (const m of activeCommunityMembers) {
      const info = activityMap[m.userId]?.activity;
      if (info?.isActive) {
        activeCount += 1;
      } else {
        inactiveCount += 1;
      }
    }
    return {
      total: activeCommunityMembers.length,
      activeCount,
      inactiveCount,
      pendingCount: pendingRequests.length,
      bannedCount: bannedUserIds.length,
    };
  }, [
    activeCommunityMembers,
    activityMap,
    pendingRequests.length,
    bannedUserIds.length,
  ]);

  // Filtered & sorted active members
  const displayedMembers = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();

    const filtered = activeCommunityMembers.filter((m) => {
      const userEntry = activityMap[m.userId];
      const profile = userEntry?.profile;
      const act = userEntry?.activity;
      const role = getEffectiveRole(m);

      if (activeFilter === 'active' && !act?.isActive) return false;
      if (activeFilter === 'inactive' && act?.isActive) return false;
      if (activeFilter === 'staff' && role === 'member') return false;

      if (!term) return true;
      const name = (profile?.displayName || m.userName || '').toLowerCase();
      const username = (profile?.username || '').toLowerCase();
      const uniqueId = (profile?.uniqueId || '').toLowerCase();
      return (
        name.includes(term) ||
        username.includes(term) ||
        uniqueId.includes(term) ||
        m.userId.toLowerCase().includes(term)
      );
    });

    const roleRank = (r: string) =>
      r === 'creator'
        ? 0
        : r === 'moderator'
        ? 1
        : r === 'partial_moderator'
        ? 2
        : 3;

    return [...filtered].sort((a, b) => {
      const actA = activityMap[a.userId]?.activity;
      const actB = activityMap[b.userId]?.activity;

      if (sortMode === 'active_desc') {
        return (actB?.lastAccessTime || 0) - (actA?.lastAccessTime || 0);
      }
      if (sortMode === 'active_asc') {
        return (actA?.lastAccessTime || 0) - (actB?.lastAccessTime || 0);
      }
      if (sortMode === 'joined_desc') {
        return (
          new Date(b.joinedAt || 0).getTime() -
          new Date(a.joinedAt || 0).getTime()
        );
      }
      const rankDiff =
        roleRank(getEffectiveRole(a)) - roleRank(getEffectiveRole(b));
      if (rankDiff !== 0) return rankDiff;
      return (actB?.lastAccessTime || 0) - (actA?.lastAccessTime || 0);
    });
  }, [
    activeCommunityMembers,
    activityMap,
    activeFilter,
    searchTerm,
    sortMode,
    community.creatorId,
    community.partialModeratorIds,
  ]);

  if (!isOpen) return null;

  // Authorization check per target member
  const canManageTargetMember = (target: CommunityMember): boolean => {
    const targetRole = getEffectiveRole(target);
    if (targetRole === 'creator') return false; // Founder cannot be demoted/banned from their own community
    if (currentUser && target.userId === currentUser.uid) return false;
    if (isTopAuthority) return true;
    // A promoted community moderator can manage regular members & partial moderators, not peer full moderators
    return targetRole !== 'moderator';
  };

  // Change Member Role (Promote / Demote)
  const handleChangeMemberRole = async (
    member: CommunityMember,
    nextRole: 'moderator' | 'partial_moderator' | 'member'
  ) => {
    if (!canManageTargetMember(member)) return;
    if (nextRole === 'moderator' && !isTopAuthority) return;

    setActionLoadingUserId(member.userId);
    try {
      await updateDoc(
        doc(db, 'communities', community.id, 'members', member.userId),
        { role: nextRole }
      );

      if (nextRole === 'partial_moderator') {
        await updateDoc(doc(db, 'communities', community.id), {
          partialModeratorIds: arrayUnion(member.userId),
        });
        const nextPartial = Array.from(
          new Set([...(community.partialModeratorIds || []), member.userId])
        );
        onUpdateCommunity({ partialModeratorIds: nextPartial });
      } else if (community.partialModeratorIds?.includes(member.userId)) {
        await updateDoc(doc(db, 'communities', community.id), {
          partialModeratorIds: arrayRemove(member.userId),
        });
        const nextPartial = (community.partialModeratorIds || []).filter(
          (id) => id !== member.userId
        );
        onUpdateCommunity({ partialModeratorIds: nextPartial });
      }

      const roleLabel =
        nextRole === 'moderator'
          ? 'Administrador / Moderador'
          : nextRole === 'partial_moderator'
          ? 'Moderador Parcial'
          : 'Membro';

      if (nextRole !== 'member') {
        sendNotification(
          member.userId,
          'system',
          `Novo cargo em "${community.name}"`,
          `Você foi promovido a ${roleLabel} na comunidade "${community.name}".`,
          `/comunidade/${community.id}`
        ).catch(() => {});
      }

      addToast({
        id: `role_upd_${member.userId}_${Date.now()}`,
        type: 'system',
        title: 'Cargo atualizado',
        message: `${member.userName} agora é ${roleLabel}.`,
      });
    } catch (err) {
      console.error('Error updating member role:', err);
      addToast({
        id: `role_err_${Date.now()}`,
        type: 'system',
        title: 'Erro ao alterar cargo',
        message: 'Não foi possível salvar a alteração de cargo.',
      });
    } finally {
      setActionLoadingUserId(null);
    }
  };

  // Silence / Unsilence inside community
  const handleToggleSilence = async (
    member: CommunityMember,
    hours: number | null
  ) => {
    if (!canManageTargetMember(member)) return;
    setActionLoadingUserId(member.userId);

    try {
      if (hours === null) {
        const nextMap = { ...(community.silencedUntilMap || {}) };
        delete nextMap[member.userId];
        const nextIds = (community.silencedUserIds || []).filter(
          (id) => id !== member.userId
        );
        await updateDoc(doc(db, 'communities', community.id), {
          silencedUserIds: arrayRemove(member.userId),
          silencedUntilMap: nextMap,
        });
        onUpdateCommunity({
          silencedUserIds: nextIds,
          silencedUntilMap: nextMap,
        });
      } else {
        const untilIso = new Date(
          Date.now() + hours * 3600 * 1000
        ).toISOString();
        const nextMap = {
          ...(community.silencedUntilMap || {}),
          [member.userId]: untilIso,
        };
        const nextIds = Array.from(
          new Set([...(community.silencedUserIds || []), member.userId])
        );
        await updateDoc(doc(db, 'communities', community.id), {
          silencedUserIds: arrayUnion(member.userId),
          silencedUntilMap: nextMap,
        });
        onUpdateCommunity({
          silencedUserIds: nextIds,
          silencedUntilMap: nextMap,
        });
      }
    } catch (err) {
      console.error('Error toggling member silence:', err);
    } finally {
      setActionLoadingUserId(null);
    }
  };

  // Remove member from community
  const handleConfirmRemove = async (member: CommunityMember) => {
    if (!canManageTargetMember(member)) return;
    setActionLoadingUserId(member.userId);
    try {
      await deleteDoc(
        doc(db, 'communities', community.id, 'members', member.userId)
      );
      const updatedCount = Math.max(1, (community.membersCount || 1) - 1);
      const updates: Record<string, any> = {
        membersCount: updatedCount,
      };
      if (community.partialModeratorIds?.includes(member.userId)) {
        updates.partialModeratorIds = arrayRemove(member.userId);
      }
      await updateDoc(doc(db, 'communities', community.id), updates);

      onUpdateCommunity({
        membersCount: updatedCount,
        ...(community.partialModeratorIds?.includes(member.userId)
          ? {
              partialModeratorIds: (community.partialModeratorIds || []).filter(
                (id) => id !== member.userId
              ),
            }
          : {}),
      });

      addToast({
        id: `rem_mem_${member.userId}_${Date.now()}`,
        type: 'system',
        title: 'Membro removido',
        message: `${member.userName} foi removido da comunidade.`,
      });
    } catch (err) {
      console.error('Error removing community member:', err);
    } finally {
      setActionLoadingUserId(null);
    }
  };

  // Ban member from community
  const handleConfirmBan = async (member: CommunityMember) => {
    if (!canManageTargetMember(member)) return;
    setActionLoadingUserId(member.userId);
    try {
      const updatedBanned = Array.from(
        new Set([...(community.bannedUserIds || []), member.userId])
      );
      const updatedCount = Math.max(1, (community.membersCount || 1) - 1);

      await updateDoc(doc(db, 'communities', community.id), {
        bannedUserIds: arrayUnion(member.userId),
        partialModeratorIds: arrayRemove(member.userId),
        membersCount: updatedCount,
      });

      await deleteDoc(
        doc(db, 'communities', community.id, 'members', member.userId)
      );

      onUpdateCommunity({
        bannedUserIds: updatedBanned,
        partialModeratorIds: (community.partialModeratorIds || []).filter(
          (id) => id !== member.userId
        ),
        membersCount: updatedCount,
      });

      addToast({
        id: `ban_mem_${member.userId}_${Date.now()}`,
        type: 'system',
        title: 'Usuário banido da comunidade',
        message: `${member.userName} não poderá mais acessar ou interagir nesta comunidade.`,
      });
    } catch (err) {
      console.error('Error banning community member:', err);
    } finally {
      setActionLoadingUserId(null);
    }
  };

  // Unban user from community
  const handleUnbanUser = async (uid: string) => {
    setActionLoadingUserId(uid);
    try {
      await updateDoc(doc(db, 'communities', community.id), {
        bannedUserIds: arrayRemove(uid),
      });
      const updatedBanned = (community.bannedUserIds || []).filter(
        (id) => id !== uid
      );
      onUpdateCommunity({ bannedUserIds: updatedBanned });
      addToast({
        id: `unban_${uid}_${Date.now()}`,
        type: 'system',
        title: 'Banimento removido',
        message: 'O usuário pode voltar a participar desta comunidade.',
      });
    } catch (err) {
      console.error('Error unbanning user:', err);
    } finally {
      setActionLoadingUserId(null);
    }
  };

  // Approve / Reject pending join requests
  const handleApprovePending = async (member: CommunityMember) => {
    setActionLoadingUserId(member.userId);
    try {
      await updateDoc(
        doc(db, 'communities', community.id, 'members', member.userId),
        {
          status: 'active',
          joinedAt: new Date().toISOString(),
        }
      );
      const updatedCount = (community.membersCount || 1) + 1;
      await updateDoc(doc(db, 'communities', community.id), {
        membersCount: updatedCount,
      });
      onUpdateCommunity({ membersCount: updatedCount });

      await sendNotification(
        member.userId,
        'community_join',
        'Entrada aprovada na comunidade!',
        `Sua solicitação para entrar em "${community.name}" foi aprovada.`,
        `/comunidade/${community.id}`
      );
      await awardXp(
        member.userId,
        15,
        `join_comm_${community.id}`,
        `Entrou no grupo: ${community.name}`
      );
    } catch (err) {
      console.error('Error approving pending member:', err);
    } finally {
      setActionLoadingUserId(null);
    }
  };

  const handleRejectPending = async (member: CommunityMember) => {
    setActionLoadingUserId(member.userId);
    try {
      await deleteDoc(
        doc(db, 'communities', community.id, 'members', member.userId)
      );
    } catch (err) {
      console.error('Error rejecting pending member:', err);
    } finally {
      setActionLoadingUserId(null);
    }
  };

  const renderActivityStatusBadge = (uid: string) => {
    const entry = activityMap[uid];
    if (!entry && loadingActivity) {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] text-zinc-400">
          <Loader2 className="h-3 w-3 animate-spin text-[#FF57B2]" />
          <span>Verificando...</span>
        </span>
      );
    }

    const stat = entry?.activity;
    if (!stat) return null;

    if (stat.isBanned) {
      return (
        <div className="flex flex-col items-start sm:items-end gap-0.5">
          <span className="inline-flex items-center gap-1 rounded-md bg-[#181818] border border-[#FF57B2]/50 text-[#FF80C5] px-2 py-0.5 text-[10px] font-bold">
            <Ban className="h-3 w-3" />
            <span>Banido na Plataforma</span>
          </span>
        </div>
      );
    }

    if (stat.isSilenced) {
      return (
        <div className="flex flex-col items-start sm:items-end gap-0.5">
          <span className="inline-flex items-center gap-1 rounded-md bg-[#181818] border border-zinc-600 text-zinc-200 px-2 py-0.5 text-[10px] font-bold">
            <VolumeX className="h-3 w-3" />
            <span>Silenciado Globalmente</span>
          </span>
        </div>
      );
    }

    if (stat.isActive) {
      return (
        <div className="flex flex-col items-start sm:items-end gap-0.5">
          <span
            className="inline-flex items-center gap-1.5 rounded-md bg-[#FF57B2]/15 text-[#FF80C5] px-2 py-0.5 text-[10px] font-bold border border-[#FF57B2]/40"
            title="Critério oficial do Desenvolvedor: acessou a plataforma nos últimos 3 dias"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF57B2] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#FF57B2]" />
            </span>
            <span>Ativo</span>
          </span>
          <span className="text-[10px] text-zinc-400 tabular-nums">
            {stat.activeRecencyLabel} · {stat.tenureLabel} no site
          </span>
        </div>
      );
    }

    return (
      <div className="flex flex-col items-start sm:items-end gap-0.5">
        <span
          className="inline-flex items-center gap-1 rounded-md bg-[#181818] text-zinc-300 px-2 py-0.5 text-[10px] font-medium border border-zinc-700"
          title="Critério oficial do Desenvolvedor: mais de 3 dias consecutivos sem acessar a plataforma"
        >
          <Clock className="h-3 w-3 text-zinc-400" />
          <span>{stat.inactiveDurationLabel || 'Inativo'}</span>
        </span>
        <span className="text-[10px] text-zinc-500 tabular-nums">
          &gt; 3 dias sem acesso · {stat.tenureLabel} no site
        </span>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-3 sm:p-5 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-3xl rounded-3xl bg-[#202020] text-white border border-zinc-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-zinc-800 p-4 sm:p-5 bg-[#262626] shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-xs">
              <Users className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-sm sm:text-base text-white font-display truncate">
                Membros & Controle de Usuários · {community.name}
              </h3>
              <p className="text-[11px] text-zinc-400 truncate">
                Status de atividade (critério oficial ≤ 3 dias), promoção de cargos e moderação do grupo.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-xl p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer shrink-0"
            aria-label="Fechar janela de membros"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* KPI Activity Strip (Mirrors Developer Area Metrics) */}
        <div className="px-4 sm:px-6 pt-4 pb-3 bg-[#1D1D1D] border-b border-zinc-800/80 space-y-3 shrink-0">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="rounded-2xl bg-[#181818] border border-zinc-800 p-2.5">
              <span className="text-[10px] uppercase font-bold text-zinc-400 block">
                Total no Grupo
              </span>
              <span className="text-lg font-black text-white font-display tabular-nums">
                {kpiStats.total}
              </span>
            </div>

            <div className="rounded-2xl bg-[#FF57B2]/10 border border-[#FF57B2]/35 p-2.5">
              <span className="text-[10px] uppercase font-bold text-[#FF80C5] block">
                Ativos (&le; 3 dias)
              </span>
              <span className="text-lg font-black text-white font-display tabular-nums">
                {kpiStats.activeCount}
              </span>
            </div>

            <div className="rounded-2xl bg-[#181818] border border-zinc-700 p-2.5">
              <span className="text-[10px] uppercase font-bold text-zinc-300 block">
                Inativos (&gt; 3 dias)
              </span>
              <span className="text-lg font-black text-zinc-200 font-display tabular-nums">
                {kpiStats.inactiveCount}
              </span>
            </div>

            <div className="rounded-2xl bg-[#262626] border border-zinc-700 p-2.5">
              <span className="text-[10px] uppercase font-bold text-zinc-400 block">
                Banidos / Pendentes
              </span>
              <span className="text-lg font-black text-white font-display tabular-nums">
                {kpiStats.bannedCount} / {kpiStats.pendingCount}
              </span>
            </div>
          </div>

          {/* Search, Sort & Filter Controls */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#FF57B2]" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar membro por nome, @username ou ID KRD..."
                className="w-full rounded-xl border border-zinc-700 bg-[#181818] py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 rounded-xl bg-[#181818] border border-zinc-700 px-3 py-2 text-xs shrink-0">
              <Filter className="h-3.5 w-3.5 text-[#FF57B2] shrink-0" />
              <select
                value={sortMode}
                onChange={(e) => setSortMode(e.target.value as MemberSortMode)}
                className="bg-[#181818] font-bold text-white focus:outline-none cursor-pointer text-xs [color-scheme:dark]"
              >
                <option value="role_priority">Cargo & Atividade</option>
                <option value="active_desc">Mais ativos → menos ativos</option>
                <option value="active_asc">Menos ativos → mais ativos</option>
                <option value="joined_desc">Entrada mais recente</option>
              </select>
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
            {[
              { id: 'all', label: `Todos (${kpiStats.total})` },
              { id: 'active', label: `Ativos (${kpiStats.activeCount})` },
              { id: 'inactive', label: `Inativos (${kpiStats.inactiveCount})` },
              { id: 'staff', label: 'Equipe & Cargos' },
              ...(kpiStats.pendingCount > 0
                ? [{ id: 'pending', label: `Solicitações (${kpiStats.pendingCount})` }]
                : []),
              ...(kpiStats.bannedCount > 0
                ? [{ id: 'banned', label: `Banidos (${kpiStats.bannedCount})` }]
                : []),
            ].map((tab) => {
              const selected = activeFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveFilter(tab.id as MemberFilterTab)}
                  className={`rounded-lg px-3 py-1.5 text-[11px] font-bold whitespace-nowrap transition cursor-pointer ${
                    selected
                      ? 'bg-[#FF57B2] text-white'
                      : 'bg-[#262626] text-zinc-300 hover:text-white border border-zinc-800'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
          {loadingMembers ? (
            <div className="py-16 flex flex-col items-center justify-center gap-2 text-zinc-400 text-xs">
              <Loader2 className="h-6 w-6 animate-spin text-[#FF57B2]" />
              <span>Carregando lista de membros da comunidade...</span>
            </div>
          ) : activeFilter === 'pending' ? (
            /* Pending Join Requests View */
            pendingRequests.length === 0 ? (
              <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-8 text-center text-xs text-zinc-400">
                Nenhuma solicitação de entrada pendente no momento.
              </div>
            ) : (
              <div className="space-y-2.5">
                {pendingRequests.map((pm) => {
                  const profile = activityMap[pm.userId]?.profile;
                  return (
                    <div
                      key={pm.userId}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-[#FF57B2]/40 bg-[#262626] p-3.5"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <UserAvatar
                          userId={pm.userId}
                          userName={profile?.displayName || pm.userName}
                          photoURL={profile?.photoURL || pm.userPhoto}
                          sizeClass="h-10 w-10 shrink-0"
                          onClick={() => openUserProfile(pm.userId)}
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <button
                              type="button"
                              onClick={() => openUserProfile(pm.userId)}
                              className="font-bold text-xs sm:text-sm text-white hover:text-[#FF57B2] hover:underline truncate cursor-pointer"
                            >
                              {profile?.displayName || pm.userName}
                            </button>
                            <UserBadges
                              userId={pm.userId}
                              isLight={false}
                              size="xs"
                            />
                          </div>
                          <p className="text-[11px] text-zinc-400 truncate">
                            {profile?.username || `@usuario_${pm.userId.slice(0, 5)}`}
                            {profile?.uniqueId ? ` · ${profile.uniqueId}` : ''}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center justify-between sm:justify-end gap-3">
                        {renderActivityStatusBadge(pm.userId)}
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleApprovePending(pm)}
                            disabled={actionLoadingUserId === pm.userId}
                            className="inline-flex items-center gap-1 rounded-xl bg-[#FF57B2] hover:bg-[#E03595] text-white px-3 py-1.5 text-[11px] font-bold transition cursor-pointer disabled:opacity-50"
                          >
                            <UserCheck className="h-3.5 w-3.5" />
                            <span>Aprovar</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRejectPending(pm)}
                            disabled={actionLoadingUserId === pm.userId}
                            className="inline-flex items-center gap-1 rounded-xl bg-[#181818] hover:bg-zinc-800 text-zinc-300 border border-zinc-700 px-3 py-1.5 text-[11px] font-semibold transition cursor-pointer disabled:opacity-50"
                          >
                            <X className="h-3.5 w-3.5" />
                            <span>Recusar</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          ) : activeFilter === 'banned' ? (
            /* Banned Users View */
            bannedUserIds.length === 0 ? (
              <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-8 text-center text-xs text-zinc-400">
                Nenhum usuário banido nesta comunidade.
              </div>
            ) : (
              <div className="space-y-2.5">
                {bannedUserIds.map((uid) => {
                  const profile = activityMap[uid]?.profile;
                  return (
                    <div
                      key={uid}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-zinc-800 bg-[#262626] p-3.5"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <UserAvatar
                          userId={uid}
                          userName={profile?.displayName || 'Usuário Banido'}
                          photoURL={profile?.photoURL}
                          sizeClass="h-10 w-10 shrink-0"
                          onClick={() => openUserProfile(uid)}
                        />
                        <div className="min-w-0">
                          <button
                            type="button"
                            onClick={() => openUserProfile(uid)}
                            className="font-bold text-xs sm:text-sm text-white hover:text-[#FF57B2] hover:underline truncate block cursor-pointer"
                          >
                            {profile?.displayName || `Usuário (${uid.slice(0, 8)})`}
                          </button>
                          <p className="text-[11px] text-zinc-400 truncate">
                            {profile?.username || ''}
                            {profile?.uniqueId
                              ? ` · ${profile.uniqueId}`
                              : `ID: ${uid}`}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-3">
                        {renderActivityStatusBadge(uid)}
                        <button
                          type="button"
                          onClick={() => handleUnbanUser(uid)}
                          disabled={actionLoadingUserId === uid}
                          className="inline-flex items-center gap-1.5 rounded-xl bg-[#FF57B2]/15 hover:bg-[#FF57B2]/25 text-[#FF80C5] border border-[#FF57B2]/40 px-3 py-1.5 text-[11px] font-bold transition cursor-pointer disabled:opacity-50"
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>
                            {actionLoadingUserId === uid
                              ? 'Desbanindo...'
                              : 'Desbanir do Grupo'}
                          </span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          ) : displayedMembers.length === 0 ? (
            <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-8 text-center text-xs text-zinc-400">
              Nenhum membro corresponde ao filtro ou pesquisa atual.
            </div>
          ) : (
            /* Main Members List with Activity Status + Role Promotion & Ban Controls */
            <div className="space-y-2.5">
              {displayedMembers.map((member) => {
                const profile = activityMap[member.userId]?.profile;
                const effectiveRole = getEffectiveRole(member);
                const canControl = canManageTargetMember(member);
                const silencedUntil = community.silencedUntilMap?.[member.userId];
                const isCommSilenced = Boolean(
                  silencedUntil &&
                    new Date(silencedUntil).getTime() > Date.now()
                );

                return (
                  <div
                    key={member.userId}
                    className="rounded-2xl border border-zinc-800 bg-[#262626] p-3.5 sm:p-4 space-y-3 hover:border-zinc-700 transition"
                  >
                    {/* Top Row: Identity + Official Activity Status */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      <div className="flex items-center gap-3 min-w-0">
                        <UserAvatar
                          userId={member.userId}
                          userName={profile?.displayName || member.userName}
                          photoURL={profile?.photoURL || member.userPhoto}
                          sizeClass="h-11 w-11 shrink-0"
                          onClick={() => openUserProfile(member.userId)}
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <button
                              type="button"
                              onClick={() => openUserProfile(member.userId)}
                              className="font-bold text-xs sm:text-sm text-white hover:text-[#FF57B2] hover:underline truncate cursor-pointer"
                            >
                              {profile?.displayName || member.userName}
                            </button>
                            <UserBadges
                              userId={member.userId}
                              isLight={false}
                              size="xs"
                            />
                            {effectiveRole === 'creator' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#FF80C5]">
                                <Crown className="h-3 w-3 text-[#FF57B2]" />
                                <span>Fundador</span>
                              </span>
                            ) : effectiveRole === 'moderator' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#FF80C5]">
                                <Shield className="h-3 w-3 text-[#FF57B2]" />
                                <span>Administrador / Moderador</span>
                              </span>
                            ) : effectiveRole === 'partial_moderator' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-zinc-200">
                                <Shield className="h-3 w-3 text-[#FF57B2]" />
                                <span>Moderador Parcial</span>
                              </span>
                            ) : (
                              <span className="text-[10px] text-zinc-400 font-semibold">
                                · Membro
                              </span>
                            )}
                          </div>

                          <p className="text-[11px] text-zinc-400 truncate mt-0.5">
                            {profile?.username ||
                              `@usuario_${member.userId.slice(0, 5)}`}
                            {profile?.uniqueId ? ` · ${profile.uniqueId}` : ''}
                            {member.joinedAt
                              ? ` · Entrou em ${new Date(
                                  member.joinedAt
                                ).toLocaleDateString('pt-BR')}`
                              : ''}
                          </p>
                        </div>
                      </div>

                      {/* Platform Activity Status (Same Criteria as Developer Panel) */}
                      <div className="shrink-0">
                        {renderActivityStatusBadge(member.userId)}
                      </div>
                    </div>

                    {/* Bottom Row: User Control Bar (Promote / Silence / Remove / Ban) */}
                    {canControl && (
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-zinc-800/80 text-xs">
                        {/* Role Promotion Selector */}
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-semibold text-zinc-400">
                            Cargo:
                          </span>
                          <select
                            value={effectiveRole}
                            disabled={actionLoadingUserId === member.userId}
                            onChange={(e) =>
                              handleChangeMemberRole(
                                member,
                                e.target.value as
                                  | 'moderator'
                                  | 'partial_moderator'
                                  | 'member'
                              )
                            }
                            className="rounded-xl border border-zinc-700 bg-[#181818] py-1.5 px-2.5 text-[11px] font-bold text-white focus:border-[#FF57B2] focus:outline-none cursor-pointer [color-scheme:dark]"
                          >
                            <option value="member">Membro</option>
                            <option value="partial_moderator">
                              Promover: Moderador Parcial (Pode Publicar)
                            </option>
                            {isTopAuthority && (
                              <option value="moderator">
                                Promover: Administrador / Moderador
                              </option>
                            )}
                          </select>
                        </div>

                        {/* Moderation Actions: Silence, Expel, Ban */}
                        <div className="flex flex-wrap items-center gap-1.5">
                          {isCommSilenced ? (
                            <button
                              type="button"
                              onClick={() => handleToggleSilence(member, null)}
                              disabled={actionLoadingUserId === member.userId}
                              className="inline-flex items-center gap-1 rounded-xl bg-[#181818] hover:bg-zinc-800 text-[#FF80C5] border border-[#FF57B2]/40 px-2.5 py-1.5 text-[11px] font-bold transition cursor-pointer"
                            >
                              <Volume2 className="h-3.5 w-3.5" />
                              <span>Remover Silêncio</span>
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleToggleSilence(member, 24)}
                              disabled={actionLoadingUserId === member.userId}
                              className="inline-flex items-center gap-1 rounded-xl bg-[#181818] hover:bg-zinc-800 text-zinc-300 border border-zinc-700 px-2.5 py-1.5 text-[11px] font-semibold transition cursor-pointer"
                              title="Silenciar por 24 horas nesta comunidade"
                            >
                              <VolumeX className="h-3.5 w-3.5 text-[#FF57B2]" />
                              <span>Silenciar 24h</span>
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() =>
                              setConfirmState({
                                isOpen: true,
                                type: 'remove',
                                member,
                              })
                            }
                            disabled={actionLoadingUserId === member.userId}
                            className="inline-flex items-center gap-1 rounded-xl bg-[#181818] hover:bg-zinc-800 text-zinc-300 border border-zinc-700 px-2.5 py-1.5 text-[11px] font-semibold transition cursor-pointer"
                            title="Remover membro da comunidade"
                          >
                            <UserMinus className="h-3.5 w-3.5" />
                            <span>Remover</span>
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              setConfirmState({
                                isOpen: true,
                                type: 'ban',
                                member,
                              })
                            }
                            disabled={actionLoadingUserId === member.userId}
                            className="inline-flex items-center gap-1 rounded-xl bg-[#FF57B2]/15 hover:bg-[#FF57B2] text-[#FF80C5] hover:text-white border border-[#FF57B2]/45 px-2.5 py-1.5 text-[11px] font-bold transition cursor-pointer"
                            title="Banir permanentemente desta comunidade"
                          >
                            <Ban className="h-3.5 w-3.5" />
                            <span>Banir</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-zinc-800 bg-[#1A1A1A] px-5 py-3 flex items-center justify-between text-[11px] text-zinc-400 shrink-0">
          <span>
            Critério de Atividade: ativo se acessou a plataforma nos últimos 3 dias.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-[#262626] hover:bg-zinc-800 border border-zinc-700 px-4 py-1.5 text-xs font-bold text-white transition cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>

      {/* Confirmation Modal for Remove / Ban */}
      <ConfirmModal
        isOpen={confirmState.isOpen && Boolean(confirmState.member)}
        onClose={() =>
          setConfirmState({ isOpen: false, type: 'remove', member: null })
        }
        onConfirm={() => {
          const target = confirmState.member;
          const actionType = confirmState.type;
          setConfirmState({ isOpen: false, type: 'remove', member: null });
          if (!target) return;
          if (actionType === 'ban') {
            handleConfirmBan(target);
          } else {
            handleConfirmRemove(target);
          }
        }}
        title={
          confirmState.type === 'ban'
            ? `Banir ${confirmState.member?.userName || 'usuário'}?`
            : `Remover ${confirmState.member?.userName || 'usuário'}?`
        }
        message={
          confirmState.type === 'ban'
            ? `Tem certeza que deseja banir ${
                confirmState.member?.userName || 'este usuário'
              } desta comunidade? Ele perderá acesso imediato e não poderá solicitar entrada novamente a menos que seja desbanido.`
            : `Deseja remover ${
                confirmState.member?.userName || 'este membro'
              } da comunidade? Ele deixará de fazer parte do grupo.`
        }
        confirmText={
          confirmState.type === 'ban' ? 'Confirmar Banimento' : 'Remover Membro'
        }
      />
    </div>
  );
};
