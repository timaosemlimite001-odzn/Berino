import React, { useState } from 'react';
import { X, ShieldCheck, FileText, Users, Lock, HeartHandshake } from 'lucide-react';

interface TermsPrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'terms' | 'privacy' | 'guidelines';
}

export const TermsPrivacyModal: React.FC<TermsPrivacyModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'terms',
}) => {
  const [activeTab, setActiveTab] = useState<'terms' | 'privacy' | 'guidelines'>(initialTab);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[85vh] flex flex-col rounded-3xl border border-zinc-800 bg-[#202020] text-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 p-5 shrink-0 bg-gradient-to-r from-[#262626] to-[#202020]">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-display">
                Transparência & Políticas KORDEL
              </h3>
              <p className="text-[11px] text-zinc-400">
                Compromisso com os direitos autorais, privacidade e convivência literária
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
            title="Fechar"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Tabs Bar */}
        <div className="flex border-b border-zinc-800 px-5 gap-2 shrink-0 bg-[#1A1A1A]">
          <button
            type="button"
            onClick={() => setActiveTab('terms')}
            className={`flex items-center gap-1.5 py-3 px-3 text-xs font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'terms'
                ? 'border-[#FF57B2] text-[#FF57B2]'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <FileText className="h-3.5 w-3.5" />
            <span>Termos de Uso</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('privacy')}
            className={`flex items-center gap-1.5 py-3 px-3 text-xs font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'privacy'
                ? 'border-[#FF57B2] text-[#FF57B2]'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Lock className="h-3.5 w-3.5" />
            <span>Políticas de Privacidade</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('guidelines')}
            className={`flex items-center gap-1.5 py-3 px-3 text-xs font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'guidelines'
                ? 'border-[#FF57B2] text-[#FF57B2]'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Users className="h-3.5 w-3.5" />
            <span>Diretrizes da Comunidade</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-zinc-300 leading-relaxed">
          {activeTab === 'terms' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/30 p-3.5 text-white">
                <p className="font-bold flex items-center gap-1.5 text-[#FF57B2]">
                  <HeartHandshake className="h-4 w-4 text-[#FF57B2] shrink-0" />
                  <span>Soberania do Autor & Propriedade Intelectual</span>
                </p>
                <p className="text-[11px] mt-1 text-zinc-300">
                  Todas as obras publicadas no KORDEL permanecem sob a propriedade intelectual irrestrita e exclusiva de seus respectivos autores. O KORDEL atua apenas como plataforma hospedeira e divulgadora.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  1. Objeto & Cadastro na Plataforma
                </h4>
                <p>
                  O KORDEL é uma plataforma digital voltada à leitura, publicação e fomento da literatura autoral e independente. Ao criar uma conta ou utilizar os serviços, o usuário compromete-se a fornecer informações verídicas e manter a segurança de suas credenciais de acesso.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  2. Direitos Autorais & Conteúdo Proibido
                </h4>
                <p>
                  É terminantemente proibido o plágio, cópia total ou parcial de textos sem autorização, ou o upload de materiais que violem leis de direitos autorais vigentes. Obras que infrinjam essas normas serão sumariamente removidas após verificação.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  3. Leituras Beta (Primeiro Olhar)
                </h4>
                <p>
                  Obras submetidas ao programa de leitura antecipada destinam-se à avaliação crítica construtiva por leitores experientes. Os leitores selecionados comprometem-se a respeitar o sigilo das narrativas inéditas antes de sua disponibilização definitiva.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  4. Moedas, Kards & Gamificação
                </h4>
                <p>
                  O sistema de progressão, XP, Kards e títulos possui finalidade cultural e recreativa dentro da comunidade, não constituindo valores financeiros resgatáveis fora da plataforma.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/30 p-3.5 text-white">
                <p className="font-bold text-[#FF80C5] flex items-center gap-1.5">
                  <Lock className="h-4 w-4 text-[#FF57B2] shrink-0" />
                  <span>Princípio da Coleta Mínima de Dados</span>
                </p>
                <p className="text-[11px] mt-1 text-zinc-300">
                  Respeitamos sua privacidade. Coletamos apenas o estritamente necessário para garantir o funcionamento do leitor, sincronização de progresso e autenticação segura.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  1. Informações Coletadas
                </h4>
                <p>
                  Coletamos seu endereço de e-mail e nome público para gestão da conta; dados de leitura (capítulos lidos, tempo de leitura e percentual) para fornecer a retomada de leitura contínua; e preferências de interface (modo escuro, tamanho de texto e margens).
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  2. Armazenamento e Não Compartilhamento
                </h4>
                <p>
                  Suas informações nunca são comercializadas para parceiros de publicidade ou corretores de dados. Todas as comunicações utilizam protocolos com criptografia de ponta a ponta (HTTPS/TLS).
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  3. Exclusão de Conta e Dados
                </h4>
                <p>
                  O usuário pode solicitar a qualquer momento a alteração, anonimização ou exclusão total de seus dados e obras publicadas através das configurações do perfil.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'guidelines' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/30 p-3.5 text-white">
                <p className="font-bold flex items-center gap-1.5 text-[#FF80C5]">
                  <Users className="h-4 w-4 text-[#FF57B2] shrink-0" />
                  <span>Convivência Respeitosa e Espírito Literário</span>
                </p>
                <p className="text-[11px] mt-1 text-zinc-300">
                  O KORDEL é uma praça literária acolhedora para quem escreve e para quem lê. O respeito à voz do outro é a base de todas as nossas comunidades.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  1. Crítica Construtiva e Empatia
                </h4>
                <p>
                  Incentivamos resenhas aprofundadas e apontamentos sinceros, sempre com polidez e foco no desenvolvimento da obra. Ataques pessoais a autores ou leitores não serão tolerados.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  2. Tolerância Zero a Discurso de Ódio
                </h4>
                <p>
                  Comentários preconceituosos, incitação à violência ou conteúdo difamatório resultarão em suspensão imediata e banimento da comunidade literária.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-white text-sm mb-1">
                  3. Uso Responsável de Spoilers
                </h4>
                <p>
                  Em discussões de capítulos e resenhas, utilize avisos claros caso seu comentário revele reviravoltas ou desfechos cruciais da trama.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-zinc-800 p-4 flex items-center justify-between bg-[#1A1A1A] shrink-0">
          <span className="text-[11px] text-zinc-400">
            Última atualização: Setembro de {new Date().getFullYear()}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] px-5 py-2 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/30 hover:shadow-[0_0_15px_rgba(255,87,178,0.5)] border border-[#FF57B2]/40 transition cursor-pointer"
          >
            Entendi e Concordo
          </button>
        </div>
      </div>
    </div>
  );
};
