import {
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import {
  CornerDownRight,
  Heart,
  Loader2,
  MessageCircle,
  Send,
  Trash2,
  X,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import {
  OperationType,
  db,
  handleFirestoreError,
  sanitizeFirestoreData,
} from '../services/firebase';
import { formatRelativeTimePt } from '../services/fluxService';
import { sendNotification } from '../services/progressionService';
import { CommunityComment, FluxFeedItem } from '../types';
import { UserAvatar } from './UserAvatar';
import { UserBadges } from './UserBadges';

interface FluxCommentsModalProps {
  isOpen: boolean;
  post: FluxFeedItem | null;
  onClose: () => void;
  onOpenAuth: () => void;
  onCommentsCountChange: (post: FluxFeedItem, nextCount: number) => void;
}

export const FluxCommentsModal: React.FC<FluxCommentsModalProps> = ({
  isOpen,
  post,
  onClose,
  onOpenAuth,
  onCommentsCountChange,
}) => {
  const { currentUser, userProfile, isDeveloper } = useAuth();
  const { openUserProfile } = usePublicProfile();

  const [comments, setComments] = useState<CommunityComment[]>([]);
  const [loading, setLoading] = useState(false);
  const [text, setText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [replyTarget, setReplyTarget] = useState<{
    id: string;
    authorName: string;
    authorId?: string;
  } | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen || !post) {
      setComments([]);
      setReplyTarget(null);
      setErrorMsg('');
      return;
    }

    setLoading(true);
    const commentsRef =
      post.postSource === 'community' && post.communityId
        ? collection(db, 'communities', post.communityId, 'posts', post.id, 'comments')
        : collection(db, 'fluxPosts', post.id, 'comments');

    const q = query(commentsRef, orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: CommunityComment[] = [];
        snap.forEach((d) => {
          const data = d.data() as CommunityComment;
          list.push({ ...data, id: data.id || d.id });
        });
        setComments(list);
        setLoading(false);
      },
      (err) => {
        console.error('[FluxCommentsModal] Error loading comments:', err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [isOpen, post?.id, post?.postSource, post?.communityId]);

  if (!isOpen || !post) return null;

  const getPostDocRef = () =>
    post.postSource === 'community' && post.communityId
      ? doc(db, 'communities', post.communityId, 'posts', post.id)
      : doc(db, 'fluxPosts', post.id);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const trimmed = text.trim();
    if (!trimmed) return;

    if (
      post.postSource === 'community' &&
      post.communityBannedUserIds?.includes(currentUser.uid)
    ) {
      setErrorMsg('Você não tem permissão para comentar nesta comunidade.');
      return;
    }

    setSubmitting(true);
    setErrorMsg('');

    const commentId = `fcomm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const commentDoc: CommunityComment = {
      id: commentId,
      postId: post.id,
      communityId: post.communityId || '',
      authorId: currentUser.uid,
      authorName: userProfile?.displayName || 'Leitor',
      authorPhoto: userProfile?.photoURL || '',
      userId: currentUser.uid,
      userName: userProfile?.displayName || 'Leitor',
      userPhoto: userProfile?.photoURL || '',
      content: trimmed,
      parentId: replyTarget?.id,
      replyToAuthorName: replyTarget?.authorName,
      likesCount: 0,
      likedUserIds: [],
      createdAt: new Date().toISOString(),
    };

    const commentDocRef =
      post.postSource === 'community' && post.communityId
        ? doc(
            db,
            'communities',
            post.communityId,
            'posts',
            post.id,
            'comments',
            commentId
          )
        : doc(db, 'fluxPosts', post.id, 'comments', commentId);

    const path =
      post.postSource === 'community' && post.communityId
        ? `communities/${post.communityId}/posts/${post.id}/comments/${commentId}`
        : `fluxPosts/${post.id}/comments/${commentId}`;

    try {
      await setDoc(commentDocRef, sanitizeFirestoreData(commentDoc));
      const nextCount = Math.max(comments.length + 1, (post.commentsCount || 0) + 1);
      await updateDoc(getPostDocRef(), {
        commentsCount: nextCount,
      });
      onCommentsCountChange(post, nextCount);

      if (post.authorId && post.authorId !== currentUser.uid) {
        sendNotification(
          post.authorId,
          'comment',
          'Novo comentário no Flux',
          `${userProfile?.displayName || 'Alguém'} comentou na sua publicação.`,
          post.communityId ? `/comunidade/${post.communityId}` : undefined
        ).catch(() => {});
      }

      setText('');
      setReplyTarget(null);
    } catch (err) {
      setErrorMsg('Não foi possível publicar o comentário.');
      try {
        handleFirestoreError(err, OperationType.CREATE, path);
      } catch {
        // already logged
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleCommentLike = async (comment: CommunityComment) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const liked = Boolean(comment.likedUserIds?.includes(currentUser.uid));
    const commentRef =
      post.postSource === 'community' && post.communityId
        ? doc(
            db,
            'communities',
            post.communityId,
            'posts',
            post.id,
            'comments',
            comment.id
          )
        : doc(db, 'fluxPosts', post.id, 'comments', comment.id);

    try {
      if (liked) {
        await updateDoc(commentRef, {
          likedUserIds: arrayRemove(currentUser.uid),
          likesCount: Math.max(0, (comment.likesCount || 1) - 1),
        });
      } else {
        await updateDoc(commentRef, {
          likedUserIds: arrayUnion(currentUser.uid),
          likesCount: (comment.likesCount || 0) + 1,
        });
      }
    } catch (err) {
      console.warn('Error liking comment:', err);
    }
  };

  const handleDeleteComment = async (comment: CommunityComment) => {
    if (!currentUser) return;
    const commentRef =
      post.postSource === 'community' && post.communityId
        ? doc(
            db,
            'communities',
            post.communityId,
            'posts',
            post.id,
            'comments',
            comment.id
          )
        : doc(db, 'fluxPosts', post.id, 'comments', comment.id);

    try {
      await deleteDoc(commentRef);
      const nextCount = Math.max(0, (post.commentsCount || comments.length) - 1);
      await updateDoc(getPostDocRef(), {
        commentsCount: nextCount,
      });
      onCommentsCountChange(post, nextCount);
    } catch (err) {
      console.warn('Error deleting comment:', err);
    }
  };

  const rootComments = comments.filter((c) => !c.parentId);
  const repliesByParent = comments.reduce<Record<string, CommunityComment[]>>(
    (acc, c) => {
      if (c.parentId) {
        if (!acc[c.parentId]) acc[c.parentId] = [];
        acc[c.parentId].push(c);
      }
      return acc;
    },
    {}
  );

  const renderCommentRow = (c: CommunityComment, isReply = false) => {
    const authorUid = c.authorId || c.userId || '';
    const authorLabel = c.authorName || c.userName || 'Leitor';
    const authorAvatar = c.authorPhoto || c.userPhoto || '';
    const isLiked = Boolean(currentUser && c.likedUserIds?.includes(currentUser.uid));
    const canDelete = Boolean(
      currentUser &&
        (currentUser.uid === authorUid ||
          currentUser.uid === post.authorId ||
          currentUser.uid === post.communityCreatorId ||
          isDeveloper)
    );

    return (
      <div
        key={c.id}
        className={`flex items-start gap-2.5 ${isReply ? 'ml-9 mt-2.5' : ''}`}
      >
        <button
          type="button"
          onClick={() => authorUid && openUserProfile(authorUid)}
          className="shrink-0 cursor-pointer"
        >
          <UserAvatar
            userId={authorUid}
            userName={authorLabel}
            photoURL={authorAvatar}
            sizeClass={isReply ? 'h-7 w-7' : 'h-8 w-8'}
          />
        </button>

        <div className="min-w-0 flex-1 rounded-2xl bg-[#2B2B2B] px-3.5 py-2.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
              <button
                type="button"
                onClick={() => authorUid && openUserProfile(authorUid)}
                className="text-xs font-bold text-white hover:text-[#FF57B2] truncate cursor-pointer"
              >
                {authorLabel}
              </button>
              {authorUid && <UserBadges userId={authorUid} size="xs" />}
              <span className="text-[10px] text-zinc-400">
                • {formatRelativeTimePt(c.createdAt)}
              </span>
            </div>

            {canDelete && (
              <button
                type="button"
                onClick={() => handleDeleteComment(c)}
                className="p-1 text-zinc-500 hover:text-[#FF80C5] transition cursor-pointer"
                title="Excluir comentário"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {c.replyToAuthorName && (
            <p className="text-[11px] text-[#FF57B2] font-semibold mt-0.5 flex items-center gap-1">
              <CornerDownRight className="h-3 w-3" />
              <span>@{c.replyToAuthorName}</span>
            </p>
          )}

          <p className="mt-1 text-xs sm:text-sm text-zinc-200 whitespace-pre-wrap break-words leading-relaxed">
            {c.content}
          </p>

          <div className="mt-2 flex items-center gap-4 text-[11px] text-zinc-400">
            <button
              type="button"
              onClick={() => handleToggleCommentLike(c)}
              className={`inline-flex items-center gap-1 font-semibold transition cursor-pointer ${
                isLiked ? 'text-[#FF57B2]' : 'hover:text-white'
              }`}
            >
              <Heart className={`h-3.5 w-3.5 ${isLiked ? 'fill-[#FF57B2]' : ''}`} />
              <span>{c.likesCount || 0}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setReplyTarget({
                  id: c.parentId || c.id,
                  authorName: authorLabel,
                  authorId: authorUid,
                });
                inputRef.current?.focus();
              }}
              className="font-semibold hover:text-[#FF57B2] transition cursor-pointer"
            >
              Responder
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-xs p-0 sm:p-4"
      onClick={onClose}
      onWheel={(e) => e.stopPropagation()}
      onTouchStart={(e) => e.stopPropagation()}
      onTouchMove={(e) => e.stopPropagation()}
      onTouchEnd={(e) => e.stopPropagation()}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:max-w-lg max-h-[82vh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-[#222222] border border-zinc-800 shadow-2xl overflow-hidden animate-in slide-in-from-bottom-4 duration-200"
      >
        {/* Grab handle on mobile */}
        <div className="sm:hidden pt-2.5 flex justify-center">
          <div className="h-1.5 w-10 rounded-full bg-zinc-700" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4 text-[#FF57B2]" />
            <h3 className="text-sm font-extrabold text-white tracking-wide">
              Comentários ({comments.length})
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
            aria-label="Fechar comentários"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Comments Body */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-2 text-zinc-400 text-xs">
              <Loader2 className="h-5 w-5 animate-spin text-[#FF57B2]" />
              <span>Carregando comentários...</span>
            </div>
          ) : rootComments.length === 0 ? (
            <div className="py-12 text-center text-zinc-400 text-xs">
              Nenhum comentário ainda. Inicie a conversa!
            </div>
          ) : (
            rootComments.map((root) => (
              <div key={root.id}>
                {renderCommentRow(root, false)}
                {repliesByParent[root.id]?.map((rep) => renderCommentRow(rep, true))}
              </div>
            ))
          )}
        </div>

        {/* Composer */}
        <form
          onSubmit={handleSubmit}
          className="border-t border-zinc-800 bg-[#1C1C1C] px-4 py-3 space-y-2"
        >
          {errorMsg && (
            <p className="text-[11px] text-[#FF80C5] font-medium px-1">{errorMsg}</p>
          )}

          {replyTarget && (
            <div className="flex items-center justify-between rounded-xl bg-[#282828] px-3 py-1.5 text-xs text-zinc-300">
              <span>
                Respondendo a{' '}
                <strong className="text-[#FF57B2]">@{replyTarget.authorName}</strong>
              </span>
              <button
                type="button"
                onClick={() => setReplyTarget(null)}
                className="text-zinc-400 hover:text-white cursor-pointer"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          <div className="flex items-center gap-2.5">
            <input
              ref={inputRef}
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={2000}
              placeholder={
                currentUser
                  ? 'Adicione um comentário...'
                  : 'Entre para comentar nesta publicação...'
              }
              onFocus={() => {
                if (!currentUser) onOpenAuth();
              }}
              className="flex-1 rounded-full bg-[#2C2C2C] px-4 py-2.5 text-xs sm:text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:ring-1 focus:ring-[#FF57B2]"
            />
            <button
              type="submit"
              disabled={submitting || !text.trim()}
              className="min-h-[42px] min-w-[42px] flex items-center justify-center rounded-full bg-[#FF66C4] hover:bg-[#FF57B2] text-[#202020] disabled:opacity-40 transition cursor-pointer"
              aria-label="Enviar comentário"
            >
              {submitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
