import { collection, doc, getDoc, limit, onSnapshot, orderBy, query } from 'firebase/firestore';
import { ArrowRight, ChevronLeft, ChevronRight, Flame, Sparkles, TrendingUp, Users } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { db } from '../services/firebase';
import { Community, CommunityMember } from '../types';

interface CommunityHomeCarouselProps {
  onSelectCommunity: (communityId: string) => void;
  onExploreCommunities?: () => void;
}

export const CommunityHomeCarousel: React.FC<CommunityHomeCarouselProps> = ({
  onSelectCommunity,
  onExploreCommunities,
}) => {
  const { currentUser, isDeveloper } = useAuth();
  const [communities, setCommunities] = useState<Community[]>([]);
  const [loading, setLoading] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let fallbackUnsub: (() => void) | null = null;

    const filterVisibleForViewer = async (rawList: Community[]): Promise<Community[]> => {
      if (isDeveloper) return rawList;
      const results = await Promise.all(
        rawList.map(async (c) => {
          if (!c.isHiddenFromNonMembers) return c;
          if (!currentUser) return null;
          if (c.creatorId === currentUser.uid) return c;
          try {
            const memSnap = await getDoc(
              doc(db, 'communities', c.id, 'members', currentUser.uid)
            );
            if (memSnap.exists()) {
              const mData = memSnap.data() as Partial<CommunityMember>;
              if (mData.status !== 'pending' && mData.status !== 'banned') {
                return c;
              }
            }
          } catch {
            // ignore
          }
          return null;
        })
      );
      return results.filter((c): c is Community => c !== null);
    };

    // Escuta comunidades em destaque configuradas pelo desenvolvedor
    const unsubFeatured = onSnapshot(doc(db, 'settings', 'featuredCommunities'), async (settingSnap) => {
      try {
        if (settingSnap.exists()) {
          const settingData = settingSnap.data();
          const commIds: string[] = (settingData?.communityIds || []).slice(0, 10);

          if (commIds.length > 0) {
            const fetchedList: Community[] = [];
            for (const id of commIds) {
              const cSnap = await getDoc(doc(db, 'communities', id));
              if (cSnap.exists()) {
                fetchedList.push(cSnap.data() as Community);
              }
            }
            const visible = await filterVisibleForViewer(fetchedList);
            if (visible.length > 0) {
              setCommunities(visible);
              setLoading(false);
              return;
            }
          }
        }
      } catch (err) {
        console.warn('Could not read featuredCommunities setting, falling back to top communities:', err);
      }

      // Fallback: top por membersCount
      const q = query(
        collection(db, 'communities'),
        orderBy('membersCount', 'desc'),
        limit(12)
      );
      if (fallbackUnsub) fallbackUnsub();
      fallbackUnsub = onSnapshot(
        q,
        async (snap) => {
          const list: Community[] = [];
          snap.forEach((d) => list.push(d.data() as Community));
          const visible = await filterVisibleForViewer(list);
          setCommunities(visible.slice(0, 10));
          setLoading(false);
        },
        (err) => {
          console.error('Error loading communities for carousel:', err);
          setLoading(false);
        }
      );
    });

    return () => {
      unsubFeatured();
      if (fallbackUnsub) fallbackUnsub();
    };
  }, [currentUser?.uid, isDeveloper]);

  // Movimento perpétuo e cíclico contínuo em sentido anti-horário (sem parar ou pausar entre os cards)
  useEffect(() => {
    if (communities.length <= 1) return;

    let animationFrameId: number;
    let lastTimestamp: number | null = null;

    const tick = (now: number) => {
      if (lastTimestamp === null) lastTimestamp = now;
      const deltaTime = (now - lastTimestamp) / 1000;
      lastTimestamp = now;

      const container = scrollContainerRef.current;
      if (container) {
        // Velocidade calibrada: 48px/s no normal (suave para ver a capa sem demorar para o próximo)
        // Reduz suavemente para 15px/s ao passar o mouse para facilitar o clique
        const currentSpeed = isPaused ? 15 : 48;
        const singleSetWidth = container.scrollWidth / 2;

        if (singleSetWidth > 0) {
          container.scrollLeft += currentSpeed * deltaTime;

          // Ciclo infinito perfeito: reseta de forma imperceptível quando alcança a metade exata
          if (container.scrollLeft >= singleSetWidth) {
            container.scrollLeft -= singleSetWidth;
          }
        }
      }

      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [communities.length, isPaused]);

  const handleScroll = (direction: 'left' | 'right') => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const singleSetWidth = container.scrollWidth / 2;
    const step = 280;

    if (direction === 'right') {
      container.scrollLeft += step;
      if (container.scrollLeft >= singleSetWidth) {
        container.scrollLeft -= singleSetWidth;
      }
    } else {
      container.scrollLeft -= step;
      if (container.scrollLeft < 0) {
        container.scrollLeft += singleSetWidth;
      }
    }
  };

  const getActivityBadge = (c: Community) => {
    const count = c.membersCount || 1;
    const posts = c.postsCount || 0;

    if (posts >= 10 || count >= 20 || c.activityLevel === 'intense') {
      return {
        label: 'Intensa',
        icon: <Flame className="h-2.5 w-2.5 text-[#FF57B2]" />,
        bg: 'bg-[#FF57B2]/20 text-[#FF80C5] border-[#FF57B2]/40',
      };
    }
    if (posts >= 4 || count >= 8 || c.activityLevel === 'high') {
      return {
        label: 'Alta',
        icon: <TrendingUp className="h-2.5 w-2.5 text-[#FF80C5]" />,
        bg: 'bg-[#262626]/90 text-[#FF80C5] border-[#FF57B2]/35',
      };
    }
    if (posts >= 1 || count >= 3 || c.activityLevel === 'moderate') {
      return {
        label: 'Ativa',
        icon: <Sparkles className="h-2.5 w-2.5 text-zinc-200" />,
        bg: 'bg-zinc-900/85 text-zinc-200 border-zinc-700',
      };
    }
    return {
      label: 'Crescendo',
      icon: <Users className="h-2.5 w-2.5 text-zinc-400" />,
      bg: 'bg-zinc-900/80 text-zinc-300 border-zinc-700',
    };
  };

  if (loading) {
    return (
      <section className="rounded-2xl border border-zinc-800 bg-[#202020] p-4 shadow-xs text-center text-xs text-zinc-400">
        Carregando comunidades literárias...
      </section>
    );
  }

  if (communities.length === 0) {
    return null;
  }

  return (
    <section
      className="space-y-2.5"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setTimeout(() => setIsPaused(false), 3000)}
    >
      {/* Header Clássico com Escala Reduzida */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 sm:h-7 sm:w-7 items-center justify-center rounded-lg bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
            <Users className="h-3.5 w-3.5" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-bold text-white font-display flex items-center gap-2">
              <span>Comunidades</span>
              <span className="rounded-full bg-[#FF57B2]/15 text-[#FF57B2] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider border border-[#FF57B2]/30">
                Círculos Literários
              </span>
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => handleScroll('left')}
            className="rounded-xl border border-zinc-700 bg-zinc-850 p-1 text-zinc-300 hover:text-white hover:bg-zinc-800 hover:border-[#FF57B2]/60 transition shadow-2xs cursor-pointer"
            title="Anterior"
            aria-label="Rolar comunidades para esquerda"
          >
            <ChevronLeft className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => handleScroll('right')}
            className="rounded-xl border border-zinc-700 bg-zinc-850 p-1 text-zinc-300 hover:text-white hover:bg-zinc-800 hover:border-[#FF57B2]/60 transition shadow-2xs cursor-pointer"
            title="Próximo"
            aria-label="Rolar comunidades para direita"
          >
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
          {onExploreCommunities && (
            <button
              type="button"
              onClick={onExploreCommunities}
              className="text-xs font-bold text-[#FF57B2] hover:text-[#FF40A4] hover:underline flex items-center gap-0.5 ml-1.5 transition cursor-pointer"
            >
              <span>Ver todas</span>
              <ArrowRight className="h-3 w-3" />
            </button>
          )}
        </div>
      </div>

      {/* Carrossel de Comunidades em Formato Retangular & Movimento Perpétuo Cíclico */}
      <div
        ref={scrollContainerRef}
        className="flex gap-3 overflow-x-auto pb-2 pt-0.5 no-scrollbar select-none"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {[...communities, ...communities].map((comm, index) => {
          const badge = getActivityBadge(comm);
          const members = comm.membersCount || 1;

          return (
            <div
              key={`${comm.id}-${index}`}
              onClick={() => onSelectCommunity(comm.id)}
              className="group relative w-64 sm:w-72 shrink-0 rounded-2xl bg-[#202020] border border-zinc-800 p-2.5 sm:p-3 cursor-pointer flex flex-col justify-between shadow-md shadow-black/40 hover:border-[#FF57B2]/60 hover:shadow-[0_0_16px_rgba(255,87,178,0.25)] transition-all duration-300 hover:-translate-y-0.5"
            >
              {/* Banner / Foto Topo Retangular */}
              <div className="relative h-18 sm:h-20 w-full overflow-hidden rounded-xl bg-zinc-900 border border-zinc-800 mb-2">
                {comm.bannerUrl || comm.coverUrl ? (
                  <img
                    src={comm.bannerUrl || comm.coverUrl}
                    alt={comm.name}
                    className="h-full w-full object-cover group-hover:scale-105 transition duration-500"
                  />
                ) : (
                  <div className="h-full w-full flex items-center justify-center bg-gradient-to-br from-zinc-800 via-zinc-900 to-[#181818] text-[#FF57B2] font-black text-xl font-display">
                    {comm.name.charAt(0).toUpperCase()}
                  </div>
                )}

                {/* Badges superiores compactos */}
                <div className="absolute top-1.5 inset-x-2 flex items-center justify-between z-10 pointer-events-none">
                  <span className="rounded-full bg-black/75 backdrop-blur-md px-2 py-0.5 text-[8.5px] font-bold text-white border border-white/20 uppercase tracking-wider">
                    {comm.category || 'Geral'}
                  </span>
                  <span className={`inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[8px] font-bold backdrop-blur-md border ${badge.bg}`}>
                    {badge.icon}
                    <span>{badge.label}</span>
                  </span>
                </div>
              </div>

              {/* Linha Inferior com Avatar, Informações e Seta no Recorte Lateral Rosa */}
              <div className="flex items-center justify-between gap-2.5 pt-0.5">
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  {comm.coverUrl ? (
                    <img
                      src={comm.coverUrl}
                      alt={comm.name}
                      className="h-9 w-9 shrink-0 rounded-xl object-cover bg-zinc-900 border border-zinc-700 shadow-xs"
                    />
                  ) : (
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-zinc-800 text-[#FF57B2] font-black text-xs border border-zinc-700 shadow-xs">
                      {comm.name.charAt(0).toUpperCase()}
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <h4 className="font-display font-bold text-xs sm:text-sm text-white truncate group-hover:text-[#FF57B2] transition">
                      {comm.name}
                    </h4>
                    <p className="text-[10px] sm:text-[11px] text-zinc-400 flex items-center gap-1 mt-0.5">
                      <Users className="h-2.5 w-2.5 text-[#FF57B2]" />
                      <span>{members} {members === 1 ? 'membro' : 'membros'}</span>
                    </p>
                  </div>
                </div>

                {/* Recorte Lateral Rosa com a Seta de Acesso */}
                <div
                  className="flex h-8 w-8 sm:h-8.5 sm:w-8.5 items-center justify-center rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] text-white shadow-md shadow-[#FF57B2]/30 group-hover:scale-105 group-hover:from-[#FF40A4] group-hover:to-[#D02685] transition-all shrink-0"
                  title="Acessar comunidade"
                >
                  <ArrowRight className="h-4 w-4 text-white group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
