import { AlertCircle, Mail, RefreshCw, ShieldCheck, User, X } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { AppLogoIcon, useBranding } from '../context/BrandingContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'login' | 'register';
  initialTab?: 'login' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'login',
  initialTab,
}) => {
  const effectiveMode = initialTab || defaultMode;
  const {
    currentUser,
    userProfile,
    isGoogleAuthPending,
    loginWithGoogle,
  } = useAuth();
  const { branding } = useBranding();

  const [mode, setMode] = useState<'login' | 'register'>(effectiveMode);
  const [emailHint, setEmailHint] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState<'leitor' | 'escritor'>('leitor');
  const [googlePending, setGooglePending] = useState(false);
  const [error, setError] = useState('');
  const [isPopupBlocked, setIsPopupBlocked] = useState(false);

  // Track which UID was signed in when the modal opened so we close immediately
  // as soon as Firebase Auth confirms a new or switched user session.
  const initialUidRef = useRef<string | null>(null);
  const wasOpenRef = useRef(false);

  useEffect(() => {
    if (isOpen && !wasOpenRef.current) {
      wasOpenRef.current = true;
      initialUidRef.current = currentUser?.uid ?? null;
      setMode(effectiveMode);
      setError('');
      setGooglePending(false);
      setIsPopupBlocked(false);
    } else if (!isOpen && wasOpenRef.current) {
      wasOpenRef.current = false;
    }
  }, [isOpen, effectiveMode, currentUser?.uid]);

  useEffect(() => {
    if (!isOpen) return;
    if (currentUser?.uid && currentUser.uid !== initialUidRef.current) {
      setGooglePending(false);
      onClose();
    }
  }, [isOpen, currentUser?.uid, onClose]);

  if (!isOpen) return null;

  const isSwitchingAccount = Boolean(currentUser);
  const isUiLocked = googlePending || isGoogleAuthPending;

  const triggerGoogleAuth = async (e?: React.SyntheticEvent, explicitHint?: string) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (isUiLocked) return;

    const cleanHint = (explicitHint ?? emailHint).trim();
    const registrationMeta =
      mode === 'register'
        ? {
            displayName: displayName.trim() || undefined,
            role,
          }
        : undefined;

    // CRITICAL: Trigger loginWithGoogle synchronously FIRST (0ms) inside the user click
    // gesture before any React state updates so navigator.userActivation is preserved.
    const authPromise = loginWithGoogle(cleanHint || undefined, registrationMeta);

    setError('');
    setIsPopupBlocked(false);
    setGooglePending(true);

    try {
      await authPromise;
      onClose();
    } catch (err: any) {
      const code = err?.code || '';
      if (
        code === 'auth/popup-closed-by-user' ||
        code === 'auth/cancelled-popup-request' ||
        code === 'auth/cancelled-by-ui-manager'
      ) {
        return;
      }

      const msg =
        err?.message || 'Não foi possível concluir a autenticação com o Google. Tente novamente.';
      setError(msg);
      if (code === 'auth/popup-blocked' || msg.toLowerCase().includes('bloqueou')) {
        setIsPopupBlocked(true);
      }
    } finally {
      setGooglePending(false);
    }
  };

  return (
    <div
      aria-busy={isUiLocked}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm animate-fade-in"
      onClick={(e) => {
        if (!isUiLocked && e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div className="w-full max-w-md overflow-hidden rounded-3xl bg-[#202020] text-white shadow-2xl border border-zinc-800 transition-all">
        {/* Header */}
        <div className="relative bg-gradient-to-b from-[#2A2A2A] to-[#202020] px-6 pt-7 pb-5 text-center border-b border-zinc-800/80">
          <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-[#FF57B2] to-transparent pointer-events-none" />

          <button
            type="button"
            disabled={isUiLocked}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              if (!isUiLocked) onClose();
            }}
            className="absolute top-4 right-4 rounded-full p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
            aria-label="Fechar modal"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-lg shadow-[#FF57B2]/30 mb-3 border border-[#FF57B2]/60">
            <AppLogoIcon className="h-7 w-7" />
          </div>

          <h3 className="text-xl font-black tracking-tight text-white font-display">
            {mode === 'login'
              ? isSwitchingAccount
                ? 'Trocar ou Acessar Outra Conta'
                : `Entrar no ${branding.appName}`
              : `Criar Nova Conta no ${branding.appName}`}
          </h3>
          <p className="mt-1 text-xs text-zinc-400">
            {mode === 'login'
              ? isSwitchingAccount
                ? 'Escolha qualquer conta Google para alternar instantaneamente sem recarregar a página.'
                : 'Autenticação oficial via Google rápida, segura e sem recarregar a página.'
              : 'Personalize seu perfil literário e conclua seu cadastro em um clique com o Google.'}
          </p>

          {/* Segmented Mode Selector (Entrar / Criar Conta) */}
          <div className="mt-4 grid grid-cols-2 gap-1.5 rounded-2xl bg-[#181818] p-1 border border-zinc-800">
            <button
              type="button"
              disabled={isUiLocked}
              onClick={() => {
                setMode('login');
                setError('');
              }}
              className={`rounded-xl py-2 px-3 text-xs font-bold transition cursor-pointer ${
                mode === 'login'
                  ? 'bg-[#FF57B2] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Entrar
            </button>
            <button
              type="button"
              disabled={isUiLocked}
              onClick={() => {
                setMode('register');
                setError('');
              }}
              className={`rounded-xl py-2 px-3 text-xs font-bold transition cursor-pointer ${
                mode === 'register'
                  ? 'bg-[#FF57B2] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Criar Conta
            </button>
          </div>
        </div>

        {/* Body (Zero <form> elements to guarantee zero native browser reloads) */}
        <div className="px-6 py-5 space-y-4">
          {isSwitchingAccount && (
            <div className="rounded-2xl bg-[#181818] px-3.5 py-2.5 border border-zinc-800 flex items-center justify-between gap-2 text-xs">
              <div className="min-w-0">
                <span className="text-[10px] text-zinc-400 block">Sessão ativa no momento</span>
                <p className="font-bold text-white truncate">
                  {userProfile?.displayName || currentUser?.displayName || 'Usuário'}{' '}
                  <span className="font-normal text-[#FF80C5]">
                    ({currentUser?.email || 'autenticado'})
                  </span>
                </p>
              </div>
              <RefreshCw className="h-4 w-4 text-[#FF57B2] shrink-0" />
            </div>
          )}

          {error && (
            <div className="rounded-2xl bg-[#262626] p-3.5 text-xs text-zinc-200 border border-[#FF57B2]/55 space-y-2.5">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-[#FF57B2] shrink-0 mt-0.5" />
                <p className="leading-relaxed text-white">{error}</p>
              </div>

              {isPopupBlocked && (
                <div className="pt-2 border-t border-zinc-800 flex flex-col gap-2">
                  <p className="text-[11px] text-zinc-300">
                    Permita pop-ups para este site no navegador ou clique abaixo para abrir o seletor novamente:
                  </p>
                  <button
                    type="button"
                    disabled={isUiLocked}
                    onClick={(e) => triggerGoogleAuth(e)}
                    className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#FF57B2] hover:bg-[#FF40A4] text-white px-3 py-2 text-xs font-bold transition shadow-sm cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
                  >
                    <RefreshCw className="h-3.5 w-3.5 shrink-0" />
                    <span>Abrir seletor de contas do Google</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {mode === 'register' && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Nome ou Pseudônimo Literário <span className="text-zinc-500 font-normal">(opcional)</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 h-4 w-4 text-zinc-500" />
                  <input
                    type="text"
                    disabled={isUiLocked}
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        triggerGoogleAuth(e);
                      }
                    }}
                    placeholder="Ex: Ariano de Souza (ou usar nome do Google)"
                    maxLength={60}
                    className="w-full rounded-xl border border-zinc-800 bg-[#181818] pl-9 pr-3 py-2 text-sm text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none disabled:opacity-60"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  Como você deseja começar no {branding.appName}?
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={isUiLocked}
                    onClick={() => setRole('leitor')}
                    className={`rounded-xl border py-2 px-3 text-center text-xs font-semibold transition cursor-pointer ${
                      role === 'leitor'
                        ? 'border-[#FF57B2] bg-[#FF57B2]/20 text-white font-bold'
                        : 'border-zinc-800 bg-[#181818] text-zinc-400 hover:bg-[#262626] hover:text-white'
                    }`}
                  >
                    Leitor
                  </button>
                  <button
                    type="button"
                    disabled={isUiLocked}
                    onClick={() => setRole('escritor')}
                    className={`rounded-xl border py-2 px-3 text-center text-xs font-semibold transition cursor-pointer ${
                      role === 'escritor'
                        ? 'border-[#FF57B2] bg-[#FF57B2]/20 text-white font-bold'
                        : 'border-zinc-800 bg-[#181818] text-zinc-400 hover:bg-[#262626] hover:text-white'
                    }`}
                  >
                    Escritor
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Optional Google Email Hint for Direct Multi-Account Selection */}
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">
              Sugerir e-mail específico do Google <span className="text-zinc-500 font-normal">(opcional)</span>
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 h-4 w-4 text-zinc-500" />
              <input
                type="email"
                disabled={isUiLocked}
                value={emailHint}
                onChange={(e) => setEmailHint(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    triggerGoogleAuth(e);
                  }
                }}
                placeholder="Deixe em branco para escolher na lista do Google"
                className="w-full rounded-xl border border-zinc-800 bg-[#181818] pl-9 pr-3 py-2 text-sm text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:ring-1 focus:ring-[#FF57B2] focus:outline-none disabled:opacity-60"
              />
            </div>
          </div>

          {/* Primary Google Authentication Button */}
          <div className="space-y-2.5 pt-1">
            <button
              type="button"
              disabled={isUiLocked}
              aria-busy={isUiLocked}
              onClick={(e) => triggerGoogleAuth(e)}
              className="group relative flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] hover:from-[#FF40A4] hover:to-[#D02685] py-3.5 px-4 text-sm font-bold text-white shadow-lg shadow-[#FF57B2]/30 hover:shadow-[0_0_24px_rgba(255,87,178,0.45)] border border-[#FF57B2]/60 transition duration-200 cursor-pointer disabled:opacity-60 disabled:pointer-events-none"
            >
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-white p-1 shadow-xs">
                <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
              </span>
              <span className="text-white font-bold text-sm truncate">
                {isUiLocked
                  ? 'Autenticando com Google...'
                  : mode === 'register'
                  ? 'Criar Conta com Google'
                  : isSwitchingAccount
                  ? 'Escolher Outra Conta Google'
                  : 'Continuar com Google'}
              </span>
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-zinc-400">
              <ShieldCheck className="h-3.5 w-3.5 text-[#FF57B2] shrink-0" />
              <span>
                {isUiLocked
                  ? 'Conclua na janela oficial do Google'
                  : 'Entre ou alterne entre quantas contas Google quiser'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
