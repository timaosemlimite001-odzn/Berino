import React, { useState } from 'react';
import { Camera, Check, EyeOff, Image as ImageIcon, Loader2, Lock, Sparkles, X } from 'lucide-react';
import { doc, updateDoc } from 'firebase/firestore';
import { db, sanitizeFirestoreData } from '../services/firebase';
import { uploadFileToStorage } from '../services/storageService';
import { Community } from '../types';

interface EditCommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
  community: Community;
  onCommunityUpdated: (updated: Community) => void;
}

const AVATAR_PRESETS = [
  { label: 'Xilogravura', url: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=300&auto=format&fit=crop&q=80' },
  { label: 'Pena & Tinteiro', url: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=300&auto=format&fit=crop&q=80' },
  { label: 'Livro Rústico', url: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=300&auto=format&fit=crop&q=80' },
  { label: 'Cacto & Luar', url: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=300&auto=format&fit=crop&q=80' },
  { label: 'Viola & Poesia', url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80' },
];

const BANNER_PRESETS = [
  { label: 'Sertão Poético', url: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=900&auto=format&fit=crop&q=80' },
  { label: 'Biblioteca Clássica', url: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=900&auto=format&fit=crop&q=80' },
  { label: 'Oceano & Céu', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=900&auto=format&fit=crop&q=80' },
  { label: 'Crepúsculo Dourado', url: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=900&auto=format&fit=crop&q=80' },
  { label: 'Café Literário', url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=900&auto=format&fit=crop&q=80' },
];

export const EditCommunityModal: React.FC<EditCommunityModalProps> = ({
  isOpen,
  onClose,
  community,
  onCommunityUpdated,
}) => {
  const [name, setName] = useState(community.name || '');
  const [description, setDescription] = useState(community.description || '');
  const [rules, setRules] = useState(community.rules || '');
  const [category, setCategory] = useState(community.category || 'Geral');
  const [isPrivate, setIsPrivate] = useState(Boolean(community.isPrivate));
  const [isHiddenFromNonMembers, setIsHiddenFromNonMembers] = useState(
    Boolean(community.isHiddenFromNonMembers)
  );
  const [hidePostsFromNonMembers, setHidePostsFromNonMembers] = useState(
    Boolean(community.hidePostsFromNonMembers)
  );

  // Foto 1: Foto menor do quadrado (Avatar/Ícone)
  const initialIcon = community.iconUrl || community.avatarUrl || '';
  const [iconPreview, setIconPreview] = useState(initialIcon);
  const [iconFile, setIconFile] = useState<File | null>(null);
  const [customIconUrl, setCustomIconUrl] = useState('');
  const [showIconUrlInput, setShowIconUrlInput] = useState(false);

  // Foto 2: Foto maior horizontal (Banner/Capa)
  const initialBanner = community.bannerUrl || community.coverUrl || '';
  const [bannerPreview, setBannerPreview] = useState(initialBanner);
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [customBannerUrl, setCustomBannerUrl] = useState('');
  const [showBannerUrlInput, setShowBannerUrlInput] = useState(false);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSelectIconPreset = (url: string) => {
    setIconFile(null);
    setIconPreview(url);
    setCustomIconUrl(url);
  };

  const handleSelectBannerPreset = (url: string) => {
    setBannerFile(null);
    setBannerPreview(url);
    setCustomBannerUrl(url);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('O nome da comunidade é obrigatório.');
      return;
    }

    setSaving(true);
    setError('');

    try {
      let finalIconUrl = iconPreview;
      if (iconFile) {
        finalIconUrl = await uploadFileToStorage(iconFile, 'avatars', `${community.id}_icon`);
      }

      let finalBannerUrl = bannerPreview;
      if (bannerFile) {
        finalBannerUrl = await uploadFileToStorage(bannerFile, 'covers', `${community.id}_banner`);
      }

      const updatedFields = {
        name: name.trim(),
        description: description.trim(),
        rules: rules.trim(),
        category,
        isPrivate,
        isHiddenFromNonMembers,
        hidePostsFromNonMembers,
        iconUrl: finalIconUrl,
        avatarUrl: finalIconUrl,
        coverUrl: finalBannerUrl,
        bannerUrl: finalBannerUrl,
        updatedAt: new Date().toISOString(),
      };

      await updateDoc(doc(db, 'communities', community.id), sanitizeFirestoreData(updatedFields));

      const updatedCommunity: Community = {
        ...community,
        ...updatedFields,
      };

      onCommunityUpdated(updatedCommunity);
      onClose();
    } catch (err: any) {
      console.error('Erro ao atualizar comunidade:', err);
      setError(err?.message || 'Falha ao salvar alterações da comunidade.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-3xl bg-[#202020] border border-zinc-800 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200 text-white">
        {/* Header Modal */}
        <div className="flex items-center justify-between border-b border-zinc-800 p-5 sm:p-6 bg-gradient-to-r from-[#262626] to-[#202020]">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-white font-display">
              Personalizar Fotos & Comunidade
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Edite a foto quadrada menor, a capa horizontal maior e os dados da comunidade.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-6 text-xs max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/40 p-3 text-[#FF80C5] font-medium text-xs">
              {error}
            </div>
          )}

          {/* 1. SEÇÃO DE FOTOS DISTINTAS */}
          <div className="space-y-5 rounded-2xl bg-[#262626] p-4 border border-zinc-800">
            {/* Foto 2: FOTO MAIOR HORIZONTAL (BANNER / CAPA) */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-bold text-white flex items-center gap-1.5">
                  <ImageIcon className="h-4 w-4 text-[#FF57B2]" />
                  <span>Foto Maior na Horizontal (Capa / Banner da Comunidade)</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowBannerUrlInput(!showBannerUrlInput)}
                  className="text-[11px] text-[#FF57B2] hover:underline cursor-pointer"
                >
                  {showBannerUrlInput ? 'Ocultar URL' : 'Inserir URL'}
                </button>
              </div>

              {/* Banner Preview */}
              <div className="relative h-28 sm:h-36 w-full rounded-2xl overflow-hidden border border-zinc-800 bg-[#1A1A1A] mb-2.5 shadow-2xs">
                {bannerPreview ? (
                  <img
                    src={bannerPreview}
                    alt="Banner preview"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="h-full w-full flex items-center justify-center text-zinc-500">
                    <span>Sem banner horizontal selecionado</span>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
                <span className="absolute bottom-2 left-3 text-[10px] font-bold text-[#FF57B2] uppercase tracking-wider bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded-md border border-[#FF57B2]/30">
                  Prévia Horizontal
                </span>
              </div>

              {/* Banner Controls */}
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <label className="inline-flex items-center gap-2 rounded-xl border border-zinc-700 bg-zinc-800/80 px-3 py-1.5 hover:border-[#FF57B2] text-white cursor-pointer transition shadow-2xs">
                  <Camera className="h-3.5 w-3.5 text-[#FF57B2]" />
                  <span className="font-semibold text-[11px]">Carregar foto horizontal</span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setBannerFile(file);
                        setBannerPreview(URL.createObjectURL(file));
                      }
                    }}
                  />
                </label>

                {bannerPreview && (
                  <button
                    type="button"
                    onClick={() => {
                      setBannerFile(null);
                      setBannerPreview('');
                    }}
                    className="text-zinc-400 hover:text-[#FF80C5] text-[11px] font-medium px-2 py-1 cursor-pointer transition"
                  >
                    Remover
                  </button>
                )}
              </div>

              {showBannerUrlInput && (
                <div className="flex gap-2 mb-2">
                  <input
                    type="url"
                    value={customBannerUrl}
                    onChange={(e) => setCustomBannerUrl(e.target.value)}
                    placeholder="https://exemplo.com/banner-comunidade.jpg"
                    className="flex-1 rounded-xl border border-zinc-700 bg-[#1A1A1A] p-2 text-xs text-white focus:outline-hidden focus:border-[#FF57B2]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (customBannerUrl.trim()) {
                        setBannerFile(null);
                        setBannerPreview(customBannerUrl.trim());
                      }
                    }}
                    className="rounded-xl bg-[#FF57B2] text-white px-3 py-1.5 font-bold hover:bg-[#E03595] transition cursor-pointer"
                  >
                    Aplicar
                  </button>
                </div>
              )}

              {/* Banner Presets */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">
                  Sugestões Rápidas de Capa
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {BANNER_PRESETS.map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => handleSelectBannerPreset(preset.url)}
                      className="rounded-lg border border-zinc-700 bg-zinc-800/80 px-2 py-1 text-[11px] text-zinc-300 hover:border-[#FF57B2] hover:text-[#FF57B2] transition cursor-pointer"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* DIVISÓRIA SUTIL */}
            <div className="border-t border-zinc-800 pt-4" />

            {/* Foto 1: FOTO MENOR DO QUADRADO (AVATAR / ÍCONE) */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="h-4 w-4 text-[#FF57B2]" />
                  <span>Foto Menor no Quadrado (Avatar / Ícone da Comunidade)</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowIconUrlInput(!showIconUrlInput)}
                  className="text-[11px] text-[#FF57B2] hover:underline cursor-pointer"
                >
                  {showIconUrlInput ? 'Ocultar URL' : 'Inserir URL'}
                </button>
              </div>

              {/* Avatar Preview & File Input */}
              <div className="flex items-center gap-4 mb-2.5">
                <div className="relative h-20 w-20 rounded-2xl sm:rounded-3xl border-2 border-zinc-700 shadow-lg overflow-hidden bg-[#1A1A1A] flex items-center justify-center shrink-0 ring-1 ring-[#FF57B2]/30">
                  {iconPreview ? (
                    <img
                      src={iconPreview}
                      alt="Ícone preview"
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <span className="font-display font-black text-2xl text-[#FF57B2]">
                      {name.charAt(0).toUpperCase() || 'C'}
                    </span>
                  )}
                </div>

                <div className="space-y-1.5 flex-1">
                  <label className="inline-flex items-center gap-2 rounded-xl border border-zinc-700 bg-zinc-800/80 px-3.5 py-2 hover:border-[#FF57B2] text-white cursor-pointer transition shadow-2xs">
                    <Camera className="h-3.5 w-3.5 text-[#FF57B2]" />
                    <span className="font-semibold text-[11px]">Carregar foto quadrada</span>
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setIconFile(file);
                          setIconPreview(URL.createObjectURL(file));
                        }
                      }}
                    />
                  </label>
                  {iconPreview && (
                    <button
                      type="button"
                      onClick={() => {
                        setIconFile(null);
                        setIconPreview('');
                      }}
                      className="block text-zinc-400 hover:text-[#FF80C5] text-[11px] font-medium cursor-pointer transition"
                    >
                      Remover foto quadrada
                    </button>
                  )}
                </div>
              </div>

              {showIconUrlInput && (
                <div className="flex gap-2 mb-2">
                  <input
                    type="url"
                    value={customIconUrl}
                    onChange={(e) => setCustomIconUrl(e.target.value)}
                    placeholder="https://exemplo.com/avatar-quadrado.jpg"
                    className="flex-1 rounded-xl border border-zinc-700 bg-[#1A1A1A] p-2 text-xs text-white focus:outline-hidden focus:border-[#FF57B2]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (customIconUrl.trim()) {
                        setIconFile(null);
                        setIconPreview(customIconUrl.trim());
                      }
                    }}
                    className="rounded-xl bg-[#FF57B2] text-white px-3 py-1.5 font-bold hover:bg-[#E03595] transition cursor-pointer"
                  >
                    Aplicar
                  </button>
                </div>
              )}

              {/* Avatar Presets */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">
                  Sugestões Rápidas de Avatar Quadrado
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {AVATAR_PRESETS.map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => handleSelectIconPreset(preset.url)}
                      className="rounded-lg border border-zinc-700 bg-zinc-800/80 px-2 py-1 text-[11px] text-zinc-300 hover:border-[#FF57B2] hover:text-[#FF57B2] transition cursor-pointer"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* 2. DADOS CADASTRAIS DA COMUNIDADE */}
          <div className="space-y-4">
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">
                Nome da Comunidade *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Roda de Cordel Nordestino"
                className="w-full rounded-xl border border-zinc-700 bg-[#1A1A1A] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">
                Categoria
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-xl border border-zinc-700 bg-[#1A1A1A] p-2.5 text-xs text-white [color-scheme:dark] focus:border-[#FF57B2] focus:outline-hidden"
              >
                <option value="Geral">Geral</option>
                <option value="Cordel & Verso">Cordel & Verso</option>
                <option value="Romance & Drama">Romance & Drama</option>
                <option value="Ficção & Fantasia">Ficção & Fantasia</option>
                <option value="Poesia & Métricas">Poesia & Métricas</option>
                <option value="Leitores Beta">Leitores Beta</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">
                Descrição do Grupo
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Explique o propósito deste espaço literário..."
                className="w-full rounded-xl border border-zinc-700 bg-[#1A1A1A] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-semibold text-zinc-300 mb-1">
                Regras e Boas Práticas (Opcional)
              </label>
              <textarea
                rows={3}
                value={rules}
                onChange={(e) => setRules(e.target.value)}
                placeholder="Diretrizes para publicações e convivência harmoniosa..."
                className="w-full rounded-xl border border-zinc-700 bg-[#1A1A1A] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-hidden"
              />
            </div>

            {/* 3. PRIVACIDADE E OCULTAÇÃO PARA NÃO-MEMBROS */}
            <div className="rounded-2xl bg-[#262626] border border-zinc-800 p-4 space-y-3">
              <div className="flex items-center gap-2 font-bold text-white text-xs">
                <Lock className="h-4 w-4 text-[#FF57B2]" />
                <span>Privacidade & Visibilidade para Não-Membros</span>
              </div>

              <label className="flex items-start justify-between gap-3 rounded-xl bg-[#1A1A1A] border border-zinc-800 p-3 cursor-pointer hover:border-[#FF57B2]/40 transition">
                <div className="space-y-0.5">
                  <span className="font-bold text-white block">
                    Privar comunidade (entrada mediante aprovação)
                  </span>
                  <span className="text-[11px] text-zinc-400 block">
                    Novos leitores precisam solicitar participação e aguardar aprovação da administração para acessar o conteúdo.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={isPrivate}
                  onChange={(e) => setIsPrivate(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                />
              </label>

              <label className="flex items-start justify-between gap-3 rounded-xl bg-[#1A1A1A] border border-zinc-800 p-3 cursor-pointer hover:border-[#FF57B2]/40 transition">
                <div className="space-y-0.5">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <EyeOff className="h-3.5 w-3.5 text-[#FF57B2]" />
                    <span>Ocultar comunidade para quem não faz parte</span>
                  </span>
                  <span className="text-[11px] text-zinc-400 block">
                    Esconde esta comunidade das buscas públicas, carrosséis e listagens para quem ainda não é membro.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={isHiddenFromNonMembers}
                  onChange={(e) => setIsHiddenFromNonMembers(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                />
              </label>

              <label className="flex items-start justify-between gap-3 rounded-xl bg-[#1A1A1A] border border-zinc-800 p-3 cursor-pointer hover:border-[#FF57B2]/40 transition">
                <div className="space-y-0.5">
                  <span className="font-bold text-white block">
                    Ocultar todas as publicações para quem não faz parte
                  </span>
                  <span className="text-[11px] text-zinc-400 block">
                    Impede que os posts desta comunidade apareçam no Flux ou fora da sala para não-membros.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={hidePostsFromNonMembers}
                  onChange={(e) => setHidePostsFromNonMembers(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                />
              </label>
            </div>
          </div>

          {/* Botões do Rodapé */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-4 py-2 text-xs font-semibold text-zinc-400 hover:text-white transition cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving || !name.trim()}
              className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-6 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-40 cursor-pointer"
            >
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Salvando...</span>
                </>
              ) : (
                <>
                  <Check className="h-4 w-4" />
                  <span>Salvar Alterações</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
