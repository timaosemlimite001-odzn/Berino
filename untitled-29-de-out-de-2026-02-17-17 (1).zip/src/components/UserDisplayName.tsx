import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getUserCachedName, subscribeUserData } from '../services/userService';

export interface UserDisplayNameProps {
  userId?: string;
  fallback?: string;
  className?: string;
  title?: string;
  onClick?: (e: React.MouseEvent) => void;
}

/**
 * Hook that reactively resolves the up-to-date user nickname/displayName:
 * 1. If viewing the current authenticated user, always uses real-time userProfile.displayName
 * 2. If viewing another user, subscribes to real-time updates so nickname updates propagate everywhere
 * 3. Fallbacks to static cached or persisted name when loading or offline
 */
export function useUserDisplayName(userId?: string, fallback: string = 'Leitor'): string {
  const { currentUser, userProfile } = useAuth();
  const isSelf = Boolean(currentUser && userId && currentUser.uid === userId);

  const [displayName, setDisplayName] = useState<string>(() => {
    if (isSelf && userProfile?.displayName) return userProfile.displayName;
    if (userId) {
      const cached = getUserCachedName(userId);
      if (cached) return cached;
    }
    return fallback;
  });

  useEffect(() => {
    if (isSelf) {
      if (userProfile?.displayName) {
        setDisplayName(userProfile.displayName);
      }
      return;
    }

    if (!userId) {
      setDisplayName(fallback);
      return;
    }

    const unsub = subscribeUserData(userId, (data) => {
      if (data.displayName) {
        setDisplayName(data.displayName);
      }
    });

    return () => unsub();
  }, [userId, isSelf, userProfile?.displayName, fallback]);

  return displayName;
}

/**
 * Component that displays the live, reactive user nickname/displayName everywhere
 */
export const UserDisplayName: React.FC<UserDisplayNameProps> = ({
  userId,
  fallback = 'Leitor',
  className = '',
  title,
  onClick,
}) => {
  const resolvedName = useUserDisplayName(userId, fallback);

  return (
    <span
      className={className}
      title={title}
      onClick={onClick}
    >
      {resolvedName}
    </span>
  );
};
