import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getUserCachedData, subscribeUserData } from '../services/userService';

export interface UserNameProps {
  userId?: string;
  fallback?: string;
  className?: string;
  prefix?: string;
  suffix?: string;
  title?: string;
  onClick?: (e: React.MouseEvent) => void;
}

/**
 * Renders user display name in real-time.
 * Automatically synchronizes when a user changes their nickname/name across books, communities, posts, and comments.
 */
export const UserName: React.FC<UserNameProps> = ({
  userId,
  fallback = 'Leitor',
  className = '',
  prefix = '',
  suffix = '',
  title,
  onClick,
}) => {
  const { currentUser, userProfile } = useAuth();
  const isSelf = Boolean(currentUser && userId && currentUser.uid === userId);

  const getInitialName = () => {
    if (isSelf && userProfile?.displayName) {
      return userProfile.displayName;
    }
    if (userId) {
      const cached = getUserCachedData(userId);
      if (cached?.displayName) return cached.displayName;
    }
    return fallback;
  };

  const [resolvedName, setResolvedName] = useState<string>(getInitialName);

  useEffect(() => {
    if (isSelf) {
      setResolvedName(userProfile?.displayName || fallback);
      return;
    }

    if (userId) {
      const unsubscribe = subscribeUserData(userId, (data) => {
        if (data.displayName && data.displayName.trim().length > 0) {
          setResolvedName(data.displayName);
        }
      });
      return unsubscribe;
    }

    setResolvedName(fallback);
  }, [isSelf, userProfile?.displayName, userId, fallback]);

  const content = `${prefix}${resolvedName || fallback}${suffix}`;

  if (onClick) {
    return (
      <span
        onClick={onClick}
        className={className}
        title={title || resolvedName}
      >
        {content}
      </span>
    );
  }

  return (
    <span className={className} title={title}>
      {content}
    </span>
  );
};
