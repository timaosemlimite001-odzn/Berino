import { Loader2, ShieldCheck, X } from 'lucide-react';
import React from 'react';
import { useAuth } from '../context/AuthContext';

export const GoogleAuthPendingOverlay: React.FC = () => {
  const { googleAuthFlow, cancelGoogleAuthFlow } = useAuth();

  if (!googleAuthFlow.isPending) {
    return null;
  }

  const isSyncingProfile = googleAuthFlow.status === 'syncing_profile';
  const headline = isSyncingProfile
    ? 'Sincronizando sua conta...'
    : googleAuthFlow.mode === 'switch'
    ? 'Alternando conta Google...'
    : 'Autenticando com Google...';

  const description = isSyncingProfile
    ? 'Validando suas credenciais e carregando seu perfil literário sem recarregar a página.'
    : 'Conclua a escolha da conta na janela do Google. As interações foram bloqueadas temporariamente para evitar recarregamentos acidentais.';

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-busy="true"
      aria-live="assertive"
      aria-labelledby="google-auth-lock-title"
      aria-describedby="google-auth-lock-desc"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
      onMouseDown={(e) => {
        if (!(e.target instanceof Element && e.target.closest('[data-google-auth-shield="allow"]'))) {
          e.preventDefault();
          e.stopPropagation();
        }
      }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm select-none"
    >
      <div className="relative w-full max-w-sm overflow-hidden rounded-3xl border border-zinc-800 bg-[#202020] p-6 text-center text-white shadow-2xl">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-[#FF57B2] to-transparent" />

        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-[#FF57B2]/45 bg-[#181818]">
          <Loader2 className="h-6 w-6 animate-spin text-[#FF57B2]" />
        </div>

        <h2
          id="google-auth-lock-title"
          className="font-display text-base font-black tracking-tight text-white"
        >
          {headline}
        </h2>

        <p
          id="google-auth-lock-desc"
          className="mt-2 text-xs leading-relaxed text-zinc-300"
        >
          {description}
        </p>

        {googleAuthFlow.loginHint && !isSyncingProfile && (
          <div className="mt-3 rounded-xl border border-zinc-800 bg-[#181818] px-3 py-2 text-[11px] text-zinc-300 truncate">
            Conta sugerida: <span className="font-semibold text-[#FF80C5]">{googleAuthFlow.loginHint}</span>
          </div>
        )}

        <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-zinc-400">
          <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-[#FF57B2]" />
          <span>Proteção ativa contra recarregamento da página</span>
        </div>

        <div className="mt-5 border-t border-zinc-800 pt-4">
          <button
            type="button"
            data-google-auth-shield="allow"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              cancelGoogleAuthFlow();
            }}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-zinc-700 bg-[#262626] px-4 py-2.5 text-xs font-bold text-zinc-200 transition hover:border-[#FF57B2] hover:text-white cursor-pointer"
          >
            <X className="h-3.5 w-3.5 text-[#FF80C5]" />
            <span>Cancelar aguardo</span>
          </button>
        </div>
      </div>
    </div>
  );
};
