import React from 'react';

/**
 * AmbientOceanAtmosphere (Minimal Liquid Edition)
 * 
 * Camada ambiental no estilo Minimal Liquid que transmite a atmosfera suave de céu,
 * nuvens brancas em brisa e águas serenas de oceano.
 * 
 * - Estilo Minimal Liquid: formas orgânicas fluidas, difusão líquida translúcida e caústicas serenas
 * - 100% pointer-events-none (não obstrui cliques, seleção ou scroll)
 * - Preserva rigorosamente a paleta de cores (azul bebê, branco puro, toques ciano/marinho)
 * - Animações ultra-discretas e descompassadas para evitar qualquer poluição visual
 */
export const AmbientOceanAtmosphere: React.FC = () => {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden select-none"
    >
      {/* 1. Sutil brilho de ambientação Pink no topo */}
      <div className="absolute -top-32 left-1/4 w-[36rem] h-72 bg-gradient-to-br from-[#FF57B2]/12 via-[#FF57B2]/5 to-transparent blur-3xl rounded-full" />

      {/* 2. Suave difusão no canto direito */}
      <div className="absolute top-1/3 -right-24 w-[32rem] h-64 bg-gradient-to-bl from-[#FF57B2]/8 to-transparent blur-3xl rounded-full" />

      {/* 3. Brilho sutil no rodapé */}
      <div className="absolute -bottom-28 -left-16 w-[38rem] h-80 bg-gradient-to-tr from-[#FF57B2]/10 via-[#FF57B2]/4 to-transparent blur-3xl rounded-full" />
    </div>
  );
};
