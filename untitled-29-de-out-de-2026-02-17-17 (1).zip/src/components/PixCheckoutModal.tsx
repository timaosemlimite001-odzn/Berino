import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  QrCode,
  Copy,
  Check,
  Clock,
  Zap,
  ShieldCheck,
  AlertCircle,
  Coins,
  Loader2,
  X,
  CheckCircle2,
  Sparkles,
  FileCheck,
  RefreshCw,
  Info,
} from 'lucide-react';
import QRCode from 'qrcode';
import { KardPackage, PixOrder, PixOrderStatus, PixTransactionData } from '../types';
import { creditKards } from '../services/kardsService';
import {
  createPixOrder,
  verifyPixPayment,
  submitPixReceipt,
  approvePixOrder,
  subscribePixOrder,
  claimAndCreditPixOrder,
  findRecentActiveOrder,
  cancelPixOrder,
} from '../services/pixService';

interface PixCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  pkg: KardPackage | null;
  existingOrder?: PixOrder | null;
  currentUser: any;
  userProfile: any;
  onSuccess: (kardsAdded: number, txId: string) => void;
}

export const PixCheckoutModal: React.FC<PixCheckoutModalProps> = ({
  isOpen,
  onClose,
  pkg,
  existingOrder,
  currentUser,
  userProfile,
  onSuccess,
}) => {
  const [loading, setLoading] = useState(true);
  const [pixData, setPixData] = useState<PixTransactionData | null>(null);
  const [copied, setCopied] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [success, setSuccess] = useState(false);
  const [confirmedTxId, setConfirmedTxId] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [paymentStatusNotice, setPaymentStatusNotice] = useState<{
    type: 'pending' | 'under_review' | 'expired' | 'error';
    msg: string;
  } | null>(null);
  const [timeLeft, setTimeLeft] = useState(15 * 60); // 15 minutos em segundos
  const [adminApproving, setAdminApproving] = useState(false);
  const [receiptSubmitted, setReceiptSubmitted] = useState(false);
  const [receiptCodeInput, setReceiptCodeInput] = useState('');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDeveloper =
    userProfile?.role === 'desenvolvedor' ||
    currentUser?.email === 'timaosemlimite001@gmail.com';

  // Inicia ou restaura a cobrança Pix quando o modal abre
  useEffect(() => {
    if (!isOpen || !pkg || !currentUser) {
      setPixData(null);
      setSuccess(false);
      setErrorMsg('');
      setPaymentStatusNotice(null);
      setVerifying(false);
      setCopied(false);
      setTimeLeft(15 * 60);
      return;
    }

    let isMounted = true;

    const initPix = async () => {
      setLoading(true);
      setErrorMsg('');
      setPaymentStatusNotice(null);
      setSuccess(false);
      setVerifying(false);

      // 1. Se foi passado um pedido existente explicitamente
      if (existingOrder) {
        const expiresMs = new Date(existingOrder.expiresAt).getTime() || Date.now() + 15 * 60 * 1000;
        const remainingSecs = Math.max(0, Math.floor((expiresMs - Date.now()) / 1000));
        setPixData({
          txId: existingOrder.txId,
          brCode: existingOrder.brCode,
          qrCodeDataUrl: '',
          amountBrl: existingOrder.amountBrl,
          kards: existingOrder.kards,
          title: existingOrder.title,
          userId: existingOrder.userId,
          expiresAt: existingOrder.expiresAt,
          status: existingOrder.status,
          pixKey: existingOrder.pixKey,
          merchantName: existingOrder.merchantName,
          receiptCode: existingOrder.receiptCode,
        });
        setTimeLeft(remainingSecs);
        if (existingOrder.status === 'under_review') {
          setReceiptSubmitted(true);
          setPaymentStatusNotice({
            type: 'under_review',
            msg: 'Comprovante já registrado para este pedido. Aguardando conciliação da compensação bancária.',
          });
        }
        setLoading(false);
        return;
      }

      // 2. Se não foi passado explicitamente, busca se já existe um pedido em aberto não expirado para este pacote
      try {
        const activeOrder = await findRecentActiveOrder(currentUser.uid, pkg.id);
        if (activeOrder && isMounted) {
          const expiresMs = new Date(activeOrder.expiresAt).getTime() || Date.now() + 15 * 60 * 1000;
          const remainingSecs = Math.max(0, Math.floor((expiresMs - Date.now()) / 1000));
          if (remainingSecs > 15) {
            setPixData({
              txId: activeOrder.txId,
              brCode: activeOrder.brCode,
              qrCodeDataUrl: '',
              amountBrl: activeOrder.amountBrl,
              kards: activeOrder.kards,
              title: activeOrder.title,
              userId: activeOrder.userId,
              expiresAt: activeOrder.expiresAt,
              status: activeOrder.status,
              pixKey: activeOrder.pixKey,
              merchantName: activeOrder.merchantName,
              receiptCode: activeOrder.receiptCode,
            });
            setTimeLeft(remainingSecs);
            if (activeOrder.status === 'under_review') {
              setReceiptSubmitted(true);
            }
            setLoading(false);
            return;
          }
        }
      } catch (checkErr) {
        console.warn('Erro ao checar pedido ativo prévio:', checkErr);
      }

      // 3. Caso não haja pedido pendente válido, cria um novo
      try {
        const data = await createPixOrder(pkg, currentUser);

        if (isMounted) {
          setPixData(data);
          setTimeLeft(15 * 60);
        }
      } catch (err: any) {
        if (isMounted) {
          setErrorMsg(err.message || 'Falha ao gerar o código Pix. Tente novamente.');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    initPix();

    return () => {
      isMounted = false;
    };
  }, [isOpen, pkg, currentUser, existingOrder]);

  // Forçar geração de um novo código Pix se o usuário quiser descartar o anterior
  const handleForceGenerateNewOrder = async () => {
    if (!pkg || !currentUser) return;
    setLoading(true);
    setErrorMsg('');
    setPaymentStatusNotice(null);
    setReceiptSubmitted(false);
    setReceiptCodeInput('');
    try {
      if (pixData?.txId) {
        await cancelPixOrder(pixData.txId, currentUser.uid).catch(() => {});
      }
      const data = await createPixOrder(pkg, currentUser);
      setPixData(data);
      setTimeLeft(15 * 60);
    } catch (err: any) {
      setErrorMsg(err.message || 'Erro ao gerar novo código.');
    } finally {
      setLoading(false);
    }
  };

  // Renderiza o QR code no Canvas quando pixData mudar
  useEffect(() => {
    if (pixData?.brCode && canvasRef.current) {
      QRCode.toCanvas(
        canvasRef.current,
        pixData.brCode,
        {
          width: 240,
          margin: 1,
          color: {
            dark: '#141414',
            light: '#F4F4F5',
          },
        },
        (error) => {
          if (error) console.error('[PixCheckoutModal] Erro ao renderizar canvas:', error);
        }
      );
    }
  }, [pixData]);

  // Contagem regressiva de validade
  useEffect(() => {
    if (!isOpen || success || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, success, timeLeft]);

  // Função interna para efetivar crédito após verificação confirmada
  const handleDeliverKards = async (txId: string, kardsCount: number) => {
    if (success) return;
    try {
      if (pixData) {
        await claimAndCreditPixOrder(
          {
            id: txId,
            txId,
            userId: currentUser.uid,
            packageId: pkg?.id || '',
            kards: kardsCount,
            amountBrl: pixData.amountBrl,
            title: pixData.title,
            status: 'completed',
            pixKey: pixData.pixKey || '',
            merchantName: pixData.merchantName || 'GB Payment',
            brCode: pixData.brCode,
            createdAt: new Date().toISOString(),
            expiresAt: pixData.expiresAt,
          },
          currentUser.uid
        );
      } else {
        await creditKards(
          currentUser.uid,
          kardsCount,
          'kard_purchase',
          `Compra de ${kardsCount} Kards via Pix Instantâneo (TXID: ${txId})`,
          txId
        );
      }
      setConfirmedTxId(txId);
      setSuccess(true);
      setPaymentStatusNotice(null);
      onSuccess(kardsCount, txId);
    } catch (err: any) {
      console.error('[PixCheckoutModal] Erro ao creditar Kards após pagamento confirmado:', err);
      setErrorMsg(err.message || 'Erro ao registrar os Kards em seu saldo.');
    }
  };

  // Escuta em tempo real se a ordem Pix foi aprovada (no Firestore)
  useEffect(() => {
    if (!isOpen || !pixData?.txId || success) return;

    const unsubscribe = subscribePixOrder(pixData.txId, async (order) => {
      if (order.status === 'paid' && !success) {
        console.log('[PixCheckoutModal] Pagamento identificado via Firestore!', order);
        const totalKards = pkg ? pkg.kards + (pkg.bonus || 0) : order.kards;
        await handleDeliverKards(order.txId, totalKards);
      }
    });

    return () => unsubscribe();
  }, [isOpen, pixData?.txId, success, pkg]);

  // Polling periódico a cada 7 segundos para verificar se foi pago
  useEffect(() => {
    if (!isOpen || !pixData?.txId || success || timeLeft <= 0) return;

    const interval = setInterval(async () => {
      try {
        const result = await verifyPixPayment(pixData.txId, currentUser.uid);
        if (result.paid && !success) {
          const totalKards = pkg ? pkg.kards + (pkg.bonus || 0) : result.kards || 0;
          await handleDeliverKards(pixData.txId, totalKards);
        }
      } catch (_) {}
    }, 7000);

    return () => clearInterval(interval);
  }, [isOpen, pixData?.txId, success, timeLeft, currentUser, pkg]);

  // Formata MM:SS
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60)
      .toString()
      .padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  // Copia o código Pix Copia e Cola
  const handleCopyCode = async () => {
    if (!pixData?.brCode) return;

    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(pixData.brCode);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = pixData.brCode;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch (err) {
      console.warn('Falha ao copiar:', err);
    }
  };

  // Verificação Estrita do Pagamento Pix
  const handleCheckPixPayment = async () => {
    if (!pixData || !currentUser || !pkg) return;

    setVerifying(true);
    setErrorMsg('');
    setPaymentStatusNotice(null);

    try {
      const totalKards = pkg.kards + (pkg.bonus || 0);
      const txId = pixData.txId;

      const fallbackOrder: PixOrder = {
        id: txId,
        txId,
        userId: currentUser.uid,
        userEmail: currentUser.email || '',
        packageId: pkg.id,
        kards: totalKards,
        amountBrl: pixData.amountBrl,
        title: pixData.title,
        status: pixData.status,
        pixKey: pixData.pixKey || '',
        merchantName: pixData.merchantName || 'GB Payment',
        brCode: pixData.brCode,
        createdAt: new Date().toISOString(),
        expiresAt: pixData.expiresAt,
      };

      // Chama a validação no servidor com fallback garantido
      const result = await verifyPixPayment(txId, currentUser.uid, undefined, fallbackOrder);

      if (result.paid) {
        // FOI PAGO: Credita os Kards
        await handleDeliverKards(txId, totalKards);
      } else {
        // NÃO FOI PAGO AINDA: Não credita nada e notifica o usuário
        if (result.status === 'expired') {
          setPaymentStatusNotice({
            type: 'expired',
            msg: 'Esta cobrança Pix expirou. Gere um novo QR Code para realizar o pagamento.',
          });
        } else if (result.status === 'under_review') {
          setPaymentStatusNotice({
            type: 'under_review',
            msg: 'Pagamento em análise! Aguardando aprovação manual do desenvolvedor no painel administrativo.',
          });
        } else {
          setPaymentStatusNotice({
            type: 'pending',
            msg: `Pagamento ainda não confirmado. Caso já tenha transferido no app do seu banco, aguarde alguns instantes pela compensação ou aprovação pelo desenvolvedor e clique novamente em 'Verificar'.`,
          });
        }
      }
    } catch (err: any) {
      console.error('[PixCheckoutModal] Erro ao checar status Pix:', err);
      let userFriendlyMsg = err.message || 'Falha ao consultar status bancário. Tente novamente.';
      setErrorMsg(userFriendlyMsg);
    } finally {
      setVerifying(false);
    }
  };

  // Ação de Administrador/Desenvolvedor para testes ou aprovação manual
  const handleAdminApprove = async () => {
    if (!pixData || !currentUser || !isDeveloper || !pkg) return;
    setAdminApproving(true);
    try {
      const totalKards = pkg.kards + (pkg.bonus || 0);
      const fallbackOrder: PixOrder = {
        id: pixData.txId,
        txId: pixData.txId,
        userId: currentUser.uid,
        userEmail: currentUser.email || '',
        packageId: pkg.id,
        kards: totalKards,
        amountBrl: pixData.amountBrl,
        title: pixData.title,
        status: pixData.status,
        pixKey: pixData.pixKey || '',
        merchantName: pixData.merchantName || 'GB Payment',
        brCode: pixData.brCode,
        createdAt: new Date().toISOString(),
        expiresAt: pixData.expiresAt,
      };
      await approvePixOrder(pixData.txId, currentUser.uid, fallbackOrder);
      await handleDeliverKards(pixData.txId, totalKards);
    } catch (err: any) {
      setErrorMsg(err.message || 'Erro ao aprovar como admin.');
    } finally {
      setAdminApproving(false);
    }
  };

  if (!isOpen || !pkg) return null;

  const totalKards = pkg.kards + (pkg.bonus || 0);

  return (
    <div
      id="pix-checkout-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !verifying) {
          onClose();
        }
      }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.2 }}
        className="relative w-full max-w-lg rounded-3xl bg-[#202020] p-6 sm:p-8 shadow-2xl border border-zinc-800 text-white my-auto"
      >
        {/* Botão Fechar */}
        <button
          id="close-pix-modal-btn"
          onClick={onClose}
          disabled={verifying}
          className="absolute right-5 top-5 p-2 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
          aria-label="Fechar"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Cabeçalho */}
        <div className="flex items-center gap-3 mb-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/35 shrink-0">
            <Zap className="h-6 w-6 fill-[#FF57B2]/30 text-[#FF57B2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 rounded-md bg-[#FF57B2]/15 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-[#FF80C5] border border-[#FF57B2]/30">
                <Sparkles className="h-3 w-3" /> Pix Instantâneo
              </span>
              <span className="text-[10px] text-zinc-400 font-medium">Validação Bancária Segura</span>
            </div>
            <h2 className="text-xl font-black text-white font-display">
              {success ? 'Pagamento Confirmado!' : 'Pagar com Pix'}
            </h2>
          </div>
        </div>

        {/* Tela de Sucesso */}
        {success ? (
          <div className="text-center py-4 space-y-4 animate-in fade-in zoom-in-95 duration-300">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/40 shadow-inner">
              <CheckCircle2 className="h-10 w-10" />
            </div>

            <div>
              <h3 className="text-lg font-black text-white font-display">
                Pagamento Confirmado! Kards Creditados!
              </h3>
              <p className="text-xs sm:text-sm text-zinc-300 mt-1 max-w-sm mx-auto">
                Identificamos o pagamento de <strong className="text-white">R$ {pkg.priceBrl.toFixed(2).replace('.', ',')}</strong> e{' '}
                <strong className="text-[#FF80C5]">+{totalKards} Kards</strong> já foram adicionados ao seu saldo com sucesso.
              </p>
            </div>

            <div className="rounded-2xl bg-[#262626] p-4 border border-zinc-800 text-left space-y-2 text-xs">
              <div className="flex justify-between text-zinc-400">
                <span>Pacote Adquirido:</span>
                <strong className="text-white">{pkg.title}</strong>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Total de Kards:</span>
                <strong className="text-[#FF80C5] font-black text-sm tabular-nums">+{totalKards} Kards</strong>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Código TXID:</span>
                <code className="text-[11px] font-mono bg-[#181818] px-2 py-0.5 rounded text-zinc-200 border border-zinc-700">
                  {confirmedTxId || pixData?.txId}
                </code>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Titular Recebedor:</span>
                <span className="font-semibold text-white">{pixData?.merchantName || 'GB Payment'}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Data & Hora:</span>
                <span className="text-zinc-200">{new Date().toLocaleString('pt-BR')}</span>
              </div>
            </div>

            <button
              id="finish-pix-success-btn"
              onClick={onClose}
              className="w-full rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] py-3.5 text-center text-sm font-bold text-white shadow-lg shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] transition cursor-pointer"
            >
              Concluir e Voltar à Loja
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Card de Resumo do Pacote */}
            <div className="flex items-center justify-between rounded-2xl bg-[#262626] p-3.5 border border-zinc-800">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30">
                  <Coins className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">{pkg.title}</h4>
                  <div className="flex items-center gap-1.5 text-[11px] text-zinc-300 font-semibold tabular-nums">
                    <span>{totalKards} Kards</span>
                    {pkg.bonus ? (
                      <span className="text-[#FF80C5] text-[10px] font-bold">
                        (+{pkg.bonus} bônus)
                      </span>
                    ) : null}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-zinc-400 font-bold block uppercase">Valor a Pagar</span>
                <span className="text-base font-black text-white font-display tabular-nums">
                  R$ {pkg.priceBrl.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>

            {loading ? (
              <div className="py-12 text-center space-y-3">
                <Loader2 className="h-8 w-8 animate-spin mx-auto text-[#FF57B2]" />
                <p className="text-xs text-zinc-400 font-medium">
                  Gerando QR Code e chave Pix instantânea...
                </p>
              </div>
            ) : errorMsg ? (
              <div className="rounded-2xl bg-[#262626] p-4 border border-[#FF57B2]/45 text-xs text-[#FF80C5] flex items-start gap-2.5">
                <AlertCircle className="h-4 w-4 shrink-0 text-[#FF57B2] mt-0.5" />
                <div>
                  <strong className="text-white">Atenção:</strong> {errorMsg}
                </div>
              </div>
            ) : (
              <>
                {/* QR Code centralizado com moldura visual escura */}
                <div className="flex flex-col items-center justify-center p-4 bg-[#262626] rounded-2xl border border-zinc-800 shadow-xs space-y-2">
                  <div className="relative p-2.5 rounded-xl bg-[#181818] border border-zinc-700 shadow-inner">
                    <canvas ref={canvasRef} className="rounded-lg max-w-[200px] h-auto" />
                  </div>
                  <div className="text-center space-y-0.5">
                    <p className="text-[11px] text-zinc-300 font-medium flex items-center justify-center gap-1">
                      <QrCode className="h-3.5 w-3.5 text-[#FF57B2]" />
                      Abra o app do seu banco e aponte para o QR Code
                    </p>
                    <p className="text-[10px] text-zinc-400">
                      Recebedor: <strong className="text-white">{pixData?.merchantName || 'GB Payment'}</strong>
                    </p>
                  </div>
                </div>

                {/* Pix Copia e Cola */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-zinc-200">Pix Copia e Cola:</span>
                    <div className="flex items-center gap-1 text-[11px] text-zinc-400">
                      <Clock className="h-3 w-3 text-[#FF57B2]" />
                      <span>Expira em: <strong className="text-white font-mono tabular-nums">{formatTime(timeLeft)}</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={pixData?.brCode || ''}
                      className="w-full rounded-xl bg-[#181818] px-3 py-2 text-[11px] font-mono text-zinc-200 border border-zinc-700 focus:outline-hidden select-all"
                      onClick={(e) => (e.target as HTMLInputElement).select()}
                    />
                    <button
                      id="copy-pix-code-btn"
                      onClick={handleCopyCode}
                      className={`shrink-0 flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition shadow-xs cursor-pointer ${
                        copied
                          ? 'bg-[#FF57B2] text-white'
                          : 'bg-[#262626] hover:bg-zinc-800 text-white border border-zinc-700'
                      }`}
                    >
                      {copied ? (
                        <>
                          <Check className="h-3.5 w-3.5" />
                          <span>Copiado!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          <span>Copiar</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Aviso / Notificação de Status de Pagamento */}
                {paymentStatusNotice && (
                  <div className="rounded-2xl p-3.5 border border-[#FF57B2]/40 bg-[#262626] text-xs text-zinc-200 flex items-start gap-2.5 animate-in fade-in slide-in-from-top-2 duration-200">
                    <Info className="h-4 w-4 shrink-0 mt-0.5 text-[#FF57B2]" />
                    <div className="space-y-1">
                      <strong className="block text-white">
                        {paymentStatusNotice.type === 'pending'
                          ? 'Pagamento Ainda Não Identificado'
                          : paymentStatusNotice.type === 'under_review'
                          ? 'Comprovante em Análise Bancária'
                          : 'Cobrança Expirada'}
                      </strong>
                      <p className="leading-relaxed text-[11px] text-zinc-300">{paymentStatusNotice.msg}</p>
                    </div>
                  </div>
                )}

                {/* Informação sobre liberação de pagamento */}
                <div className="rounded-2xl bg-[#262626] p-3.5 border border-zinc-800 text-xs flex items-center gap-3 text-zinc-300">
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#FF57B2]/15 text-[#FF57B2] border border-[#FF57B2]/30 shrink-0">
                    <ShieldCheck className="h-4 w-4" />
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    Após pagar no app do seu banco, o sistema verifica a compensação automaticamente. Os Kards são liberados após validação bancária ou aprovação pelo desenvolvedor.
                  </p>
                </div>

                {/* Seção Exclusiva de Desenvolvedor / Administrador para homologação e testes */}
                {isDeveloper && (
                  <div className="rounded-2xl bg-[#262626] p-3 border border-[#FF57B2]/40 text-xs text-zinc-200 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <strong className="flex items-center gap-1 text-white">
                        <Sparkles className="h-3.5 w-3.5 text-[#FF57B2]" />
                        Painel do Titular / Desenvolvedor
                      </strong>
                      <span className="text-[10px] font-mono bg-[#FF57B2]/20 px-1.5 py-0.5 rounded text-[#FF80C5] border border-[#FF57B2]/30">
                        ADMIN
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-300">
                      Como titular da conta (GB Payment), você pode aprovar esta ordem de teste manualmente:
                    </p>
                    <button
                      type="button"
                      onClick={handleAdminApprove}
                      disabled={adminApproving}
                      className="w-full py-1.5 rounded-xl bg-[#181818] hover:bg-[#FF57B2] border border-[#FF57B2]/40 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      {adminApproving ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Check className="h-3.5 w-3.5" />
                      )}
                      <span>Aprovar Pagamento Recebido (Simular Extrato GB Payment)</span>
                    </button>
                  </div>
                )}

                {/* Ações */}
                <div className="pt-2 space-y-2">
                  <button
                    id="confirm-pix-payment-btn"
                    onClick={handleCheckPixPayment}
                    disabled={verifying || timeLeft <= 0}
                    className="w-full flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] py-3.5 text-center text-xs font-bold text-white shadow-lg shadow-[#FF57B2]/25 hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer"
                  >
                    {verifying ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Verificando com o Sistema Bancário...</span>
                      </>
                    ) : (
                      <>
                        <RefreshCw className="h-4 w-4" />
                        <span>Verificar se o Pix foi Pago</span>
                      </>
                    )}
                  </button>

                  {/* Garantia de Persistência */}
                  <div className="rounded-xl bg-[#181818] p-2.5 border border-zinc-800 text-left">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white">
                      <ShieldCheck className="h-3.5 w-3.5 text-[#FF57B2] shrink-0" />
                      <span>Pedido Seguro e Permanente</span>
                    </div>
                    <p className="text-[10px] text-zinc-400 mt-0.5 leading-relaxed">
                      Se você fechar esta tela ou recarregar o app, seu pedido continua aberto na sua conta até ser validado ou expirar o tempo limite.
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={handleForceGenerateNewOrder}
                      disabled={loading || verifying}
                      className="text-[11px] text-zinc-400 hover:text-[#FF80C5] underline font-medium transition cursor-pointer"
                    >
                      Descartar e gerar novo código Pix
                    </button>
                    <button
                      id="cancel-pix-modal-btn"
                      onClick={onClose}
                      disabled={verifying}
                      className="rounded-xl px-3 py-1 text-center text-xs font-semibold text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
                    >
                      Acompanhar na Loja
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
};

