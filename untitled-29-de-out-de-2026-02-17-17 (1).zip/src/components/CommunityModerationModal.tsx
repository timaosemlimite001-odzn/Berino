import {
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  orderBy,
  query,
  updateDoc
} from 'firebase/firestore';
import {
  AlertCircle,
  Ban,
  Camera,
  Check,
  Clock,
  Crown,
  EyeOff,
  Loader2,
  Lock,
  Save,
  Settings,
  Shield,
  Trash2,
  UserCheck,
  UserMinus,
  UserPlus,
  Users,
  Volume2,
  VolumeX,
  X
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { usePublicProfile } from '../context/PublicProfileContext';
import { deleteCommunityCascade } from '../services/communityService';
import { db, sanitizeFirestoreData } from '../services/firebase';
import { awardXp, sendNotification } from '../services/progressionService';
import { uploadFileToStorage } from '../services/storageService';
import { Community, CommunityMember } from '../types';
import { ConfirmModal } from './ConfirmModal';
import { UserAvatar } from './UserAvatar';

interface CommunityModerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  community: Community;
  onUpdateCommunity: (updated: Partial<Community>) => void;
  onCommunityDeleted?: () => void;
}

export const CommunityModerationModal: React.FC<CommunityModerationModalProps> = ({
  isOpen,
  onClose,
  community,
  onUpdateCommunity,
  onCommunityDeleted,
}) => {
  const { currentUser, isDeveloper } = useAuth();
  const { openUserProfile } = usePublicProfile();
  const [activeTab, setActiveTab] = useState<'moderation' | 'settings'>('moderation');

  // Can delete community: creator or developer
  const canDeleteCommunity = Boolean(
    (currentUser && currentUser.uid === community.creatorId) || isDeveloper
  );
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeletingCommunity, setIsDeletingCommunity] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Members state
  const [members, setMembers] = useState<CommunityMember[]>([]);
  const [loadingMembers, setLoadingMembers] = useState(true);
  const [memberActionLoading, setMemberActionLoading] = useState<string | null>(null);
  const [memberConfirmState, setMemberConfirmState] = useState<{
    isOpen: boolean;
    type: 'remove' | 'ban';
    member: CommunityMember | null;
  }>({
    isOpen: false,
    type: 'remove',
    member: null,
  });

  // Community Settings state
  const [name, setName] = useState(community.name || '');
  const [description, setDescription] = useState(community.description || '');
  const [rules, setRules] = useState(community.rules || '');
  const [category, setCategory] = useState(community.category || 'Geral');
  const [isPrivate, setIsPrivate] = useState(Boolean(community.isPrivate));
  const [isHiddenFromNonMembers, setIsHiddenFromNonMembers] = useState(
    Boolean(community.isHiddenFromNonMembers)
  );
  const [hidePostsFromNonMembers, setHidePostsFromNonMembers] = useState(
    Boolean(community.hidePostsFromNonMembers)
  );
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [coverPreview, setCoverPreview] = useState(community.coverUrl || '');
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsStatus, setSettingsStatus] = useState<{ text: string; error: boolean } | null>(null);

  // Sync settings when community changes
  useEffect(() => {
    setName(community.name || '');
    setDescription(community.description || '');
    setRules(community.rules || '');
    setCategory(community.category || 'Geral');
    setIsPrivate(Boolean(community.isPrivate));
    setIsHiddenFromNonMembers(Boolean(community.isHiddenFromNonMembers));
    setHidePostsFromNonMembers(Boolean(community.hidePostsFromNonMembers));
    setCoverPreview(community.coverUrl || '');
  }, [community]);

  // Load community members
  useEffect(() => {
    if (!isOpen || !community.id) return;
    setLoadingMembers(true);

    const q = query(
      collection(db, 'communities', community.id, 'members'),
      orderBy('joinedAt', 'desc')
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: CommunityMember[] = [];
        snap.forEach((d) => list.push(d.data() as CommunityMember));
        setMembers(list);
        setLoadingMembers(false);
      },
      (err) => {
        console.error('Error loading community members for moderation:', err);
        setLoadingMembers(false);
      }
    );

    return () => unsub();
  }, [isOpen, community.id]);

  if (!isOpen) return null;

  const pendingMembers = members.filter((m) => m.status === 'pending');
  const activeMembers = members.filter((m) => m.status !== 'pending');

  // Approve pending join request
  const handleApprovePendingMember = async (member: CommunityMember) => {
    setMemberActionLoading(member.userId);
    try {
      await updateDoc(doc(db, 'communities', community.id, 'members', member.userId), {
        status: 'active',
        joinedAt: new Date().toISOString(),
      });
      const updatedCount = (community.membersCount || 1) + 1;
      await updateDoc(doc(db, 'communities', community.id), {
        membersCount: updatedCount,
      });
      onUpdateCommunity({ membersCount: updatedCount });

      await sendNotification(
        member.userId,
        'community_join',
        'Entrada aprovada na comunidade!',
        `Sua solicitação para entrar em "${community.name}" foi aprovada.`,
        `/comunidade/${community.id}`
      );
      await awardXp(
        member.userId,
        15,
        `join_comm_${community.id}`,
        `Entrou no grupo: ${community.name}`
      );
    } catch (err) {
      console.error('Error approving pending member:', err);
    } finally {
      setMemberActionLoading(null);
    }
  };

  // Reject pending join request
  const handleRejectPendingMember = async (member: CommunityMember) => {
    setMemberActionLoading(member.userId);
    try {
      await deleteDoc(doc(db, 'communities', community.id, 'members', member.userId));
    } catch (err) {
      console.error('Error rejecting pending member:', err);
    } finally {
      setMemberActionLoading(null);
    }
  };

  // 1. Remove member (leaves community)
  const handleRemoveMember = async (member: CommunityMember) => {
    if (member.userId === community.creatorId) return;

    setMemberActionLoading(member.userId);
    try {
      await deleteDoc(doc(db, 'communities', community.id, 'members', member.userId));
      if (member.status !== 'pending') {
        const updatedCount = Math.max(1, (community.membersCount || 1) - 1);
        await updateDoc(doc(db, 'communities', community.id), {
          membersCount: updatedCount,
        });
        onUpdateCommunity({ membersCount: updatedCount });
      }
    } catch (err) {
      console.error('Error removing member:', err);
    } finally {
      setMemberActionLoading(null);
    }
  };

  // 2. Ban member (strictly within this community only)
  const handleBanMember = async (member: CommunityMember) => {
    if (member.userId === community.creatorId) return;

    setMemberActionLoading(member.userId);
    try {
      const updatedBanned = Array.from(new Set([...(community.bannedUserIds || []), member.userId]));
      const updatedCount = Math.max(1, (community.membersCount || 1) - 1);

      await updateDoc(doc(db, 'communities', community.id), {
        bannedUserIds: arrayUnion(member.userId),
        membersCount: updatedCount,
      });

      await deleteDoc(doc(db, 'communities', community.id, 'members', member.userId));
      onUpdateCommunity({
        bannedUserIds: updatedBanned,
        membersCount: updatedCount,
      });
    } catch (err) {
      console.error('Error banning member:', err);
    } finally {
      setMemberActionLoading(null);
    }
  };

  // 3. Unban member
  const handleUnbanUserId = async (userId: string) => {
    setMemberActionLoading(userId);
    try {
      await updateDoc(doc(db, 'communities', community.id), {
        bannedUserIds: arrayRemove(userId),
      });
      const updatedBanned = (community.bannedUserIds || []).filter((id) => id !== userId);
      onUpdateCommunity({ bannedUserIds: updatedBanned });
    } catch (err) {
      console.error('Error unbanning user:', err);
    } finally {
      setMemberActionLoading(null);
    }
  };

  // 4. Silence member (temporarily, e.g. 1h, 24h, 3d, 7d)
  const handleSilenceMember = async (member: CommunityMember, hours: number) => {
    if (member.userId === community.creatorId) return;
    setMemberActionLoading(member.userId);

    const untilTimestamp = new Date(Date.now() + hours * 3600 * 1000).toISOString();
    const updatedMap = {
      ...(community.silencedUntilMap || {}),
      [member.userId]: untilTimestamp,
    };
    const updatedSilenced = Array.from(new Set([...(community.silencedUserIds || []), member.userId]));

    try {
      await updateDoc(doc(db, 'communities', community.id), {
        silencedUserIds: arrayUnion(member.userId),
        silencedUntilMap: updatedMap,
      });
      onUpdateCommunity({
        silencedUserIds: updatedSilenced,
        silencedUntilMap: updatedMap,
      });
    } catch (err) {
      console.error('Error silencing member:', err);
    } finally {
      setMemberActionLoading(null);
    }
  };

  // 5. Unsilence member
  const handleUnsilenceMember = async (userId: string) => {
    setMemberActionLoading(userId);
    try {
      const updatedMap = { ...(community.silencedUntilMap || {}) };
      delete updatedMap[userId];
      const updatedSilenced = (community.silencedUserIds || []).filter((id) => id !== userId);

      await updateDoc(doc(db, 'communities', community.id), {
        silencedUserIds: arrayRemove(userId),
        silencedUntilMap: updatedMap,
      });
      onUpdateCommunity({
        silencedUserIds: updatedSilenced,
        silencedUntilMap: updatedMap,
      });
    } catch (err) {
      console.error('Error unsilencing member:', err);
    } finally {
      setMemberActionLoading(null);
    }
  };

  // 5.1 Toggle Partial Moderator (Authorizes member to post in this community only, cannot edit/delete)
  const handleTogglePartialModerator = async (member: CommunityMember) => {
    if (member.userId === community.creatorId) return;
    setMemberActionLoading(member.userId);
    const isCurrentlyPartialMod = Boolean(
      community.partialModeratorIds?.includes(member.userId) ||
      member.role === 'partial_moderator'
    );
    try {
      if (isCurrentlyPartialMod) {
        // Demote to regular member
        await updateDoc(doc(db, 'communities', community.id), {
          partialModeratorIds: arrayRemove(member.userId),
        });
        await updateDoc(doc(db, 'communities', community.id, 'members', member.userId), {
          role: 'member',
        });
        const updatedList = (community.partialModeratorIds || []).filter((id) => id !== member.userId);
        onUpdateCommunity({ partialModeratorIds: updatedList });
        setMembers((prev) =>
          prev.map((item) => (item.userId === member.userId ? { ...item, role: 'member' } : item))
        );
      } else {
        // Promote to partial moderator
        await updateDoc(doc(db, 'communities', community.id), {
          partialModeratorIds: arrayUnion(member.userId),
        });
        await updateDoc(doc(db, 'communities', community.id, 'members', member.userId), {
          role: 'partial_moderator',
        });
        const updatedList = Array.from(new Set([...(community.partialModeratorIds || []), member.userId]));
        onUpdateCommunity({ partialModeratorIds: updatedList });
        setMembers((prev) =>
          prev.map((item) => (item.userId === member.userId ? { ...item, role: 'partial_moderator' } : item))
        );
      }
    } catch (err) {
      console.error('Error toggling partial moderator role:', err);
    } finally {
      setMemberActionLoading(null);
    }
  };

  // 6. Save Community Settings & Cover Image
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    setSettingsStatus(null);

    try {
      let finalCoverUrl = coverPreview;

      // Real upload to Firebase Storage if a new file was chosen
      if (coverFile) {
        finalCoverUrl = await uploadFileToStorage(coverFile, 'covers', community.id);
      }

      const updates: Partial<Community> = {
        name: name.trim(),
        description: description.trim(),
        rules: rules.trim(),
        category,
        isPrivate,
        isHiddenFromNonMembers,
        hidePostsFromNonMembers,
        coverUrl: finalCoverUrl,
        updatedAt: new Date().toISOString(),
      };

      await updateDoc(
        doc(db, 'communities', community.id),
        sanitizeFirestoreData(updates)
      );

      onUpdateCommunity(updates);
      setSettingsStatus({ text: 'Configurações e capa da comunidade atualizadas com sucesso!', error: false });
      setTimeout(() => setSettingsStatus(null), 4000);
    } catch (err: any) {
      console.error('Error saving community settings:', err);
      setSettingsStatus({ text: err.message || 'Erro ao salvar alterações.', error: true });
    } finally {
      setSavingSettings(false);
    }
  };

  // 7. Delete Community Permanently (Creator or Developer)
  const handleDeleteCommunity = async () => {
    if (!canDeleteCommunity) return;
    setIsDeletingCommunity(true);
    setDeleteError(null);
    try {
      await deleteCommunityCascade(community.id);
      setShowDeleteConfirm(false);
      onClose();
      if (onCommunityDeleted) {
        onCommunityDeleted();
      }
    } catch (err: any) {
      console.error('Error deleting community:', err);
      setDeleteError(err.message || 'Erro ao excluir comunidade.');
    } finally {
      setIsDeletingCommunity(false);
    }
  };

  const categories = [
    'Geral',
    'Cordel & Verso',
    'Romance & Drama',
    'Ficção & Fantasia',
    'Poesia & Métricas',
    'Leitores Beta',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
      <div className="w-full max-w-2xl rounded-3xl bg-[#202020] text-white border border-zinc-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 p-5 bg-[#262626]">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#FF57B2] to-[#E03595] text-white shadow-xs border border-[#FF57B2]/40">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white font-display">
                Gestão da Comunidade: {community.name}
              </h3>
              <p className="text-[11px] text-zinc-400">
                Poderes exclusivos do criador para moderação de membros e edição da comunidade.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-800 px-6 pt-3 gap-6 bg-[#202020]">
          <button
            type="button"
            onClick={() => setActiveTab('moderation')}
            className={`pb-3 text-xs font-bold transition flex items-center gap-1.5 border-b-2 cursor-pointer ${
              activeTab === 'moderation'
                ? 'border-[#FF57B2] text-[#FF57B2]'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Users className="h-4 w-4" />
            <span>Membros & Moderação ({members.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`pb-3 text-xs font-bold transition flex items-center gap-1.5 border-b-2 cursor-pointer ${
              activeTab === 'settings'
                ? 'border-[#FF57B2] text-[#FF57B2]'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Settings className="h-4 w-4" />
            <span>Editar Capa & Dados do Grupo</span>
          </button>
        </div>

        {/* Tab 1: Members & Moderation */}
        {activeTab === 'moderation' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Notice about scope */}
            <div className="rounded-2xl bg-[#262626] border border-[#FF57B2]/30 p-3 text-xs text-zinc-200 flex items-start gap-2">
              <AlertCircle className="h-4 w-4 shrink-0 text-[#FF57B2] mt-0.5" />
              <div>
                <strong className="text-white">Moderação local desta comunidade:</strong> As penalidades de silêncio e banimento aplicam-se exclusivamente a este espaço e são validadas nas regras de segurança do Firestore.
              </div>
            </div>

            {/* Banned Users Section */}
            {(community.bannedUserIds || []).length > 0 && (
              <div className="space-y-3 rounded-2xl bg-[#262626] border border-[#FF57B2]/35 p-4">
                <div className="flex items-center gap-2 text-xs font-bold text-[#FF80C5] uppercase tracking-wider">
                  <Ban className="h-4 w-4 text-[#FF57B2]" />
                  <span>Membros Banidos Desta Comunidade ({community.bannedUserIds?.length})</span>
                </div>
                <div className="space-y-2">
                  {community.bannedUserIds?.map((uid) => (
                    <div
                      key={uid}
                      className="flex items-center justify-between rounded-xl bg-[#181818] p-2.5 border border-zinc-800 text-xs shadow-2xs"
                    >
                      <span className="font-mono text-[11px] text-zinc-300">ID: {uid}</span>
                      <button
                        type="button"
                        onClick={() => handleUnbanUserId(uid)}
                        disabled={memberActionLoading === uid}
                        className="rounded-lg bg-[#FF57B2]/15 hover:bg-[#FF57B2]/25 text-[#FF80C5] border border-[#FF57B2]/35 px-3 py-1 font-bold text-[11px] transition cursor-pointer"
                      >
                        {memberActionLoading === uid ? 'Desbanindo...' : 'Desbanir Usuário'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Pending Join Requests Section (Private Communities) */}
            {pendingMembers.length > 0 && (
              <div className="space-y-3 rounded-2xl bg-[#262626] border border-[#FF57B2]/45 p-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#FF80C5] uppercase tracking-wider">
                    <UserPlus className="h-4 w-4 text-[#FF57B2]" />
                    <span>Solicitações de Entrada Pendentes ({pendingMembers.length})</span>
                  </div>
                </div>
                <div className="space-y-2">
                  {pendingMembers.map((pm) => (
                    <div
                      key={pm.userId}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 rounded-xl bg-[#181818] p-3 border border-zinc-800 text-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <UserAvatar
                          userId={pm.userId}
                          userName={pm.userName}
                          photoURL={pm.userPhoto}
                          sizeClass="h-9 w-9 shrink-0"
                          onClick={() => openUserProfile(pm.userId)}
                        />
                        <div className="min-w-0">
                          <span
                            onClick={() => openUserProfile(pm.userId)}
                            className="font-bold text-white hover:text-[#FF57B2] hover:underline cursor-pointer block truncate"
                          >
                            {pm.userName}
                          </span>
                          <span className="text-[10px] text-zinc-400">
                            Solicitado em {new Date(pm.joinedAt).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleApprovePendingMember(pm)}
                          disabled={memberActionLoading === pm.userId}
                          className="inline-flex items-center gap-1 rounded-xl bg-[#FF57B2] hover:bg-[#E03595] text-white px-3 py-1.5 font-bold text-[11px] transition cursor-pointer disabled:opacity-50"
                        >
                          <UserCheck className="h-3.5 w-3.5" />
                          <span>Aprovar</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRejectPendingMember(pm)}
                          disabled={memberActionLoading === pm.userId}
                          className="inline-flex items-center gap-1 rounded-xl bg-[#262626] hover:bg-zinc-800 text-zinc-300 border border-zinc-700 px-3 py-1.5 font-semibold text-[11px] transition cursor-pointer disabled:opacity-50"
                        >
                          <X className="h-3.5 w-3.5" />
                          <span>Recusar</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Active Members List */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                Lista de Participantes ({activeMembers.length})
              </h4>

              {loadingMembers ? (
                <div className="py-10 text-center text-xs text-zinc-400">
                  Carregando membros da comunidade...
                </div>
              ) : activeMembers.length === 0 ? (
                <div className="rounded-2xl border border-zinc-800 bg-[#262626] p-8 text-center text-xs text-zinc-400">
                  Nenhum membro encontrado.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {activeMembers.map((m) => {
                    const isFounder = m.userId === community.creatorId;
                    const isPartialMod =
                      !isFounder &&
                      Boolean(
                        community.partialModeratorIds?.includes(m.userId) ||
                          m.role === 'partial_moderator'
                      );
                    const silencedUntil = community.silencedUntilMap?.[m.userId];
                    const isCurrentlySilenced =
                      silencedUntil && new Date(silencedUntil).getTime() > Date.now();

                    return (
                      <div
                        key={m.userId}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-zinc-800 bg-[#262626] p-3.5 shadow-2xs"
                      >
                        <div className="flex items-center gap-3">
                          <UserAvatar
                            userId={m.userId}
                            userName={m.userName}
                            photoURL={m.userPhoto}
                            sizeClass="h-10 w-10"
                            onClick={() => openUserProfile(m.userId)}
                            title={`Ver perfil de ${m.userName}`}
                          />
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span
                                onClick={() => openUserProfile(m.userId)}
                                className="font-bold text-xs sm:text-sm text-white hover:text-[#FF57B2] hover:underline cursor-pointer transition"
                                title={`Ver perfil de ${m.userName}`}
                              >
                                {m.userName}
                              </span>
                              {isFounder ? (
                                <span className="rounded-md bg-[#FF57B2]/15 text-[#FF80C5] border border-[#FF57B2]/40 px-2 py-0.5 text-[10px] font-bold flex items-center gap-1">
                                  <Crown className="h-3 w-3 text-[#FF57B2]" />
                                  Fundador
                                </span>
                              ) : isPartialMod ? (
                                <span
                                  className="rounded-md bg-[#FF57B2]/10 text-[#FF80C5] border border-[#FF57B2]/30 px-2 py-0.5 text-[10px] font-bold flex items-center gap-1"
                                  title="Moderador parcial: permissão exclusiva para publicar nesta comunidade (sem permissão de editar ou excluir)"
                                >
                                  <Shield className="h-3 w-3 text-[#FF57B2]" />
                                  Moderador Parcial
                                </span>
                              ) : (
                                <span className="rounded-md bg-zinc-800 text-zinc-300 border border-zinc-700 px-2 py-0.5 text-[10px] font-semibold">
                                  Membro
                                </span>
                              )}
                              {isCurrentlySilenced && (
                                <span className="rounded-md bg-[#181818] text-[#FF80C5] border border-[#FF57B2]/40 px-2 py-0.5 text-[10px] font-bold flex items-center gap-1">
                                  <VolumeX className="h-3 w-3 text-[#FF57B2]" />
                                  Silenciado
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-zinc-400">
                              Entrou em: {new Date(m.joinedAt).toLocaleDateString('pt-BR')}
                              {isCurrentlySilenced &&
                                ` • Silêncio até: ${new Date(silencedUntil).toLocaleString('pt-BR', {
                                  day: '2-digit',
                                  month: 'short',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}`}
                            </span>
                          </div>
                        </div>

                        {/* Moderation Actions for this member (Disabled for Founder) */}
                        {!isFounder && (
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {/* Toggle Moderador Parcial */}
                            <button
                              type="button"
                              onClick={() => handleTogglePartialModerator(m)}
                              disabled={memberActionLoading === m.userId}
                              className={`inline-flex items-center gap-1 rounded-xl px-2.5 py-1.5 text-[11px] font-bold transition cursor-pointer ${
                                isPartialMod
                                  ? 'bg-[#FF57B2]/20 text-[#FF80C5] hover:bg-[#FF57B2]/30 border border-[#FF57B2]/50'
                                  : 'bg-[#181818] text-zinc-200 hover:bg-zinc-800 hover:text-[#FF80C5] border border-zinc-700'
                              }`}
                              title={
                                isPartialMod
                                  ? 'Revogar permissão de moderador parcial'
                                  : 'Tornar moderador parcial (autoriza a publicar na comunidade)'
                              }
                            >
                              <Shield className="h-3.5 w-3.5 text-[#FF57B2]" />
                              <span>{isPartialMod ? 'Revogar Moderação' : 'Tornar Moderador Parcial'}</span>
                            </button>

                            {/* Silence / Unsilence */}
                            {isCurrentlySilenced ? (
                              <button
                                type="button"
                                onClick={() => handleUnsilenceMember(m.userId)}
                                disabled={memberActionLoading === m.userId}
                                className="inline-flex items-center gap-1 rounded-xl bg-[#FF57B2]/15 text-[#FF80C5] hover:bg-[#FF57B2]/25 border border-[#FF57B2]/40 px-2.5 py-1.5 text-[11px] font-bold transition cursor-pointer"
                                title="Desilenciar membro"
                              >
                                <Volume2 className="h-3.5 w-3.5" />
                                <span>Desilenciar</span>
                              </button>
                            ) : (
                              <div className="flex items-center gap-1">
                                <select
                                  onChange={(e) => {
                                    const val = parseInt(e.target.value, 10);
                                    if (val > 0) {
                                      handleSilenceMember(m, val);
                                      e.target.value = '';
                                    }
                                  }}
                                  defaultValue=""
                                  disabled={memberActionLoading === m.userId}
                                  className="rounded-xl border border-zinc-700 bg-[#181818] px-2 py-1.5 text-[11px] font-semibold text-white [color-scheme:dark] focus:outline-none focus:border-[#FF57B2] cursor-pointer"
                                >
                                  <option value="" disabled>Silenciar...</option>
                                  <option value="1">1 hora</option>
                                  <option value="24">24 horas</option>
                                  <option value="72">3 dias</option>
                                  <option value="168">7 dias</option>
                                </select>
                              </div>
                            )}

                            {/* Remove Member */}
                            <button
                              type="button"
                              onClick={() =>
                                setMemberConfirmState({
                                  isOpen: true,
                                  type: 'remove',
                                  member: m,
                                })
                              }
                              disabled={memberActionLoading === m.userId}
                              className="inline-flex items-center gap-1 rounded-xl border border-zinc-700 bg-[#181818] text-zinc-300 hover:bg-zinc-800 hover:text-white px-2.5 py-1.5 text-[11px] font-semibold transition cursor-pointer"
                              title="Remover membro da comunidade"
                            >
                              <UserMinus className="h-3.5 w-3.5 text-zinc-400" />
                              <span>Remover</span>
                            </button>

                            {/* Ban Member */}
                            <button
                              type="button"
                              onClick={() =>
                                setMemberConfirmState({
                                  isOpen: true,
                                  type: 'ban',
                                  member: m,
                                })
                              }
                              disabled={memberActionLoading === m.userId}
                              className="inline-flex items-center gap-1 rounded-xl bg-[#181818] text-[#FF80C5] hover:bg-[#FF57B2]/20 border border-[#FF57B2]/40 px-2.5 py-1.5 text-[11px] font-bold transition cursor-pointer"
                              title="Banir membro desta comunidade"
                            >
                              <Ban className="h-3.5 w-3.5 text-[#FF57B2]" />
                              <span>Banir</span>
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Settings & Cover Image Edit */}
        {activeTab === 'settings' && (
          <form onSubmit={handleSaveSettings} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
            {settingsStatus && (
              <div
                className={`rounded-2xl p-3 border text-xs font-medium flex items-center gap-2 ${
                  settingsStatus.error
                    ? 'bg-[#262626] border-[#FF57B2]/45 text-[#FF80C5]'
                    : 'bg-[#262626] border-[#FF57B2]/35 text-white'
                }`}
              >
                {settingsStatus.error ? (
                  <AlertCircle className="h-4 w-4 shrink-0 text-[#FF57B2]" />
                ) : (
                  <Check className="h-4 w-4 shrink-0 text-[#FF57B2]" />
                )}
                <span>{settingsStatus.text}</span>
              </div>
            )}

            {/* Cover Image Upload */}
            <div className="space-y-2">
              <label className="block font-bold text-zinc-200">
                Imagem de Capa da Comunidade (Salva no Firebase Storage & Firestore)
              </label>

              <div className="relative overflow-hidden rounded-2xl border border-zinc-800 bg-[#181818] h-36 flex items-center justify-center">
                {coverPreview ? (
                  <img
                    src={coverPreview}
                    alt="Capa da Comunidade"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-zinc-400 text-xs gap-1.5">
                    <Camera className="h-6 w-6 text-[#FF57B2]" />
                    <span>Nenhuma imagem de capa selecionada</span>
                  </div>
                )}

                <label className="absolute bottom-3 right-3 flex items-center gap-1.5 rounded-xl bg-zinc-950/90 hover:bg-zinc-900 text-white border border-zinc-700 px-3 py-1.5 text-[11px] font-bold shadow-md cursor-pointer transition">
                  <Camera className="h-3.5 w-3.5 text-[#FF57B2]" />
                  <span>{coverPreview ? 'Alterar Imagem de Capa' : 'Carregar Imagem de Capa'}</span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setCoverFile(file);
                        setCoverPreview(URL.createObjectURL(file));
                      }
                    }}
                  />
                </label>

                {coverPreview && (
                  <button
                    type="button"
                    onClick={() => {
                      setCoverFile(null);
                      setCoverPreview('');
                    }}
                    className="absolute top-3 right-3 rounded-full bg-[#262626] text-white border border-zinc-700 p-1.5 hover:bg-[#FF57B2] shadow cursor-pointer transition"
                    title="Remover capa"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Name */}
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Nome da Comunidade</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-none"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Categoria</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white [color-scheme:dark] focus:border-[#FF57B2] focus:outline-none"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Description */}
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">Descrição do Grupo</label>
              <textarea
                required
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-none"
              />
            </div>

            {/* Rules */}
            <div>
              <label className="block font-semibold text-zinc-300 mb-1">
                Regras de Convivência (Diretrizes)
              </label>
              <textarea
                rows={2}
                value={rules}
                onChange={(e) => setRules(e.target.value)}
                className="w-full rounded-xl border border-zinc-700 bg-[#181818] p-2.5 text-xs text-white focus:border-[#FF57B2] focus:outline-none"
              />
            </div>

            {/* Privacy & Hiding Settings */}
            <div className="rounded-2xl bg-[#262626] border border-zinc-800 p-4 space-y-3">
              <div className="flex items-center gap-2 font-bold text-white text-xs">
                <Lock className="h-4 w-4 text-[#FF57B2]" />
                <span>Privacidade & Ocultação para Não-Membros</span>
              </div>

              <label className="flex items-start justify-between gap-3 rounded-xl bg-[#181818] border border-zinc-800 p-3 cursor-pointer hover:border-[#FF57B2]/40 transition">
                <div className="space-y-0.5">
                  <span className="font-bold text-white block">
                    Privar comunidade (entrada sujeita a aprovação)
                  </span>
                  <span className="text-[11px] text-zinc-400 block">
                    Quem não faz parte precisa solicitar entrada e ser aprovado para acessar.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={isPrivate}
                  onChange={(e) => setIsPrivate(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                />
              </label>

              <label className="flex items-start justify-between gap-3 rounded-xl bg-[#181818] border border-zinc-800 p-3 cursor-pointer hover:border-[#FF57B2]/40 transition">
                <div className="space-y-0.5">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <EyeOff className="h-3.5 w-3.5 text-[#FF57B2]" />
                    <span>Ocultar comunidade para quem não faz parte</span>
                  </span>
                  <span className="text-[11px] text-zinc-400 block">
                    Remove a comunidade das listagens públicas, carrosséis e buscas para não-membros.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={isHiddenFromNonMembers}
                  onChange={(e) => setIsHiddenFromNonMembers(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                />
              </label>

              <label className="flex items-start justify-between gap-3 rounded-xl bg-[#181818] border border-zinc-800 p-3 cursor-pointer hover:border-[#FF57B2]/40 transition">
                <div className="space-y-0.5">
                  <span className="font-bold text-white block">
                    Ocultar publicações para quem não faz parte
                  </span>
                  <span className="text-[11px] text-zinc-400 block">
                    Garante que nenhuma publicação desta comunidade apareça no Flux ou externamente para não-membros.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={hidePostsFromNonMembers}
                  onChange={(e) => setHidePostsFromNonMembers(e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-[#FF57B2] cursor-pointer shrink-0"
                />
              </label>
            </div>

            <div className="flex justify-end pt-3 border-t border-zinc-800">
              <button
                type="submit"
                disabled={savingSettings}
                className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#FF57B2] to-[#E03595] px-6 py-2.5 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/20 hover:from-[#FF40A4] hover:to-[#D02685] transition disabled:opacity-50 cursor-pointer"
              >
                {savingSettings ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Salvando...</span>
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    <span>Salvar Alterações da Comunidade</span>
                  </>
                )}
              </button>
            </div>

            {/* Danger Zone: Delete Community (Creator or Developer) */}
            {canDeleteCommunity && (
              <div className="mt-8 rounded-2xl border border-[#FF57B2]/35 bg-[#262626] p-4 sm:p-5 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-[#FF80C5] font-bold text-xs uppercase tracking-wider">
                      <Trash2 className="h-4 w-4 text-[#FF57B2]" />
                      <span>Zona de Exclusão — Excluir Comunidade</span>
                    </div>
                    <p className="text-xs text-zinc-300 font-medium">
                      Excluir permanentemente <strong className="text-white">"{community.name}"</strong>, apagando todas as postagens, comentários e inscrições de membros. Esta ação não poderá ser desfeita.
                    </p>
                    {deleteError && (
                      <p className="text-xs font-bold text-[#FF80C5] pt-1">{deleteError}</p>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowDeleteConfirm(true)}
                    disabled={isDeletingCommunity}
                    className="shrink-0 inline-flex items-center justify-center gap-2 rounded-xl bg-[#181818] border border-[#FF57B2]/50 px-4 py-2.5 text-xs font-bold text-[#FF80C5] shadow-sm hover:bg-[#FF57B2] hover:text-white transition cursor-pointer disabled:opacity-50"
                  >
                    <Trash2 className="h-4 w-4" />
                    <span>Excluir Comunidade</span>
                  </button>
                </div>
              </div>
            )}
          </form>
        )}
        {/* Confirm Modal for Member Remove / Ban */}
        <ConfirmModal
          isOpen={memberConfirmState.isOpen}
          onClose={() => setMemberConfirmState((prev) => ({ ...prev, isOpen: false }))}
          onConfirm={async () => {
            if (!memberConfirmState.member) return;
            if (memberConfirmState.type === 'remove') {
              await handleRemoveMember(memberConfirmState.member);
            } else {
              await handleBanMember(memberConfirmState.member);
            }
            setMemberConfirmState((prev) => ({ ...prev, isOpen: false }));
          }}
          title={
            memberConfirmState.type === 'remove'
              ? `Remover "${memberConfirmState.member?.userName}"?`
              : `Banir "${memberConfirmState.member?.userName}" desta comunidade?`
          }
          message={
            memberConfirmState.type === 'remove'
              ? 'O membro sairá da comunidade, mas poderá retornar quando desejar.'
              : 'O usuário não poderá mais participar, publicar ou comentar nesta comunidade. O banimento é restrito a este espaço e seguro no banco de dados.'
          }
          confirmText={memberConfirmState.type === 'remove' ? 'Remover Membro' : 'Banir Membro'}
          cancelText="Cancelar"
          variant="danger"
          isLoading={Boolean(memberActionLoading)}
        />

        {/* Confirm Modal for Deleting Entire Community */}
        <ConfirmModal
          isOpen={showDeleteConfirm}
          onClose={() => setShowDeleteConfirm(false)}
          onConfirm={handleDeleteCommunity}
          title={`Excluir "${community.name}"?`}
          message={`Tem certeza absoluta que deseja excluir a comunidade "${community.name}"? Todas as discussões, enquetes, mídias, comentários e lista de membros serão apagados definitivamente do KORDEL. Esta ação é irreversível.`}
          confirmText="Sim, Excluir Comunidade"
          cancelText="Cancelar"
          variant="danger"
          isLoading={isDeletingCommunity}
        />
      </div>
    </div>
  );
};
