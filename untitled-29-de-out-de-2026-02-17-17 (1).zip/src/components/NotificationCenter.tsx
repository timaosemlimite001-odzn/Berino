import {
  AlertCircle,
  Award,
  Bell,
  CheckCheck,
  ChevronRight,
  Coins,
  FileText,
  MessageSquare,
  Sparkles,
  TrendingUp,
  X
} from 'lucide-react';
import React from 'react';
import { useNotifications } from '../context/NotificationContext';
import { NotificationItem, NotificationType } from '../types';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (path: string) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications();

  if (!isOpen) return null;

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case 'level_up':
        return <TrendingUp className="h-4 w-4 text-[#FF80C5]" />;
      case 'achievement':
        return <Award className="h-4 w-4 text-[#FF57B2]" />;
      case 'new_title':
        return <Sparkles className="h-4 w-4 text-[#FF80C5]" />;
      case 'kards_received':
      case 'kards_spent':
      case 'kards_purchase':
        return <Coins className="h-4 w-4 text-[#FF57B2]" />;
      case 'comment':
      case 'reply':
        return <MessageSquare className="h-4 w-4 text-[#FF57B2]" />;
      case 'beta_event':
        return <FileText className="h-4 w-4 text-[#FF57B2]" />;
      default:
        return <Bell className="h-4 w-4 text-[#FF57B2]" />;
    }
  };

  const handleItemClick = (item: NotificationItem) => {
    if (!item.read) {
      markAsRead(item.id);
    }
    if (item.linkUrl && onNavigate) {
      onNavigate(item.linkUrl);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="flex h-full w-full max-w-sm flex-col bg-[#202020] text-white shadow-2xl transition-all border-l border-zinc-800">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 p-4 bg-gradient-to-r from-[#262626] to-[#202020]">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#FF57B2]/20 text-[#FF57B2] border border-[#FF57B2]/40">
              <Bell className="h-4 w-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">Notificações</h3>
              <p className="text-[11px] text-[#FF57B2] font-semibold">
                {unreadCount > 0 ? `${unreadCount} não lidas` : 'Tudo em dia'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                title="Marcar todas como lidas"
                className="rounded-lg p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
              >
                <CheckCheck className="h-4 w-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto divide-y divide-zinc-800/60 p-2">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center px-4">
              <div className="rounded-full bg-zinc-800 p-4 text-[#FF57B2] mb-3 border border-[#FF57B2]/30 shadow-sm">
                <Bell className="h-6 w-6" />
              </div>
              <p className="text-sm font-semibold text-white">Nenhuma notificação</p>
              <p className="text-xs text-zinc-400 mt-1 max-w-[220px]">
                Você receberá avisos sobre novos capítulos, comentários, conquistas e Kards aqui.
              </p>
            </div>
          ) : (
            notifications.map((item) => (
              <div
                key={item.id}
                onClick={() => handleItemClick(item)}
                className={`group flex items-start gap-3 rounded-xl p-3 text-left transition cursor-pointer ${
                  item.read
                    ? 'hover:bg-zinc-800/50 opacity-75'
                    : 'bg-zinc-850 hover:bg-zinc-800 border border-[#FF57B2]/30 shadow-xs'
                }`}
              >
                <div className="mt-0.5 rounded-lg bg-zinc-900 p-2 shadow-xs border border-zinc-700/60">
                  {getIcon(item.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <p className={`text-xs truncate ${item.read ? 'font-medium text-zinc-300' : 'font-bold text-white'}`}>
                      {item.title}
                    </p>
                    {!item.read && (
                      <span className="h-2 w-2 shrink-0 rounded-full bg-[#FF57B2] shadow-[0_0_6px_#FF57B2]"></span>
                    )}
                  </div>
                  <p className="mt-0.5 text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                    {item.message}
                  </p>
                  <span className="mt-1 block text-[10px] text-zinc-500">
                    {new Date(item.createdAt).toLocaleDateString('pt-BR', {
                      day: '2-digit',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                {item.linkUrl && (
                  <ChevronRight className="h-4 w-4 self-center text-zinc-400 opacity-0 group-hover:opacity-100 transition" />
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

// Discrete floating top banner component for on-screen notifications (system messages, comments, achievements, etc.)
export const NotificationToastBanner: React.FC<{ onNavigate: (path: string) => void }> = ({
  onNavigate,
}) => {
  const { activeBanner, dismissBanner, markAsRead } = useNotifications();

  if (!activeBanner) return null;

  const handleClick = () => {
    markAsRead(activeBanner.id);
    if (activeBanner.linkUrl) {
      onNavigate(activeBanner.linkUrl);
    }
    dismissBanner();
  };

  const getToastMeta = (type: NotificationType) => {
    switch (type) {
      case 'comment':
      case 'reply':
        return {
          icon: <MessageSquare className="h-4 w-4 text-[#FF57B2]" />,
          bg: 'bg-[#262626] border-[#FF57B2]/40 text-white',
          badgeBg: 'bg-[#FF57B2]/20 text-[#FF57B2]',
          badgeLabel: 'Comentário',
        };
      case 'system':
        return {
          icon: <Bell className="h-4 w-4 text-[#FF57B2]" />,
          bg: 'bg-[#262626] border-[#FF57B2]/40 text-white',
          badgeBg: 'bg-[#FF57B2]/20 text-[#FF57B2]',
          badgeLabel: 'Sistema',
        };
      case 'kards_received':
      case 'kards_purchase':
      case 'kards_spent':
        return {
          icon: <Coins className="h-4 w-4 text-[#FF80C5]" />,
          bg: 'bg-[#262626] border-[#FF57B2]/40 text-white',
          badgeBg: 'bg-[#FF57B2]/20 text-[#FF80C5]',
          badgeLabel: 'Kards',
        };
      case 'level_up':
        return {
          icon: <TrendingUp className="h-4 w-4 text-[#FF57B2]" />,
          bg: 'bg-[#262626] border-[#FF57B2]/40 text-white',
          badgeBg: 'bg-[#FF57B2]/20 text-[#FF57B2]',
          badgeLabel: 'Nível',
        };
      case 'achievement':
      case 'new_title':
        return {
          icon: <Award className="h-4 w-4 text-[#FF80C5]" />,
          bg: 'bg-[#262626] border-[#FF57B2]/40 text-white',
          badgeBg: 'bg-[#FF57B2]/20 text-[#FF80C5]',
          badgeLabel: 'Conquista',
        };
      case 'beta_event':
        return {
          icon: <FileText className="h-4 w-4 text-[#FF57B2]" />,
          bg: 'bg-[#262626] border-[#FF57B2]/40 text-white',
          badgeBg: 'bg-[#FF57B2]/20 text-[#FF57B2]',
          badgeLabel: 'Leitura Beta',
        };
      default:
        return {
          icon: <Sparkles className="h-4 w-4 text-[#FF57B2]" />,
          bg: 'bg-[#262626] border-[#FF57B2]/40 text-white',
          badgeBg: 'bg-[#FF57B2]/20 text-[#FF57B2]',
          badgeLabel: 'Notificação',
        };
    }
  };

  const meta = getToastMeta(activeBanner.type);

  return (
    <div className="fixed top-4 inset-x-4 md:left-auto md:right-6 md:w-96 z-50 pointer-events-auto animate-in slide-in-from-top-4 duration-300">
      <div
        onClick={handleClick}
        className={`flex items-start gap-3 rounded-2xl border p-3.5 shadow-xl backdrop-blur-md cursor-pointer transition hover:shadow-2xl ${meta.bg}`}
      >
        <div className="rounded-xl bg-[#1B1B1B] p-2 shadow-2xs border border-zinc-700/80 shrink-0">
          {meta.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <span className={`rounded-md px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wider ${meta.badgeBg}`}>
              {meta.badgeLabel}
            </span>
            <p className="text-xs font-bold text-white truncate">{activeBanner.title}</p>
          </div>
          <p className="text-xs text-zinc-300 line-clamp-2 mt-1 leading-snug">
            {activeBanner.message}
          </p>
        </div>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            dismissBanner();
          }}
          className="rounded-lg p-1 text-zinc-400 hover:bg-white/10 hover:text-white transition shrink-0 cursor-pointer"
          title="Fechar notificação"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export const NotificationDrawer = NotificationCenter;

