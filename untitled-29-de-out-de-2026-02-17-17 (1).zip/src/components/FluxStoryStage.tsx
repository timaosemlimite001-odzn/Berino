import {
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Disc3,
  Film,
  Music,
  Volume2,
  VolumeX,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import {
  CommunityPoll,
  FluxAudioTrack,
  FluxStoryCanvas,
  FluxStoryTextLayer,
  StoryFontStyle,
} from '../types';

interface FluxStoryStageProps {
  mediaItems: { url: string; type: 'image' | 'video' }[];
  activeMediaIndex: number;
  onChangeMediaIndex?: (nextIdx: number) => void;
  storyCanvas?: FluxStoryCanvas;
  audioTrack?: FluxAudioTrack;
  isAudioActive?: boolean;
  isAudioMuted?: boolean;
  onToggleAudioMute?: (forceUnmute?: boolean) => void;
  fallbackText?: string;
  poll?: CommunityPoll;
  currentUserId?: string;
  onVotePoll?: (optionId: string) => void;
  votingPoll?: boolean;
  className?: string;
}

export function getStoryFontClass(style: StoryFontStyle): string {
  switch (style) {
    case 'literary':
      return 'font-literary';
    case 'display':
      return 'font-display font-bold';
    case 'mono':
      return 'font-mono';
    case 'sans':
    default:
      return 'font-sans';
  }
}

export function mapStoryPtToPx(pt: number): number {
  if (!pt || Number.isNaN(pt)) return 16;
  return Math.max(12, Math.min(34, Math.round(pt * 1.05)));
}

export const FluxStoryStage: React.FC<FluxStoryStageProps> = ({
  mediaItems,
  activeMediaIndex,
  onChangeMediaIndex,
  storyCanvas,
  audioTrack,
  isAudioActive = true,
  isAudioMuted = false,
  onToggleAudioMute,
  fallbackText,
  poll,
  currentUserId,
  onVotePoll,
  votingPoll = false,
  className = '',
}) => {
  const [brokenUrls, setBrokenUrls] = useState<Record<string, boolean>>({});
  const [audioBroken, setAudioBroken] = useState(false);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [autoplayBlocked, setAutoplayBlocked] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  const safeIndex =
    mediaItems.length > 0
      ? Math.max(0, Math.min(mediaItems.length - 1, activeMediaIndex))
      : 0;
  const currentMedia = mediaItems[safeIndex];

  const validTextLayers: FluxStoryTextLayer[] = (
    storyCanvas?.texts || []
  ).filter((layer) => typeof layer.text === 'string' && layer.text.trim().length > 0);

  const hasValidAudio = Boolean(audioTrack?.url && !audioBroken);
  const startSec = Math.max(0, audioTrack?.startSec || 0);
  const endSec =
    audioTrack?.endSec && audioTrack.endSec > startSec
      ? audioTrack.endSec
      : undefined;
  const targetVolume = Math.max(
    0.05,
    Math.min(1, typeof audioTrack?.volume === 'number' ? audioTrack.volume : 0.85)
  );

  // Reset broken/blocked flags when audio URL changes
  useEffect(() => {
    setAudioBroken(false);
    setAutoplayBlocked(false);
    setIsAudioPlaying(false);
  }, [audioTrack?.url]);

  // Synchronize volume, mute, active state & snippet playback loop
  useEffect(() => {
    const el = audioRef.current;
    if (!el || !hasValidAudio) return;

    el.volume = targetVolume;

    if (!isAudioActive) {
      el.pause();
      setIsAudioPlaying(false);
      return;
    }

    el.muted = Boolean(isAudioMuted);

    if (el.readyState >= 1 && (el.currentTime < startSec || (endSec && el.currentTime >= endSec))) {
      try {
        el.currentTime = startSec;
      } catch {
        // ignore seek before ready
      }
    }

    const playPromise = el.play();
    if (playPromise && typeof playPromise.then === 'function') {
      playPromise
        .then(() => {
          setAutoplayBlocked(false);
          setIsAudioPlaying(true);
        })
        .catch(() => {
          // Browser blocked unmuted autoplay prior to first user gesture:
          // start muted so loop runs in sync and allow one-tap unmute
          if (!isAudioMuted) {
            setAutoplayBlocked(true);
            el.muted = true;
            el.play()
              .then(() => setIsAudioPlaying(true))
              .catch(() => setIsAudioPlaying(false));
          } else {
            setIsAudioPlaying(false);
          }
        });
    }
  }, [
    hasValidAudio,
    audioTrack?.url,
    isAudioActive,
    isAudioMuted,
    startSec,
    endSec,
    targetVolume,
  ]);

  // Cleanup audio on unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const handleAudioLoadedMetadata = () => {
    const el = audioRef.current;
    if (!el) return;
    el.volume = targetVolume;
    if (startSec > 0 && startSec < (el.duration || Infinity)) {
      try {
        el.currentTime = startSec;
      } catch {
        // ignore
      }
    }
  };

  const handleAudioTimeUpdate = () => {
    const el = audioRef.current;
    if (!el) return;
    const effectiveEnd =
      endSec && (!el.duration || endSec <= el.duration)
        ? endSec
        : el.duration;
    if (effectiveEnd && effectiveEnd > startSec && el.currentTime >= effectiveEnd - 0.08) {
      el.currentTime = startSec;
      if (isAudioActive && el.paused) {
        el.play().catch(() => {});
      }
    }
  };

  const handleAudioEnded = () => {
    const el = audioRef.current;
    if (!el || !isAudioActive) return;
    try {
      el.currentTime = startSec;
      el.play().catch(() => {});
    } catch {
      // ignore
    }
  };

  const handleAudioButtonTap = (e: React.MouseEvent) => {
    e.stopPropagation();
    const el = audioRef.current;

    if (autoplayBlocked) {
      setAutoplayBlocked(false);
      onToggleAudioMute?.(true);
      if (el) {
        el.muted = false;
        el.volume = targetVolume;
        el.play()
          .then(() => setIsAudioPlaying(true))
          .catch(() => {});
      }
      return;
    }

    const nextMuted = !isAudioMuted;
    onToggleAudioMute?.();
    if (el) {
      el.muted = nextMuted;
      el.volume = targetVolume;
      if (!nextMuted && isAudioActive) {
        el.play()
          .then(() => setIsAudioPlaying(true))
          .catch(() => {});
      }
    }
  };

  const effectivelyMuted = Boolean(isAudioMuted || autoplayBlocked);
  const soundWaveAnimating = Boolean(
    hasValidAudio && isAudioActive && isAudioPlaying && !effectivelyMuted
  );

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (mediaItems.length <= 1 || e.touches.length !== 1) return;
    touchStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY,
    };
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (
      mediaItems.length <= 1 ||
      !touchStartRef.current ||
      e.changedTouches.length === 0 ||
      !onChangeMediaIndex
    ) {
      return;
    }

    const dx = touchStartRef.current.x - e.changedTouches[0].clientX;
    const dy = touchStartRef.current.y - e.changedTouches[0].clientY;
    touchStartRef.current = null;

    if (Math.abs(dx) > 34 && Math.abs(dx) > Math.abs(dy)) {
      e.stopPropagation();
      if (dx > 0 && safeIndex < mediaItems.length - 1) {
        onChangeMediaIndex(safeIndex + 1);
      } else if (dx < 0 && safeIndex > 0) {
        onChangeMediaIndex(safeIndex - 1);
      }
    }
  };

  const buildTextDecoration = (layer: FluxStoryTextLayer): string => {
    const parts: string[] = [];
    if (layer.underline) parts.push('underline');
    if (layer.strikethrough) parts.push('line-through');
    return parts.length > 0 ? parts.join(' ') : 'none';
  };

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      style={{
        backgroundColor: storyCanvas?.backgroundColor || '#262626',
      }}
      className={`relative w-full h-full overflow-hidden flex items-center justify-center select-none ${className}`}
    >
      {/* Hidden Managed Audio Element */}
      {hasValidAudio && audioTrack?.url && (
        <audio
          ref={audioRef}
          src={audioTrack.url}
          preload="auto"
          playsInline
          onLoadedMetadata={handleAudioLoadedMetadata}
          onTimeUpdate={handleAudioTimeUpdate}
          onEnded={handleAudioEnded}
          onPlay={() => setIsAudioPlaying(true)}
          onPause={() => setIsAudioPlaying(false)}
          onError={() => setAudioBroken(true)}
          className="hidden"
        />
      )}

      {/* 1. Media Background Layer (Image or Video) */}
      {currentMedia && !brokenUrls[currentMedia.url] ? (
        currentMedia.type === 'video' ? (
          <video
            key={currentMedia.url}
            src={currentMedia.url}
            controls
            playsInline
            muted={hasValidAudio}
            preload="metadata"
            onError={() =>
              setBrokenUrls((prev) => ({ ...prev, [currentMedia.url]: true }))
            }
            className="h-full w-full object-cover"
          />
        ) : (
          <img
            key={currentMedia.url}
            src={currentMedia.url}
            alt="Publicação Flux"
            referrerPolicy="no-referrer"
            draggable={false}
            onError={() =>
              setBrokenUrls((prev) => ({ ...prev, [currentMedia.url]: true }))
            }
            className="h-full w-full object-cover pointer-events-none select-none"
          />
        )
      ) : currentMedia && brokenUrls[currentMedia.url] ? (
        <div className="flex flex-col items-center justify-center gap-2 text-zinc-400 p-6 text-center">
          <Film className="h-8 w-8 text-[#FF66C4]" />
          <span className="text-xs font-medium">Mídia indisponível</span>
        </div>
      ) : null}

      {/* Measured contrast scrim when Story text sits over photography/video */}
      {currentMedia && validTextLayers.length > 0 && (
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/35 via-black/20 to-black/45" />
      )}

      {/* 2. Overlaid Story Text Layers */}
      {validTextLayers.length > 0 && (
        <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden">
          {validTextLayers.map((layer) => {
            const safeX = Math.max(8, Math.min(92, layer.x ?? 50));
            const safeY = Math.max(8, Math.min(92, layer.y ?? 50));
            const pxSize = mapStoryPtToPx(layer.fontSizePt);

            return (
              <div
                key={layer.id}
                style={{
                  left: `${safeX}%`,
                  top: `${safeY}%`,
                  transform: 'translate(-50%, -50%)',
                  maxWidth: '86%',
                }}
                className="absolute w-max"
              >
                <p
                  style={{
                    color: layer.color || '#FFFFFF',
                    fontSize: `${pxSize}px`,
                    textAlign: layer.align || 'center',
                    textDecoration: buildTextDecoration(layer),
                    fontStyle: layer.italic ? 'italic' : 'normal',
                    textTransform: layer.uppercase ? 'uppercase' : 'none',
                    textShadow: layer.hasBackdrop
                      ? 'none'
                      : '0 2px 10px rgba(0,0,0,0.65)',
                  }}
                  className={`${getStoryFontClass(
                    layer.fontStyle
                  )} leading-relaxed whitespace-pre-wrap break-words ${
                    layer.hasBackdrop
                      ? 'rounded-2xl bg-black/70 backdrop-blur-xs px-3.5 py-2 shadow-lg'
                      : 'px-2 py-1'
                  }`}
                >
                  {layer.text}
                </p>
              </div>
            );
          })}
        </div>
      )}

      {/* 3. Poll Stage (if a community poll post is rendered in Flux) */}
      {!currentMedia && validTextLayers.length === 0 && poll && (
        <div className="relative z-10 w-full max-w-sm px-5 py-4 space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <BarChart3 className="h-4 w-4 text-[#FF66C4] shrink-0" />
            <span>{poll.question}</span>
          </div>
          <div className="space-y-2">
            {poll.options.map((opt) => {
              const total = poll.totalVotes || 0;
              const pct =
                total > 0 ? Math.round(((opt.votesCount || 0) / total) * 100) : 0;
              const votedThis = Boolean(
                currentUserId && opt.voterIds?.includes(currentUserId)
              );
              const userVotedAny = Boolean(
                currentUserId &&
                  (poll.voterIds?.includes(currentUserId) ||
                    poll.options.some((o) =>
                      o.voterIds?.includes(currentUserId)
                    ))
              );

              return (
                <button
                  key={opt.id}
                  type="button"
                  disabled={userVotedAny || votingPoll || !onVotePoll}
                  onClick={(e) => {
                    e.stopPropagation();
                    onVotePoll?.(opt.id);
                  }}
                  className={`relative w-full overflow-hidden rounded-xl border p-2.5 text-left text-xs transition ${
                    onVotePoll && !userVotedAny ? 'cursor-pointer' : 'cursor-default'
                  } ${
                    votedThis
                      ? 'border-[#FF66C4] bg-[#FF66C4]/20 font-bold text-white'
                      : 'border-zinc-700/80 bg-[#1E1E1E] text-zinc-200 hover:border-[#FF66C4]/50'
                  }`}
                >
                  {userVotedAny && (
                    <div
                      className="absolute inset-y-0 left-0 bg-[#FF66C4]/25 transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  )}
                  <div className="relative z-10 flex items-center justify-between gap-2">
                    <span className="truncate">{opt.text}</span>
                    {userVotedAny && (
                      <span className="font-bold text-[#FF66C4] tabular-nums">
                        {pct}%
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
          <p className="text-[11px] text-zinc-400 text-center tabular-nums">
            Total de {poll.totalVotes || 0} votos
          </p>
        </div>
      )}

      {/* 4. Legacy / Pure Text Fallback when post has neither media nor storyCanvas */}
      {!currentMedia &&
        validTextLayers.length === 0 &&
        !poll &&
        fallbackText && (
          <div className="relative z-10 w-full h-full flex items-center justify-center px-6 py-6 overflow-hidden">
            <p className="text-sm sm:text-base text-zinc-100 font-sans text-center leading-relaxed whitespace-pre-wrap line-clamp-[11] break-words">
              {fallbackText}
            </p>
          </div>
        )}

      {/* 4B. Audio-Focused Centerpiece when post has audioTrack and no visual media/text */}
      {!currentMedia &&
        validTextLayers.length === 0 &&
        !poll &&
        !fallbackText &&
        hasValidAudio && (
          <button
            type="button"
            onClick={handleAudioButtonTap}
            onTouchStart={(e) => e.stopPropagation()}
            onTouchEnd={(e) => e.stopPropagation()}
            className="relative z-10 flex flex-col items-center justify-center gap-3.5 px-6 py-6 text-center cursor-pointer group"
          >
            <div className="h-24 w-24 rounded-full bg-[#1C1C1C] border border-[#FF66C4]/40 flex items-center justify-center shadow-xl group-hover:border-[#FF66C4] transition">
              <Disc3
                className={`h-12 w-12 text-[#FF66C4] ${
                  soundWaveAnimating ? 'animate-spin' : ''
                }`}
                style={{ animationDuration: '5s' }}
              />
            </div>
            <div className="space-y-1 max-w-[240px]">
              <p className="text-sm font-bold text-white truncate">
                {audioTrack?.title || 'Áudio original'}
              </p>
              <p className="text-xs text-zinc-400">
                {effectivelyMuted ? 'Toque para ativar o áudio' : 'Reproduzindo no Flux'}
              </p>
            </div>
          </button>
        )}

      {/* 5. Desktop / Tap Left-Right Carousel Arrows when multiple media items exist */}
      {mediaItems.length > 1 && onChangeMediaIndex && (
        <>
          {safeIndex > 0 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onChangeMediaIndex(safeIndex - 1);
              }}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 z-20 h-8 w-8 rounded-full bg-black/55 hover:bg-black/80 text-white flex items-center justify-center transition cursor-pointer"
              aria-label="Mídia anterior"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
          )}
          {safeIndex < mediaItems.length - 1 && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onChangeMediaIndex(safeIndex + 1);
              }}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 z-20 h-8 w-8 rounded-full bg-black/55 hover:bg-black/80 text-white flex items-center justify-center transition cursor-pointer"
              aria-label="Próxima mídia"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          )}
        </>
      )}

      {/* 6. Reels Audio Track & Mute/Unmute Bar */}
      {hasValidAudio && (
        <div
          onTouchStart={(e) => e.stopPropagation()}
          onTouchEnd={(e) => e.stopPropagation()}
          className="absolute bottom-3 inset-x-3 z-20 flex items-center justify-between gap-2 pointer-events-none"
        >
          <button
            type="button"
            onClick={handleAudioButtonTap}
            className="pointer-events-auto max-w-[78%] min-h-[34px] rounded-xl bg-black/70 hover:bg-black/85 backdrop-blur-xs border border-white/15 px-3 py-1.5 flex items-center gap-2 text-left transition cursor-pointer"
            title={effectivelyMuted ? 'Ativar áudio' : 'Silenciar áudio'}
          >
            <Music className="h-3.5 w-3.5 text-[#FF66C4] shrink-0" />
            <span className="text-xs font-semibold text-white truncate">
              {audioTrack?.title || 'Áudio original'}
            </span>
            {autoplayBlocked && (
              <span className="text-[11px] font-bold text-[#FF66C4] shrink-0">
                · Ouvir
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={handleAudioButtonTap}
            className="pointer-events-auto h-9 w-9 rounded-full bg-black/70 hover:bg-black/85 backdrop-blur-xs border border-white/15 text-white flex items-center justify-center transition active:scale-95 cursor-pointer shrink-0"
            title={effectivelyMuted ? 'Ativar som' : 'Silenciar som'}
            aria-label={effectivelyMuted ? 'Ativar som' : 'Silenciar som'}
          >
            {effectivelyMuted ? (
              <VolumeX className="h-4 w-4 text-zinc-300" />
            ) : (
              <Volume2 className="h-4 w-4 text-[#FF66C4]" />
            )}
          </button>
        </div>
      )}
    </div>
  );
};

