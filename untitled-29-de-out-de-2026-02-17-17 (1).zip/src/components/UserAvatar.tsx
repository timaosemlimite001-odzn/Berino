import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getUserCachedData, getUserCachedPhoto, subscribeUserData, subscribeUserPhoto } from '../services/userService';

export interface UserAvatarProps {
  userId?: string;
  userName?: string;
  photoURL?: string;
  sizeClass?: string;
  className?: string;
  onClick?: (e: React.MouseEvent) => void;
  title?: string;
  fallbackInitial?: string;
  hasProBorder?: boolean;
}

export const UserAvatar: React.FC<UserAvatarProps> = ({
  userId,
  userName = 'Leitor',
  photoURL,
  sizeClass = 'h-8 w-8',
  className = '',
  onClick,
  title,
  fallbackInitial,
  hasProBorder: propHasProBorder,
}) => {
  const { currentUser, userProfile } = useAuth();
  const isSelf = Boolean(currentUser && userId && currentUser.uid === userId);

  // If viewing self, always prefer the authenticated profile photoURL in real-time
  const getInitialPhoto = () => {
    if (isSelf) {
      return userProfile?.photoURL || currentUser?.photoURL || photoURL || '';
    }
    if (photoURL && photoURL.trim().length > 0) {
      return photoURL;
    }
    if (userId) {
      return getUserCachedPhoto(userId) || '';
    }
    return '';
  };

  const [resolvedPhoto, setResolvedPhoto] = useState<string>(getInitialPhoto);
  const [imgError, setImgError] = useState(false);
  const [isProUser, setIsProUser] = useState<boolean>(() => {
    if (propHasProBorder !== undefined) return propHasProBorder;
    if (isSelf && userProfile) {
      return Boolean(userProfile.showProBorder ?? userProfile.hasKardelProBadge);
    }
    if (userId) {
      const cached = getUserCachedData(userId);
      return Boolean(cached?.showProBorder ?? cached?.hasKardelProBadge);
    }
    return false;
  });

  useEffect(() => {
    setImgError(false);

    if (isSelf) {
      const selfPhoto = userProfile?.photoURL || currentUser?.photoURL || photoURL || '';
      setResolvedPhoto(selfPhoto);
      if (propHasProBorder === undefined) {
        setIsProUser(Boolean(userProfile?.showProBorder ?? userProfile?.hasKardelProBadge));
      }
      return;
    }

    if (userId) {
      // Subscribe to cache/Firestore so updated profile photos and Pro border are reflected everywhere in real time
      const unsubscribe = subscribeUserPhoto(userId, (fetchedPhoto) => {
        if (fetchedPhoto && fetchedPhoto.trim().length > 0) {
          setResolvedPhoto(fetchedPhoto);
          setImgError(false);
        } else if (photoURL && photoURL.trim().length > 0) {
          setResolvedPhoto(photoURL);
        }
      });

      const cached = getUserCachedData(userId);
      if (cached && propHasProBorder === undefined) {
        setIsProUser(Boolean(cached.showProBorder ?? cached.hasKardelProBadge));
      }

      return unsubscribe;
    }

    if (photoURL && photoURL.trim().length > 0) {
      setResolvedPhoto(photoURL);
    }
  }, [isSelf, userProfile?.photoURL, userProfile?.showProBorder, userProfile?.hasKardelProBadge, currentUser?.photoURL, photoURL, userId, propHasProBorder]);

  const showEnergyBorder = propHasProBorder !== undefined ? propHasProBorder : isProUser;

  const initial =
    fallbackInitial ||
    (userName ? userName.trim().charAt(0).toUpperCase() : 'U') ||
    'U';

  const baseAvatar =
    resolvedPhoto && !imgError ? (
      <img
        src={resolvedPhoto}
        alt={userName}
        onError={() => setImgError(true)}
        className={`${sizeClass} rounded-full object-cover shrink-0 select-none ${
          showEnergyBorder
            ? 'ring-2 ring-[#FF57B2] shadow-[0_0_12px_rgba(255,87,178,0.7)]'
            : 'border border-zinc-700/80 shadow-2xs'
        } ${className}`}
      />
    ) : (
      <div
        className={`${sizeClass} flex shrink-0 items-center justify-center rounded-full bg-zinc-900 text-white font-bold text-xs uppercase shadow-2xs select-none ${
          showEnergyBorder
            ? 'ring-2 ring-[#FF57B2] shadow-[0_0_12px_rgba(255,87,178,0.7)]'
            : 'border border-zinc-700/80'
        } ${className}`}
      >
        {initial}
      </div>
    );

  const wrappedAvatar = showEnergyBorder ? (
    <div className="relative inline-flex items-center justify-center shrink-0 group/pro-avatar">
      {/* Emanating radiating energy glow / pulse */}
      <span className="absolute -inset-1 rounded-full bg-gradient-to-r from-[#FF57B2] via-[#FF007A] to-[#FF80C5] opacity-80 blur-[2px] animate-pulse pointer-events-none" />
      <span className="absolute -inset-0.5 rounded-full border border-[#FF57B2]/70 animate-ping opacity-35 pointer-events-none" />
      <div className="relative z-10 flex items-center justify-center">
        {baseAvatar}
      </div>
    </div>
  ) : (
    baseAvatar
  );

  if (onClick) {
    return (
      <div
        onClick={onClick}
        className="cursor-pointer hover:opacity-90 transition shrink-0 inline-flex items-center"
        title={title || (showEnergyBorder ? `${userName} (KARDEL Pró)` : `Ver perfil de ${userName}`)}
      >
        {wrappedAvatar}
      </div>
    );
  }

  return wrappedAvatar;
};
