import {
  Check,
  Maximize2,
  Minimize2,
  Move,
  RotateCcw,
  SlidersHorizontal,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { PostImageFormat } from '../types';

export interface AdjustableImageEntry {
  id: string;
  originalFile: File;
  originalUrl: string;
  naturalWidth: number;
  naturalHeight: number;
  zoom: number;
  panX: number; // fraction of frame width
  panY: number; // fraction of frame height
}

export interface AdjustedImageOutput {
  id: string;
  originalFile: File;
  originalUrl: string;
  adjustedFile: File;
  adjustedPreviewUrl: string;
  zoom: number;
  panX: number;
  panY: number;
}

interface ImagePostAdjusterModalProps {
  isOpen: boolean;
  initialFormat: PostImageFormat;
  images: {
    id: string;
    originalFile: File;
    originalUrl: string;
    zoom?: number;
    panX?: number;
    panY?: number;
  }[];
  initialActiveId?: string;
  onClose: () => void;
  onConfirm: (result: {
    format: PostImageFormat;
    adjustedImages: AdjustedImageOutput[];
  }) => void;
}

const FORMAT_CONFIG: Record<
  PostImageFormat,
  {
    label: string;
    ratioLabel: string;
    aspectRatio: number; // width / height
    outWidth: number;
    outHeight: number;
  }
> = {
  default: {
    label: 'Padrão',
    ratioLabel: 'Atual',
    aspectRatio: 16 / 10,
    outWidth: 1280,
    outHeight: 800,
  },
  instagram: {
    label: 'Instagram',
    ratioLabel: '4:5',
    aspectRatio: 4 / 5,
    outWidth: 1080,
    outHeight: 1350,
  },
  story: {
    label: 'Story Flux',
    ratioLabel: 'Vertical',
    aspectRatio: 3 / 4,
    outWidth: 1080,
    outHeight: 1440,
  },
};

function computeRelativeDims(
  imgRatio: number,
  frameRatio: number,
  zoom: number
): { wRel: number; hRel: number; minFitZoom: number } {
  const safeImgRatio = imgRatio > 0 ? imgRatio : 1;
  const minFitZoom = Math.min(
    frameRatio / safeImgRatio,
    safeImgRatio / frameRatio
  );
  const wRel = zoom * Math.max(1, safeImgRatio / frameRatio);
  const hRel = zoom * Math.max(1, frameRatio / safeImgRatio);
  return { wRel, hRel, minFitZoom: Math.max(0.35, Math.min(1, minFitZoom)) };
}

function clampPan(
  panX: number,
  panY: number,
  wRel: number,
  hRel: number
): { panX: number; panY: number } {
  const maxPanX = Math.max(0, (wRel - 1) / 2);
  const maxPanY = Math.max(0, (hRel - 1) / 2);
  return {
    panX: Math.max(-maxPanX, Math.min(maxPanX, panX)),
    panY: Math.max(-maxPanY, Math.min(maxPanY, panY)),
  };
}

async function loadHtmlImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

async function renderAdjustedCanvasFile(
  entry: AdjustableImageEntry,
  format: PostImageFormat
): Promise<{ file: File; previewUrl: string }> {
  const cfg = FORMAT_CONFIG[format];
  const img = await loadHtmlImage(entry.originalUrl);
  const imgRatio =
    (img.naturalWidth || entry.naturalWidth || 1) /
    (img.naturalHeight || entry.naturalHeight || 1);

  const { wRel, hRel } = computeRelativeDims(
    imgRatio,
    cfg.aspectRatio,
    entry.zoom
  );
  const clamped = clampPan(entry.panX, entry.panY, wRel, hRel);

  const canvas = document.createElement('canvas');
  canvas.width = cfg.outWidth;
  canvas.height = cfg.outHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return {
      file: entry.originalFile,
      previewUrl: entry.originalUrl,
    };
  }

  ctx.fillStyle = '#1E1E1E';
  ctx.fillRect(0, 0, cfg.outWidth, cfg.outHeight);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  const drawW = wRel * cfg.outWidth;
  const drawH = hRel * cfg.outHeight;
  const drawX = (cfg.outWidth - drawW) / 2 + clamped.panX * cfg.outWidth;
  const drawY = (cfg.outHeight - drawH) / 2 + clamped.panY * cfg.outHeight;

  ctx.drawImage(img, drawX, drawY, drawW, drawH);

  const blob: Blob = await new Promise((resolve) => {
    canvas.toBlob(
      (b) => {
        resolve(b || entry.originalFile);
      },
      'image/jpeg',
      0.92
    );
  });

  const baseName = entry.originalFile.name.replace(/\.[^.]+$/, '') || 'imagem';
  const adjustedFile = new File([blob], `${baseName}_${format}.jpg`, {
    type: 'image/jpeg',
  });
  const previewUrl = URL.createObjectURL(adjustedFile);
  return { file: adjustedFile, previewUrl };
}

export const ImagePostAdjusterModal: React.FC<ImagePostAdjusterModalProps> = ({
  isOpen,
  initialFormat,
  images,
  initialActiveId,
  onClose,
  onConfirm,
}) => {
  const [format, setFormat] = useState<PostImageFormat>(initialFormat);
  const [entries, setEntries] = useState<AdjustableImageEntry[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [applying, setApplying] = useState(false);

  const viewportRef = useRef<HTMLDivElement>(null);
  const dragStartRef = useRef<{
    clientX: number;
    clientY: number;
    startPanX: number;
    startPanY: number;
  } | null>(null);

  useEffect(() => {
    if (!isOpen || images.length === 0) return;
    setFormat(initialFormat);

    let cancelled = false;
    const initEntries = async () => {
      const loaded: AdjustableImageEntry[] = await Promise.all(
        images.map(async (item) => {
          try {
            const img = await loadHtmlImage(item.originalUrl);
            return {
              id: item.id,
              originalFile: item.originalFile,
              originalUrl: item.originalUrl,
              naturalWidth: img.naturalWidth || 1000,
              naturalHeight: img.naturalHeight || 1000,
              zoom: item.zoom ?? 1,
              panX: item.panX ?? 0,
              panY: item.panY ?? 0,
            };
          } catch {
            return {
              id: item.id,
              originalFile: item.originalFile,
              originalUrl: item.originalUrl,
              naturalWidth: 1000,
              naturalHeight: 1000,
              zoom: item.zoom ?? 1,
              panX: item.panX ?? 0,
              panY: item.panY ?? 0,
            };
          }
        })
      );

      if (!cancelled) {
        setEntries(loaded);
        if (initialActiveId) {
          const foundIdx = loaded.findIndex((e) => e.id === initialActiveId);
          setActiveIndex(foundIdx >= 0 ? foundIdx : 0);
        } else {
          setActiveIndex(0);
        }
      }
    };

    initEntries();
    return () => {
      cancelled = true;
    };
  }, [isOpen, images, initialFormat, initialActiveId]);

  const activeEntry = entries[activeIndex];
  const cfg = FORMAT_CONFIG[format];

  const activeMetrics = useMemo(() => {
    if (!activeEntry) {
      return { wRel: 1, hRel: 1, minFitZoom: 0.5, panX: 0, panY: 0 };
    }
    const imgRatio = activeEntry.naturalWidth / activeEntry.naturalHeight;
    const { wRel, hRel, minFitZoom } = computeRelativeDims(
      imgRatio,
      cfg.aspectRatio,
      activeEntry.zoom
    );
    const clamped = clampPan(activeEntry.panX, activeEntry.panY, wRel, hRel);
    return { wRel, hRel, minFitZoom, panX: clamped.panX, panY: clamped.panY };
  }, [activeEntry, cfg.aspectRatio]);

  const updateActiveEntry = useCallback(
    (updater: (prev: AdjustableImageEntry) => AdjustableImageEntry) => {
      setEntries((prev) =>
        prev.map((item, idx) => {
          if (idx !== activeIndex) return item;
          const updated = updater(item);
          const imgRatio = updated.naturalWidth / updated.naturalHeight;
          const { wRel, hRel, minFitZoom } = computeRelativeDims(
            imgRatio,
            FORMAT_CONFIG[format].aspectRatio,
            updated.zoom
          );
          const safeZoom = Math.max(minFitZoom, Math.min(3, updated.zoom));
          const { wRel: w2, hRel: h2 } = computeRelativeDims(
            imgRatio,
            FORMAT_CONFIG[format].aspectRatio,
            safeZoom
          );
          const clamped = clampPan(updated.panX, updated.panY, w2, h2);
          return {
            ...updated,
            zoom: safeZoom,
            panX: clamped.panX,
            panY: clamped.panY,
          };
        })
      );
    },
    [activeIndex, format]
  );

  // Re-clamp all entries whenever format toggles between 'default' and 'instagram'
  const handleSelectFormat = (nextFormat: PostImageFormat) => {
    setFormat(nextFormat);
    setEntries((prev) =>
      prev.map((item) => {
        const imgRatio = item.naturalWidth / item.naturalHeight;
        const { minFitZoom } = computeRelativeDims(
          imgRatio,
          FORMAT_CONFIG[nextFormat].aspectRatio,
          1
        );
        const nextZoom = Math.max(minFitZoom, Math.min(3, item.zoom));
        const { wRel, hRel } = computeRelativeDims(
          imgRatio,
          FORMAT_CONFIG[nextFormat].aspectRatio,
          nextZoom
        );
        const clamped = clampPan(item.panX, item.panY, wRel, hRel);
        return {
          ...item,
          zoom: nextZoom,
          panX: clamped.panX,
          panY: clamped.panY,
        };
      })
    );
  };

  // Pointer drag handlers (mouse & touch unified)
  const startDrag = (clientX: number, clientY: number) => {
    if (!activeEntry) return;
    setIsDragging(true);
    dragStartRef.current = {
      clientX,
      clientY,
      startPanX: activeMetrics.panX,
      startPanY: activeMetrics.panY,
    };
  };

  useEffect(() => {
    if (!isDragging) return;

    const handleMove = (clientX: number, clientY: number) => {
      const start = dragStartRef.current;
      const box = viewportRef.current;
      if (!start || !box) return;
      const rect = box.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return;

      const deltaX = (clientX - start.clientX) / rect.width;
      const deltaY = (clientY - start.clientY) / rect.height;

      updateActiveEntry((prev) => ({
        ...prev,
        panX: start.startPanX + deltaX,
        panY: start.startPanY + deltaY,
      }));
    };

    const onMouseMove = (e: MouseEvent) => {
      e.preventDefault();
      handleMove(e.clientX, e.clientY);
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length !== 1) return;
      if (e.cancelable) e.preventDefault();
      handleMove(e.touches[0].clientX, e.touches[0].clientY);
    };

    const onEnd = () => {
      setIsDragging(false);
      dragStartRef.current = null;
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onEnd);
    window.addEventListener('touchmove', onTouchMove, { passive: false });
    window.addEventListener('touchend', onEnd);
    window.addEventListener('touchcancel', onEnd);

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onEnd);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onEnd);
      window.removeEventListener('touchcancel', onEnd);
    };
  }, [isDragging, updateActiveEntry]);

  const handleWheelZoom = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    const step = -e.deltaY * 0.0018;
    updateActiveEntry((prev) => ({
      ...prev,
      zoom: prev.zoom + step,
    }));
  };

  const handleConfirmAdjustments = async () => {
    if (applying || entries.length === 0) return;
    setApplying(true);
    try {
      const adjustedImages: AdjustedImageOutput[] = await Promise.all(
        entries.map(async (entry) => {
          const rendered = await renderAdjustedCanvasFile(entry, format);
          return {
            id: entry.id,
            originalFile: entry.originalFile,
            originalUrl: entry.originalUrl,
            adjustedFile: rendered.file,
            adjustedPreviewUrl: rendered.previewUrl,
            zoom: entry.zoom,
            panX: entry.panX,
            panY: entry.panY,
          };
        })
      );

      onConfirm({ format, adjustedImages });
    } finally {
      setApplying(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/85 backdrop-blur-sm p-3 sm:p-4">
      <div className="w-full max-w-lg rounded-[26px] bg-[#202020] border border-zinc-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-5 py-3.5 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="h-4 w-4 text-[#FF66C4]" />
            <h3 className="text-sm sm:text-base font-extrabold text-white">
              Ajustar imagem da publicação
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="h-8 w-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
            aria-label="Fechar ajuste"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Format Selector: Padrão (16:10), Instagram (4:5), Story (3:4) */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <span className="text-xs font-semibold text-zinc-400">
              Formato da imagem:
            </span>
            <div className="inline-flex rounded-xl bg-[#161616] p-1 border border-zinc-800">
              <button
                type="button"
                onClick={() => handleSelectFormat('default')}
                className={`px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                  format === 'default'
                    ? 'bg-[#FF66C4] text-[#1D1D1D] shadow-xs'
                    : 'text-zinc-300 hover:text-white'
                }`}
              >
                <span>Padrão</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectFormat('instagram')}
                className={`px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                  format === 'instagram'
                    ? 'bg-[#FF66C4] text-[#1D1D1D] shadow-xs'
                    : 'text-zinc-300 hover:text-white'
                }`}
              >
                <span>Instagram</span>
                <span className="opacity-75 text-[10px]">(4:5)</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectFormat('story')}
                className={`px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                  format === 'story'
                    ? 'bg-[#FF66C4] text-[#1D1D1D] shadow-xs'
                    : 'text-zinc-300 hover:text-white'
                }`}
              >
                <span>Story</span>
                <span className="opacity-75 text-[10px]">(Flux)</span>
              </button>
            </div>
          </div>

          {/* Interactive Crop / Pan / Zoom Frame */}
          <div className="flex flex-col items-center justify-center bg-[#151515] rounded-2xl p-3 border border-zinc-800/80">
            {activeEntry && (
              <div
                ref={viewportRef}
                onMouseDown={(e) => {
                  e.preventDefault();
                  startDrag(e.clientX, e.clientY);
                }}
                onTouchStart={(e) => {
                  if (e.touches.length === 1) {
                    startDrag(e.touches[0].clientX, e.touches[0].clientY);
                  }
                }}
                onWheel={handleWheelZoom}
                style={{
                  aspectRatio:
                    format === 'story'
                      ? '3 / 4'
                      : format === 'instagram'
                      ? '4 / 5'
                      : '16 / 10',
                }}
                className={`relative overflow-hidden rounded-[16px] bg-[#1E1E1E] border border-zinc-700/80 select-none touch-none ${
                  format === 'instagram' || format === 'story'
                    ? 'w-full max-w-[260px] sm:max-w-[290px]'
                    : 'w-full max-w-[400px]'
                } ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
              >
                <img
                  src={activeEntry.originalUrl}
                  alt="Prévia de ajuste"
                  draggable={false}
                  style={{
                    width: `${activeMetrics.wRel * 100}%`,
                    height: `${activeMetrics.hRel * 100}%`,
                    maxWidth: 'none',
                    position: 'absolute',
                    left: `${
                      50 - activeMetrics.wRel * 50 + activeMetrics.panX * 100
                    }%`,
                    top: `${
                      50 - activeMetrics.hRel * 50 + activeMetrics.panY * 100
                    }%`,
                  }}
                  className="pointer-events-none select-none"
                />

                {/* Subtle Rule-of-Thirds Grid while adjusting */}
                <div
                  className={`pointer-events-none absolute inset-0 transition-opacity duration-200 ${
                    isDragging ? 'opacity-70' : 'opacity-20'
                  }`}
                >
                  <div className="absolute inset-y-0 left-1/3 w-px bg-white/40" />
                  <div className="absolute inset-y-0 left-2/3 w-px bg-white/40" />
                  <div className="absolute inset-x-0 top-1/3 h-px bg-white/40" />
                  <div className="absolute inset-x-0 top-2/3 h-px bg-white/40" />
                </div>

                {/* Drag Hint */}
                <div className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-black/65 px-2.5 py-1 text-[10px] font-semibold text-zinc-200 flex items-center gap-1 whitespace-nowrap">
                  <Move className="h-3 w-3 text-[#FF66C4]" />
                  <span>Arraste para posicionar</span>
                </div>
              </div>
            )}
          </div>

          {/* Zoom Slider & Quick Fit Controls */}
          {activeEntry && (
            <div className="space-y-2.5">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() =>
                    updateActiveEntry((prev) => ({
                      ...prev,
                      zoom: prev.zoom - 0.15,
                    }))
                  }
                  className="h-8 w-8 rounded-lg bg-[#2A2A2A] text-zinc-300 hover:text-white flex items-center justify-center cursor-pointer shrink-0"
                  aria-label="Diminuir zoom"
                >
                  <ZoomOut className="h-4 w-4" />
                </button>

                <input
                  type="range"
                  min={activeMetrics.minFitZoom}
                  max={3}
                  step={0.02}
                  value={activeEntry.zoom}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    updateActiveEntry((prev) => ({
                      ...prev,
                      zoom: val,
                    }));
                  }}
                  className="flex-1 accent-[#FF66C4] cursor-pointer"
                />

                <button
                  type="button"
                  onClick={() =>
                    updateActiveEntry((prev) => ({
                      ...prev,
                      zoom: prev.zoom + 0.15,
                    }))
                  }
                  className="h-8 w-8 rounded-lg bg-[#2A2A2A] text-zinc-300 hover:text-white flex items-center justify-center cursor-pointer shrink-0"
                  aria-label="Aumentar zoom"
                >
                  <ZoomIn className="h-4 w-4" />
                </button>
              </div>

              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() =>
                      updateActiveEntry((prev) => ({
                        ...prev,
                        zoom: 1,
                        panX: 0,
                        panY: 0,
                      }))
                    }
                    className="inline-flex items-center gap-1 rounded-lg bg-[#2A2A2A] hover:bg-zinc-700 px-2.5 py-1.5 text-[11px] font-semibold text-zinc-200 transition cursor-pointer"
                  >
                    <Maximize2 className="h-3 w-3 text-[#FF66C4]" />
                    <span>Preencher</span>
                  </button>

                  {activeMetrics.minFitZoom < 0.98 && (
                    <button
                      type="button"
                      onClick={() =>
                        updateActiveEntry((prev) => ({
                          ...prev,
                          zoom: activeMetrics.minFitZoom,
                          panX: 0,
                          panY: 0,
                        }))
                      }
                      className="inline-flex items-center gap-1 rounded-lg bg-[#2A2A2A] hover:bg-zinc-700 px-2.5 py-1.5 text-[11px] font-semibold text-zinc-200 transition cursor-pointer"
                    >
                      <Minimize2 className="h-3 w-3 text-[#FF66C4]" />
                      <span>Imagem inteira</span>
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() =>
                    updateActiveEntry((prev) => ({
                      ...prev,
                      zoom: 1,
                      panX: 0,
                      panY: 0,
                    }))
                  }
                  className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold text-zinc-400 hover:text-white transition cursor-pointer"
                >
                  <RotateCcw className="h-3 w-3" />
                  <span>Redefinir</span>
                </button>
              </div>
            </div>
          )}

          {/* Multi-image selector strip if user picked more than 1 image */}
          {entries.length > 1 && (
            <div className="pt-2 border-t border-zinc-800 space-y-1.5">
              <span className="text-[11px] font-semibold text-zinc-400">
                Imagens selecionadas ({activeIndex + 1}/{entries.length}):
              </span>
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {entries.map((entry, idx) => (
                  <button
                    key={entry.id}
                    type="button"
                    onClick={() => setActiveIndex(idx)}
                    className={`relative h-12 w-12 rounded-xl overflow-hidden shrink-0 border-2 transition cursor-pointer ${
                      idx === activeIndex
                        ? 'border-[#FF66C4] scale-105'
                        : 'border-zinc-700 opacity-65 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={entry.originalUrl}
                      alt={`Miniatura ${idx + 1}`}
                      className="h-full w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2.5 px-4 sm:px-5 py-3.5 border-t border-zinc-800 bg-[#1B1B1B]">
          <button
            type="button"
            onClick={onClose}
            disabled={applying}
            className="rounded-xl px-4 py-2 text-xs font-bold text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleConfirmAdjustments}
            disabled={applying}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[#FF66C4] hover:bg-[#FF57B2] px-5 py-2 text-xs font-extrabold text-[#1D1D1D] shadow-md transition disabled:opacity-50 cursor-pointer"
          >
            <Check className="h-4 w-4 stroke-[2.5]" />
            <span>{applying ? 'Aplicando...' : 'Aplicar ajuste'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
