import {
  Award,
  Bell,
  BookMarked,
  BookOpen,
  Compass,
  Crown,
  Feather,
  Home,
  LayoutGrid,
  LogOut,
  Pencil,
  RefreshCw,
  Search,
  ShieldAlert,
  Sparkles,
  Trophy,
  User as UserIcon,
  Users,
  X,
} from 'lucide-react';
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { useBranding, AppLogoIcon } from '../context/BrandingContext';
import { DeveloperBrandModal } from './DeveloperBrandModal';
import { UserAvatar } from './UserAvatar';
import { UserBadges } from './UserBadges';
import { isSubscriptionActive } from '../services/subscriptionService';

interface NavbarProps {
  currentTab?: string;
  activeTab?: string;
  hideTopHeader?: boolean;
  hideFloatingDock?: boolean;
  onNavigate: (tab: string, param?: string) => void;
  onOpenAuth: (tab?: 'login' | 'register') => void;
  onOpenNotifications: () => void;
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  activeTab,
  hideTopHeader = false,
  hideFloatingDock = false,
  onNavigate,
  onOpenAuth,
  onOpenNotifications,
  onOpenSearch,
}) => {
  const rawTab = activeTab || currentTab || 'home';
  const activeCurrentTab = rawTab === 'communities' ? 'social' : rawTab;
  const {
    currentUser,
    userProfile,
    isDeveloper,
    isGoogleAuthPending,
    loginWithGoogle,
    logout,
    switchGoogleAccount,
  } = useAuth();
  const { unreadCount } = useNotifications();
  const { branding } = useBranding();
  const [userDropdown, setUserDropdown] = useState(false);
  const [brandModalOpen, setBrandModalOpen] = useState(false);
  const [isMobileMenuExpanded, setIsMobileMenuExpanded] = useState(false);

  // Links do Menu Flutuante Centralizado (Substitui completamente a gaveta lateral)
  const floatingDockLinks = [
    { id: 'home', label: 'Início', icon: Home },
    { id: 'explore', label: 'Explorar', icon: Compass },
    { id: 'social', label: 'Social', icon: Users },
    { id: 'library', label: 'Biblioteca', icon: BookMarked },
    { id: 'ranking', label: 'Ranking', icon: Trophy },
    { id: 'achievements', label: 'Conquistas', icon: Award },
    { id: 'subscriptions', label: 'Assinaturas', icon: Crown, highlight: true },
    { id: 'studio', label: 'Estúdio', icon: Feather },
    ...(isDeveloper
      ? [{ id: 'developer', label: 'Área Dev', icon: ShieldAlert, highlight: true }]
      : []),
  ];

  const handleNav = (tabId: string) => {
    onNavigate(tabId);
    setUserDropdown(false);
    setIsMobileMenuExpanded(false);
  };

  const isUserSubscribed = userProfile?.subscription?.status === 'active';

  return (
    <>
      {!hideTopHeader && (
      <header className="relative z-40 border-b border-zinc-800 bg-[#202020] text-white">
        {/* Linha sutil rosa no rodapé do cabeçalho */}
        <div className="absolute bottom-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#FF57B2]/40 to-transparent pointer-events-none" />

        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          {/* Left: Logo e Links de Desktop */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => handleNav('home')}
                className="flex items-center gap-2.5 text-left group cursor-pointer"
              >
                <AppLogoIcon />
                <span className="text-xl font-black tracking-wider text-white font-display">
                  {branding.appName}
                </span>
              </button>

              {/* Opção de alterar logo e nome: visível e permitida APENAS para o desenvolvedor */}
              {isDeveloper && (
                <button
                  type="button"
                  onClick={() => setBrandModalOpen(true)}
                  className="rounded-lg p-1.5 text-zinc-400 hover:text-[#FF57B2] hover:bg-[#FF57B2]/20 transition cursor-pointer"
                  title="Alterar Logo e Nome do App (Exclusivo Desenvolvedor)"
                  aria-label="Alterar Logo e Nome"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {/* Desktop primary links */}
            <nav className="hidden lg:flex items-center gap-1 ml-6">
              {floatingDockLinks.slice(0, 5).map((item) => {
                const Icon = item.icon;
                const active = activeCurrentTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNav(item.id)}
                    className={`flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold transition cursor-pointer ${
                      active
                        ? 'bg-[#FF57B2] text-white shadow-xs font-bold'
                        : 'text-zinc-300 hover:bg-zinc-800 hover:text-white'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Right: Search, Notifications, Subscriptions (Icon Only), and Profile (Right Beside Subscriptions) */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Search shortcut */}
            <button
              type="button"
              onClick={onOpenSearch}
              className="flex items-center gap-2 rounded-xl border border-zinc-700 bg-zinc-900/90 px-2.5 py-1.5 sm:px-3 sm:py-2 text-xs text-zinc-300 hover:border-[#FF57B2]/60 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
              title="Buscar livros ou autores"
            >
              <Search className="h-4 w-4 text-[#FF57B2]" />
              <span className="hidden sm:inline">Buscar...</span>
            </button>

            {/* Notifications icon */}
            {currentUser && (
              <button
                type="button"
                onClick={onOpenNotifications}
                className="relative rounded-xl p-2 text-zinc-300 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
                title="Notificações"
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#FF57B2] text-[10px] font-bold text-white shadow-[0_0_8px_#FF57B2]">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>
            )}

            {/* Subscriptions icon only (reduzido, sem texto redundante para desocupar o cabeçalho) */}
            {currentUser && (
              <button
                type="button"
                onClick={() => handleNav('subscriptions')}
                className={`relative flex items-center justify-center rounded-xl p-2 transition cursor-pointer border ${
                  isUserSubscribed
                    ? 'border-[#FF57B2]/70 bg-gradient-to-r from-[#FF57B2]/20 to-[#E03595]/20 text-[#FF57B2] shadow-[0_0_12px_rgba(255,87,178,0.3)]'
                    : 'border-zinc-700 bg-zinc-900/80 text-zinc-300 hover:border-[#FF57B2]/50 hover:text-white'
                }`}
                title={
                  isUserSubscribed
                    ? `Assinatura Ativa: ${userProfile?.subscription?.planName || 'Assinante'}`
                    : 'Planos de Assinatura KARDEL'
                }
                aria-label="Assinaturas"
              >
                <Crown className="h-5 w-5 text-[#FF57B2]" />
                {isUserSubscribed && (
                  <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-[#FF57B2] ring-1 ring-zinc-900" />
                )}
              </button>
            )}

            {/* User Profile colocado no lado direito imediato da assinatura */}
            {currentUser ? (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setUserDropdown(!userDropdown)}
                  className="flex items-center gap-1.5 rounded-xl p-0.5 hover:ring-2 hover:ring-[#FF57B2]/60 transition cursor-pointer"
                  title="Meu Perfil e Configurações"
                  aria-label="Perfil do Usuário"
                >
                  <UserAvatar
                    userId={currentUser.uid}
                    userName={userProfile?.displayName}
                    photoURL={userProfile?.photoURL}
                    sizeClass="h-9 w-9"
                    className="border border-zinc-700"
                  />
                </button>

                {/* Dropdown Menu de Usuário */}
                {userDropdown && (
                  <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-[#202020] p-2 shadow-2xl border border-zinc-800 text-xs text-white z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="border-b border-zinc-800 p-2.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <p className="font-bold text-white truncate">
                          {userProfile?.displayName}
                        </p>
                        <UserBadges userId={currentUser.uid} size="xs" />
                      </div>
                      <p className="text-zinc-400 truncate text-[11px]">{userProfile?.email}</p>
                      <div className="mt-1.5 flex items-center gap-1.5">
                        <span className="rounded-md bg-zinc-800 px-1.5 py-0.5 text-[10px] font-semibold text-zinc-300 uppercase">
                          {isSubscriptionActive(userProfile, 'leitor') ? `Nível ${userProfile?.level || 1}` : 'Nível 0'}
                        </span>
                        {userProfile?.hasExperiencedReaderBadge && (
                          <span className="rounded-md bg-zinc-800 border border-[#FF57B2]/40 text-[#FF57B2] px-1.5 py-0.5 text-[10px] font-semibold">
                            ★ Leitor Experiente
                          </span>
                        )}
                        {userProfile?.isVerifiedWriter && (
                          <span className="rounded-md bg-[#FF57B2]/20 border border-[#FF57B2]/40 text-[#FF57B2] px-1.5 py-0.5 text-[10px] font-semibold">
                            ✓ Escritor Verificado
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleNav('profile')}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
                    >
                      <UserIcon className="h-4 w-4 text-[#FF57B2]" />
                      <span>Meu Perfil</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleNav('library')}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
                    >
                      <BookMarked className="h-4 w-4 text-zinc-400" />
                      <span>Minha Biblioteca</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleNav('subscriptions')}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-[#FF57B2] hover:bg-[#FF57B2]/15 font-bold transition cursor-pointer"
                    >
                      <Crown className="h-4 w-4 text-[#FF57B2]" />
                      <span>Assinaturas & Membresia</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleNav('studio')}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-300 hover:text-white hover:bg-zinc-800 transition cursor-pointer"
                    >
                      <Feather className="h-4 w-4 text-zinc-400" />
                      <span>Estúdio do Autor</span>
                    </button>

                    {isDeveloper && (
                      <>
                        <button
                          type="button"
                          onClick={() => handleNav('developer')}
                          className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-[#FF57B2] hover:bg-[#FF57B2]/20 font-bold transition cursor-pointer"
                        >
                          <ShieldAlert className="h-4 w-4" />
                          <span>Área do Desenvolvedor</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setUserDropdown(false);
                            setBrandModalOpen(true);
                          }}
                          className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-[#FF57B2] hover:bg-[#FF57B2]/20 font-semibold transition cursor-pointer"
                        >
                          <Pencil className="h-4 w-4" />
                          <span>Personalizar Logo & Nome</span>
                        </button>
                      </>
                    )}

                    <div className="border-t border-zinc-800 mt-1 pt-1 space-y-0.5">
                      <button
                        type="button"
                        disabled={isGoogleAuthPending}
                        aria-busy={isGoogleAuthPending}
                        onClick={async (e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          if (isGoogleAuthPending) return;
                          const switchPromise = switchGoogleAccount();
                          requestAnimationFrame(() => setUserDropdown(false));
                          try {
                            await switchPromise;
                          } catch (err: any) {
                            const code = err?.code || '';
                            if (
                              code !== 'auth/popup-closed-by-user' &&
                              code !== 'auth/cancelled-popup-request' &&
                              code !== 'auth/cancelled-by-ui-manager'
                            ) {
                              onOpenAuth('login');
                            }
                          }
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-300 hover:text-white hover:bg-[#262626] transition cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
                      >
                        <RefreshCw className={`h-4 w-4 text-[#FF57B2] ${isGoogleAuthPending ? 'animate-spin' : ''}`} />
                        <span>{isGoogleAuthPending ? 'Autenticando...' : 'Trocar de Conta Google'}</span>
                      </button>
                      <button
                        type="button"
                        disabled={isGoogleAuthPending}
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          if (isGoogleAuthPending) return;
                          setUserDropdown(false);
                          onOpenAuth('login');
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-300 hover:text-white hover:bg-[#262626] transition cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
                      >
                        <Users className="h-4 w-4 text-[#FF80C5]" />
                        <span>Acessar Outra Conta</span>
                      </button>
                      <button
                        type="button"
                        disabled={isGoogleAuthPending}
                        onClick={async (e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          if (isGoogleAuthPending) return;
                          setUserDropdown(false);
                          await logout();
                        }}
                        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-zinc-300 hover:text-[#FF57B2] hover:bg-[#262626] transition cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
                      >
                        <LogOut className="h-4 w-4 text-[#FF80C5]" />
                        <span>Sair da Conta</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={isGoogleAuthPending}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (isGoogleAuthPending) return;
                    onOpenAuth('register');
                  }}
                  className="hidden sm:inline-flex items-center justify-center rounded-xl border border-zinc-700 bg-zinc-900/90 hover:border-[#FF57B2]/60 hover:bg-zinc-800 px-3 py-2 text-xs font-semibold text-zinc-200 hover:text-white transition cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
                >
                  Criar Conta
                </button>
                <button
                  type="button"
                  disabled={isGoogleAuthPending}
                  aria-busy={isGoogleAuthPending}
                  onClick={async (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (isGoogleAuthPending) return;
                    // Trigger Google popup synchronously at 0ms inside click gesture
                    const authPromise = loginWithGoogle();
                    try {
                      await authPromise;
                    } catch (err: any) {
                      const code = err?.code || '';
                      if (
                        code !== 'auth/popup-closed-by-user' &&
                        code !== 'auth/cancelled-popup-request' &&
                        code !== 'auth/cancelled-by-ui-manager'
                      ) {
                        onOpenAuth('login');
                      }
                    }
                  }}
                  className="inline-flex items-center gap-2 rounded-xl bg-[#FF57B2] hover:bg-[#FF40A4] px-3.5 py-2 text-xs font-bold text-white shadow-md shadow-[#FF57B2]/25 transition cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
                  title="Entrar com Google"
                >
                  <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-sm bg-white p-0.5">
                    <svg className="h-3 w-3" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                  </span>
                  <span className="sm:hidden">Entrar</span>
                  <span className="hidden sm:inline">
                    {isGoogleAuthPending ? 'Autenticando...' : 'Entrar com Google'}
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>
      )}

      {/* Menu Flutuante Centralizado e Recolhível (Com TODAS as opções do antigo menu lateral) */}
      {!hideFloatingDock && (
      <div className="fixed bottom-6 inset-x-0 z-40 flex flex-col items-center justify-end pointer-events-none">
        {/* Backdrop suave ao expandir */}
        {isMobileMenuExpanded && (
          <div
            onClick={() => setIsMobileMenuExpanded(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs z-30 pointer-events-auto transition-opacity animate-in fade-in duration-200"
          />
        )}

        {/* Menu Expandido: Contém todas as opções da plataforma de forma didática e minimalista */}
        {isMobileMenuExpanded && (
          <div className="relative z-40 mb-3 pointer-events-auto animate-in zoom-in-95 slide-in-from-bottom-4 duration-200 max-w-[96vw] sm:max-w-xl">
            <div className="rounded-3xl bg-[#1C1C1C]/95 p-3 border border-zinc-750 shadow-[0_16px_40px_rgba(0,0,0,0.9)] backdrop-blur-xl">
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-h-[60vh] overflow-y-auto no-scrollbar p-1">
                {floatingDockLinks.map((item) => {
                  const Icon = item.icon;
                  const active = activeCurrentTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleNav(item.id)}
                      className={`flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl transition cursor-pointer ${
                        active
                          ? 'bg-[#FF57B2] text-white font-bold shadow-md shadow-[#FF57B2]/30 scale-102'
                          : item.highlight
                          ? 'bg-[#FF57B2]/10 text-[#FF57B2] border border-[#FF57B2]/30 hover:bg-[#FF57B2]/20'
                          : 'text-zinc-300 hover:text-white hover:bg-zinc-800/80 border border-zinc-800/60'
                      }`}
                      title={item.label}
                    >
                      <Icon className="h-5 w-5 shrink-0" />
                      <span className="text-[10px] mt-1 font-semibold truncate max-w-full px-1">
                        {item.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Botão Centralizado Único (Recolhível com animação de expansão) */}
        <button
          type="button"
          onClick={() => setIsMobileMenuExpanded((prev) => !prev)}
          className="relative z-40 pointer-events-auto flex items-center justify-center rounded-2xl p-0.5 transition-all duration-200 active:scale-90 hover:scale-105 cursor-pointer shadow-[0_8px_28px_rgba(255,87,178,0.5)] group"
          title={isMobileMenuExpanded ? 'Recolher Menu' : 'Abrir Menu de Navegação'}
          aria-expanded={isMobileMenuExpanded}
        >
          <div className="flex h-13 w-13 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#FF57B2] to-[#E03595] text-white border-2 border-[#181818] transition-all duration-300">
            {isMobileMenuExpanded ? (
              <X className="h-6 w-6 text-white transition-transform duration-200 rotate-90" />
            ) : (
              <LayoutGrid className="h-6 w-6 text-white transition-transform duration-200 group-hover:rotate-6" />
            )}
          </div>
        </button>
      </div>
      )}

      {/* Modal de Personalização de Marca & Logo — Exclusivo do Desenvolvedor */}
      {isDeveloper && (
        <DeveloperBrandModal
          isOpen={brandModalOpen}
          onClose={() => setBrandModalOpen(false)}
        />
      )}
    </>
  );
};
