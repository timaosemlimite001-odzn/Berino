import { doc, setDoc } from 'firebase/firestore';
import { AlertTriangle, CheckCircle, X } from 'lucide-react';
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { db } from '../services/firebase';
import { SafetyReport } from '../types';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetType: 'book' | 'chapter' | 'comment' | 'post' | 'community' | 'user';
  targetId: string;
  targetSummary: string;
}

const REASONS = [
  'Conteúdo impróprio ou ofensivo',
  'Violação de direitos autorais / plágio',
  'Discurso de ódio ou assédio',
  'Spam ou publicidade enganosa',
  'Desrespeito às diretrizes da comunidade',
  'Outro motivo',
];

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  targetType,
  targetId,
  targetSummary,
}) => {
  const { currentUser, userProfile } = useAuth();
  const [selectedReason, setSelectedReason] = useState(REASONS[0]);
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setError('Você precisa estar autenticado para enviar uma denúncia.');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      const reportId = `rep_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const report: SafetyReport = {
        id: reportId,
        reporterId: currentUser.uid,
        reporterName: userProfile?.displayName || 'Usuário',
        targetType,
        targetId,
        targetSummary,
        reason: selectedReason,
        details: details.trim(),
        status: 'pending',
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'reports', reportId), report);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1800);
    } catch (err) {
      console.error('Error submitting report:', err);
      setError('Falha ao registrar denúncia. Tente novamente.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs"
      onWheel={(e) => e.stopPropagation()}
      onTouchStart={(e) => e.stopPropagation()}
    >
      <div className="w-full max-w-md rounded-3xl bg-[#222222] border border-zinc-800 p-6 shadow-2xl transition-all text-white">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2 text-white font-bold">
            <AlertTriangle className="h-5 w-5 text-[#FF57B2]" />
            <span>Denunciar Conteúdo</span>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {success ? (
          <div className="py-8 text-center">
            <CheckCircle className="mx-auto h-12 w-12 text-[#FF57B2] mb-3" />
            <h4 className="text-lg font-bold text-white">Denúncia enviada</h4>
            <p className="text-sm text-zinc-400 mt-1">
              Nossa equipe de gestão analisará a situação com base nas diretrizes do KORDEL.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            <div className="rounded-xl bg-[#2B2B2B] p-3 text-xs text-zinc-300 border border-zinc-700/70">
              <span className="font-bold text-white">Alvo: </span>
              {targetSummary}
            </div>

            {error && (
              <div className="rounded-xl bg-[#2B2B2B] border border-[#FF57B2]/45 p-3 text-xs text-[#FF80C5] font-medium">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Motivo da denúncia
              </label>
              <select
                value={selectedReason}
                onChange={(e) => setSelectedReason(e.target.value)}
                className="w-full rounded-xl border border-zinc-700 bg-[#2B2B2B] px-3 py-2.5 text-sm text-white [color-scheme:dark] focus:border-[#FF57B2] focus:outline-none"
              >
                {REASONS.map((r) => (
                  <option key={r} value={r} className="bg-[#222222] text-white">
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Detalhes adicionais (opcional)
              </label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                rows={3}
                placeholder="Explique o contexto para ajudar na apuração..."
                className="w-full rounded-xl border border-zinc-700 bg-[#2B2B2B] p-3 text-sm text-white placeholder-zinc-500 focus:border-[#FF57B2] focus:outline-none"
                maxLength={1000}
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl px-4 py-2 text-sm font-medium text-zinc-400 hover:bg-zinc-800 hover:text-white transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="rounded-xl bg-[#FF57B2] px-5 py-2 text-sm font-bold text-white hover:bg-[#FF40A4] transition disabled:opacity-50 cursor-pointer"
              >
                {submitting ? 'Enviando...' : 'Confirmar Denúncia'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
