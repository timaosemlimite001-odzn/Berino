export type UserRole = 'leitor' | 'escritor' | 'desenvolvedor';

export type SubscriptionPlanId =
  | 'leitor'
  | 'escritor'
  | 'kardel_pro'
  | 'kardel_verificado'
  | 'kardel_escritor';
export type SubscriptionStatus = 'active' | 'canceled' | 'expired' | 'suspended';

export interface UserSubscription {
  planId: SubscriptionPlanId;
  planName: string;
  price: number; // 4.90 (Leitor) or 13.49 (Escritor)
  status: SubscriptionStatus;
  startedAt: string;
  currentPeriodEnd: string; // ISO date timestamp
  autoRenew: boolean;
  canceledAt?: string;
  suspendedReason?: string;
  paymentMethod?: string;
  boostsUsedThisCycle?: number;
  lastBoostCycle?: string;
  receiptId?: string;
  receiptType?: string;
  bankName?: string;
  validatedAt?: string;
  communitiesCreatedThisCycle?: number;
  createdCommunityId?: string;
  createdCommunityAt?: string;
}

export interface BookBoostRecord {
  id: string;
  bookId: string;
  bookTitle: string;
  bookCoverUrl?: string;
  authorId: string;
  authorName: string;
  activatedAt: string; // ISO date timestamp
  expiresAt: string; // ISO date timestamp (7 days after activation)
  status: 'active' | 'expired';
  cycleMonth: string; // e.g. "2026-10"
}

export interface WriterBoostQuota {
  totalAllowed: number; // 2
  usedCount: number;
  availableCount: number;
  activeBoosts: BookBoostRecord[];
}

export interface UserProfile {
  id: string;
  uniqueId?: string; // Permanent unique user identifier (e.g. KRD-10492)
  username?: string; // Searchable username handle
  email: string;
  displayName: string;
  photoURL?: string;
  bio?: string;
  role: UserRole;
  kards: number;
  xp: number;
  level: number;
  progressionCycle: number;
  titles: string[];
  activeTitle?: string;
  equippedTitles?: string[];
  achievements: string[];
  hasExperiencedReaderBadge: boolean;
  isVerifiedWriter: boolean;
  isVerifiedWriterSuspended?: boolean;
  hasKardelProBadge?: boolean;
  showProBorder?: boolean;
  subscription?: UserSubscription;
  isBanned: boolean;
  banReason?: string;
  totalLikesReceived?: number;
  totalDislikesReceived?: number;
  booksReadCount?: number;
  reportsCount?: number;
  followersCount?: number;
  followingCount?: number;
  lastActiveAt?: string;
  lastLoginAt?: string;
  createdAt: string;
  updatedAt: string;
}

export type BookStatus = 'draft' | 'published' | 'completed' | 'archived';
export type PublishStatus = 'draft' | 'published' | 'completed' | 'archived';
export type ContentRating = 'Livre' | '12+' | '14+' | '16+' | '18+';

export interface Book {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  title: string;
  synopsis: string;
  coverUrl?: string;
  genres: string[];
  classification: ContentRating;
  status: BookStatus;
  isBoosted?: boolean;
  boostedAt?: string;
  boostExpiresAt?: string;
  isBeta?: boolean;
  betaSpots?: number;
  betaAcceptedCount?: number;
  betaDeadline?: string;
  readersCount: number;
  viewsCount: number;
  likesCount: number;
  ratingSum: number;
  ratingCount: number;
  chaptersCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Chapter {
  id: string;
  bookId: string;
  authorId?: string;
  chapterNumber: number;
  title: string;
  content: string;
  status?: PublishStatus;
  isDraft?: boolean;
  wordsCount?: number;
  commentsCount?: number;
  isEarlyAccess?: boolean;
  createdAt: string;
  updatedAt: string;
}

export type LibraryStatus = 'reading' | 'completed' | 'saved' | 'favorite';

export interface LibraryItem {
  id: string;
  userId: string;
  bookId: string;
  bookTitle: string;
  bookCover?: string;
  authorName: string;
  status: LibraryStatus;
  currentChapterNumber: number;
  progressPercent: number;
  lastReadAt: string;
  openedAt?: number;
}

export interface BookReview {
  id: string;
  bookId: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  rating: number; // 1-5
  comment: string;
  createdAt: string;
}

export interface ChapterComment {
  id: string;
  bookId: string;
  chapterId: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  content: string;
  parentId?: string;
  replyToAuthorName?: string;
  replyToUserId?: string;
  likesCount: number;
  likedUserIds?: string[];
  editedAt?: string;
  createdAt: string;
}

export interface Community {
  id: string;
  name: string;
  description: string;
  creatorId: string;
  creatorName: string;
  category: string;
  coverUrl?: string;
  bannerUrl?: string;
  iconUrl?: string;
  avatarUrl?: string;
  rules?: string;
  membersCount: number;
  postsCount?: number;
  userPostsCount?: number;
  postCostKards?: number;
  costInKardsToPost?: number;
  isPrivate?: boolean; // Comunidade privada (requer aprovação para entrar e fecha conteúdo)
  isHiddenFromNonMembers?: boolean; // Comunidade oculta nas listagens/buscas para quem não faz parte
  hidePostsFromNonMembers?: boolean; // Oculta todas as publicações desta comunidade para não-membros
  partialModeratorIds?: string[]; // IDs dos usuários com cargo de moderador parcial (podem publicar)
  silencedUserIds?: string[]; // Silenced members (cannot post or comment)
  silencedUntilMap?: Record<string, string>; // userId -> ISO date until which the user is silenced
  bannedUserIds?: string[]; // Banned members from this community
  featuredOnHome?: boolean;
  activityLevel?: 'intense' | 'high' | 'moderate' | 'growing';
  createdAt: string;
  updatedAt?: string;
}

export interface CommunityMember {
  id: string;
  communityId: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  role: 'member' | 'moderator' | 'partial_moderator' | 'creator';
  status?: 'active' | 'pending' | 'silenced' | 'banned';
  silencedUntil?: string; // ISO date timestamp
  banReason?: string;
  joinedAt: string;
}

export interface PollOption {
  id: string;
  text: string;
  votesCount: number;
  voterIds?: string[];
}

export interface CommunityPoll {
  question: string;
  options: PollOption[];
  totalVotes: number;
  voterIds?: string[];
}

export type PostImageFormat = 'default' | 'instagram' | 'story';

export type StoryFontStyle = 'sans' | 'literary' | 'display' | 'mono';
export type StoryTextAlign = 'left' | 'center' | 'right';

export interface FluxStoryTextLayer {
  id: string;
  text: string;
  x: number; // 0..100 percentage of canvas width
  y: number; // 0..100 percentage of canvas height
  fontStyle: StoryFontStyle;
  fontSizePt: number; // e.g. 12, 14, 16, 20, 24, 28
  color: string;
  underline?: boolean;
  italic?: boolean;
  uppercase?: boolean;
  strikethrough?: boolean;
  align: StoryTextAlign;
  hasBackdrop?: boolean;
}

export interface FluxStoryCanvas {
  backgroundColor?: string;
  texts: FluxStoryTextLayer[];
}

export interface FluxAudioTrack {
  url: string;
  title: string;
  sourceType?: 'upload' | 'recording' | 'library';
  durationSec?: number;
  startSec?: number;
  endSec?: number;
  volume?: number; // 0..1
}

export interface CommunityPost {
  id: string;
  communityId: string;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  authorTitle?: string;
  title?: string;
  content: string;
  type?: 'text' | 'image' | 'video' | 'media' | 'poll';
  imageFormat?: PostImageFormat;
  storyCanvas?: FluxStoryCanvas;
  audioTrack?: FluxAudioTrack;
  isPrivate?: boolean; // Post privado (restrito a membros autorizados da comunidade)
  isHiddenFromNonMembers?: boolean; // Post oculto para quem não faz parte da comunidade
  mediaUrl?: string;
  imageUrl?: string;
  mediaUrls?: string[];
  mediaTypes?: ('image' | 'video')[];
  poll?: CommunityPoll;
  likesCount: number;
  likedUserIds?: string[];
  dislikesCount?: number;
  dislikedUserIds?: string[];
  blockedUserIds?: string[];
  commentsCount: number;
  kardsSpent?: number;
  editedAt?: string;
  createdAt: string;
}

export interface FluxFeedItem extends CommunityPost {
  postSource: 'community' | 'flux';
  communityName?: string;
  communityCoverUrl?: string;
  communityCreatorId?: string;
  communityBannedUserIds?: string[];
  communityIsPrivate?: boolean;
  communityIsHidden?: boolean;
  communityHidePosts?: boolean;
}

export interface FavoritePostRecord {
  id: string;
  userId: string;
  postId: string;
  communityId: string;
  postSource: 'community' | 'flux';
  savedAt: string;
  authorId?: string;
  authorName?: string;
  authorPhoto?: string;
  communityName?: string;
  contentPreview?: string;
  mediaUrl?: string;
  createdAt?: string;
}

export interface SavedPostResolvedItem {
  favId: string;
  savedAt: string;
  post: FluxFeedItem;
}

export interface PostComment {
  id: string;
  postId: string;
  communityId?: string;
  authorId?: string;
  authorName?: string;
  authorPhoto?: string;
  userId?: string;
  userName?: string;
  userPhoto?: string;
  content: string;
  mentions?: string[];
  parentId?: string;
  replyToAuthorName?: string;
  likesCount?: number;
  likedUserIds?: string[];
  dislikesCount?: number;
  dislikedUserIds?: string[];
  editedAt?: string;
  createdAt: string;
}

export type CommunityComment = PostComment;

export type TransactionType =
  | 'purchase'
  | 'kard_purchase'
  | 'pix_purchase'
  | 'book_publish'
  | 'community_create'
  | 'community_post'
  | 'reward'
  | 'admin_grant'
  | 'admin_deduct';

export type PixOrderStatus = 'pending' | 'under_review' | 'paid' | 'completed' | 'expired' | 'rejected';

export interface PixOrder {
  id: string;
  txId: string;
  userId: string;
  userEmail?: string;
  packageId?: string;
  kards: number;
  amountBrl: number;
  title: string;
  status: PixOrderStatus;
  pixKey: string;
  merchantName: string;
  brCode: string;
  createdAt: string;
  expiresAt: string;
  paidAt?: string;
  receiptCode?: string;
  receiptSentAt?: string;
  verifiedAt?: string;
  verifiedBy?: string;
  orderType?: 'kards' | 'subscription';
  subscriptionPlanId?: 'leitor' | 'escritor';
  bankName?: string;
}

export interface PixTransactionData {
  txId: string;
  brCode: string;
  qrCodeDataUrl: string;
  amountBrl: number;
  kards: number;
  title: string;
  userId: string;
  expiresAt: string;
  status: PixOrderStatus;
  pixKey?: string;
  merchantName?: string;
  receiptCode?: string;
}

export interface KardTransaction {
  id: string;
  userId: string;
  amount: number;
  type: TransactionType;
  description: string;
  referenceId?: string;
  paymentMethod?: string;
  status: 'completed' | 'pending' | 'failed';
  createdAt: string;
}

export interface KardPackage {
  id: string;
  kards: number;
  priceBrl: number;
  title: string;
  popular?: boolean;
  bonus?: number;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  targetType: 'read_chapters' | 'review_book' | 'community_post' | 'comment';
  targetCount: number;
  xpReward: number;
  kardReward: number;
  period: 'daily' | 'weekly';
}

export interface UserMissionProgress {
  missionId: string;
  currentCount: number;
  completed: boolean;
  completedAt?: string;
  rewardClaimed: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: 'reading' | 'writing' | 'community' | 'progression';
  icon: string;
  xpReward: number;
  titleReward?: string;
  isWriterExclusive?: boolean;
}

export type NotificationType =
  | 'comment'
  | 'reply'
  | 'mention'
  | 'follower'
  | 'like'
  | 'achievement'
  | 'level_up'
  | 'new_title'
  | 'kards_received'
  | 'kards_spent'
  | 'kards_purchase'
  | 'benefit'
  | 'new_chapter'
  | 'beta_event'
  | 'community_join'
  | 'system';

export interface NotificationItem {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  linkUrl?: string;
  read: boolean;
  createdAt: string;
}

export type BetaApplicationStatus = 'applied' | 'approved' | 'rejected' | 'feedback_submitted';

export interface BetaApplication {
  id: string;
  bookId: string;
  bookTitle: string;
  authorId: string;
  readerId: string;
  readerName: string;
  readerEmail: string;
  readerLevel: number;
  hasExperiencedBadge: boolean;
  motivation: string;
  status: BetaApplicationStatus;
  feedback?: string;
  feedbackRating?: number;
  createdAt: string;
  updatedAt: string;
}

export interface SafetyReport {
  id: string;
  reporterId: string;
  reporterName: string;
  targetType: 'book' | 'chapter' | 'comment' | 'post' | 'community' | 'user';
  targetId: string;
  targetSummary: string;
  reason: string;
  details: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
  resolvedBy?: string;
  resolvedAt?: string;
  actionTaken?: string;
}

export interface AuditLogItem {
  id: string;
  adminId: string;
  adminEmail: string;
  action: string;
  targetUserId?: string;
  details: string;
  createdAt: string;
}
