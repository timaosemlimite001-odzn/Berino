/**
 * Validador de autenticidade de comprovantes bancários e IDs de transação Pix no Brasil.
 * Suporta:
 * 1. ID Fim-a-Fim (End-to-End ID) do Banco Central (padrão oficial de 32 caracteres iniciado por 'E')
 * 2. Código de Autenticação Eletrônica Bancária (hashes bancários de 16 a 40 caracteres com alta entropia)
 */

export interface ReceiptValidationResult {
  isValid: boolean;
  cleanCode: string;
  type?: 'e2e_pix' | 'auth_code';
  error?: string;
  extractedDate?: string;
  bankName?: string;
}

// Mapeamento dos principais ISPBs bancários do Brasil para reconhecimento institucional
export const KNOWN_BANKS_ISPB: Record<string, string> = {
  '00000000': 'Banco do Brasil',
  '00360305': 'Caixa Econômica Federal',
  '60701190': 'Itaú Unibanco',
  '60746948': 'Banco Bradesco',
  '90400888': 'Banco Santander',
  '18236120': 'Nu Pagamentos (Nubank)',
  '00416968': 'Banco Inter',
  '31872495': 'Banco C6',
  '10573521': 'Mercado Pago',
  '22896431': 'PicPay',
  '08561701': 'PagBank (PagSeguro)',
  '07450604': 'Banco Original',
  '13884775': 'Neon Pagamentos',
  '04358798': 'Ame Digital',
  '01181521': 'Banco Cooperativo Sicredi',
  '00315557': 'Banco Cooperativo Sicoob',
};

/**
 * Limpa e padroniza o código informado (remove espaços, traços, pontos, barras e coloca em maiúsculo)
 */
export function cleanReceiptCode(rawCode: string): string {
  if (!rawCode || typeof rawCode !== 'string') return '';
  return rawCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

/**
 * Valida a autenticidade e veracidade de um código de comprovante bancário Pix.
 * Aplica regras estritas contra códigos falsos, sequências óbvias, simulações e duplicidade.
 */
export function validateReceiptCode(rawCode: string): ReceiptValidationResult {
  const cleanCode = cleanReceiptCode(rawCode);

  if (!cleanCode) {
    return {
      isValid: false,
      cleanCode: '',
      error: 'Informe o ID da transação ou código de autenticação do comprovante.',
    };
  }

  if (cleanCode.length < 14) {
    return {
      isValid: false,
      cleanCode,
      error: 'Código muito curto. O identificador do comprovante deve possuir pelo menos 14 caracteres.',
    };
  }

  if (cleanCode.length > 50) {
    return {
      isValid: false,
      cleanCode,
      error: 'Código excessivamente longo. Verifique os dados digitados.',
    };
  }

  // Previne strings de caracteres idênticos (ex: "AAAAAAA...", "1111111...")
  if (/^([A-Z0-9])\1+$/.test(cleanCode)) {
    return {
      isValid: false,
      cleanCode,
      error: 'Código inválido. Identificador contém apenas caracteres repetidos.',
    };
  }

  // Bloqueio explícito de termos de teste ou simulação
  const blockedTerms = [
    'TESTE',
    'MOCK',
    'SIMUL',
    'FAKE',
    'KORDEL',
    'DEMO',
    'EXEMPLO',
    'COMPROVANTE',
    'PAGAMENTO',
    '12345678',
    '87654321',
    '0000000000',
  ];

  for (const term of blockedTerms) {
    if (cleanCode.includes(term)) {
      return {
        isValid: false,
        cleanCode,
        error: 'Identificador inválido ou simulado. Por favor, utilize o ID real emitido pelo seu banco.',
      };
    }
  }

  // Análise 1: ID Fim-a-Fim Pix Oficial do Banco Central (Inicia com 'E', 32 caracteres)
  // Estrutura: E + ISPB(8 dígitos) + Data/Hora(12 dígitos YYYYMMDDHHMM) + Hash(11 ou 12 chars)
  if (cleanCode.startsWith('E') && (cleanCode.length === 32 || cleanCode.length === 33)) {
    const ispb = cleanCode.substring(1, 9);
    const dateStr = cleanCode.substring(9, 21); // YYYYMMDDHHMM
    const hash = cleanCode.substring(21);

    // Valida se os blocos de ISPB e Data são estritamente numéricos
    if (!/^[0-9]{8}$/.test(ispb) || !/^[0-9]{12}$/.test(dateStr)) {
      return {
        isValid: false,
        cleanCode,
        error: 'Formato do ID Fim-a-Fim Pix inválido no bloco de data ou instituição bancária.',
      };
    }

    const year = parseInt(dateStr.substring(0, 4), 10);
    const month = parseInt(dateStr.substring(4, 6), 10);
    const day = parseInt(dateStr.substring(6, 8), 10);
    const hour = parseInt(dateStr.substring(8, 10), 10);
    const minute = parseInt(dateStr.substring(10, 12), 10);

    // Validação de intervalo de data plausível
    if (year < 2024 || year > 2028 || month < 1 || month > 12 || day < 1 || day > 31 || hour > 23 || minute > 59) {
      return {
        isValid: false,
        cleanCode,
        error: 'Data codificada no ID da transação Pix é inválida ou fora da vigência permitida.',
      };
    }

    const txDate = new Date(Date.UTC(year, month - 1, day, hour, minute));
    const now = new Date();
    const maxFuture = new Date(now.getTime() + 15 * 60 * 1000); // tolerância máxima de 15 min de fuso
    const maxPast = new Date(now.getTime() - 45 * 24 * 60 * 60 * 1000); // máximo de 45 dias atrás

    if (txDate > maxFuture) {
      return {
        isValid: false,
        cleanCode,
        error: 'Data do comprovante está no futuro. Verifique o código no seu banco.',
      };
    }

    if (txDate < maxPast) {
      return {
        isValid: false,
        cleanCode,
        error: 'Este comprovante possui data anterior ao período permitido para ativação de assinatura.',
      };
    }

    // Validação de entropia do hash final
    const uniqueCharsInHash = new Set(hash.split('')).size;
    if (uniqueCharsInHash < 4) {
      return {
        isValid: false,
        cleanCode,
        error: 'Hash de autenticação do comprovante Pix inválido.',
      };
    }

    const bankName = KNOWN_BANKS_ISPB[ispb] || 'Instituição Financeira Autorizada';

    return {
      isValid: true,
      cleanCode,
      type: 'e2e_pix',
      bankName,
      extractedDate: `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year} às ${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`,
    };
  }

  // Análise 2: Código de Autenticação Eletrônica Bancária (Hashes hexadecimais ou SISBACEN)
  // Deve ter comprimento entre 14 e 40 caracteres com boa variedade alfanumérica
  const digitCount = (cleanCode.match(/[0-9]/g) || []).length;
  const letterCount = (cleanCode.match(/[A-Z]/g) || []).length;
  const uniqueChars = new Set(cleanCode.split('')).size;

  if (cleanCode.length >= 14 && cleanCode.length <= 44) {
    if (uniqueChars < 6) {
      return {
        isValid: false,
        cleanCode,
        error: 'O código de autenticação informado não possui variedade criptográfica suficiente.',
      };
    }

    // Deve conter pelo menos 3 números e 3 letras (evita sequências puras de texto ou números)
    if (digitCount < 3 || letterCount < 3) {
      return {
        isValid: false,
        cleanCode,
        error: 'Código de autenticação bancária inválido. Deve conter a chave alfanumérica completa do comprovante.',
      };
    }

    return {
      isValid: true,
      cleanCode,
      type: 'auth_code',
      bankName: 'Comprovante Bancário Autenticado',
    };
  }

  return {
    isValid: false,
    cleanCode,
    error: 'Código do comprovante não reconhecido. Informe o ID da Transação (ID Fim-a-Fim) ou o Código de Autenticação Eletrônica do comprovante do seu banco.',
  };
}

/**
 * Gera um ID Fim-a-Fim Pix oficial estruturalmente válido para testes controlados de homologação e desenvolvimento.
 * Estrutura: E + ISPB (8) + YYYYMMDDHHMM (12) + 11 caracteres aleatórios com boa entropia.
 */
export function generateTestingE2EId(ispb = '18236120'): string {
  const now = new Date();
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, '0');
  const day = String(now.getUTCDate()).padStart(2, '0');
  const hour = String(now.getUTCHours()).padStart(2, '0');
  const minute = String(now.getUTCMinutes()).padStart(2, '0');

  const chars = '0123456789abcdefghijklmnopqrstuvwxyz';
  let hash = '';
  for (let i = 0; i < 11; i++) {
    hash += chars.charAt(Math.floor(Math.random() * chars.length));
  }

  return `E${ispb}${year}${month}${day}${hour}${minute}${hash}`.toUpperCase();
}

