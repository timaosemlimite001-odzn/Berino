/**
 * Utilitário para geração de códigos EMV / BR Code no padrão oficial Pix do Banco Central do Brasil.
 * Permite criar a string "Pix Copia e Cola" com chave, valor, beneficiário e TXID.
 */

export interface PixPayloadOptions {
  pixKey: string;
  merchantName: string;
  merchantCity: string;
  amount: number;
  txId: string;
  description?: string;
}

// Formata campo no padrão TLV (Tag - Length - Value)
function formatTLV(id: string, value: string): string {
  const len = value.length.toString().padStart(2, '0');
  return `${id}${len}${value}`;
}

// Cálculo oficial do CRC16-CCITT (Polinômio 0x1021, valor inicial 0xFFFF)
export function calculateCRC16(payload: string): string {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) {
        crc = ((crc << 1) ^ 0x1021) & 0xffff;
      } else {
        crc = (crc << 1) & 0xffff;
      }
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

/**
 * Normaliza strings para caracteres ASCII permitidos no padrão EMV do Pix
 */
function normalizeAscii(str: string, maxLength: number): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove acentos
    .replace(/[^a-zA-Z0-9 ]/g, '') // remove caracteres especiais
    .trim()
    .slice(0, maxLength);
}

/**
 * Gera a string "Pix Copia e Cola" pronta para leitura em qualquer aplicativo bancário
 */
export function generatePixBrCode({
  pixKey,
  merchantName,
  merchantCity,
  amount,
  txId,
  description,
}: PixPayloadOptions): string {
  const cleanName = normalizeAscii(merchantName || 'KORDEL PLATAFORMA', 25);
  const cleanCity = normalizeAscii(merchantCity || 'BRASILIA', 15);
  const cleanTxId = normalizeAscii(txId || 'KORDEL', 25).replace(/\s+/g, '');
  const formattedAmount = amount.toFixed(2);

  // 00 - Payload Format Indicator (versão fixa '01')
  let payload = formatTLV('00', '01');

  // 26 - Merchant Account Information (Pix)
  let maiPayload = formatTLV('00', 'br.gov.bcb.pix');
  maiPayload += formatTLV('01', pixKey.trim());
  if (description) {
    maiPayload += formatTLV('02', normalizeAscii(description, 35));
  }
  payload += formatTLV('26', maiPayload);

  // 52 - Merchant Category Code
  payload += formatTLV('52', '0000');

  // 53 - Transaction Currency (986 = Real Brasileiro)
  payload += formatTLV('53', '986');

  // 54 - Transaction Amount
  payload += formatTLV('54', formattedAmount);

  // 58 - Country Code
  payload += formatTLV('58', 'BR');

  // 59 - Merchant Name
  payload += formatTLV('59', cleanName);

  // 60 - Merchant City
  payload += formatTLV('60', cleanCity);

  // 62 - Additional Data Field Template (TXID)
  const txidTLV = formatTLV('05', cleanTxId);
  payload += formatTLV('62', txidTLV);

  // 63 - CRC16 (Tag 63, tamanho fixo '04')
  payload += '6304';
  const crc = calculateCRC16(payload);

  return `${payload}${crc}`;
}
