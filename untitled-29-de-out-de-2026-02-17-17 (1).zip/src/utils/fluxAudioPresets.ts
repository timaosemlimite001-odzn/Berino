/**
 * Procedural literary ambient & acoustic soundtrack generator for KORDEL Flux.
 * Synthesizes clean, warm 16-bit PCM WAV files locally in <20ms so users can immediately
 * attach atmospheric soundtracks during Flux post editing (in addition to uploading MP3/WAV/M4A files
 * or recording their own voice/narration).
 */

export interface FluxAudioPresetItem {
  id: string;
  title: string;
  subtitle: string;
  durationSec: number;
}

export const FLUX_AUDIO_PRESETS: FluxAudioPresetItem[] = [
  {
    id: 'dedilhado_cordel',
    title: 'Dedilhado de Cordel',
    subtitle: 'Viola acústica suave',
    durationSec: 12,
  },
  {
    id: 'noite_leitura',
    title: 'Noite de Leitura',
    subtitle: 'Piano elétrico quente',
    durationSec: 12,
  },
  {
    id: 'chuva_varanda',
    title: 'Chuva na Varanda',
    subtitle: 'Ambiência relaxante',
    durationSec: 10,
  },
  {
    id: 'cafe_literario',
    title: 'Café Literário',
    subtitle: 'Harpa & acordes lo-fi',
    durationSec: 12,
  },
  {
    id: 'misterio_noturno',
    title: 'Mistério Noturno',
    subtitle: 'Atmosfera dramática',
    durationSec: 12,
  },
];

function writeString(view: DataView, offset: number, str: string): void {
  for (let i = 0; i < str.length; i++) {
    view.setUint8(offset + i, str.charCodeAt(i));
  }
}

function encodeMonoWav(samples: Float32Array, sampleRate: number): Blob {
  const numSamples = samples.length;
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // PCM format = 1
  view.setUint16(22, 1, true); // Mono = 1 channel
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true); // Byte rate
  view.setUint16(32, 2, true); // Block align
  view.setUint16(34, 16, true); // 16-bit
  writeString(view, 36, 'data');
  view.setUint32(40, numSamples * 2, true);

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(
      offset,
      clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff,
      true
    );
    offset += 2;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

function addPluckedNote(
  out: Float32Array,
  sampleRate: number,
  startSec: number,
  durSec: number,
  freqHz: number,
  amp: number
): void {
  const startIdx = Math.floor(startSec * sampleRate);
  const totalSamples = Math.floor(durSec * sampleRate);
  const twoPiF = (2 * Math.PI * freqHz) / sampleRate;

  for (let n = 0; n < totalSamples; n++) {
    const idx = startIdx + n;
    if (idx >= out.length) break;
    const t = n / sampleRate;
    const attack = Math.min(1, t / 0.012);
    const decay = Math.exp(-t * 2.9);
    const env = attack * decay;
    const wave =
      Math.sin(twoPiF * n) * 0.68 +
      Math.sin(twoPiF * 2 * n) * 0.22 * Math.exp(-t * 4.5) +
      Math.sin(twoPiF * 3 * n) * 0.1 * Math.exp(-t * 7.0);
    out[idx] += wave * env * amp;
  }
}

function addWarmPadChord(
  out: Float32Array,
  sampleRate: number,
  startSec: number,
  durSec: number,
  freqs: number[],
  amp: number
): void {
  const startIdx = Math.floor(startSec * sampleRate);
  const totalSamples = Math.floor(durSec * sampleRate);

  for (let n = 0; n < totalSamples; n++) {
    const idx = startIdx + n;
    if (idx >= out.length) break;
    const t = n / sampleRate;
    const fadeIn = Math.min(1, t / 0.35);
    const fadeOut = Math.min(1, (durSec - t) / 0.45);
    const env = Math.max(0, fadeIn * fadeOut);
    let sum = 0;
    for (let k = 0; k < freqs.length; k++) {
      const f = freqs[k];
      sum +=
        Math.sin((2 * Math.PI * f * n) / sampleRate) * 0.75 +
        Math.sin((2 * Math.PI * (f * 2) * n) / sampleRate) * 0.15;
    }
    out[idx] += (sum / Math.max(1, freqs.length)) * env * amp;
  }
}

export function buildFluxAudioPresetFile(presetId: string): {
  file: File;
  durationSec: number;
  title: string;
} {
  const preset =
    FLUX_AUDIO_PRESETS.find((p) => p.id === presetId) || FLUX_AUDIO_PRESETS[0];
  const sampleRate = 22050;
  const durationSec = preset.durationSec;
  const samples = new Float32Array(sampleRate * durationSec);

  if (preset.id === 'dedilhado_cordel') {
    // D Mixolydian warm arpeggio (D3, F#3, A3, C4, D4, A3, F#3, A3)
    const pattern = [146.83, 185.0, 220.0, 261.63, 293.66, 220.0, 185.0, 220.0];
    const patternC = [130.81, 164.81, 196.0, 261.63, 293.66, 196.0, 164.81, 196.0];
    const step = 0.375; // 160 BPM eighth notes -> 3s per bar -> 4 bars = 12s
    for (let bar = 0; bar < 4; bar++) {
      const notes = bar % 2 === 0 ? pattern : patternC;
      for (let i = 0; i < notes.length; i++) {
        addPluckedNote(
          samples,
          sampleRate,
          bar * 3 + i * step,
          1.15,
          notes[i],
          0.34
        );
      }
    }
  } else if (preset.id === 'noite_leitura') {
    const chords = [
      [174.61, 220.0, 261.63, 329.63], // Fmaj7
      [146.83, 174.61, 220.0, 261.63], // Dm7
      [196.0, 246.94, 293.66, 349.23], // G7
      [130.81, 164.81, 196.0, 246.94], // Cmaj7
    ];
    for (let c = 0; c < chords.length; c++) {
      addWarmPadChord(samples, sampleRate, c * 3, 3.1, chords[c], 0.28);
      addPluckedNote(samples, sampleRate, c * 3 + 0.05, 1.8, chords[c][3] * 2, 0.14);
      addPluckedNote(samples, sampleRate, c * 3 + 1.5, 1.5, chords[c][2] * 2, 0.12);
    }
  } else if (preset.id === 'chuva_varanda') {
    // Filtered soft rain + warm ambient drone
    let b0 = 0;
    let b1 = 0;
    let b2 = 0;
    for (let i = 0; i < samples.length; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.997 * b0 + white * 0.029;
      b1 = 0.985 * b1 + white * 0.032;
      b2 = 0.95 * b2 + white * 0.048;
      const t = i / sampleRate;
      const loopFade =
        Math.min(1, t / 0.4) * Math.min(1, (durationSec - t) / 0.4);
      samples[i] += (b0 + b1 + b2) * 0.22 * loopFade;
    }
    addWarmPadChord(samples, sampleRate, 0, 5.2, [146.83, 220.0, 261.63], 0.14);
    addWarmPadChord(samples, sampleRate, 4.8, 5.2, [130.81, 196.0, 246.94], 0.14);
  } else if (preset.id === 'cafe_literario') {
    const prog = [
      [196.0, 246.94, 293.66, 369.99], // Gmaj7
      [164.81, 196.0, 246.94, 293.66], // Em7
      [220.0, 261.63, 329.63, 392.0], // Am7
      [146.83, 220.0, 261.63, 329.63], // D9sus
    ];
    for (let bar = 0; bar < 4; bar++) {
      const ch = prog[bar];
      addWarmPadChord(samples, sampleRate, bar * 3, 3.0, ch, 0.2);
      for (let stepIdx = 0; stepIdx < 6; stepIdx++) {
        const note = ch[stepIdx % ch.length] * (stepIdx >= 4 ? 2 : 1);
        addPluckedNote(
          samples,
          sampleRate,
          bar * 3 + stepIdx * 0.5,
          0.95,
          note,
          0.2
        );
      }
    }
  } else {
    // misterio_noturno — C minor atmospheric cello/pad + sparse bells
    const darkChords = [
      [130.81, 155.56, 196.0], // Cm
      [103.83, 155.56, 207.65], // Ab
      [116.54, 146.83, 174.61], // Bb
      [98.0, 146.83, 185.0], // Gm/D
    ];
    for (let bar = 0; bar < 4; bar++) {
      addWarmPadChord(samples, sampleRate, bar * 3, 3.15, darkChords[bar], 0.3);
      addPluckedNote(
        samples,
        sampleRate,
        bar * 3 + 0.75,
        1.8,
        darkChords[bar][2] * 2,
        0.14
      );
    }
  }

  // Soft master limiter + loop crossfade polish
  for (let i = 0; i < samples.length; i++) {
    samples[i] = Math.tanh(samples[i] * 1.15) * 0.92;
  }

  const wavBlob = encodeMonoWav(samples, sampleRate);
  const file = new File([wavBlob], `${preset.id}.wav`, { type: 'audio/wav' });
  return {
    file,
    durationSec,
    title: preset.title,
  };
}
