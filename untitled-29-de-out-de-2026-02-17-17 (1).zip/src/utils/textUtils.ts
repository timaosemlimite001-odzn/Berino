/**
 * Utilitário de formatação de prévia da sinopse literária.
 * Corta o texto no limite desejado respeitando o limite de palavras e
 * finaliza obrigatoriamente a prévia com os três pontinhos literais ("...").
 */
export function getSynopsisPreview(text?: string, maxLength = 160): string {
  if (!text || !text.trim()) {
    return 'Uma narrativa envolvente em destaque nas páginas desta obra...';
  }

  // Normaliza quebras de linha e espaços múltiplos
  const normalized = text
    .replace(/\r?\n|\r/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/…/g, '...')
    .trim();

  // Se o texto já terminar com '...' e for menor ou igual ao maxLength
  if (normalized.endsWith('...') && normalized.length <= maxLength) {
    return normalized;
  }

  // Se o texto for maior que o maxLength, corta na palavra anterior
  if (normalized.length > maxLength) {
    const sliced = normalized.slice(0, maxLength);
    const lastSpace = sliced.lastIndexOf(' ');
    const cut = lastSpace > 20 ? sliced.slice(0, lastSpace) : sliced;
    const cleanCut = cut.replace(/[.,;:\s—\-«»"']+$|\.{2,}$/, '');
    return `${cleanCut}...`;
  }

  // Se o texto for menor que maxLength mas não termina com '...', adiciona os três pontinhos literais
  const cleanCut = normalized.replace(/[.,;:\s—\-«»"']+$|\.{2,}$/, '');
  return `${cleanCut}...`;
}
