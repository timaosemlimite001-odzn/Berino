import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';
import { defineConfig, Plugin } from 'vite';

const rootDir =
  typeof import.meta.dirname === 'string'
    ? import.meta.dirname
    : path.dirname(fileURLToPath(import.meta.url));

function disableClientAutoReloadPlugin(): Plugin {
  return {
    name: 'disable-vite-client-autoreload',
    enforce: 'post',
    transform(code, id) {
      if (id.includes('vite/dist/client/client.mjs')) {
        return {
          code: code
            .replace(
              'transport.connect(createHMRHandler(handleMessage));',
              '/* HMR WebSocket disabled to prevent popup/focus auto-reloads */'
            )
            .replaceAll('location.reload();', '/* auto-reload disabled */'),
          map: null,
        };
      }
      return null;
    },
  };
}

export default defineConfig({
  plugins: [react(), tailwindcss(), disableClientAutoReloadPlugin()],
  resolve: {
    alias: {
      '@': path.resolve(rootDir, '.'),
    },
  },
  server: {
    hmr: false,
    watch: null,
  },
});
