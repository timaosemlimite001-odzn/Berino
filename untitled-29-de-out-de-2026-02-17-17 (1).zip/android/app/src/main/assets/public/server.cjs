var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_vite = require("vite");
var import_stripe = __toESM(require("stripe"), 1);
import_dotenv.default.config();
var stripeClient = null;
function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return null;
  if (!stripeClient) {
    stripeClient = new import_stripe.default(key);
  }
  return stripeClient;
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      stripeConfigured: !!process.env.STRIPE_SECRET_KEY
    });
  });
  app.post("/api/create-stripe-checkout", async (req, res) => {
    try {
      const { packageId, kards, amountBrl, title, userId, userEmail } = req.body;
      if (!userId) {
        return res.status(401).json({ error: "Usu\xE1rio n\xE3o autenticado." });
      }
      if (!kards || !amountBrl) {
        return res.status(400).json({ error: "Dados do pacote inv\xE1lidos." });
      }
      const stripe = getStripe();
      if (!stripe) {
        return res.status(400).json({
          error: "A chave STRIPE_SECRET_KEY n\xE3o foi configurada nas vari\xE1veis de ambiente. Para processar pagamentos reais com o Stripe, configure a vari\xE1vel STRIPE_SECRET_KEY nas configura\xE7\xF5es."
        });
      }
      const origin = req.headers.origin || process.env.APP_URL || `http://${req.headers.host || "localhost:3000"}`;
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "brl",
              product_data: {
                name: `Pacote Kards: ${title || "KORDEL"}`,
                description: `${kards} Kards para publica\xE7\xE3o, apoio e comunidades no KORDEL`
              },
              unit_amount: Math.round(Number(amountBrl) * 100)
            },
            quantity: 1
          }
        ],
        mode: "payment",
        customer_email: userEmail || void 0,
        client_reference_id: String(userId),
        metadata: {
          userId: String(userId),
          kards: String(kards),
          packageId: String(packageId || "")
        },
        success_url: `${origin}/?stripe_success=true&session_id={CHECKOUT_SESSION_ID}&kards=${kards}&pkg=${packageId || ""}`,
        cancel_url: `${origin}/?stripe_cancel=true`
      });
      if (!session.url) {
        return res.status(500).json({ error: "Falha ao obter URL de checkout do Stripe." });
      }
      return res.json({ url: session.url, sessionId: session.id });
    } catch (err) {
      console.error("Error creating Stripe session:", err);
      return res.status(500).json({
        error: err.message || "Erro ao comunicar com a API do Stripe."
      });
    }
  });
  app.post("/api/verify-stripe-payment", async (req, res) => {
    try {
      const { sessionId } = req.body;
      if (!sessionId) {
        return res.status(400).json({ error: "sessionId \xE9 obrigat\xF3rio." });
      }
      const stripe = getStripe();
      if (!stripe) {
        return res.status(500).json({ error: "Stripe n\xE3o configurado no servidor." });
      }
      const session = await stripe.checkout.sessions.retrieve(sessionId);
      if (session.payment_status === "paid") {
        return res.json({
          paid: true,
          sessionId: session.id,
          userId: session.metadata?.userId || session.client_reference_id,
          kards: Number(session.metadata?.kards || 0),
          packageId: session.metadata?.packageId,
          amountTotal: session.amount_total,
          currency: session.currency
        });
      } else {
        return res.json({
          paid: false,
          status: session.payment_status
        });
      }
    } catch (err) {
      console.error("Error verifying Stripe session:", err);
      return res.status(500).json({
        error: err.message || "Erro ao verificar sess\xE3o do Stripe."
      });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`KORDEL Server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
