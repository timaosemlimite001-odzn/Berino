package com.kordel.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
